<?php

$w['w00001'] = "Hoş Geldiniz";
$w['w00002'] = "Hizmet Koşulları";
$w['w00003'] = "yazma izinlerini kontrol etme";
$w['w00004'] = "Yapılandırma Veritabanı";
$w['w00005'] = "Yapılandırma Web Sitesi";
$w['w00006'] = "Sistem Yöneticisi";
$w['w00007'] = "Kopyalama veri";
$w['w00008'] = "Kurulum tamamlandı";

$w['w00009'] = "Yükleyici Hoşgeldiniz doorGets CMS V4.0";
$w['w00010'] = "Hizmet Lisanslama Koşulları";
$w['w00011'] = "yazma izinlerini kontrol etme";
$w['w00012'] = "Veritabanına bağlantı ayarla";
$w['w00013'] = "Web siteniz ayarlama";
$w['w00014'] = "Yönetici olarak ayarla";
$w['w00015'] = "web alanınıza Kopyalama veri";
$w['w00016'] = "Instalation Bravo, tamamlandı";

$w['w00017'] = "Geri";
$w['w00018'] = "Sonraki";

$w['w00019'] = "Dilinizi seçin";
$w['w00020'] = "Bu kullanım koşullarını kabul ediyorum";

$w['w00021'] = "Testi yazılabilir";
$w['w00022'] = "Sizin dizini yazılabilir.";
$w['w00023'] = "Sizin dizin yazma izinlerine sahip değil ...";

$w['w00024'] = "Veritabanı Bağlan";
$w['w00025'] = "Sunucu";
$w['w00026'] = "Veritabanı Adı";
$w['w00027'] = "Giriş";
$w['w00028'] = "Şifre";
$w['w00029'] = "Önek";
$w['w00030'] = "Test Connection";

$w['w00031'] = "bağlantının bulmuyor kurulamadığı";
$w['w00032'] = "Sizin bağlantısı kurulmuştur";

$w['w00033'] = "Web Sitesi";
$w['w00034'] = "Başlık";
$w['w00035'] = "Slogan";
$w['w00036'] = "Açıklama";
$w['w00037'] = "Telif hakkı";
$w['w00038'] = "yaratılış Yıl";
$w['w00039'] = "Anahtar Kelimeler";
$w['w00040'] = "Konum";
$w['w00041'] = "Ülke";
$w['w00042'] = "Şehir";
$w['w00043'] = "Posta Kodu";
$w['w00044'] = "Adres";
$w['w00045'] = "Sabit Telefon";
$w['w00046'] = "Cep Telefonu";
$w['w00047'] = "Telefon Faks";
$w['w00048'] = "Sosyal Ağ";
$w['w00049'] = "İstatistik";
$w['w00050'] = "Google Analytics kodu";
$w['w00051'] = "Google Analytics, Google tarafından sunulan bir analitik hizmeti ücretsiz web siteleri olduğunu";
$w['w00052'] = "Ücretsiz hesap oluştur";
$w['w00053'] = "Lütfen aministration için tanımlayıcıları Sistemi";
$w['w00054'] = "E-posta Adresi";
$w['w00055'] = "Giriş";
$w['w00056'] = "Şifre";

$w['w00057'] = "Lütfen FCM'ler Öğretici doorGets Generate";
$w['w00058'] = "Şimdi benim web Generate";

$w['w00059'] = "düzenlendi ve Verdiği";
$w['w00060'] = "Tüm hakları saklıdır";

$w['w00061'] = "Web siteniz için bir renk seçin";