<?php

header("Location:../");
exit();