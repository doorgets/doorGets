<?php

/**
 *
    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

$w[0] = "8 caractères minimum";
$w[1] = "a voir aussi";
$w[2] = "accepter";
$w[3] = "accueil";
$w[4] = "activer ce module";
$w[5] = "activer ce portefolio";
$w[6] = "activer ce tutoriel";
$w[7] = "activer cette article";
$w[8] = "activer";
$w[9] = "actualité";
$w[10] = "actualités";
$w[11] = "addresse email";
$w[12] = "addresse";
$w[13] = "adresse e-mail déja dans vos contacts.";
$w[14] = "adresse e-mail importé.";
$w[15] = "adresse email";
$w[16] = "adresse";
$w[17] = "adresses emails importés.";
$w[18] = "adresses mails déja dans vos contacts.";
$w[19] = "afficher toute les rubriques";
$w[20] = "afficher";
$w[21] = "ajouter un article";
$w[22] = "ajouter un contact";
$w[23] = "ajouter un fichier";
$w[24] = "ajouter un lien";
$w[25] = "ajouter un module";
$w[26] = "ajouter une actualité";
$w[27] = "ajouter une catégorie";
$w[28] = "ajouter une image";
$w[29] = "ajouter une question / réponse";
$w[30] = "ajouter une rubrique";
$w[31] = "ajouter une vidéo";
$w[32] = "annuler";
$w[33] = "année de création";
$w[34] = "archiver ce commentaire";
$w[35] = "archiver";
$w[36] = "article";
$w[37] = "articles";
$w[38] = "asoccié au module";
$w[39] = "attention vous n'avez déclaré aucun module comme page d'acceuil";
$w[40] = "aucun article trouvé pour votre recherche.";
$w[41] = "aucun commentaire trouvé.";
$w[42] = "aucun message trouvé.";
$w[43] = "aucune actualité trouvé pour votre recherche.";
$w[44] = "aucune adresse mail trouvé dans le fichier importer.";
$w[45] = "aucune image trouvée pour votre recherche.";
$w[46] = "aucune image trouvé pour votre recherche.";
$w[47] = "aucune vidéo trouvé pour votre recherche.";
$w[48] = "autoriser le partage";
$w[49] = "autoriser les commentaires";
$w[50] = "blog articles";
$w[51] = "blog vidéos";
$w[52] = "blog";
$w[53] = "candidat";
$w[54] = "candidats";
$w[55] = "caractères alpha numérique seulement";
$w[56] = "catégorie";
$w[57] = "catégories";
$w[58] = "cette catégorie est utilisée par un ou plusieurs articles, merci de les supprimer pour pouvoir supprimer cette catégorie.";
$w[59] = "cette rubrique est accrochée au module";
$w[60] = "champ obligatoire";
$w[61] = "chercher";
$w[62] = "choisir un theme pour votre site";
$w[63] = "code postal";
$w[64] = "code youtube";
$w[65] = "commentaire active";
$w[66] = "commentaire bloqué";
$w[67] = "commentaire en attente";
$w[68] = "commentaire";
$w[69] = "commentaires";
$w[70] = "conditions d'utilisations";
$w[71] = "conditions générale d'utilisation";
$w[72] = "configuration";
$w[73] = "connexion";
$w[74] = "contact";
$w[75] = "contacts";
$w[76] = "contenu";
$w[77] = "contenus";
$w[78] = "copyright";
$w[79] = "créer votre compte gratuitement sur :";
$w[80] = "dans";
$w[81] = "date";
$w[82] = "description courte";
$w[83] = "description";
$w[84] = "dupliquer un module";
$w[85] = "durée";
$w[86] = "désarchiver ce commentaire";
$w[87] = "ecrire un commentaire";
$w[88] = "envoyer le message";
$w[89] = "extraire";
$w[90] = "faq";
$w[91] = "fichier type";
$w[92] = "fichier";
$w[93] = "fichiers";
$w[94] = "formulaire de candidature";
$w[95] = "formulaire de contact";
$w[96] = "galerie d'images";
$w[97] = "galerie";
$w[98] = "galeries";
$w[99] = "gestion";
$w[100] = "google analytics est un service d'analyse de sites web gratuit proposé par google";
$w[101] = "google analytics";
$w[102] = "groupe";
$w[103] = "générer le plan du site";
$w[104] = "générer un nouveau module";
$w[105] = "hauteur";
$w[106] = "icône";
$w[107] = "identifiant";
$w[108] = "identifiez-vous";
$w[109] = "il n'y a actuellement aucun article pour cette catégorie.";
$w[110] = "il n'y a actuellement aucun article.";
$w[111] = "il n'y a actuellement aucun contact";
$w[112] = "il n'y a actuellement aucun lien";
$w[113] = "il n'y a actuellement aucun module dans la base";
$w[114] = "il n'y a actuellement aucun module";
$w[115] = "il n'y a actuellement aucune actualité pour cette catégorie.";
$w[116] = "il n'y a actuellement aucune candidature";
$w[117] = "il n'y a actuellement aucune image dans la base";
$w[118] = "il n'y a actuellement aucune image pour cette catégorie.";
$w[119] = "il n'y a actuellement aucune image.";
$w[120] = "il n'y a actuellement aucune question / réponse";
$w[121] = "il n'y a actuellement aucune rubrique";
$w[122] = "il n'y a actuellement aucune vidéo pour cette catégorie.";
$w[123] = "il n'y a actuellement aucune vidéo.";
$w[124] = "image";
$w[125] = "images";
$w[126] = "importer des contacts depuis un fichier";
$w[127] = "importer des fichiers";
$w[128] = "inscription à la newsletter";
$w[129] = "intitulé";
$w[130] = "langue active du frontoffice";
$w[131] = "langue du backoffice";
$w[132] = "langue du frontoffice principal";
$w[133] = "langue";
$w[134] = "largeur";
$w[135] = "le fichier a bien été télécharger.";
$w[136] = "le module n'est associé a aucun module";
$w[137] = "le";
$w[138] = "lien externe";
$w[139] = "lien";
$w[140] = "liens";
$w[141] = "lire l'article";
$w[142] = "lire la suite";
$w[143] = "logo";
$w[144] = "masquer le formulaire";
$w[145] = "masquer";
$w[146] = "mentions lègales";
$w[147] = "mentions légales";
$w[148] = "message";
$w[149] = "messages";
$w[150] = "meta description";
$w[151] = "meta mots clés";
$w[152] = "meta titre";
$w[153] = "minute";
$w[154] = "models";
$w[155] = "modifier cette page";
$w[156] = "modifier mon mot de passe";
$w[157] = "modifier un contact";
$w[158] = "modifier un contenu";
$w[159] = "modifier un fichier";
$w[160] = "modifier un lien";
$w[161] = "modifier un module";
$w[162] = "modifier un tutoriel";
$w[163] = "modifier une catégorie";
$w[164] = "modifier une image";
$w[165] = "modifier une question / réponse";
$w[166] = "modifier une rubrique";
$w[167] = "modifier votre mot de passe";
$w[168] = "modifier";
$w[169] = "module active non utilisé";
$w[170] = "module active";
$w[171] = "module inactive";
$w[172] = "module";
$w[173] = "modules interne";
$w[174] = "mot de passe";
$w[175] = "mots clés";
$w[176] = "newsletter";
$w[177] = "nom / entreprise";
$w[178] = "nom du fichier";
$w[179] = "nom";
$w[180] = "née le";
$w[181] = "page d'acceuil";
$w[182] = "page d'accueil du site";
$w[183] = "page introuvable";
$w[184] = "page static";
$w[185] = "par";
$w[186] = "partenaires";
$w[187] = "pays";
$w[188] = "photos";
$w[189] = "plan du site";
$w[190] = "portefolio";
$w[191] = "propulsé avec";
$w[192] = "pseudo";
$w[193] = "publier votre commentaire";
$w[194] = "question";
$w[195] = "questions";
$w[196] = "qui c'est ?";
$w[197] = "qui c'est";
$w[198] = "qui etes vous ?";
$w[199] = "recherche";
$w[200] = "rechercher";
$w[201] = "refuser";
$w[202] = "retaper votre nouveau mot de passe";
$w[203] = "retour sur le site";
$w[204] = "retour à la liste compléte";
$w[205] = "retour à la liste des candidatures";
$w[206] = "retour";
$w[207] = "rubrique";
$w[208] = "rubriques";
$w[209] = "réponse";
$w[210] = "réseaux sociaux";
$w[211] = "s'inscrire à la newsletter";
$w[212] = "sauvegarder";
$w[213] = "se deconnecter";
$w[214] = "site web";
$w[215] = "slogan";
$w[216] = "statut";
$w[217] = "sujet";
$w[218] = "suppimer";
$w[219] = "suppression effectuée avec succès.";
$w[220] = "supprimer définitivement";
$w[221] = "supprimer la candidature";
$w[222] = "supprimer le commentaire";
$w[223] = "supprimer le contenu";
$w[224] = "supprimer un contact";
$w[225] = "supprimer un fichier";
$w[226] = "supprimer un lien";
$w[227] = "supprimer un module";
$w[228] = "supprimer une catégorie";
$w[229] = "supprimer une rubrique";
$w[230] = "supprimer";
$w[231] = "sur";
$w[232] = "taille max";
$w[233] = "telephone fax";
$w[234] = "telephone fixe";
$w[235] = "telephone mobile";
$w[236] = "telephone";
$w[237] = "titre du tutoriel";
$w[238] = "titre";
$w[239] = "tous les fichiers";
$w[240] = "tous";
$w[241] = "tutoriels";
$w[242] = "type";
$w[243] = "uri de l'article";
$w[244] = "uri de la catégorie";
$w[245] = "uri du tutoriel";
$w[246] = "uri";
$w[247] = "url";
$w[248] = "validation";
$w[249] = "valider cette candidature";
$w[250] = "veuillez importer un fichier valide.";
$w[251] = "veuillez remplir correctement le formulaire.";
$w[252] = "veuillez saisir le nom du fichier.";
$w[253] = "veuilliez remplir le fomulaire suivant afin de déposer votre candidature...";
$w[254] = "veuilliez remplir le fomulaire suivant afin de nous contacter, nous vous contacterons rapidement...";
$w[255] = "vidéo";
$w[256] = "vidéos";
$w[257] = "ville";
$w[258] = "voir";
$w[259] = "vos contacts ont été importés.";
$w[260] = "vos informations ont bien été mises à jour.";
$w[261] = "votre adresse e-mail";
$w[262] = "votre candidature à bien été prise en compte";
$w[263] = "votre code google analytics";
$w[264] = "votre commentaire est en cours de modération, merci.";
$w[265] = "votre commentaire est maintenant accepté.";
$w[266] = "votre commentaire est maintenant archiver.";
$w[267] = "votre commentaire est maintenant refusé.";
$w[268] = "votre fichier est trop lourd.";
$w[269] = "votre fichier n'est pas compatible";
$w[270] = "votre fichier";
$w[271] = "votre message ?";
$w[272] = "votre message à bien été envoyé. merci.";
$w[273] = "votre mot de passe actuel";
$w[274] = "votre nom, prénom";
$w[275] = "votre nouveau mot de passe";
$w[276] = "vous devez commencez par ajouter une catégorie";
$w[277] = "vous venez d'envoyer un commentaire, le temps d'attente pour envoyer un nouveau commentaire est de";
$w[278] = "vous êtes maintenant inscrit à la newsletter. merci.";
$w[279] = "à";
$w[280] = "choisir...";
$w[281] = "homme";
$w[282] = "femme";
$w[283] = "africain";
$w[284] = "arabe";
$w[285] = "asiatique";
$w[286] = "européen";
$w[287] = "indien";
$w[288] = "métisse";
$w[289] = "photo";
$w[290] = "ethnie";
$w[291] = "sexe";

