<?php

/**
 *
    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/


$w[0] = "pelo menos 8 caracteres";
$w[1] = "a ver também";
$w[2] = "aceitar";
$w[3] = "casa";
$w[4] = "Ativar este módulo";
$w[5] = "Habilitar este Portefólio";
$w[6] = "Habilitar este tutorial";
$w[7] = "Habilitar este item";
$w[8] = "enable";
$w[9] = "notícia";
$w[10] = "notícia";
$w[11] = "endereço de email";
$w[12] = "endereço";
$w[13] = "endereço de e-mail já em seus contatos.";
$w[14] = "Endereço de email importados.";
$w[15] = "e-mail";
$w[16] = "endereço";
$w[17] = "endereços de email importados.";
$w[18] = "endereços de email já está em seus contatos.";
$w[19] = "exibir todos os itens";
$w[20] = "show";
$w[21] = "adicionar um item";
$w[22] = "adicionar um contato";
$w[23] = "adicionar arquivo";
$w[24] = "adicionar um link";
$w[25] = "add módulo";
$w[26] = "adicionar notícias";
$w[27] = "adicionar uma classe";
$w[28] = "adicionar imagem";
$w[29] = "adicionar uma pergunta / resposta";
$w[30] = "adicionar um item";
$w[31] = "Adicionar um vídeo";
$w[32] = "cancel";
$w[33] = "ano de criação";
$w[34] = "Arquivo este comentário";
$w[35] = "arquivo";
$w[36] = "item";
$w[37] = "artigos";
$w[38] = "asoccié módulo";
$w[39] = "atenção que disse não módulo como página inicial";
$w[40] = "o artigo não encontrado para sua pesquisa.";
$w[41] = "Não foram encontrados comentários.";
$w[42] = "mensagem não foi encontrado.";
$w[43] = "Nenhuma notícia para a sua pesquisa.";
$w[44] = "endereço de e-mail não encontrado no arquivo de importação.";
$w[45] = "Não foram encontradas imagens para sua pesquisa.";
$w[46] = "Não foram encontradas imagens para sua pesquisa.";
$w[47] = "Nenhum vídeo encontrado para sua pesquisa.";
$w[48] = "permitir o compartilhamento";
$w[49] = "Permitir comentários";
$w[50] = "artigos do blog";
$w[51] = "video blog";
$w[52] = "blog";
$w[53] = "candidato";
$w[54] = "candidatos";
$w[55] = "caracteres alfa-numéricos apenas";
$w[56] = "categoria";
$w[57] = "categorias";
$w[58] = "Esta categoria é usada por um ou mais artigos, obrigado excluir pode excluir essa categoria.";
$w[59] = "esta secção é ligado ao módulo";
$w[60] = "campo obrigatório";
$w[61] = "Pesquisar";
$w[62] = "escolher um tema para o seu site";
$w[63] = "CEP";
$w[64] = "youtube código";
$w[65] = "revisão ativa";
$w[66] = "comentários bloqueado";
$w[67] = "comentário aguardando";
$w[68] = "Comentário";
$w[69] = "comentários";
$w[70] = "termos de uso";
$w[71] = "privacidade";
$w[72] = "Configuração";
$w[73] = "Conexão";
$w[74] = "contato";
$w[75] = "contatos";
$w[76] = "conteúdo";
$w[77] = "conteúdo";
$w[78] = "copyright";
$w[79] = "criar sua conta de graça";
$w[80] = "em";
$w[81] = "Data";
$w[82] = "Descrição curta";
$w[83] = "descrição";
$w[84] = "duplicar um módulo";
$w[85] = "duração";
$w[86] = "desarquivar este comentário";
$w[87] = "escreva um comentário";
$w[88] = "enviar uma mensagem";
$w[89] = "Remover";
$w[90] = "faq";
$w[91] = "Tipo de Arquivo";
$w[92] = "file";
$w[93] = "file";
$w[94] = "formulário de inscrição";
$w[95] = "formulário de contato";
$w[96] = "galeria de imagens";
$w[97] = "galeria";
$w[98] = "galerias";
$w[99] = "gestão";
$w[100] = "O Google Analytics é um serviço de análise sites gratuitos oferecidos pelo Google";
$w[101] = "google analytics";
$w[102] = "Grupo";
$w[103] = "gerar sitemap";
$w[104] = "gerar um novo módulo";
$w[105] = "altura";
$w[106] = "icon";
$w[107] = "nome de usuário";
$w[108] = "Log in";
$w[109] = "Não existem itens para esta categoria.";
$w[110] = "Não existem itens.";
$w[111] = "Não há atualmente nenhum contato";
$w[112] = "Não existem links";
$w[113] = "Não há atualmente nenhum módulo na base de dados";
$w[114] = "Não há atualmente nenhum módulo";
$w[115] = "Atualmente não há notícias para esta categoria.";
$w[116] = "não há atualmente nenhuma aplicação";
$w[117] = "atualmente não há imagens no banco de dados";
$w[118] = "atualmente não há imagens para esta categoria.";
$w[119] = "não há atualmente nenhuma imagem.";
$w[120] = "Não há atualmente nenhuma pergunta / resposta";
$w[121] = "Não há atualmente nenhum item";
$w[122] = "não há atualmente nenhum vídeo para esta categoria.";
$w[123] = "não há atualmente nenhum vídeo.";
$w[124] = "imagem";
$w[125] = "imagens";
$w[126] = "importar contatos de um arquivo";
$w[127] = "arquivos de importação";
$w[128] = "subscrição da newsletter";
$w[129] = "título";
$w[130] = "linguagem frontoffice ativa";
$w[131] = "linguagem backoffice";
$w[132] = "linguagem frontoffice principal";
$w[133] = "língua";
$w[134] = "width";
$w[135] = "O arquivo foi baixado.";
$w[136] = "módulo é nenhum módulo associado";
$w[137] = "o";
$w[138] = "link externo";
$w[139] = "link";
$w[140] = "links";
$w[141] = "ler o artigo";
$w[142] = "mais";
$w[143] = "logo";
$w[144] = "esconder forma";
$w[145] = "hide";
$w[146] = "condições";
$w[147] = "legal";
$w[148] = "mensagem";
$w[149] = "mensagens";
$w[150] = "meta description";
$w[151] = "meta keywords";
$w[152] = "título meta";
$w[153] = "minutos";
$w[154] = "modelos";
$w[155] = "Editar esta página";
$w[156] = "alterar minha senha";
$w[157] = "editar um contato";
$w[158] = "Editar conteúdo";
$w[159] = "editar um arquivo";
$w[160] = "editar link";
$w[161] = "Editar módulo";
$w[162] = "Editar tutorial";
$w[163] = "Editar categoria";
$w[164] = "de edição de imagem";
$w[165] = "editar uma pergunta / resposta";
$w[166] = "editar um item";
$w[167] = "alterar sua senha";
$w[168] = "Editar";
$w[169] = "módulo permite não utilizada";
$w[170] = "módulo ativo";
$w[171] = "módulo inativo";
$w[172] = "módulo";
$w[173] = "módulos internos";
$w[174] = "senha";
$w[175] = "palavras-chave";
$w[176] = "newsletter";
$w[177] = "Nome / Empresa";
$w[178] = "nome";
$w[179] = "nome";
$w[180] = "nascer";
$w[181] = "home page";
$w[182] = "home page de seu site";
$w[183] = "página não encontrada";
$w[184] = "página estática";
$w[185] = "por";
$w[186] = "parceiros";
$w[187] = "País";
$w[188] = "imagens";
$w[189] = "mapa do site";
$w[190] = "Portefólio";
$w[191] = "alimentado com";
$w[192] = "nome de usuário";
$w[193] = "publicar seu comentário";
$w[194] = "questão";
$w[195] = "perguntas";
$w[196] = "quem?";
$w[197] = "que é";
$w[198] = "quem é você?";
$w[199] = "Pesquisar";
$w[200] = "Pesquisar";
$w[201] = "recusar";
$w[202] = "redigite sua nova senha";
$w[203] = "return para o site";
$w[204] = "Voltar para a lista completa";
$w[205] = "Voltar para a lista de candidatos";
$w[206] = "voltar";
$w[207] = "item";
$w[208] = "itens";
$w[209] = "resposta";
$w[210] = "redes sociais";
$w[211] = "subscrever newsletter";
$w[212] = "Salvar";
$w[213] = "log out";
$w[214] = "Website";
$w[215] = "slogan";
$w[216] = "status";
$w[217] = "em";
$w[218] = "suppimer";
$w[219] = "delete concluída com êxito.";
$w[220] = "excluir definitivamente";
$w[221] = "remover o aplicativo";
$w[222] = "excluir comentário";
$w[223] = "conteúdo delete";
$w[224] = "Excluir contato";
$w[225] = "Excluir arquivos";
$w[226] = "excluir link";
$w[227] = "remover um módulo";
$w[228] = "Categoria Delete";
$w[229] = "item delete";
$w[230] = "delete";
$w[231] = "on";
$w[232] = "tamanho máximo";
$w[233] = "fax, telefone";
$w[234] = "telefone fixo";
$w[235] = "telefone móvel";
$w[236] = "telefone";
$w[237] = "Título do tutorial";
$w[238] = "título";
$w[239] = "Todos os arquivos";
$w[240] = "all";
$w[241] = "tutoriais";
$w[242] = "tipo";
$w[243] = "uri do artigo";
$w[244] = "uri da categoria";
$w[245] = "tutorial uri";
$w[246] = "uri";
$w[247] = "url";
$w[248] = "validação";
$w[249] = "validar esta aplicação";
$w[250] = "Por favor, importar um arquivo válido.";
$w[251] = "por favor preencha o formulário corretamente.";
$w[252] = "Por favor insira o nome do arquivo.";
$w[253] = "Por favor, preencha o formulário seguinte pedido para apresentar a sua candidatura ...";
$w[254] = "Por favor preencha o formulário abaixo para entrar em contato conosco, nós entraremos em contato com você em breve ...";
$w[255] = "vídeo";
$w[256] = "vídeo";
$w[257] = "Cidade";
$w[258] = "show";
$w[259] = "Seus contatos foram importados.";
$w[260] = "Sua informação foi atualizado.";
$w[261] = "seu endereço de email";
$w[262] = "sua candidatura foi tida em conta";
$w[263] = "o google analytics código";
$w[264] = "Seu comentário está sendo moderado, muito obrigado.";
$w[265] = "Seu comentário é aceito.";
$w[266] = "Seu comentário está agora arquivado.";
$w[267] = "Seu comentário é negado.";
$w[268] = "O arquivo é muito grande.";
$w[269] = "O arquivo não é compatível";
$w[270] = "Seu arquivo";
$w[271] = "sua mensagem?";
$w[272] = "Sua mensagem foi enviada Obrigado.";
$w[273] = "Sua senha atual";
$w[274] = "seu nome completo";
$w[275] = "Sua nova senha";
$w[276] = "Você deve primeiro adicionar uma categoria";
$w[277] = "Você acabou de enviar um comentário, o tempo de espera para enviar um novo comentário é";
$w[278] = "Você agora está subscrito a nossa newsletter Obrigado.";
$w[279] = "para";
$w[280] = "Escolha ...";
$w[281] = "homem";
$w[282] = "mulher";
$w[283] = "Africano";
$w[284] = "árabe";
$w[285] = "asiática";
$w[286] = "europeu";
$w[287] = "Índia";
$w[288] = "mestiço";
$w[289] = "foto";
$w[290] = "etnia";
$w[291] = "sexo";