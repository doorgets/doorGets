<?php

/**
 *
    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/


$w[0] = "almeno 8 caratteri";
$w[1] = "a vedere anche";
$w[2] = "accettare";
$w[3] = "casa";
$w[4] = "Attiva questo modulo";
$w[5] = "Attiva questa portefolio";
$w[6] = "Attiva questa esercitazione";
$w[7] = "Attiva questa voce";
$w[8] = "Attiva";
$w[9] = "news";
$w[10] = "news";
$w[11] = "indirizzo email";
$w[12] = "Indirizzo";
$w[13] = "Indirizzo e-mail già nei tuoi contatti.";
$w[14] = "Indirizzo e-mail importati.";
$w[15] = "email";
$w[16] = "Indirizzo";
$w[17] = "indirizzi e-mail importati.";
$w[18] = "indirizzi di posta elettronica già nei tuoi contatti.";
$w[19] = "visualizzare tutti gli elementi";
$w[20] = "show";
$w[21] = "Aggiungi un elemento";
$w[22] = "Aggiungi un contatto";
$w[23] = "Aggiungi file";
$w[24] = "Aggiungi un link";
$w[25] = "Aggiungi modulo";
$w[26] = "aggiungi news";
$w[27] = "aggiungere una classe";
$w[28] = "Aggiungi immagine";
$w[29] = "aggiungere una domanda / risposta";
$w[30] = "Aggiungi un elemento";
$w[31] = "Aggiungi un video";
$w[32] = "cancel";
$w[33] = "anno di creazione";
$w[34] = "archivio questo commento";
$w[35] = "archivio";
$w[36] = "voce";
$w[37] = "articoli";
$w[38] = "asoccié modulo";
$w[39] = "attenzione che hai detto di no modulo come home page";
$w[40] = "nessun articolo trovato per la ricerca.";
$w[41] = "non ci sono commenti trovati.";
$w[42] = "Nessun messaggio trovato.";
$w[43] = "Nessuna notizia che per la tua ricerca.";
$w[44] = "nessun indirizzo e-mail trovata nel file di importazione.";
$w[45] = "Nessuna immagine per la tua ricerca.";
$w[46] = "Nessuna immagine per la tua ricerca.";
$w[47] = "Nessun video trovato per la ricerca.";
$w[48] = "consentire la condivisione";
$w[49] = "Consenti i commenti";
$w[50] = "articoli blog";
$w[51] = "video blog";
$w[52] = "blog";
$w[53] = "candidato";
$w[54] = "candidati";
$w[55] = "caratteri alfanumerici solo";
$w[56] = "categoria";
$w[57] = "categorie";
$w[58] = "Questa categoria viene utilizzata da uno o più articoli, grazie si elimina è possibile eliminare questa categoria.";
$w[59] = "questa sezione viene allegata al modulo";
$w[60] = "campo obbligatorio";
$w[61] = "ricerca";
$w[62] = "scegliere un tema per il tuo sito";
$w[63] = "CAP";
$w[64] = "youtube codice";
$w[65] = "revisione attiva";
$w[66] = "commenti bloccati";
$w[67] = "commento in attesa";
$w[68] = "Commento";
$w[69] = "commenti";
$w[70] = "Condizioni di utilizzo";
$w[71] = "privacy";
$w[72] = "configurazione";
$w[73] = "connessione";
$w[74] = "contatto";
$w[75] = "contatti";
$w[76] = "contenuto";
$w[77] = "contenuto";
$w[78] = "diritto d'autore";
$w[79] = "Crea il tuo account gratis";
$w[80] = "a";
$w[81] = "data";
$w[82] = "descrizione breve";
$w[83] = "Descrizione";
$w[84] = "duplicare un modulo";
$w[85] = "durata";
$w[86] = "richiamare dall'archivio questo commento";
$w[87] = "scrivi un commento";
$w[88] = "invia un messaggio";
$w[89] = "remove";
$w[90] = "faq";
$w[91] = "Tipo di file";
$w[92] = "file";
$w[93] = "file";
$w[94] = "modulo di domanda";
$w[95] = "modulo di contatto";
$w[96] = "galleria di immagini";
$w[97] = "Galleria";
$w[98] = "gallerie";
$w[99] = "Gestione";
$w[100] = "Google Analytics è un servizio di analisi web gratuiti offerti da Google";
$w[101] = "google analytics";
$w[102] = "Gruppo";
$w[103] = "generare sitemap";
$w[104] = "generare un nuovo modulo";
$w[105] = "altezza";
$w[106] = "icona";
$w[107] = "username";
$w[108] = "Login";
$w[109] = "Non ci sono elementi per questa categoria.";
$w[110] = "Non ci sono elementi.";
$w[111] = "Non ci sono nessun contatto";
$w[112] = "Non ci sono link";
$w[113] = "Non ci sono attualmente modulo nel database";
$w[114] = "Non ci sono attualmente modulo";
$w[115] = "Non ci sono novità per questa categoria.";
$w[116] = "non esiste attualmente alcuna applicazione";
$w[117] = "attualmente non vi sono immagini nel database";
$w[118] = "attualmente non ci sono immagini in questa categoria.";
$w[119] = "non esiste attualmente alcuna immagine.";
$w[120] = "Non ci sono attualmente domanda / risposta";
$w[121] = "Non ci sono attualmente voce";
$w[122] = "non esiste attualmente alcuna video di questa categoria.";
$w[123] = "non esiste attualmente alcun video.";
$w[124] = "immagine";
$w[125] = "immagini";
$w[126] = "Importa i contatti da un file";
$w[127] = "File di importazione";
$w[128] = "iscrizione newsletter";
$w[129] = "title";
$w[130] = "lingua attiva frontoffice";
$w[131] = "lingua backoffice";
$w[132] = "lingua frontoffice principale";
$w[133] = "linguaggio";
$w[134] = "width";
$w[135] = "Il file è stato scaricato.";
$w[136] = "modulo non è modulo associato";
$w[137] = "il";
$w[138] = "link esterno";
$w[139] = "link";
$w[140] = "link";
$w[141] = "leggi l'articolo";
$w[142] = "più";
$w[143] = "logo";
$w[144] = "nascondere forma";
$w[145] = "hide";
$w[146] = "condizioni";
$w[147] = "legale";
$w[148] = "messaggio";
$w[149] = "messaggi";
$w[150] = "meta description";
$w[151] = "meta keywords";
$w[152] = "meta title";
$w[153] = "minuti";
$w[154] = "modelli";
$w[155] = "modifica questa pagina";
$w[156] = "cambiare la mia password";
$w[157] = "modificare un contatto";
$w[158] = "Modifica contenuto";
$w[159] = "modificare un file";
$w[160] = "Modifica link";
$w[161] = "Modifica modulo";
$w[162] = "edit tutorial";
$w[163] = "Modifica categoria";
$w[164] = "Modifica immagine";
$w[165] = "modificare una domanda / risposta";
$w[166] = "modificare una voce";
$w[167] = "cambiare la password";
$w[168] = "edit";
$w[169] = "modulo permette non utilizzati";
$w[170] = "modulo attivo";
$w[171] = "Modulo non attivo";
$w[172] = "modulo";
$w[173] = "moduli interni";
$w[174] = "password";
$w[175] = "parole chiave";
$w[176] = "newsletter";
$w[177] = "Nome / Azienda";
$w[178] = "filename";
$w[179] = "nome";
$w[180] = "nato";
$w[181] = "home page";
$w[182] = "home page del tuo sito web";
$w[183] = "pagina non trovata";
$w[184] = "pagina statica";
$w[185] = "da";
$w[186] = "partner";
$w[187] = "Nazione";
$w[188] = "immagini";
$w[189] = "Mappa del sito";
$w[190] = "portefolio";
$w[191] = "alimentato con";
$w[192] = "username";
$w[193] = "pubblicare il tuo commento";
$w[194] = "domanda";
$w[195] = "domande";
$w[196] = "chi?";
$w[197] = "che è";
$w[198] = "chi sei?";
$w[199] = "Cerca";
$w[200] = "Cerca";
$w[201] = "rifiuti";
$w[202] = "digitare nuovamente la nuova password";
$w[203] = "ritorno al sito";
$w[204] = "Torna alla lista completa";
$w[205] = "Torna alla lista dei candidati";
$w[206] = "indietro";
$w[207] = "voce";
$w[208] = "voci";
$w[209] = "risposta";
$w[210] = "reti sociali";
$w[211] = "iscriviti alla newsletter";
$w[212] = "Salva";
$w[213] = "log out";
$w[214] = "Sito Web";
$w[215] = "slogan";
$w[216] = "stato";
$w[217] = "on";
$w[218] = "suppimer";
$w[219] = "delete completata con successo.";
$w[220] = "eliminare definitivamente";
$w[221] = "rimozione applicazione";
$w[222] = "Elimina commento";
$w[223] = "content elimina";
$w[224] = "Elimina scheda";
$w[225] = "Elimina file";
$w[226] = "Elimina collegamento";
$w[227] = "rimuovere un modulo";
$w[228] = "Categoria Elimina";
$w[229] = "Elimina elemento";
$w[230] = "delete";
$w[231] = "on";
$w[232] = "dimensione massima";
$w[233] = "telefono fax";
$w[234] = "telefono fisso";
$w[235] = "telefono cellulare";
$w[236] = "telefono";
$w[237] = "Titolo del tutorial";
$w[238] = "title";
$w[239] = "Tutti i file";
$w[240] = "tutti";
$w[241] = "tutorial";
$w[242] = "tipo";
$w[243] = "uri dell'articolo";
$w[244] = "uri di categoria";
$w[245] = "tutorial uri";
$w[246] = "uri";
$w[247] = "url";
$w[248] = "convalida";
$w[249] = "confermare questa applicazione";
$w[250] = "Si prega di importare un file valido.";
$w[251] = "si prega di compilare il modulo correttamente.";
$w[252] = "Inserire il nome del file.";
$w[253] = "Si prega di compilare il modulo di richiesta seguente per presentare la domanda ...";
$w[254] = "Si prega di compilare il modulo di richiesta sottostante per contattarci e ti contatteremo al più presto ...";
$w[255] = "video";
$w[256] = "video";
$w[257] = "Città";
$w[258] = "show";
$w[259] = "I tuoi contatti sono stati importati.";
$w[260] = "Le tue informazioni sono state aggiornate.";
$w[261] = "Il tuo indirizzo e-mail";
$w[262] = "la sua candidatura state prese in considerazione";
$w[263] = "il tuo codice di Google Analytics";
$w[264] = "Il tuo commento è in fase di moderato, grazie.";
$w[265] = "il tuo commento è accettato.";
$w[266] = "Il tuo commento è ora archiviato.";
$w[267] = "Il tuo commento è negato.";
$w[268] = "Il file è troppo grande.";
$w[269] = "Il file non è compatibile";
$w[270] = "Il file";
$w[271] = "Il tuo messaggio?";
$w[272] = "Il tuo messaggio è stato inviato Grazie..";
$w[273] = "La tua password corrente";
$w[274] = "il tuo nome";
$w[275] = "La tua nuova password";
$w[276] = "E 'necessario aggiungere una categoria";
$w[277] = "Devi solo inviare un commento, il tempo di attesa per inviare un nuovo commento è";
$w[278] = "Ora sei iscritto alla nostra newsletter Grazie..";
$w[279] = "a";
$w[280] = "Scegli ...";
$w[281] = "uomo";
$w[282] = "donna";
$w[283] = "africana";
$w[284] = "arabo";
$w[285] = "asiatica";
$w[286] = "europea";
$w[287] = "India";
$w[288] = "meticcio";
$w[289] = "foto";
$w[290] = "etnia";
$w[291] = "sesso";