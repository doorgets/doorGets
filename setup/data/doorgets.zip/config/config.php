<?php

define('ACTIVE_CACHE',true);
define('ACTIVE_DEMO',false);
define('KEY_SECRET','rOm1yrn33ylh8Gq7058l');

define('KEY_DOORGETS','jHieLBuUSxmfY8exbgGm');

define('APP',BASE.'doorgets/app/');
define('CORE',BASE.'doorgets/core/');
define('LIB',BASE.'doorgets/lib/');
define('CONFIG',BASE.'doorgets/config/');
define('TEMPLATE',BASE.'doorgets/template/');
define('ROUTER',BASE.'doorgets/routers/');
define('CONFIGURATION',BASE.'config/');
define('THEME',BASE.'themes/');
define('LANGUE',BASE.'doorgets/locale/');
define('LANGUE_DEFAULT_FILE',BASE.'doorgets/locale/temp.lg.php');
define('CONTROLLERS',BASE.'doorgets/app/controllers/');
define('MODELS',BASE.'doorgets/app/models/');
define('VIEW',BASE.'doorgets/app/views/');
define('MODULES',BASE.'doorgets/app/modules/');
define('BASE_DATA',BASE.'data/');
define('BASE_IMG',BASE.'skin/img/');
define('BASE_CSS',BASE.'skin/css/');
define('BASE_JS',BASE.'skin/js/');
define('CACHE_DB',BASE.'cache/database/');
define('CACHE_TEMPLATE',BASE.'cache/template/');
define('CACHE_THEME',BASE.'cache/themes/');
define('URL','http://localhost/doorGets600/');
define('SQL_HOST','127.0.0.1');
define('SQL_LOGIN','root');
define('SQL_PWD','');
define('SQL_DB','doorgets600');
define('USR_NAME','doorGets');
define('USR_LOGIN','doorgets');
define('USR_PWD','doorgets');

require_once CORE.'doorgets.php';