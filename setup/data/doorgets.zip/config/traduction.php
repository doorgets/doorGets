<?php


$arrLangue = array(
    
    'en' => $this->l('Anglais'),
    'fr' => $this->l('Français'),
    'de' => $this->l('Allemand'),
    'es' => $this->l('Espagnol'),
    'pl' => $this->l('Polonais'),
    'ru' => $this->l('Russe'),
    'tu' => $this->l('Turque'),
    'po' => $this->l('Portugais'),
    'su' => $this->l('Suédois'),
    'it' => $this->l('Italien'),
    
);