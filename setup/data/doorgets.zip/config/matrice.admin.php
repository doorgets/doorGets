<?php

/**
 *
    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/


// function de chargement des classes
function __autoload($name){
    
    $name = strtolower($name);
    
    $classCore      = MVC.'core/class.'.$name.'.php';
    $classSystem    = MVC.'system/class.'.$name.'.php';
    $classModule    = MVC.'module/class.'.$name.'.php';
    $classAdmin     = MVC.'admin/class.'.$name.'.php';
    
    
    if( is_file($classCore) ){ require_once $classCore; }
    elseif( is_file($classSystem) ){ require_once $classSystem; }
    elseif( is_file($classModule) ){ require_once $classModule; }
    elseif( is_file($classAdmin) ){ require_once $classAdmin; }
    else { die('La classe <b>class'.$name.'</b> est introuvable.'); }
    
}

define('BASE',URL);

// creation du squelette de la page


// test si l'utilisateur est connécter
$Auth = new Auth();
$bdInfo = new CRUD();
$isWebsiteInfo = $bdInfo->dbQS(1,'_website');
$lgWebsite = 'fr';
$PageAdmin = new PageAdmin($lgWebsite);
if( !empty($isWebsiteInfo) ){
    $lgWebsite = $isWebsiteInfo['langue'];
    
    switch($lgWebsite){
        case 'fr':
            setlocale (LC_TIME, 'fr_FR.utf8','fra');
            break;
    }
}

// generer le systeme d'identification
$Authentification = new Authentification('administrateur',$lgWebsite);

if( !empty($Auth->in) ){
    
    $ControllerAdmin = new ControllerAdmin($Auth->in['nom'],'',$lgWebsite);
    
}

// Information de mise à jour
$flash = new FlashInfoGet();

// Aucun cache 
header("Cache-Control: no-cache");

print $PageAdmin->getHeader();

// check if you have flash info
print $flash->Get('auth');

if( empty($Auth->in) ){
    
    print $Authentification->get();
    
}else{
    
    print $ControllerAdmin->get();
    
}

print $PageAdmin->getFooter(); 