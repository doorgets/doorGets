<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 - 28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
<!-- doorGets:start:page -->
{{?(!empty($this->infoWeb['facebook'])):}}{{ $Facobook = '<a target="blank" href="http://www.facebook.com/'.$this->infoWeb['facebook'].'" class="img_network" ><img alt="" class="img_network_" src="'.URL.'theme/'.$this->theme.'/img/icone_facebook.png" /></a>'; }}{?}
{{?(!empty($this->infoWeb['twitter'])):}}{{ $Youtube= '<a target="blank" href="http://www.twitter.com/'.$this->infoWeb['twitter'].'" class="img_network" ><img alt="" class="img_network_" src="'.URL.'theme/'.$this->theme.'/img/icone_twitter.png" /></a>'; }}{?}
{{?(!empty($this->infoWeb['google'])):}}{{ $Google = '<a target="blank" href="https://plus.google.com/u/0/'.$this->infoWeb['google'].'" class="img_network" ><img alt="" class="img_network_" src="'.URL.'theme/'.$this->theme.'/img/icone_google.png" /></a>'; }}{?}
{{?(!empty($this->infoWeb['youtube'])):}}{{ $Twitter = '<a target="blank" href="http://www.youtube.com/user/'.$this->infoWeb['youtube'].'" class="img_network" ><img alt="" class="img_network_" src="'.URL.'theme/'.$this->theme.'/img/icone_youtube.png" /></a>'; }}{?}
{{ $shareNetwork = " $Facobook $Youtube $Twitter $Google "; }}
{{ $twitterIn = $this->infoWeb['twitter']; }}
{{?(empty($twitterIn)):}}{{$twitterIn = 'doorgets';}}{?}
{{ $facebookIn = $this->infoWeb['facebook']; }}
{{?(empty($facebookIn)):}}{{$facebookIn = 'doorgets';}}{?}
<div id="top_lg" >
    <div id="top_lg_in" >
        <table >
            <tr>
                <td>{{!$this->genLangueMenuFrontOffice()!}}</td>
                <td style="text-align: right;">{{!$shareNetwork!}}</td>
            </tr>
        </table>
    </div>
</div>
<div id="header-page">
    <div class="header-page-in">
        <a   href="{{!BASE!}}"><img alt="" src="{{!URL!}}ad_/img/logo.png" style="width: 250px;height: 120px;" ></a>
    </div>
</div>
{{!$this->rubrique()!}}
<div id="page">
    <div id="contenu">
        {{!$contentHeader!}}
        {{!$this->content()!}}
        {{!NewsletterFrontOffice::formInscription($this->GetLangue())!}}
        
    </div>
</div>
<!-- doorGets:end:page -->