<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 - 28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
<!-- doorGets:start:m.tuto.voir -->
<div id="m-tuto-voir" >
    
    <div class="m-tuto-rubrique"  >
        
        <a href="./">{{!$this->getWords('Accueil')!}}</a> / <a href="./?r={{!$this->uri!}}">{{!$moduleName!}}</a> / <a href="./?in={{!$this->categorie[$isTuto['categorie']]!}}">{{!$this->categorieSimple[$isTuto['categorie']]!}}</a> / {{!ucwords($isTuto['titre'])!}}
        
    </div>
    <div class="titre" >
    
        <b class="color-in">{{!$isTuto['titre']!}}</b>
        
    </div>
    <div class="size-11 pad-top-bottom-10" >
        <img alt="" src="{{!$fileCalendar!}}" class="img-icone" > 
        {{!ucfirst(strftime("%A %d %B %Y",$isTuto['date_creation']))!}}
        
        {{?($isTutoActive['comments']):}}
             <span class="right " > 
                <img alt="" src="{{!$fileComment!}}" class="img-icone-right" >
                <a href="./?{{!$this->uri!}}={{!$isTuto['uri']!}}#commentaire" >
                {{!$tutoComment->countCommentaire.' '.$sComm!}}
                </a>
             </span>
        {?}
        
        <span class="right " > 
            <img alt="" src="{{!$fileTag!}}" class="img-icone-right" >
             <a href="./?in={{!$this->categorie[$isTuto['categorie']]!}}">{{!$this->categorieSimple[$isTuto['categorie']]!}}</a>
        </span>
        
        <span class="right " >
            <img alt="" src="{{!$fileTime!}}" class="img-icone-right"  >
            {{!$isTuto['temps']!}}m
        </span>
    </div>
    <div class="video" >
    
        <iframe width="880" height="650" src="http://www.youtube.com/embed/{{!$isTuto['youtube']!}}"  ></iframe>
        
    </div>
    <div class="article" >
        {{!$isTuto['description']!}}
    </div>
    
</div>
<!-- doorGets:end:m.tuto.voir -->