<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 - 28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/


?>
<!-- doorGets:start:m.comments.form -->
<a id="commentaire"></a>
<div id="m-comments-form" >
    
    <div class="head" >
        <img alt="" src="{{!$file!}}"  >
        {{!$this->countCommentaire.' '.$iBlogS!}}
        <span id="ck_afficher_commentaire"   > {{!$this->getWords('ecrire un commentaire')!}} </span>
        
    </div>
    {{!$erreur!}}
    {{?(empty($erreur)):}}
        
        {{!$form->open('post',$_SERVER['REQUEST_URI'].$lkComment.'#commentaire','')!}}
        <div id="form_commentaire_in" >
        <table  >
            <tr>
                <td   >
                    <br />
                    {{!$form->input($this->getWords('Pseudo').'<br />','nom');  }}
                    
                </td>
                <td   >
                    <br />
                    {{!$form->input($this->getWords('Votre adresse e-mail').'<br />','email')!}}
                    
                </td>
            </tr>
        </table>
        <table  >
        <tr>
            <td   >
                <br />
                {{!$form->textarea($this->getWords('Commentaire').'<br />','comment')!}}
                
            </td>
        </tr>
        
        </table>
        <table  >
            <tr>
                <td  >
                    
                {{!$form->submit($this->getWords("Publier votre commentaire"))!}}
                
                </td>
            </tr>
        </table>
        </div>
        {{!$form->close()!}}
        
    {?}

</div>
<!-- doorGets:end:m.comments.form -->