<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 - 28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?><!DOCTYPE html>
<html>
    <head>
        <title>{{!$this->title!}} - doorGets.com</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="generator" content="doorgets" />
        <meta name="author" content="{{!$copy!}}, doorgets" />
        <meta name="description" content="{{!$description!}}" />
        <meta name="keywords" content="{{!$keys!}}, doorgets" />
        <meta property="og:site_name" content="{{!$this->title!}}" />
        <meta property="og:title" content="{{!$this->description!}}" />
        <meta property="og:url" content="{{!$url!}}" />
        <meta property="og:language" content="{{!$langue!}}" />
        <meta property="fb:admins" content="{{!$idFacebookAdmin!}}"/>
        <script  src="{{!URL!}}ad_/js/jquery-1.8.0.min.js" type="text/javascript">
        </script><script src="{{!URL!}}ad_/js/jquery-ui-1.8.23.custom.min.js" type="text/javascript"></script>
        <link href="{{!$uri!}}/{{!$this->theme!}}/css/doorgets.css" rel="stylesheet" type="text/css" />
        <script type="text/javascript">var switchTo5x=false;</script>
        <script type="text/javascript" src="{{!URL!}}ad_/js/button.js">
        </script><script type="text/javascript">stLight.options({publisher: "ur-98e6d9d3-7ce5-b403-7dad-3b31d2276b9", lang:"{{!$langue!}}"});</script>
    </head>
    <body >
    <div id="fb-root" style="width:0;height:0;"></div>
    <script>
    (function(d, s, id)
    {   var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s);
        js.id = id;js.src = "//connect.facebook.net/{{!$lgFacebook!}}/all.js#xfbml=1";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
    </script>