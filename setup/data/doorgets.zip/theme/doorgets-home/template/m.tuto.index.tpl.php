<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 - 28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
<!-- doorGets:start:m.tuto.index -->
<div id="m-tuto-index">
{{?(!empty($q)):}}
    <div class="dash-top-bottom" >
        
        {{!$this->getWords('rechercher')!}} : <b>{{!$q!}}</b> - 
        <a href="./?r={{!$this->uri!}}" class="annuler" >{{!$this->getWords('retour à la liste compléte')!}}</a>
        
    </div>
{?}
{{?( empty($q) && empty($cAll) && !array_key_exists('q',$_GET) ):}}
    <script type="text/javascript">
         $("#form_seach_doorgets").hide();
    </script>
{?}
{{?(!empty($cAll)):}}
    
    <div class="dash-top-bottom" >
    {{!($ini+1).' '.$this->getWords('à').' '.$finalPer.' '.$this->getWords('sur').' '.$cResultsInt.' '!}}
    {{?( $cResultsInt > 1 ):}}{{! $this->getWords('Vidéos') !}}{??}{{!$this->getWords('Vidéo');!}}{?}
    </div>
    <dl class="line-none"  >
    {{-($i=0;$i<$cAll;$i++):}}
        
        {{ $tutoComment = new ContentCommentaire($all[$i]['id_content'],'_comments',$this->uri,$this->GetLangue()); }}
        {{?(strlen($all[$i]['titre']) > 34):}}{{ $all[$i]['titre'] = substr($all[$i]['titre'],0,30); }}{?}
        
        <dd class="contour-hombre"  >
            
            <div >
                <span  class="color-in"  >
                    {{!ucfirst(mb_strtolower($all[$i]['titre'],'UTF-8'))!}}
                </span>
            </div>
            <div  >
                <a href="{{!BASE!}}?{{!$this->uri!}}={{!$all[$i]['uri']!}}"  >
                    <img alt="" src="https://i2.ytimg.com/vi/{{!$all[$i]['youtube']!}}/mqdefault.jpg" style="width:265px;height:160px;margin-right:2px;border:solid 1px #ccc;padding:2px;background-color:#000;" >
                </a>
                
                <div  >
                    <span >
                        <img alt="" src="{{!$fileTime!}}" class="img-icone"  >
                        {{!$all[$i]['temps']!}}m
                    </span>
                    {{?($all[$i]['comments']):}}
                    <span >
                       <a href="{{!BASE!}}?{{!$this->uri!}}={{!$all[$i]['uri']!}}#commentaire"  >
                       <img alt="" src="{{!$fileComment!}}" class="img-icone"  >
                       {{!$tutoComment->countCommentaire!}}
                       </a>
                    </span>
                    {?}
                    <span >
                        <img alt="" src="{{!$fileTag!}}" class="img-icone"  >
                         <a  href="{{!BASE!}}?in={{!$this->categorie[$all[$i]['categorie']]!}}">{{!$this->categorieSimple[$all[$i]['categorie']]!}}</a>
                    </span>
                
                </div>
            </div> 
            
        </dd>
    {-}
    </dl>
    {{?(!empty($valPage)):}}
    <br />
    <div id="pagination"  >
        {{!$valPage!}}
    </div>
    {?}
    
    
{??}
    
    {{?(isset($_GET['c'])):}}
        
        <div class="no-found-result" >
            {{!$this->getWords("Il n'y a actuellement aucune vidéo pour cette catégorie.")!}}
        </div>
        
    {{???(!empty($q)):}}
        
        <div class="no-found-result" >
            {{!$this->getWords("Aucune vidéo trouvé pour votre recherche.")!}}
        </div>
        
    {??}
        
        <div class="no-found-result" >
            {{!$this->getWords("Il n'y a actuellement aucune vidéo.")!}}
        </div>
        
    {?}

{?}
</div>
<!-- doorGets:end:m.tuto.index -->