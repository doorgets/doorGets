<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 - 28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/


?>
<!-- doorGets:start:m.blog.voir -->
<div id="m-blog-voir" >
    <div class="m-blog-rubrique" >
        
        <a href="./">{{!$this->getWords('Accueil')!}}</a> / <a href="./?r={{!$this->uri!}}">{{!$moduleName!}}</a> / <a href="./?in={{!$this->categorie[$isNews['categorie']]!}}">{{!$this->categorieSimple[$isNews['categorie']]!}}</a> / {{!ucwords($isNews['titre'])!}}
        
    </div>
    <div class="titre" >
    
        <b class="color-in">{{!$isNews['titre']!}}</b>
        
    </div>
    <div class="size-11 pad-top-bottom-10" >
        <img alt="" src="{{!$fileCalendar!}}" class="img-icone" > 
        {{!ucfirst(strftime("%A %d %B %Y",$isNews['date_creation']))!}}
        {{?($isNewsActive['comments']):}}
            <span class="right " >
               <img alt="" src="{{!$fileComment!}}" class="img-icone-right" >
               <a href="./?{{!$this->uri!}}={{!$isNews['uri']!}}#commentaire" >
               {{!$newsComment->countCommentaire.' '.$sComm!}}
               </a>
            </span>
        {?}
        
         <span class="right " >
            <img alt="" src="{{!$fileTag!}}" class="img-icone-right"  >
            <a href="./?in={{!$this->categorie[$isNews['categorie']]!}}">{{!$this->categorieSimple[$isNews['categorie']]!}}</a>
        </span>
    </div>
    <div class="article" >
        <div class="color-in">
            {{!$isNews['description']!}}
        </div>
        {{!$isNews['article']!}}
    
    </div>
</div>
<!-- doorGets:end:m.blog.voir -->