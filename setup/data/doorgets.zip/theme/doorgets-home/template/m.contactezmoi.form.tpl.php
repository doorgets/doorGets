<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 - 28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
<!-- doorGets:start:m.contactezmoi.form -->
<div id="m-contactezmoi">
    <br />
        <p>
            {{!$this->getWords('Veuilliez remplir le fomulaire suivant afin de nous contacter, nous vous contacterons rapidement...') }}
        </p>
    <br />
    <table  style="width:100%;border:0;">
        <tr>
            <td   style="width:50%;padding:5px;">
                
                {{!$form->input('','secureFormulaire','hidden',$_SESSION['idForm'])!}}
                {{!$form->input('<span class="red">*</span> '.$this->getWords('Nom / Entreprise').'<br />','nom')!}}
                <br />
                {{!$form->input($this->getWords('Telephone').'<br />','telephone')!}}
                <br />
                {{!$form->textarea(''.$this->getWords('Qui etes vous ?').'<br />','descprition')!}}
                
            </td>
            <td  style="width:50%;padding:5px;">
                
                {{!$form->input('<span class="red">*</span> '.$this->getWords('Adresse email').'<br />','email')!}}
                <br />
                {{!$form->input('<span class="red">*</span> '.$this->getWords('Sujet').'<br />','sujet')!}}
                <br />
                {{!$form->textarea('<span class="red">*</span> '.$this->getWords('Votre message ?').'<br />','message')!}}
                
            </td>
        </tr>
        <tr>
            <td>
                
                <span class="red">*</span> {{!$this->getWords('Champ obligatoire')!}}
                
            </td>
            <td style="text-align:right;">
            
                {{!$form->submit($this->getWords('Envoyer le message'))!}}
                
            </td>
        </tr>
    </table>
</div>
<!-- doorGets:end:m.contactezmoi.form -->