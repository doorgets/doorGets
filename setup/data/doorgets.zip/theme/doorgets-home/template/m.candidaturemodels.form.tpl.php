<div id="m-contactezmoi">
<p>{{!$this->getWords("Veuilliez remplir le fomulaire suivant afin de déposer votre candidature...")!}}</p>

    <div class="helper_view_content topbottom " style="border-bottom:0;">
    
        
        {{!$form->open()!}}
        <table id="box_login" class=" topbottom width-100 green " >
        <tr>
            <td valign="top" style="padding:5px;width:50%;" >
            
                {{!$form->input('* '.$this->getWords("Votre nom, prénom").'<br />','nom')!}}
                <br />
                {{!$form->input('* '.$this->getWords("Votre adresse e-mail").'<br />','email')!}}
                <br />
                {{!$form->input('* '.$this->getWords("Telephone").'<br />','telephone')!}}
                <br />
                {{!$form->textarea('* '.$this->getWords("Qui etes vous ?").'<br />','description')!}}
                <br />
                {{!$form->input('* '.$this->getWords("Née le").' <small style="font-weight:100;">jj/mm/yyyy</small><br />','date_naissance','text')!}}
               
                
                
            </td>
            <td valign="top" style="padding:5px;width:50%;" >
                {{
                
                    $arSexe = array(0=>$this->getWords('Choisir...'),'men'=>$this->getWords('Homme'),'women'=>$this->getWords('Femme'));
                    $arEthnie = array(0=>$this->getWords('Choisir...'),'africa'=>$this->getWords('Africain'),'arab'=>$this->getWords('Arabe'),'asiatique'=>$this->getWords('Asiatique'),'europeen'=>$this->getWords('Européen'),'indien'=>$this->getWords('Indien'),'metisse'=>$this->getWords('Métisse'));
                
                }}
                {{!$form->select('* '.$this->getWords("Sexe").' <br />','sexe',$arSexe)!}}
                <br />
                {{!$form->select('* '.$this->getWords("Ethnie").'<br />','ethnie',$arEthnie)!}}
                
                <br /><br />
                PNG, JPG, 2Mo max<br /><br />
                {{!$form->file('* '.$this->getWords("Photo").' ','photo_visage')!}}
                <br /><br />
                {{!$form->file(''.$this->getWords("Photo").' ','photo_face')!}}
                <br /><br />
                {{!$form->file(''.$this->getWords("Photo").' ','photo_profil')!}}
                <br /><br />
                {{!$form->file(''.$this->getWords("Photo").' ','photo_autre')!}}
                
            </td>
        </tr>
        
        </table>
        <table id="box_login_bottom" class=" topbottom width-100 center " style="border-bottom:0;padding-top:15px;"><tr><td>
            
            * {{!$this->getWords("Champ obligatoire")!}}
            
        </td><td style="text-align:right;">
            {{!$form->submit($this->getWords("Valider cette candidature"))!}}
        </td></tr></table>
        {{!$form->close()!}}
            
            
    </div>
</div>