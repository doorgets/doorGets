<div style="text-align: center;margin-left:auto;margin-right:auto;width: 850px;padding:10px 0;">
    <img src="{{!$imgMessageOk!}}" style="vertical-align:middle;width:25px;height:25px;"  >
    {{!$this->getWords("Votre candidature à bien été prise en compte")!}}
    <br /><a href="./">{{!$this->getWords("retour sur le site")!}}</a> 
</div>