<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 - 28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
<!-- doorGets:start:m.blog.index -->
<div id="m-blog-index">
{{

    $fileTag = THM.'theme/'.$this->theme.'/img//tag.png';
    $fileComment = THM.'theme/'.$this->theme.'/img//comment_blog.png';
    $fileCalendar = THM.'theme/'.$this->theme.'/img//calendar.png';
    
}}
{{?(!empty($q)):}}
    <div class="dash-top-bottom" >
        
        {{!$this->getWords('rechercher')!}} : <b>{{!$q!}}</b> - 
        <a href="./?r={{!$this->uri!}}" class="annuler" >{{!$this->getWords('retour à la liste compléte')!}}</a>
        
    </div>
{?}

{{?(empty($q) && empty($cAll) && !array_key_exists('q',$_GET)):}}
    <script type="text/javascript">
        $("#form_seach_doorgets").hide();
    </script>
{?}

{{?(!empty($cAll)):}}

    <div class="dash-top-bottom" >
        {{! ($ini+1).' '.$this->getWords("à").' '.$finalPer.' '.$this->getWords("sur").' '.$cResultsInt!}}
        {{?( $cResultsInt > 1 ):}}{{! $this->getWords('articles') !}} {??}  {{! $this->getWords('article') !}}{?}
    </div>
    <dl class="line-none" >
    {{-($i=0;$i<$cAll;$i++):}}
        
        {{ $blogComment = new ContentCommentaire($all[$i]['id_content'],'_comments',$this->uri,$this->GetLangue()); }}
        {{ $sComm = $this->getWords('Commentaire'); }}
        {{?($blogComment->countCommentaire > 1):}}{{ $sComm = $this->getWords('Commentaires'); }}{?}
        {{ $fileLogo = URL.'data/'.$this->uri.'/'.$all[$i]['image'];  }}
        
        <dd class="contour-hombre">
            
            <div class="titre" >
                <a href="./?{{!$this->uri!}}={{!$all[$i]['uri']!}}"  >
                    {{!ucfirst(mb_strtolower($all[$i]['titre'],'UTF-8'))!}}
                </a>
            </div>
            <div class="size-11 pad-top-bottom-10" >
                <img alt="" src="{{!$fileCalendar!}}" class="img-icone" >
                {{!ucfirst(strftime("%A %d %B %Y",$all[$i]['date_creation']))!}}
                {{?($all[$i]['comments']):}}
                <span class="right " >
                    <img alt="" src="{{!$fileComment!}}" class="img-icone-right" >
                    <a href="./?{{!$this->uri!}}={{!$all[$i]['uri']!}}#commentaire"  > {{!$blogComment->countCommentaire.' '.$sComm!}}</a>
                </span>
                {?}
                
                <span class="right "  > 
                    <img alt="" src="{{!$fileTag!}}" class="img-icone-right" >
                    <a href="./?in={{!$this->categorie[$all[$i]['categorie']]!}}">{{!$this->categorieSimple[$all[$i]['categorie']]!}}</a>
                </span>
            </div>
            <div class="block-left" >
                <div class="block-right" >
                    <a href="./?{{!$this->uri!}}={{!$all[$i]['uri']!}}"  >
                        <img alt="" src="{{!$fileLogo!}}" class="img-blog" >
                    </a>
                </div>
                <a href="./?{{!$this->uri!}}={{!$all[$i]['uri']!}}" class="contour-hombre right" >{{!$this->getWords("Lire l'article")!}}</a>
                {{!$all[$i]['description']!}}
                <br />
                
            </div>
            
        </dd>
    {-}
    </dl>
    {{?(!empty($valPage)):}}
        <div id="pagination">
            {{!$valPage!}}
        </div>
    {?}
{??}
    {{?(isset($_GET['c'])):}}
        <div class="no-found-result" >
            {{!$this->getWords("Il n'y a actuellement aucun article pour cette catégorie.")!}}
        </div>
    {{???(!empty($q)):}}
        <div class="no-found-result">
            {{!$this->getWords("Aucun article trouvé pour votre recherche.")!}}
        </div>
    {??}
        <div class="no-found-result">
            {{!$this->getWords("Il n'y a actuellement aucun article.")!}}
        </div>
    {?}
{?}
</div>
<!-- doorGets:end:m.blog.index -->