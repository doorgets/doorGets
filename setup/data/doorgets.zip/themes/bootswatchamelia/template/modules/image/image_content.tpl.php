<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.2 - 05, January 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

 
 /*
  * Variables :
  *
        $isContent['id_content'] => $id_content
        $isContent['categorie'] => $categorie
        $isContent['titre' => $titre   
        $isContent['description'] => $description
        $isContent['uri'] => $uri
        $isContent['date_creation'] => $date_creation
        $isContent['article'] => $article

 */
 
    $nexContent         = $Website->getUrlNextContent();
    $prevContent        = $Website->getUrlPreviousContent();
    $cComment           = $Website->getCountComment($Website->getModule(),$isContent['uri']);
    $urlGoToComments    = BASE_URL.'?'.$Website->getModule().'='.$isContent['uri'].'#comments';

    $labelModuleGroup = $Website->getActiveModules();
    $labelModule = $labelModuleGroup[$Website->getModule()]['all']['nom'];
    
?>
<!-- doorGets:start:modules/image/image_content -->
<div class="doorGets-image-content doorGets-module-{{!$Website->getModule()!}}">
    <div class="row">
        <div class="col-md-9">
            <ol class="breadcrumb">
                <li><a href="{{!BASE_URL!}}">Home</a></li>
                <li><a href="{{!BASE_URL!}}?{{!$Website->getModule()!}}">{{!$labelModule!}}</a></li>
                <li class="active">{{!$isContent['title']!}}</li>
            </ol>
            <div class="doorGets-listing-contents left">
                {{?(!empty($isContent)):}}
                    <h2>{{!$isContent['title']!}}</h2>
                    <div class="infos-content-title ">
                        <span ><img alt="" src="{{!$_imgTag!}}" class="img-icone"  > {{!$linksToCategories!}}</span>
                        <span class="right"><a href="{{!$urlGoToComments!}}"><img alt="" src="{{!$_imgComment!}}" class="img-icone"  > {{!$cComment!}}</a></span>
                    </div>
                    <p class="img-content">
                        {{?(!empty($nexContent)):}}<a href="{{!$nexContent['url']!}}">{?}
                            <img  src="{{!BASE!}}data/{{!$Website->getModule()!}}/real/{{!$isContent['image']!}}"  />
                        {{?(!empty($nexContent)):}}</a>{?}
                    </p>
                    <p>
                        {{!$isContent['article']!}}
                    </p>
                    {{?($sharethis):}}
                    <div class="box-sharethis">
                        {{!$Website->getHtmlShareThis();}}
                    </div>
                    {?}
                    
                    {{?($comments):}}
                    <div class="box-comment-listing">
                        {{!$Website->getHtmlModuleComments()!}}
                    </div>
                    <div class="box-comments">
                        {{!$Website->getHtmlComment();}}
                    </div>
                    {?}
                    
                    {{?($facebook):}}
                    <div class="box-facebook">
                        {{!$Website->getHtmlCommentFacebook();}}
                    </div> 
                    {?}
                   
                    {{?($disqus):}}
                    <div class="box-disqus">   
                        {{!$Website->getHtmlCommentDisqus();}}
                    </div>
                    {?}
                    
                    <div class="content-next-previous">
                        <ul class="pager">
                            <li class="previous">
                                {{?(!empty($prevContent)):}}<a href="{{!$prevContent['url']!}}">&larr; {{!$prevContent['label']!}}</a>{?}
                            </li>
                            <li class="next">
                                {{?(!empty($nexContent)):}}<a href="{{!$nexContent['url']!}}">{{!$nexContent['label']!}} &rarr;</a>{?}
                            </li>
                        </ul>
                    </div>
                    
                {?}
            </div>
        </div>
        <div class="col-md-3">
            {{!$Website->getHtmlModuleSearch($q)!}}
            <div class="panel panel-default">
                <div class="panel-heading">
                  <a href="{{!BASE_URL.'?'.$Website->getModule()!}}"><h3 class="panel-title">{{!$Website->l('Catégories')!}}</h3></a>
                </div>
                <div class="panel-body">
                  {{!$Website->getHtmlModuleCategories()!}}
                </div>
            </div>
        </div>
    </div>
</div>
<!-- doorGets:end:modules/image/image_content -->