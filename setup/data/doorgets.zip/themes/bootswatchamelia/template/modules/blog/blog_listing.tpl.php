<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 20, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

 
 /*
  * Variables :
  *
        $contents[$i]['uri']            => $uri
        $contents[$i]['title']          => $title
        $contents[$i]['description']    => $description
        $contents[$i]['article']        => $article
        $contents[$i]['categories']     => $categories
        $contents[$i]['order']          => $order
        $contents[$i]['date']           => $date

 */
 
 $labelModuleGroup = $Website->getActiveModules();
 $labelModule = $labelModuleGroup[$Website->getModule()]['all']['nom'];
 
?>
<!-- doorGets:start:modules/news/news_listing -->
<div class="doorGets-news-listing doorGets-module-{{!$Website->getModule()!}}">
    <div class="row">
        <div class="col-md-9">
            <ol class="breadcrumb">
                <li><a href="{{!BASE_URL!}}">Home</a></li>
                <li><a href="{{!BASE_URL!}}?{{!$Website->getModule()!}}">{{!$labelModule!}}</a></li>
                {{?(!empty($categoryLabel)):}}
                    <li class="active">{{!$categoryLabel!}}</li>
                {?}
            </ol>
            <div class="doorGets-listing-contents-title">
                {{!$ini!}} {{!$Website->l('à')!}} {{!$finalPer!}} {{!$Website->l('sur')!}} <b>{{!$totalContents!}} {{?($totalContents > 1):}} {{!$Website->l('articles')!}} {??}  {{!$Website->l('article')!}}{?}</b>
                {{?(!empty($q)):}}
                    {{!$Website->l('pour la recherche')!}} : <b>{{!$q!}}</b>
                {{???(empty($categoryLabel)):}}
                    {{!$Website->l('dans toutes les catégories')!}}
                {??}
                    {{!$Website->l('dans la catégorie')!}} {{!$categoryLabel!}}
                {?}
            </div>
            {{?(!empty($contents)):}}
                {{/($contents as $content):}}
                    <div class="row content-listing-news">    
                        <div class="col-md-3  left-date-news">
                            <h3 class="visible-xs">
                                <a href="{{!BASE_URL!}}?{{!$Website->getModule()!}}={{!$content['uri']!}}">{{!$content['title']!}}</a>
                            </h3>
                            <img src="{{!BASE!}}data/{{!$Website->getModule()!}}/real/{{!$content['image']!}}" class="img-thumbnail img-responsive hover-t img-blog-listing" />
                        </div>
                        <div class="col-md-9  ">
                            <h3 class="hidden-xs">
                                <a href="{{!BASE_URL!}}?{{!$Website->getModule()!}}={{!$content['uri']!}}">{{!$content['title']!}}</a>
                            </h3>
                            <div>
                                <br class="visible-xs" />{{!$content['article']!}}
                            </div>
                            <div class="t-right">
                                <small>{{!$content['date']!}}</small>
                                <span><img src="{{!BASE_IMG.'comments.png'!}}" class="min-index" />{{!$Website->getCountComment($Website->getModule(),$content['uri'])!}}</span>
                                <a href="{{!BASE_URL!}}?{{!$Website->getModule()!}}={{!$content['uri']!}}" class="btn btn-info">
                                {{!$Website->l('Lire la suite')!}}
                                </a>
                            </div>
                        </div>
                    </div>
                {/}
            {?}
            {{?(empty($contents)):}}
            <div class="info-not-found">
                {{!$Website->l('Aucun article trouvée')!}} {{?(!empty($q)):}}{{!$Website->l('pour votre recherche')!}}{?}.
            </div>
            {?}
            {{?(!empty($getPagination)):}}
                <br /><br />
                {{!$getPagination!}}
            {?}
        </div>
        <div class="col-md-3">
            {{!$Website->getHtmlModuleSearch($q)!}}
            <div class="panel panel-default">
                <div class="panel-heading">
                  <a href="{{!BASE_URL.'?'.$Website->getModule()!}}"><h3 class="panel-title">{{!$Website->l('Catégories')!}}</h3></a>
                </div>
                <div class="panel-body">
                  {{!$Website->getHtmlModuleCategories()!}}
                </div>
            </div>
        </div>
    </div>
</div>
<!-- doorGets:end:modules/news/news_listing -->