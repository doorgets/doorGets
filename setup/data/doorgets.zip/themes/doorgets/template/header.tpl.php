<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 10 November, 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


 /*
  * Variables :
        $label
        $title
        $description 
        $keywords
 */
 
$url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];

?><!doctype html>
<html lang="{{!$this->myLanguage()!}}">
    <head>
        <title>{{!$label!}}</title>
        
        <meta charset="utf-8" />
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta http-equiv="Content-Style-Type" content="text/css" />
	
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
        <meta name="generator" content="doorGets" />
        <meta name="author" content="Doorgets.com, doorgets" />
        <meta name="description" content="{{!$description!}}" />
        <meta name="keywords" content="{{!$keywords!}}" />
        
        <meta property="og:site_name" content="{{!$title!}}" />
        <meta property="og:title" content="{{!$label!}}" />
        <meta property="og:url" content="{{!$url!}}" />
        <meta property="og:language" content="{{!$this->myLanguage()!}}" />
        
        {{!$rssLinks!}}
	
        <link href="{{!URL!}}skin/js/syntax/styles/shCoreDefault.css" rel="stylesheet" type="text/css" />
	<link href="{{!URL!}}skin/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css" />
        
	<script type="text/javascript" src="{{!URL!}}skin/js/jquery.js"></script>
	<script type="text/javascript" src="{{!URL!}}skin/js/jquery.ui.js"></script>
	
	<script type="text/javascript" src="{{!URL!}}skin/bootstrap/js/bootstrap.js"></script>
	<script  src="{{!URL!}}skin/js/syntax/scripts/shCore.js" type="text/javascript"></script>
	<script  src="{{!URL!}}skin/js/syntax/scripts/shBrushPhp.js" type="text/javascript"></script>
	<script type="text/javascript">SyntaxHighlighter.config.bloggerMode = false; SyntaxHighlighter.config.stripBrs = true; SyntaxHighlighter.defaults['toolbar'] = false; SyntaxHighlighter.all();</script>
	
	<link href="{{!URL!}}themes/{{!$this->theme!}}/css/doorgets.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="{{!URL!}}themes/{{!$this->theme!}}/js/doorgets.js"  ></script>
	
	<script type="text/javascript">var switchTo5x=true;</script>
	<script type="text/javascript" src="{{!URL!}}skin/js/sharethis.js"></script>
	<script type="text/javascript">stLight.options({publisher: "ur-18e3bdf-961f-e19f-ca63-7f3c4c06cf98",lang:"{{!$this->myLanguage!}}, doNotHash: false, doNotCopy: false, hashAddressBar: false"});</script>
	
    </head>
    <body>
    <div id="fb-root"></div>
    <script type="text/javascript">(function(d, s, id) {   var js, fjs = d.getElementsByTagName(s)[0]; if (d.getElementById(id)){ return; } js = d.createElement(s);  js.id = id;js.src = "//connect.facebook.net/{{!$lgFacebook!}}/all.js#xfbml=1"; fjs.parentNode.insertBefore(js, fjs); }(document, 'script', 'facebook-jssdk'));</script>