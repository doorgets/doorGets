<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 17 December, 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


 /*
  * Variables :
  * 
        $navigation[$uri_module]['label']
        $navigation[$uri_module]['type']
 */
 
$i = 1;
$cNav = count($navigation);


?>
<!-- doorGets:start:widgets/navigation -->
<button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse">
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
</button>
<div class="collapse navbar-collapse navHeaderCollapse">
    <ul class="nav navbar-nav navbar-right">
        
        {{/($navigation as $uri_module => $value_module):}}
            <li class="{{?(!empty($this->rubriques[$uri_module]['categories'])):}}dropdown{?} {{?( $uri_module === $this->module ):}}active{?} ">
                <a {{?(!empty($this->rubriques[$uri_module]['categories'])):}}class="dropdown-toggle" data-toggle="dropdown" {?}  href="{{!BASE_URL!}}?{{!$uri_module!}}">
                    {{!$value_module['label']!}} {{?(!empty($this->rubriques[$uri_module]['categories'])):}}<b class="caret"></b>{?}
                </a>
                {{?(!empty($this->rubriques[$uri_module]['categories'])):}}
                    <ul class="dropdown-menu">
                        {{/($this->rubriques[$uri_module]['categories'] as $uri_category=>$value_category):}}
                            {{$door = 'doorgets';}}{{?($this->rubriques[$uri_module]['type'] === 'multipage'):}}{{$door=$uri_module;}}{?}
                            <li ><a href="{{!BASE_URL!}}?{{!$door!}}={{!$uri_category!}}">{{!$value_category['name']!}}</a></li>
                        {/}
                    </ul>
                {?}
            </li>
            {{$i++;}}
        {/}
        {{!$this->getHtmlLanguages()!}}
    </ul>
</div>

<!-- doorGets:end:widgets/navigation -->
