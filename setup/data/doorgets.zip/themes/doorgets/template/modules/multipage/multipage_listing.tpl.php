<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 17 December, 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

 
 /*
  * Variables :
  *
  *
        $isContent['id_content']    => $id_content
        $isContent['categorie']     => $categorie
        $isContent['titre']         => $titre   
        $isContent['description']   => $description
        $isContent['uri']           => $uri
        $isContent['date_creation'] => $date_creation
        $isContent['article']       => $article
        $isContent['comments']      => $comments
        $isContent['sharethis']     => $sharethis
        $isContent['disqus']        => $disqus
        $isContent['facebook']      => $facebook

 */
 
 $nexContent = $Website->getUrlNextContent();
 $prevContent = $Website->getUrlPreviousContent();
 
?>
<!-- doorGets:start:modules/multipage/multipage_listing -->
<div class="doorGets-multipage-listing doorGets-module-{{!$Website->getModule()!}}">
    
    <div class="doorGets-multipage-contents ">
        {{?(!empty($isContent)):}}
        
            <div>
                {{!$article!}}
            </div>
            
            {{?($sharethis):}}
            <div class="box-sharethis">
                {{!$Website->getHtmlShareThis();}}
            </div>
            {?}
            
            {{?($comments):}}
            <div class="box-comment-listing">
                {{!$Website->getHtmlModuleComments()!}}
            </div>
            <div class="box-comments">
                {{!$Website->getHtmlComment();}}
            </div>
            {?}
            
            {{?($facebook):}}
            <div class="box-facebook">
                {{!$Website->getHtmlCommentFacebook();}}
            </div> 
            {?}
           
            {{?($disqus):}}
            <div class="box-disqus">   
                {{!$Website->getHtmlCommentDisqus();}}
            </div>
            {?}
            
            <div class="content-next-previous">
                <ul class="pager">
                    <li class="previous">
                        {{?(!empty($nexContent)):}}<a href="{{!$nexContent['url']!}}">&larr; {{!$nexContent['label']!}}</a>{?}
                    </li>
                    <li class="next">
                        {{?(!empty($prevContent)):}}<a href="{{!$prevContent['url']!}}">{{!$prevContent['label']!}} &rarr;</a>{?}
                    </li>
                </ul>
            </div>
            
        {?}
    </div>
</div>
<!-- doorGets:end:modules/multipage/multipage_listing -->