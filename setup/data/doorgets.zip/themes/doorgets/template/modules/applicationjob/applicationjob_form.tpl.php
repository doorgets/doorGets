<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.2 - 05, January 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

 
 /*
  * Variables :
  *
        $title
        $description
        $article
        $date_creation
 */
 
?>
<!-- doorGets:start:modules/applicationjob/applicationjob_form -->
<div class="doorGets-applicationjob-content doorGets-module-{{!$Website->getModule()!}}">
    <div class="jumbotron">
        <p>
            <h2>{{!$Website->l('Candidature spontanée');}}</h2>
            <p>{{!$Website->l('Veuilliez remplir le fomulaire suivant afin de nous contacter, nous vous contacterons rapidement...');}}</p>
        </p>
    </div>
    {{?($Website->form['contact_applicationjob']->isSended):}}
        <div class="alert alert-success">
            {{!$Website->l("Votre candidature à été envoyé")!}}, {{!$Website->l("nous prendrons contact avec vous rapidement")!}}, {{!$Website->l("merci")!}}.
        </div>
        {{ $_POST = array(); }}
        
    {?}
    
    {{!$Website->form['contact_applicationjob']->open('post')!}}
        {{!$Website->form['contact_applicationjob']->input('','secureFormulaire','hidden',$_SESSION['idForm'])!}}
        <div class="input-group">
            {{!$Website->form['contact_applicationjob']->input('<span class="red">*</span> '.$Website->l('Quel est votre métier').' ?<br />','sujet','text','','form-control')!}}
        </div>
        <div class="input-group">
            {{!$Website->form['contact_applicationjob']->input('<span class="red">*</span> '.$Website->l('Nom').'<br />','last_name','text','','form-control')!}}
        </div>
        <div class="input-group">
            {{!$Website->form['contact_applicationjob']->input('<span class="red">*</span> '.$Website->l('Prénom').'<br />','first_name','text','','form-control')!}}
        </div>
        <div class="input-group">
            {{!$Website->form['contact_applicationjob']->input('<span class="red">*</span> '.$Website->l('Adresse E-Mail').'<br />','email','text','','form-control')!}}
        </div>
        <div class="input-group">
            {{!$Website->form['contact_applicationjob']->file('<span class="red">*</span> '.$Website->l('Votre CV').'<br />','f_cv','form-control')!}}
        </div>
        <div class="input-group">
            {{!$Website->form['contact_applicationjob']->submit($Website->l('Envoyer votre candidature'),'','btn btn-success')!}}
            <div class="right">* {{!$Website->l('Champ obligatoire')!}}</div>
        </div>
        
        
    {{!$Website->form['contact_applicationjob']->close()!}}
    
</div>
<!-- doorGets:end:modules/applicationjob/applicationjob_form -->