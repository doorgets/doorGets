<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.0 - 01 Nov, 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

 
 /*
  * Variables :
  *
        $contents[$i]['uri']            => $uri
        $contents[$i]['title']          => $title
        $contents[$i]['description']    => $description
        $contents[$i]['article']        => $article
        $contents[$i]['categories']     => $categories
        $contents[$i]['order']          => $order
        $contents[$i]['date']           => $date

 */
 
 
?>
<!-- doorGets:start:modules/image/image_listing -->
<div class="doorGets-image-listing doorGets-module-{{!$Website->getModule()!}}">
    <div class="doorGets-categories right">
        {{!$Website->getHtmlModuleSearch($q)!}}
        <div class="separateur-tb"></div>
        <a href="{{!BASE_URL.'?'.$Website->getModule()!}}">{{!$Website->l('Catégories')!}}</a>
        <div class="separateur-tb"></div>
        <div class="separateur-tb"></div>
        {{!$Website->getHtmlModuleCategories()!}}
    </div>
    <div class="doorGets-listing-contents left">
        <div class="doorGets-listing-contents-title">
            {{!$ini!}} {{!$Website->l('à')!}} {{!$finalPer!}} {{!$Website->l('sur')!}} <b>{{!$totalContents!}} {{?($totalContents > 1):}} {{!$Website->l('images')!}} {??}  {{!$Website->l('image')!}}{?}</b>
            {{?(!empty($q)):}}
                {{!$Website->l('pour la recherche')!}} : <b>{{!$q!}}</b>
            {{???(empty($categoryLabel)):}}
                {{!$Website->l('dans toutes les catégories.')!}}
            {??}
                {{!$Website->l('dans la catégorie')!}} {{!$categoryLabel!}}.
            {?}
        </div>
        {{?(!empty($contents)):}}
            <ul>
            {{/($contents as $content):}}
                <li >
                    <a href="{{!BASE_URL!}}?{{!$Website->getModule()!}}={{!$content['uri']!}}" title="{{!$content['title']!}}">
                        <img src="{{!BASE!}}data/{{!$Website->getModule()!}}/middle/{{!$content['image']!}}"  />
                
                    </a>
                </li>
                
            {/}                
            </ul>
        {?}
        {{?(empty($contents)):}}
        <div class="info-not-found">
            {{!$Website->l('Aucune image trouvée')!}} {{?(!empty($q)):}}{{!$Website->l('pour votre recherche')!}}{?}.
        </div>
        {?}
        {{?(!empty($getPagination)):}}
            <br /><br />
            {{!$getPagination!}}
        {?}
    </div>
</div>
<!-- doorGets:end:modules/image/image_listing -->