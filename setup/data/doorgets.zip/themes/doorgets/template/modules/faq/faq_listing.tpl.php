<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 04 December, 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

 
 /*
  * Variables :
  *
  *
        $isContents

 */
 
 $_imgTop = URL.'/themes/'.$Website->getTheme().'/img/top.png';
 $i=$ii=1;
?>
<!-- doorGets:start:modules/faq/faq_listing -->
<div class="doorGets-faq-listing doorGets-module-{{!$Website->getModule()!}}">
    
    {{?(!empty($isContents)):}}
    
        <div >
            <div class="page-header">
                <p>
                    <h2>{{!$Website->l("Foire aux questions")!}}</h2>
                </p>
            </div>
            <ul class="q-bottom">
            {{/($isContents as $content):}}
                <li>
                    <div id="q-{{!$ii!}}" ><h3>Q: {{!$content['question']!}}</h3></div>
                    <div>{{!$content['reponse']!}}</div>
                    <div class="t-right"><a href="#wrap"><img src="{{!$_imgTop!}}" class="img-icone-top" />{{!$Website->l("Retour en Haut")!}}</a></div>
                    
                </li>
                {{$ii++;}}
            {/}
            </ul>
        </div>
        
    {?}
</div>
<!-- doorGets:end:modules/faq/faq_listing -->