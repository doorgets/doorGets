<?php

/**
 *
    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class GenSitemapXml extends Langue{
    
    private $xmlOut;
    
    
    public function __construct($lg= 'fr'){
        
        $this->setLangue($lg);
        $base = BASE;
        
        $this->xmlOut = '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
        $this->xmlOut .= "<url><loc>$base</loc><priority>1.00</priority><changefreq>daily</changefreq></url>";
        
        $this->Gen();
        
        $this->xmlOut .= '</urlset>';
        
        $fileSitemap = THM.'sitemap.xml';
        $newXml = new SimpleXMLElement($this->xmlOut);
        $newXml->asXML($fileSitemap);
        
    }
    
    public function Gen(){
        
        return $this->genXML();
    
    }
    
    
    
    private function genXML(){
        return $this->loadModuleActive();
    }
    
    public function loadModuleActive(){
        
        $module = $this->getRubriquePublic();
        $module = array_reverse($module,true);
        
        if(!empty($module)){
            foreach($module as $name=>$tab){
                
                switch($tab['type']){
                    
                    case 'page':
                        $this->getSysPage($name,$tab['titre']);
                        break;
                    
                    case 'link':
                        $this->getSysPage($name,$tab['titre']);
                        break;
                    
                    case 'news':
                        $this->getSysModule($name,$tab['titre']);
                        break;
                    
                    case 'blog':
                        $this->getSysModule($name,$tab['titre']);
                        break;
                    
                    case 'tuto':
                        $this->getSysModule($name,$tab['titre']);
                        break;
                    
                    case 'portefolio':
                        $this->getSysModule($name,$tab['titre']);
                        break;
                    
                    case 'liens':
                        $this->getSysPage($name,$tab['titre']);
                        break;
                    
                    case 'faq':
                        $this->getSysPage($name,$tab['titre']);
                        break;
                    
                    case 'contact':
                        $this->getSysPage($name,$tab['titre']);
                        break;
                    
                    case 'candidaturemodels':
                        $this->getSysPage($name,$tab['titre']);
                        break;
                    
                }
                
            }
        }
        
        
        
    }
    
    private function getSysPage($name,$titre){
        
        $uri = BASE.'?r='.$name;
        $this->xmlOut .=    "<url><loc>$uri</loc><priority>0.80</priority><changefreq>weekly</changefreq></url>";
        
    }
    
    private function getSysModule($name,$titre){
        
        $uri = BASE.'?r='.$name;
        $this->xmlOut .= "<url><loc>$uri</loc><priority>0.80</priority><changefreq>monthly</changefreq></url>";
        $this->getSysModuleCategories($name);
        
    }
    
    private function getSysModuleCategories($name){
        
        $out = '';
        $lgActu = $this->GetLangue();
        
        $sqlT = "
        SELECT _categories_traduction.uri, _categories_traduction.id,_categories.uri_module , _categories.id, _categories_traduction.nom
        FROM _categories, _categories_traduction
        WHERE _categories_traduction.langue =  '$lgActu'
        AND _categories.id = _categories_traduction.id_cat
        AND _categories.uri_module = '$name'
        ORDER BY _categories.ordre ASC 
        LIMIT 0 , 30";
        
        $isAllRC = $this->dbQ($sqlT);
        $cRC = count($isAllRC);
        if($cRC > 0){
            for($i=0;$i<$cRC;$i++){
                
                $uri = BASE.'?in='.$isAllRC[$i]['uri'];
                $this->xmlOut .=    "<url><loc>$uri</loc><priority>0.70</priority><changefreq>monthly</changefreq></url>";
                $this->getSysModuleContent($name,$isAllRC[$i]['id']);
            }
        }
        
        return $out;
        
    }
    
    private function getSysModuleContent($name,$categorie){
        
        $out = '';
        $table = '_m_'.$name;
        $tableTrad = '_m_'.$name.'_traduction';
        
        $lgActu = $this->GetLangue();
        
        $sqlT = "
        SELECT $table.active, $tableTrad.uri, $tableTrad.titre
        FROM $table, $tableTrad
        WHERE $tableTrad.langue =  '$lgActu'
        AND $table.categorie =  '$categorie'
        AND $table.active = 1
        AND $table.id = $tableTrad.id_content
        ORDER BY $table.date_creation DESC 
        LIMIT 500";
        
        $isAllRC = $this->dbQ($sqlT);
        $cRC = count($isAllRC);
        $base = BASE;
        if($cRC > 0){
            
            for($i=0;$i<$cRC;$i++){
                
                $uri = BASE.'?'.$name.'='.$isAllRC[$i]['uri'];
                $this->xmlOut .=    "<url><loc>$uri</loc><priority>0.60</priority><changefreq>monthly</changefreq></url>";
                
            }
        }
        
        return $out;
        
    }
    
    
}