<?php

/**
 *
    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class ContentCommentaire extends Langue{
    
    public $tableComment;
    
    public $idBlog;
    
    public $countCommentaire;
    
    public $uri;
    
    public $module;

    private $sendMail;
    
    public function __construct($uri='blog',$table='_comments',$module = '',$lg= 'fr',$sendMail=0){
        
        $this->setLangue($lg);
        
        $this->tableComment = $table;
        $this->uri = $uri;
        $this->module = $module;
        $this->countCommentaire = $this->countCommentaire();
        $this->sendMail = $sendMail;
    }
    
    
    private function countCommentaire(){
        $module = $this->module;
        $iComments = $this->dbQ("SELECT COUNT(*) as counter FROM _comments
                               WHERE uri_content = '".$this->uri."'
                               AND uri_module = '$module'
                               AND validation = 1  AND archive = 0  ");
        $cResultsInt = (int)$iComments[0]['counter'];
        return $cResultsInt;
    
    }
    
    public function formCommentaire($module = 'no-module',$sendTo=0){
        
        $timeHack = 900;
        
        $out = '';
        
        $form = new formulaire('ajouter_commentaire');
        
            $erreur = '';
        
        if(!empty($form->i)){
            
            foreach($form->i as $k=>$v){
                
                if(
                    empty($v)
                ){
                    
                    $form->e['ajouter_commentaire_'.$k] = 'ok';
                    
                }
                
            }
            
            $var = $form->i['email'];
            $isEmail = filter_var($var, FILTER_VALIDATE_EMAIL);
            if( empty($isEmail) ){
                
                $form->e['ajouter_commentaire_email'] = 'ok';
                
            }
            
            $varIp = $_SERVER['REMOTE_ADDR'];
            $varIpExist = $this->dbQS($varIp,'_comments','adress_ip',' ORDER BY date_creation DESC LIMIT 1 ');
            if( !empty($varIpExist) ){
                
                $timeLeft = time() - $varIpExist['date_creation'];
                
                $timeOk = $timeHack - $timeLeft;
                $timeOk = $timeOk / 60;
                $timeOk = ceil($timeOk);
                
                $timeS = ''; if( $timeOk > 1 ){ $timeS = 's'; }
                
                if($timeLeft < $timeHack){
                    $form->e[0] = '1';
                    $erreur = '<div class="helper_view_content padding center" style="color:#ff0000;padding-top:12px;">'.$this->getWords("Vous venez d'envoyer un commentaire, le temps d'attente pour envoyer un nouveau commentaire est de")." <b>".$timeOk.' minute'.$timeS.'</b> </div>';
                }
                
            }
            
            if(empty($form->e)){
                
                
                $data = $form->i;
                $data['uri_module'] = $module;
                $data['uri_content'] = $this->uri;
                $data['date_creation'] = time();
                $data['adress_ip'] = $_SERVER['REMOTE_ADDR'];
                
                $id = $this->dbQI($data,'_comments');
                
                $isGotoOut = 1;

                if(!empty($this->sendMail) && !empty($sendTo)){

                    $_email = $sendTo;
                    $_sujet = $this->getWords("Commentaire").' / '.$data['uri_module'].' / '.$data['uri_content'];

                    $newAlertAdmin = new SendMailAlert($_email,$_sujet,$this->getLangue());
                    
                }
                    
        

            }
            
            
        }
        if(isset($isGotoOut)){
            
            $out .= $this->outCommentaire();
            
        }else{
            
            $file = THM.'theme/'.$this->theme.'/img/comment_blog.png';
            $iBlogS = $this->getWords("Commentaire");
            if( $this->countCommentaire > 1 ){ $iBlogS = $this->getWords("Commentaires");; }
            
            $isDisplay = 'display:none;';
            $isDisplayMasquer = '';
            $lkComment = '&amp;commentaire=1';
            if( isset($_GET['commentaire']) ){ $isDisplayMasquer = 'display:none;'; $isDisplay = ''; $lkComment = ''; }
            
            $fTpl = TplTranslate::get($this->theme,'m.comments.form.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
            
        }
        
        return $out;
    
    }
    
    
    public function outCommentaire(){
        
        $imgMessageOk = THM.'theme/'.$this->theme.'/img/silouhettes_candidature.png';
        $commentValide = $this->getWords("Votre commentaire est en cours de modération, Merci.");
        
        $fTpl = TplTranslate::get($this->theme,'m.comments.val.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        return $out;
        
    }
    

    public function listingCommentaire($uri){
        
        $out = '';
        $module = $this->module;
        $Comments = $this->dbQ("SELECT * FROM _comments WHERE uri_module = '$module' AND uri_content = '$uri'  AND validation = 1  AND archive = 0   ORDER BY date_validation DESC ");
        $iComments = $this->countCommentaire;
        $file = THM.'theme/'.$this->theme.'/img/comment_blog.png';
        
        $fTpl = TplTranslate::get($this->theme,'m.comments.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        return $out;
    }

}