<?php

/**
 *
    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class WebsiteTraduction extends Langue{
    
    private $content;
    
    public function __construct($lg = 'fr'){
        
        
        $this->setLangue($lg);
        $lgActuel = $this->getLangueTradution();
        //var_dump($this->configInfo);
        $isPage = $this->dbQS($lgActuel,'_website_traduction','langue');
        
        if( empty($isPage) ){
            
            $data['langue'] = $lgActuel;
            $data['title'] = $this->configInfo['title'];;
            $data['slogan'] = $this->configInfo['slogan'];;
            $data['description'] = $this->configInfo['description'];;
            $data['copyright'] = $this->configInfo['copyright'];;
            $data['year'] = $this->configInfo['year'];
            $data['keywords'] = $this->configInfo['keywords'];
            $data['date_modification'] = time();
            
            
            $data['id'] = $this->dbQI($data,'_website_traduction');
            
            $this->content = $data;
            
        }else{
            
            $this->content = $isPage;
            
        }
        
        
    }
    
    public function content(){
        
        return $this->content;
        
    }
    
    
}