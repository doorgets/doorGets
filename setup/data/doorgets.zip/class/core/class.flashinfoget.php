<?php

/**
 *
    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class FlashInfoGet{
    
    private $Get;
    
    public function __construct(){
        
        $out = '';
        
        if( isset($_SESSION['flashInfo']) && $_SESSION['flashInfo']['message'] && $_SESSION['flashInfo']['type'] ){
            
            $out .= '<div id="flash" ><div  ';
            switch($_SESSION['flashInfo']['type']){
                case 'success':
                    $out .= ' id="flashOk" > ';
                    break;
                case 'error':
                    $out .= ' id="flashNoOk" > ';
                    break;
                case 'info':
                    $out .= ' id="flashInfo" > ';
                    break;
            }
            $out .= '<img src="'.URL.'ad_/img/info.png" style="vertical-align:middle;margin-right:8px;" >';
            $out .= $_SESSION['flashInfo']['message'];
            $out .= '<span id="closeFlash" style="float:right;cursor:pointer;" ><img src="'.URL.'ad_/img/close.png" style="vertical-align:middle;margin-top:5px;" ></span></div></div>';
            
            unset( $_SESSION['flashInfo'] );
            
        }
        
        $this->Get = $out;
        
    }
    
    public function Get(){
        
        return $this->Get;
    }
    
    
}