<?php

/**
 *
    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class Langue extends CRUD{
    
    public $GetLangue;
    private $w = array();
    private $wDefaut = array();
    public $lg = array();
    public $configInfo = array();
    public $theme;
    
    
    
    public function loadConfigInfo(){
        
        
        
        $myProfilSetting = $this->dbQS(1,'_website');
    
        $out = array();
        
        if(!empty($myProfilSetting)){
            
            $out = $myProfilSetting;
            $out['langue_groupe'] = unserialize($out['langue_groupe']);
        }
        
        $this->configInfo = $out;
        
        return $this->configInfo;
    }
    
    public function setLangue($lg = 'fr'){
        
        parent::__construct();
        
        $this->GetLangue = $lg;
        
        $infoWeb = $this->dbQS(1,'_website');
        if(!empty($infoWeb)){
            $this->configInfo = $infoWeb;
            $this->theme = $infoWeb['theme'];      
        }

        
        $arrLangue['en'] = 'English';
        $arrLangue['fr'] = 'Français';
        $arrLangue['de'] = 'Deutsch';
        $arrLangue['es'] = 'Español';
        $arrLangue['pl'] = 'Polski';
        $arrLangue['ru'] = 'Pусский';
        $arrLangue['tu'] = 'Türk';
        $arrLangue['po'] = 'Português';
        $arrLangue['su'] = 'Svenska';
        $arrLangue['it'] = 'Italiano';
        
        $this->lg = $arrLangue;
        
        $fileLangue = THM.'langue/'.$this->GetLangue.'.php';
        $fileLanguePrincipale = THM.'langue/fr.php';
        
        include $fileLanguePrincipale;
        
        $this->w = $w;
        $this->wDefaut = $w;
        
        if( $fileLanguePrincipale !== $fileLangue && is_file($fileLangue) ){
            
            include $fileLangue;
            $this->w = $w;
            
        }
        
        
    }
    
    public function GetLangue(){
        
        return $this->GetLangue;
        
    }
    
    
    public function getWords($word = ''){
        $word = mb_strtolower($word,'UTF-8');
        if(in_array($word,$this->wDefaut)){
            
            $key = array_search($word,$this->wDefaut);
            
            if(array_key_exists($key,$this->w)){
                return ucfirst($this->w[$key]);
            }
            
        }
        
        return $word;
        
    }
    
    protected function genLangueMenu(){
        
        $out ='';
        $url = '?';
        foreach($_GET as $k=>$v){
            if($k !== 'lg'){
                $url .= $k;
                if(!empty($v)){
                    $url .= '='.$v;
                }
                $url .= '&';                
            }

        }
        
        $info = $this->loadConfigInfo();
        if(!empty($info['langue_groupe'])){
            
            $out .= '<div>';
            foreach($this->lg as $k=>$v){
                if( array_key_exists($k,$info['langue_groupe']) ){
                    
                    $out .= '<a ';
                    if( (isset($_GET['lg']) && $_GET['lg']===$k) ){
                        
                        $out .= ' class="annuler" ';
                    }
                    
                    if( !isset($_GET['lg']) && $k === $this->GetLangue() ){
                        $out .= ' class="annuler" ';
                    }
                    
                    $out .= ' href="'.$url.'lg='.$k.'">'.$v.'</a> | ';
                    
                }
                
            }
            $out = substr($out,0,-3);
            $out .= '</div>';
            
        }
        
        
        return $out;
        
    }
    
    protected function genLangueMenuFrontOffice(){
        
        $out ='';
        $url = URL.'t/';
        
        
        $info = $this->loadConfigInfo();
        if(!empty($info['langue_groupe'])){
            
            $rubInMenu = '';
            if(isset($_GET['r'])){
                
                $rubrique = filter_input(INPUT_GET,'r',FILTER_SANITIZE_STRING);
                $rubInMenu = '?r='.$rubrique;
            }
            
            $isInLangue = array();
            
            $info['langue_groupe'][$info['langue_front']] = $this->lg[$info['langue_front']];
            $allRubs = $this->getRubriquePublic();
            foreach($this->lg as $langue=>$langueVal){
                
                
                if( array_key_exists($langue,$info['langue_groupe']) ){
                    
                    
                    if(!empty($_GET)){
                        
                        foreach($_GET as $kk=>$vv){
                            
                            if( isset($_GET[$kk]) && array_key_exists($kk,$allRubs)) {
                                
                                $isIn = filter_input(INPUT_GET,$kk,FILTER_SANITIZE_STRING);
                                $isIntad = $this->dbQS($isIn,'_m_'.$kk.'_traduction','uri');
                                if(!empty($isIntad)){
                                    
                                    $idTrad = $this->dbQS($isIntad['id_content'],'_m_'.$kk.'_traduction','id_content', " AND langue = '$langue' LIMIT 1");
                                    $rubInMenu = '?'.$kk.'='.$idTrad['uri'];
                                    break;
                                }
                            }
                            
                        }
                        
                        if( isset($_GET['in']) ) {
                            
                            $isModule = '';
                            $isCat = filter_input(INPUT_GET,'in',FILTER_SANITIZE_STRING);
                            
                            $isInCat = $this->dbQS($isCat,'_categories_traduction','uri');
                            if(!empty($isInCat)){
                                
                                $isModule = $this->dbQS($isInCat['id_cat'],'_categories');
                                if(!empty($isModule)){
                                    
                                    $isInCatTrad = $this->dbQS($isModule['id'],'_categories_traduction','id_cat', " AND langue = '$langue' LIMIT 1");
                                    
                                    $rubInMenu = '?in='.$isInCatTrad['uri'];
                                    
                                }
                            }
                            
                        }
                    }
                    
                    $isInLangue[$langue]['val'] = $langueVal;
                    $isInLangue[$langue]['rubrique'] = $rubInMenu;
                    
                }
                
            }
            
            $cIsInLangue = count($isInLangue);
            $fTpl = TplTranslate::get($this->theme,'m.langue.tpl.php');
            include $fTpl;
            $out = ob_get_clean();
            
        }
        
        
        return $out;
        
    }
    
    protected function getLangueTradution(){
        
        $out = $this->GetLangue();
        $info = $this->loadConfigInfo();
        if( isset($_GET['lg']) && array_key_exists($_GET['lg'],$this->lg) && array_key_exists($_GET['lg'],$info['langue_groupe']) ){
            
            $out = filter_input(INPUT_GET,'lg',FILTER_SANITIZE_STRING);
            
        }
        return $out;
        
    }
    
    public function loadCategorie($module=''){
        
        $out = array(0=>'Choisir...');
        $outs = array();
        
        $isAllRC = $this->dbQ("
        SELECT _categories.id as id,
        _categories.uri_module as module,
        _categories_traduction.nom as nom,
        _categories_traduction.uri as uri
        FROM _categories,_categories_traduction
        WHERE  _categories.id = _categories_traduction.id_cat
        AND _categories.uri_module = '$module'
        AND _categories_traduction.langue = '".$this->getLangueTradution()."'
        ORDER BY _categories.ordre ASC ");
        
        $cRC = count($isAllRC);
        if($cRC > 0){
            for($i=0;$i<$cRC;$i++){
                
                $out[$isAllRC[$i]['id']] = $isAllRC[$i]['nom'];
                
                $outs[$isAllRC[$i]['uri']] = $isAllRC[$i]['nom'];
            }
        }
        $this->categorieSimple = $out;
        return $outs;
        
    }
    
    protected function getRubriquePublic(){
        
        
        
        $rubOut = array();
        $isGroupeRubrique = $this->dbQ("SELECT * FROM _rubrique ORDER BY ordre DESC");
        if( !empty($isGroupeRubrique) ){
            foreach($isGroupeRubrique as $v ){
                
                if( !empty($v['idModule']) ){
                    
                    $isModule = $this->dbQS($v['idModule'],'_modules');
                    
                    if( !empty($isModule) AND $isModule['active'] === '1'){
                        
                        $isModuleTrad = $this->dbQS($v['idModule'],'_modules_traduction','id_module'," AND langue = '".$this->GetLangue()."'");
                        if( !empty($isModuleTrad) ){
                            
                            $rubOut[$isModule['uri']] = $isModuleTrad;
                            
                        }
                        
                    }
                }
                if( !empty($v['idModule']) ){
                    
                    $isModule = $this->dbQS($v['idModule'],'_modules');
                    
                    if( !empty($isModule) AND $isModule['active'] === '1' ){
                        
                        $isModuleTrad = $this->dbQS($v['idModule'],'_modules_traduction','id_module'," AND langue = '".$this->GetLangue()."'");
                        if( !empty($isModuleTrad) ){
                            
                            $rubOut[$isModule['uri']]['nom'] = $isModuleTrad['nom'];
                            $rubOut[$isModule['uri']]['type'] = $isModule['type'];
                            
                        }
                        
                    }
                }   
            }

        }
        
        return $rubOut;
        
    }
    
    public function clearCache() {
        
        $dir = THM.'cache/database/';
        
        foreach (scandir($dir) as $file) { 
            if ($file == '.' || $file == '..') continue;
            $f = $dir.$file;
            if(is_file($f)){
                unlink($f);
            }
        }
    } 
    
}