<?php

/**

    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class CandidatureFrontOffice extends Langue{
    
    private $isSend = 0;
    
    private $get;
    
    private $message;
    
    private $name;
    
    public function __construct($name = '',$lg= 'fr'){
        
        $this->name = $name;
        $this->setLangue($lg);
        $this->get = $this->formCandidature();  
        
    }
    
    public function get(){
        
        return $this->get;
        
    }
    
    
    private function formCandidature(){
        
        return $this->formAjouter();
        
    }
    
    public function outContact(){
        
        $message = $this->message;
        $imgMessageOk = THM.'ad_/img/activer.png';
        
        $fTpl = TplTranslate::get($this->theme,'m.candidaturemodels.val.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
        
    }
    
    public function formAjouter(){
        
        $out = '';
        
        $form = new formulaire('ajouter_candidature');
        
        if(!empty($form->i)){
            
            foreach($form->i as $k=>$v){
                if(
                    empty($v)
                    && $k !== 'photo_visage' && $k !== 'photo_profil'
                    && $k !== 'photo_face' && $k !== 'photo_autre'
                ){
                    
                    $form->e['ajouter_candidature_'.$k] = 'ok';
                    
                }
            }
            
            $var = $form->i['email'];
            $isEmail = filter_var($var, FILTER_VALIDATE_EMAIL);
            $isEmailExist = $this->dbQS($var,'candidature','email');
            if( !empty($isEmailExist) ){
                
                $form->e['ajouter_candidature_email'] = 'ok';
                
            }
            if( empty($isEmail) ){
                
                $form->e['ajouter_candidature_email'] = 'ok';
                
            }
            
            
            $extension = '.png';
            
            if (    isset($_FILES['ajouter_candidature_photo_visage']) &&
                    (
                        $_FILES['ajouter_candidature_photo_visage']["type"] == "image/jpeg"
                        || $_FILES['ajouter_candidature_photo_visage']["type"] == "image/png"
                    )
                    && ($_FILES['ajouter_candidature_photo_visage']["error"] === 0 )
            ){
                
                if($_FILES['ajouter_candidature_photo_visage']["type"] == "image/jpeg"){
                    $extension = '.jpg';
                }
                
            }else{
                
                $form->e['ajouter_candidature_photo_visage'] = 'ok';
            }
            
            if(empty($form->e)){
                
                $uni = time().'-'.uniqid('doorgets').'';
                $uploaddir = THM.'/data/'.$this->name.'/';
                if(!is_dir($uploaddir)){
                    mkdir($uploaddir);
                }
                
                $nameFileImage = $uni.'-models-visage'.$extension;
                
                $uploadfile = $uploaddir . $nameFileImage;
                
                if(
                   move_uploaded_file($_FILES['ajouter_candidature_photo_visage']['tmp_name'], $uploadfile)
                ){
                    $form->i['photo_visage'] = $nameFileImage;
                }
                
                // traitement de photo face
                
                if (    isset($_FILES['ajouter_candidature_photo_face']) &&
                        (
                            $_FILES['ajouter_candidature_photo_face']["type"] == "image/jpeg"
                            || $_FILES['ajouter_candidature_photo_face']["type"] == "image/png"
                        )
                        && ($_FILES['ajouter_candidature_photo_face']["error"] === 0 )
                ){
                    
                    if($_FILES['ajouter_candidature_photo_face']["type"] == "image/jpeg"){
                        $extension = '.jpg';
                    }
                    
                }
                
                $nameFileImage = $uni.'-models-face'.$extension;
                
                $uploadfile = $uploaddir . $nameFileImage;
                if(
                   move_uploaded_file($_FILES['ajouter_candidature_photo_face']['tmp_name'], $uploadfile)
                ){
                    $form->i['photo_face'] = $nameFileImage;
                }
                
                // traitement de photo profil
                
                if (    isset($_FILES['ajouter_candidature_photo_profil']) &&
                        (
                            $_FILES['ajouter_candidature_photo_profil']["type"] == "image/jpeg"
                            || $_FILES['ajouter_candidature_photo_profil']["type"] == "image/png"
                        )
                        && ($_FILES['ajouter_candidature_photo_profil']["error"] === 0 )
                ){
                    
                    if($_FILES['ajouter_candidature_photo_profil']["type"] == "image/jpeg"){
                        $extension = '.jpg';
                    }
                    
                }
                
                $nameFileImage = $uni.'-models-profil'.$extension;
                
                $uploadfile = $uploaddir . $nameFileImage;
                if(
                   move_uploaded_file($_FILES['ajouter_candidature_photo_profil']['tmp_name'], $uploadfile)
                ){
                    $form->i['photo_profil'] = $nameFileImage;
                }
                
                // traitement de photo autre
                
                if (    isset($_FILES['ajouter_candidature_photo_autre']) &&
                        (
                            $_FILES['ajouter_candidature_photo_autre']["type"] == "image/jpeg"
                            || $_FILES['ajouter_candidature_photo_autre']["type"] == "image/png"
                        )
                        && ($_FILES['ajouter_candidature_photo_autre']["error"] === 0 )
                ){
                    
                    if($_FILES['ajouter_candidature_photo_autre']["type"] == "image/jpeg"){
                        $extension = '.jpg';
                    }
                    
                }
                
                $nameFileImage = $uni.'-models-autre'.$extension;
                
                
                $uploadfile = $uploaddir . $nameFileImage;
                if(
                   move_uploaded_file($_FILES['ajouter_candidature_photo_autre']['tmp_name'], $uploadfile)
                ){
                    $form->i['photo_autre'] = $nameFileImage;
                }
                
                
                
            }
            
            if(empty($form->e)){
                
                $formulaireEnvoyer = 1;
                $data = $form->i;
                $data['uri_module'] = $this->name;
                $data['date_creation'] = time();
                
                $idUser = $this->dbQI($data,'candidature');
                
                // Mail 
                $moduleInfo = $this->dbQS($this->name,'_modules','uri');
                if( !empty($moduleInfo) && !empty($moduleInfo['notification_mail'])){

                    $_email = $this->configInfo['email'];
                    $_sujet = $this->getWords("Candidat").' / '.ucfirst($this->name).'['.$idUser.']';

                    $newAlertAdmin = new SendMailAlert($_email,$_sujet,$this->getLangue());

                }
            }
            
        }
        
        if(isset($formulaireEnvoyer)){
            
            $out .= $this->outContact();
            
        }else{
            
            $fTpl = TplTranslate::get($this->theme,'m.candidaturemodels.form.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
        
        }
        
        return $out;
        
    }
    
}