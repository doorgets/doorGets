<?php

/**
 *
    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class NewsletterFrontOffice{
    
    static function formInscription($lg='fr'){
        
        $out = '';
        $isLangue = new Langue();
        $isLangue->setLangue($lg);
        
        $form = new Formulaire('ajouter_newsletter');
        
        if(!empty($form->i)){
        
            foreach($form->i as $k=>$v){
                if( empty($v) ){ $form->e['ajouter_newsletter_'.$k] = 'ok'; }
            }
            
            $var = $form->i['email'];
            $isEmail = filter_var($var, FILTER_VALIDATE_EMAIL);
            $isEmailExist = $isLangue->dbQS($var,'newsletter','email'," AND id_user = 1 LIMIT 1 ");
            
            if( !empty($isEmailExist) ){ $form->e['ajouter_newsletter_email'] = 'ok'; }
            if( empty($isEmail) ){ $form->e['ajouter_newsletter_email'] = 'ok'; }

            if( empty($form->e )){ 
                
                $data = $form->i; $data['date_creation'] = time(); 
                $idUser = $isLangue->dbQI($data,'newsletter'); 

                header('Location:'.$_SERVER['REQUEST_URI'].'&ok#newsletter'); 
                $_GET['ok'] = 1;
            }
            
        }
        
        if(!isset($_GET['ok'])){
            
            $isDisplay = 'display:none;';
            $isDisplayMasquer = '';
            $lkNewsletter = '&newsletter=1';
            if( empty($_GET) ){ $lkNewsletter = '?newsletter=1'; }
            if( isset($_GET['newsletter']) ){ $isDisplayMasquer = 'display:none;'; $isDisplay = ''; $lkNewsletter = '&newsletter=1'; }
            
            
            $fTpl = TplTranslate::get($isLangue->theme,'m.newsletter.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
            
        }else{
            
            $imgMessageOk = THM.'theme/img/message_envoye.jpg';
            $msgOk = $isLangue->getWords("Vous êtes maintenant inscrit à la newsletter. Merci.");
            
            $fTpl = TplTranslate::get($isLangue->theme,'m.newsletter.val.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
            
        }
        
        return $out;
    
    }
    
}