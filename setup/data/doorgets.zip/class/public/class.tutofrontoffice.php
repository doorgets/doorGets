<?php

/**
 *
    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class TutoFrontOffice extends Langue{
    
    private $get;
    
    public $table;
    
    public $categorie;
    
    public $categorieSimple;
    
    public $rubrique;
    
    public $uri;

    public $bynum;

    public $bynumavoiraussi;
    
    public function __construct($table = 'tuto',$uri = 'tuto',$bynum = '10',$bynumavoiraussi = '3',$lg= 'fr'){
        
        $this->setLangue($lg);
        $q = '';
        
        if( isset($_GET['q']) && !empty($_GET['q']) ){
            
            $q = filter_input(INPUT_GET,'q',FILTER_SANITIZE_STRING);
            $q = mb_strtolower($q,'UTF-8');
        }
        
        $this->bynum = $bynum;
        $this->bynumavoiraussi = $bynumavoiraussi;
        $this->uri = $uri;
        
        $this->table = $table;
        
        $this->categorie = $this->loadCategorie($this->uri);
        
        $this->rubrique = 'all';
        if( isset($_GET['in']) ){
            $this->rubrique = filter_input(INPUT_GET,'in',FILTER_SANITIZE_STRING);
        }
        
        $out = '';
        
        $this->get .=  $this->formSearch();
        
        
        if(isset($_GET[$this->uri]) ){
            
            $idContent = ctype_alnum(str_replace('-','',$_GET[$this->uri]));
            if($idContent){
                
                $this->get .=   $this->voir($_GET[$this->uri]);
    
            }else{
                
                header('Location:./?r='.$this->uri);
                exit;
                
            }
            
            
            
        }else{
            
            $this->get .=  $this->rubriqueCategorie();
            $this->get .=   $this->listing($this->bynum);
            
        }
        
    }
    
    public function get(){
        
        return $this->get;
        
    }
    
    
    public function voir($uri){
        
        $fileTag = THM.'theme/'.$this->theme.'/img/tag.png';
        $fileComment = THM.'theme/'.$this->theme.'/img/comment_blog.png';
        $fileCalendar = THM.'theme/'.$this->theme.'/img/calendar.png';
        $fileTuto = THM.'theme/'.$this->theme.'/img/tuto.png';
        $fileTime = THM.'theme/'.$this->theme.'/img/icone_time.png';
        
        $out = '';
        
        $isTuto = $this->dbQS($uri,$this->table.'_traduction','uri');
        if(empty($isTuto)){
            
            header('Location:./?r='.$this->uri);
            exit;
            
        }else{
            
            $moduleName = '';
            
            $isModule = $this->dbQS($this->uri,'_modules','uri');
            if(!empty($isModule)){
                $isModuleTrad = $this->dbQS($isModule['id'],'_modules_traduction','id_module'," AND langue = '".$this->GetLangue()."' LIMIT 1 ");
                if(!empty($isModuleTrad)){
                    $moduleName = $isModuleTrad['nom'];
                }
            }
            
            $isTutoActive = $this->dbQS($isTuto['id_content'],$this->table,'id');
            if( empty($isTutoActive) || empty($isTutoActive['active']) ){
                header('Location:./?r='.$this->uri);
                exit;
            }
            
            $tutoComment = new ContentCommentaire($isTutoActive['id'],'_comments',$this->uri,$this->GetLangue(),$isTutoActive['partage']);
            $sComm = $this->getWords('Commentaire');
            if($tutoComment->countCommentaire > 1){ $sComm = $this->getWords('Commentaires'); }
            
            $this->rubrique = $isTuto['categorie'];
            
            $fTpl = TplTranslate::get($this->theme,'m.tuto.voir.tpl.php');
            ob_start();
            include $fTpl;
            $out .= ob_get_clean();
            
            if($isTutoActive['partage']){
                
                $fTpl = TplTranslate::get($this->theme,'m.tuto.sharethis.tpl.php');
                ob_start();
                include $fTpl;
                $out .= ob_get_clean();
                
            }
            if($isTutoActive['comments']){

                $out .= $tutoComment->formCommentaire($this->uri,$isTutoActive['sendto']);
                $out .= $tutoComment->listingCommentaire($isTutoActive['id'],$this->uri);

            }
            
            if($isTutoActive['disqus']){

                $idDisqus = $isTutoActive['id_disqus'];

                $fTpl = TplTranslate::get($this->theme,'m.comments.disqus.tpl.php');
                ob_start();
                include $fTpl;
                $out .= ob_get_clean();
                
            }

            if($isTutoActive['facebook']){
                
                $urlFacebook = URL.'?'.$this->uri.'='.$isTuto['uri'];

                $fTpl = TplTranslate::get($this->theme,'m.comments.facebook.tpl.php');
                ob_start();
                include $fTpl;
                $out .= ob_get_clean();
                
            }
            
            $out .= $this->getRandumContent(6,$isTutoActive['id']);
            
        }
        
        
        
        return $out;
        
        
    }
    
    public function listing($par=9){
        
        $fileTag = THM.'theme/'.$this->theme.'/img/tag.png';
        $fileComment = THM.'theme/'.$this->theme.'/img/comment_blog.png';
        $fileCalendar = THM.'theme/'.$this->theme.'/img/calendar.png';
        $fileTime = THM.'theme/'.$this->theme.'/img/icone_time.png';
        
        $q = '';
        
        if( isset($_GET['q']) && !empty($_GET['q']) ){
            
            $q = filter_input(INPUT_GET,'q',FILTER_SANITIZE_STRING);
            $q = mb_strtolower($q,'UTF-8');
        }
        
        $qN = '';
        if( !empty($q) ){
            $qN = '&amp;q='.$q;
        }
        
        $valFilter = 'date';
        $outFilterAND = '';
        $outFilterORDER = ' '.$this->table.'.date_creation DESC ';
        $outGroupe = 'all';
        $outSqlGroupe = "
        
        WHERE ".$this->table.".active = 1
        AND ".$this->table."_traduction.id_content = ".$this->table.".id
        AND ".$this->table."_traduction.langue = '".$this->GetLangue()."'
        ORDER BY ".$this->table.".date_creation DESC  ";
        
        $sqlGroupe = '';
        $getGroupe = '';
        
        $outRub = 'r='.$this->uri;
        
        if(isset($_GET['filter'])){
            $getFilter = filter_input(INPUT_GET,'filter',FILTER_SANITIZE_STRING);
            
        }
        if(isset($_GET['in'])){
            $getGroupe = filter_input(INPUT_GET,'in',FILTER_SANITIZE_STRING);
            $isCategorie = $this->dbQS($getGroupe,'_categories_traduction','uri');
            if(!empty($isCategorie)){
                $outGroupe = $getGroupe;
                $outSqlGroupe = "
                WHERE ".$this->table.".categorie = '".$isCategorie['id_cat']."'
                AND ".$this->table."_traduction.id_content = ".$this->table.".id
                AND  ".$this->table.".active = 1
                AND ".$this->table."_traduction.langue = '".$this->GetLangue()."'
                ORDER BY ".$this->table.".date_creation DESC  ";
                
                $outRub = 'in='.$getGroupe;
            }
        }
        
        if( !empty($q) ){
            $outSqlGroupe = "
            WHERE ".$this->table."_traduction.id_content = ".$this->table.".id
            AND ".$this->table.".active = 1
            AND ".$this->table."_traduction.langue = '".$this->GetLangue()."' ";
        }
        
        $champsliste[] = $this->table.'_traduction.titre';
        $champsliste[] = $this->table.'_traduction.description';
        $champsliste[] = $this->table.'_traduction.uri';
        $champsliste[] = $this->table.'_traduction.meta_titre';
        $champsliste[] = $this->table.'_traduction.meta_description';
        $champsliste[] = $this->table.'_traduction.meta_keys';
        
        if( !empty($q) && !empty($champsliste) ){
            $sqlGroupe .= " AND (";
            foreach($champsliste as $v){
                $sqlGroupe .= " ".$v." LIKE '%".$q."%' OR";
            }
            $sqlGroupe = substr($sqlGroupe,0,-2);
            $sqlGroupe .= ") ";
        }
        
        $outSqlGroupe = $outSqlGroupe.$sqlGroupe;
        
        $iUsers = $this->dbQ('SELECT COUNT(*) as counter FROM '.$this->table.', '.$this->table.'_traduction '.$outSqlGroupe);
        $cResultsInt = (int)$iUsers[0]['counter'];
        
        $urlPage = BASE."?$outRub$qN&amp;page=";
        
        $p = 1;
        $ini = 0;
        $per = $par;
        
        if(isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] <= (ceil($cResultsInt / $per))){
            
            $p = $_GET['page'];
            $ini = $p * $per - $per;
        }
        
        $sqlLimit = " $outSqlGroupe  LIMIT ".$ini.",".$per;
        
        if($cResultsInt > $per){
            
            $valPage = '<div class="pagination">'.PaginationFrontOffice::page($cResultsInt,$p,$per,$urlPage).'</div>';
            
            
        }else{
            $valPage = '';
        }
        
        $all = $this->dbQ('SELECT * FROM '.$this->table.', '.$this->table.'_traduction '.$sqlLimit);
        $cAll = count($all);
        
        $finalPer = $ini+$per;
        if( $finalPer >  $cResultsInt){
            $finalPer = $cResultsInt;
        }
        
        $out = '';
        $q = '';
        
        if( isset($_GET['q']) && !empty($_GET['q']) ){
            
            $q = filter_input(INPUT_GET,'q',FILTER_SANITIZE_STRING);
            $q = mb_strtolower($q,'UTF-8');
        }
        
        
        $fTpl = TplTranslate::get($this->theme,'m.tuto.index.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    }
    
    public function getRandumContent($par=3,$id){

        $par = $this->bynumavoiraussi;

        $fileTime = THM.'theme/'.$this->theme.'/img/icone_time.png';
        $fileTag = THM.'theme/'.$this->theme.'/img/tag.png';
        $fileComment = THM.'theme/'.$this->theme.'/img/comment_blog.png';
        $fileCalendar = THM.'theme/'.$this->theme.'/img/calendar.png';
        $q = '';
        
        
        $all = $this->dbQ('SELECT * FROM '.$this->table.', '.$this->table.'_traduction '."
                         WHERE ".$this->table.".id = ".$this->table."_traduction.id_content
                         AND ".$this->table.".active = 1
                         AND ".$this->table.".id != $id
                         AND ".$this->table."_traduction.langue = '".$this->GetLangue()."'
                         ORDER BY RAND() LIMIT $par");
        $cAll = count($all);
        
        
        $out = '';
        
        $fTpl = TplTranslate::get($this->theme,'m.tuto.randum.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    
    }


    
    
    public function loadCategorie($module=''){
        
        $out = array(0=>'Choisir...');
        $outs = array();
        
        $isAllRC = $this->dbQ("
        SELECT _categories.id as id,
        _categories.uri_module as module,
        _categories_traduction.nom as nom,
        _categories_traduction.uri as uri
        FROM _categories,_categories_traduction
        WHERE  _categories.id = _categories_traduction.id_cat
        AND _categories.uri_module = '$module'
        AND _categories_traduction.langue = '".$this->getLangueTradution()."'
        ORDER BY _categories.ordre ASC ");
        
        $cRC = count($isAllRC);
        if($cRC > 0){
            for($i=0;$i<$cRC;$i++){
                
                $out[$isAllRC[$i]['id']] = $isAllRC[$i]['nom'];
                
                $outs[$isAllRC[$i]['id']] = $isAllRC[$i]['uri'];
            }
        }
        $this->categorieSimple = $out;
        return $outs;
        
    }

    public function rubriqueCategorie(){
        
        $out = '';
        $rubrique = $this->categorieSimple;
        $categorie = $this->categorie;
        unset($rubrique[0]);
        
        $fTpl = TplTranslate::get($this->theme,'m.tuto.rubrique.tpl.php');
        ob_start();
        include $fTpl;
        $out .= ob_get_clean();
        
        return $out;
        
    }
    
    private function formSearch(){
        
        $q = '';
        
        if( isset($_GET['q']) && !empty($_GET['q']) ){
            
            $q = filter_input(INPUT_GET,'q',FILTER_SANITIZE_STRING);
            $q = mb_strtolower($q,'UTF-8');
        }
        $out = '';
        
        $fTpl = TplTranslate::get($this->theme,'m.search.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
        
    }
    
}