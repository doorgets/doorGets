<?php


/**

    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/


class PortefolioFrontOffice extends Langue{
    
    private $get;
    
    public $table;
    
    public $categorie;
    
    public $categorieSimple;
    
    public $rubrique;
    
    public $uri;

    public $bynum;

    public $bynumavoiraussi;
    
    public function __construct($table = 'portefolio',$uri = 'portefolio',$bynum = '10',$bynumavoiraussi = '3',$lg= 'fr'){
        
        $this->setLangue($lg);
        $q = '';
        
        if( isset($_GET['q']) && !empty($_GET['q']) ){
            
            $q = filter_input(INPUT_GET,'q',FILTER_SANITIZE_STRING);
            $q = mb_strtolower($q,'UTF-8');
        }
        
        $this->bynum = $bynum;
        $this->bynumavoiraussi = $bynumavoiraussi;
        $this->uri = $uri;
        
        $this->table = $table;
        
        $this->categorie = $this->loadCategorie($uri);
        
        $this->rubrique = 'all';
        if( isset($_GET['in']) ){
            $this->rubrique = filter_input(INPUT_GET,'in',FILTER_SANITIZE_STRING);
        }
        
        $out = '';
        
        //$this->get .=  $this->formSearch();
        
        
        if(isset($_GET[$this->uri]) ){
            
            $idContent = ctype_alnum(str_replace('-','',$_GET[$this->uri]));
            if($idContent){
                
                $this->get .=   $this->voir($_GET[$this->uri]);
    
            }else{
                
                header('Location:./?r='.$this->uri);
                exit;
                
            }
            
            
            
        }else{
            
            
            if( !isset($_GET['in']) ){
                
                $this->get .=   $this->home(50);
                
            }else{
                $this->get .=  $this->rubriqueCategorie();
                $this->get .=   $this->listing($this->bynum);
            }
            
            
        }
        
    }
    
    public function get(){
        
        return $this->get;
        
    }
    
    
    public function voir($uri){
        
        $fileTag = URL.'theme/'.$this->theme.'/img/tag.png';
        $fileComment = URL.'theme/'.$this->theme.'/img/comment_blog.png';
        $fileCalendar = URL.'theme/'.$this->theme.'/img/calendar.png';
        $filePortefolio = URL.'theme/'.$this->theme.'/img/portefolio.png';
        
        $out = '';
        
        $isPortefolio = $this->dbQS($uri,$this->table.'_traduction','uri');
        if(empty($isPortefolio)){
            
            header('Location:./?r='.$this->uri);
            exit;
            
        }else{
            
            $urlNext = '';
            $urlPrev = '';
            $urlImage = '';
            $moduleName = '';
            
            $isModule = $this->dbQS($this->uri,'_modules','uri');
            if(!empty($isModule)){
                $isModuleTrad = $this->dbQS($isModule['id'],'_modules_traduction','id_module'," AND langue = '".$this->GetLangue()."' LIMIT 1 ");
                if(!empty($isModuleTrad)){
                    $moduleName = $isModuleTrad['nom'];
                }
            }
            
            $isPortefolioBase = $this->dbQS($isPortefolio['id_content'],$this->table);
            
            if(!empty($isPortefolioBase)){
                
                $iPlus = $isPortefolioBase['ordre'] + 1;
                
                $isPortefolioNext = $this->dbQS($iPlus,$this->table,'ordre'," AND categorie = '".$isPortefolioBase['categorie']."'  LIMIT 1");
                if(!empty($isPortefolioNext)){
                    
                    $isPortefolioNextTrad = $this->dbQS($isPortefolioNext['id'],$this->table.'_traduction','id_content'," AND langue = '".$this->GetLangue()."' ");
                    if(!empty($isPortefolioNextTrad)){
                        
                        $urlNext = BASE.'?'.$this->uri.'='.$isPortefolioNextTrad['uri'].'#content';
                        $urlImage = $urlNext;
                    }
                    
                }else{
                    
                    $isPortefolioNext = $this->dbQS(1,$this->table,'ordre'," AND categorie = '".$isPortefolioBase['categorie']."'  LIMIT 1");
                    if(!empty($isPortefolioNext)){
                        
                        $isPortefolioNextTrad = $this->dbQS($isPortefolioNext['id'],$this->table.'_traduction','id_content'," AND langue = '".$this->GetLangue()."' ");
                        if(!empty($isPortefolioNextTrad)){
                            
                            $urlImage = BASE.'?'.$this->uri.'='.$isPortefolioNextTrad['uri'].'#content';
                        }
                    }

                    
                }
                $iMoins = $isPortefolioBase['ordre'] - 1;
                $isPortefolioPrev = $this->dbQS($iMoins,$this->table,'ordre'," AND categorie = '".$isPortefolioBase['categorie']."'  LIMIT 1");
                if(!empty($isPortefolioPrev)){
                    
                    $isPortefolioPrevTrad = $this->dbQS($isPortefolioPrev['id'],$this->table.'_traduction','id_content'," AND langue = '".$this->GetLangue()."' ");
                    if(!empty($isPortefolioPrevTrad)){
                        
                        $urlPrev = BASE.'?'.$this->uri.'='.$isPortefolioPrevTrad['uri'].'#content';
                        
                    }
                }
            }
            
            $isPortefolioActive = $this->dbQS($isPortefolio['id_content'],$this->table,'id');
            if( empty($isPortefolioActive) || empty($isPortefolioActive['active']) ){
                header('Location:./?r='.$this->uri);
                exit;
            }
            
            $portefolioComment = new ContentCommentaire($isPortefolioActive['id'],'_comments',$this->uri,$this->GetLangue(),$isPortefolioActive['partage']);
            $sComm = $this->getWords('Commentaire');
            if($portefolioComment->countCommentaire > 1){ $sComm = $this->getWords('Commentaires'); }
            
            $this->rubrique = $isPortefolio['categorie'];
            
            $fTpl = TplTranslate::get($this->theme,'m.portefolio.voir.tpl.php');
            ob_start();
            include $fTpl;
            $out .= ob_get_clean();
            
            if($isPortefolioActive['partage']){
                
                $fTpl = TplTranslate::get($this->theme,'m.portefolio.sharethis.tpl.php');
                ob_start();
                include $fTpl;
                $out .= ob_get_clean();
                
            }
            
            if($isPortefolioActive['comments']){

                $out .= $portefolioComment->formCommentaire($this->uri,$isPortefolioActive['sendto']);
                $out .= $portefolioComment->listingCommentaire($isPortefolioActive['id'],$this->uri);

            }
            
            if($isPortefolioActive['disqus']){

                $idDisqus = $isPortefolioActive['id_disqus'];

                $fTpl = TplTranslate::get($this->theme,'m.comments.disqus.tpl.php');
                ob_start();
                include $fTpl;
                $out .= ob_get_clean();
                
            }

            if($isPortefolioActive['facebook']){
                
                $urlFacebook = URL.'?'.$this->uri.'='.$isPortefolio['uri'];

                $fTpl = TplTranslate::get($this->theme,'m.comments.facebook.tpl.php');
                ob_start();
                include $fTpl;
                $out .= ob_get_clean();
                
            }
            
            $out .= $this->getRandumContent(6,$isPortefolioActive['id']);
            
        }
        
        
        
        return $out;
        
        
    }
    
    public function listing($par=9){
        
        $fileTag = URL.'theme/'.$this->theme.'/img/tag.png';
        $fileComment = URL.'theme/'.$this->theme.'/img/comment_blog.png';
        $fileCalendar = URL.'theme/'.$this->theme.'/img/calendar.png';
        $q = '';
        
        if( isset($_GET['q']) && !empty($_GET['q']) ){
            
            $q = filter_input(INPUT_GET,'q',FILTER_SANITIZE_STRING);
            $q = mb_strtolower($q,'UTF-8');
        }
        
        $qN = '';
        if( !empty($q) ){
            $qN = '&amp;q='.$q;
        }
        
        $valFilter = 'date';
        $outFilterAND = '';
        $outFilterORDER = ' '.$this->table.'.ordre ASC ';
        $outGroupe = 'all';
        $outSqlGroupe = " WHERE ".$this->table.".active = 1
        AND ".$this->table."_traduction.id_content = ".$this->table.".id
        AND ".$this->table."_traduction.langue = '".$this->GetLangue()."'
        ORDER BY ".$this->table.".ordre ASC  ";
        $sqlGroupe = '';
        $getGroupe = '';
        
        $outRub = 'r='.$this->uri;
        
        if(isset($_GET['filter'])){
            $getFilter = filter_input(INPUT_GET,'filter',FILTER_SANITIZE_STRING);
            
        }
        if(isset($_GET['in'])){
            $getGroupe = filter_input(INPUT_GET,'in',FILTER_SANITIZE_STRING);
            $isCategorie = $this->dbQS($getGroupe,'_categories_traduction','uri');
            if(!empty($isCategorie)){
                
                $outGroupe = $getGroupe;
                $outSqlGroupe = " WHERE ".$this->table.".categorie = '".$isCategorie['id_cat']."'
                AND ".$this->table."_traduction.id_content = ".$this->table.".id
                AND  ".$this->table.".active = 1
                AND ".$this->table."_traduction.langue = '".$this->GetLangue()."'
                ORDER BY ".$this->table.".ordre ASC  ";
                $outRub = 'in='.$getGroupe;
                
            }
        }
        
        if( !empty($q) ){
            
            $outSqlGroupe = " WHERE ".$this->table."_traduction.id_content = ".$this->table.".id
            AND ".$this->table.".active = 1
            AND ".$this->table."_traduction.langue = '".$this->GetLangue()."' ";
            
        }
        
        $champsliste[] = $this->table.'_traduction.titre';
        $champsliste[] = $this->table.'_traduction.description';
        $champsliste[] = $this->table.'_traduction.uri';
        $champsliste[] = $this->table.'_traduction.meta_titre';
        $champsliste[] = $this->table.'_traduction.meta_description';
        $champsliste[] = $this->table.'_traduction.meta_keys';
        
        if( !empty($q) && !empty($champsliste) ){
            $sqlGroupe .= " AND (";
            foreach($champsliste as $v){
                $sqlGroupe .= " ".$v." LIKE '%".$q."%' OR";
            }
            $sqlGroupe = substr($sqlGroupe,0,-2);
            $sqlGroupe .= ") ";
        }
        
        $outSqlGroupe = $outSqlGroupe.$sqlGroupe;
        
        $iUsers = $this->dbQ('SELECT COUNT(*) as counter FROM '.$this->table.', '.$this->table.'_traduction '.$outSqlGroupe);
        $cResultsInt = (int)$iUsers[0]['counter'];
        
        $urlPage = BASE."?$outRub$qN&amp;page=";
        
        $p = 1;
        $ini = 0;
        $per = $par;
        
        if(isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] <= (ceil($cResultsInt / $per))){
            
            $p = $_GET['page'];
            $ini = $p * $per - $per;
        }
        
        $sqlLimit = " $outSqlGroupe  LIMIT ".$ini.",".$per;
        
        if($cResultsInt > $per){
            
            $valPage = '<div class="pagination">'.PaginationFrontOffice::page($cResultsInt,$p,$per,$urlPage).'</div>';
            
            
        }else{
            $valPage = '';
        }
        
        $all = $this->dbQ('SELECT * FROM '.$this->table.', '.$this->table.'_traduction '.$sqlLimit);
        $cAll = count($all);
        
        $finalPer = $ini+$per;
        if( $finalPer >  $cResultsInt){
            $finalPer = $cResultsInt;
        }
        
        $out = '';
        $q = '';
        
        if( isset($_GET['q']) && !empty($_GET['q']) ){
            
            $q = filter_input(INPUT_GET,'q',FILTER_SANITIZE_STRING);
            $q = mb_strtolower($q,'UTF-8');
        }
        
        
        $fTpl = TplTranslate::get($this->theme,'m.portefolio.index.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    }
    
    public function home($par=9){
        
        $fileTag = URL.'theme/'.$this->theme.'/img/tag.png';
        $fileComment = URL.'theme/'.$this->theme.'/img/comment_blog.png';
        $fileCalendar = URL.'theme/'.$this->theme.'/img/calendar.png';
        $filePortefolio = URL.'theme/'.$this->theme.'/img/portefolio.png';
        
        
        $q = '';
        
        if( isset($_GET['q']) && !empty($_GET['q']) ){
            
            $q = filter_input(INPUT_GET,'q',FILTER_SANITIZE_STRING);
            $q = mb_strtolower($q,'UTF-8');
        }
        
        $qN = '';
        if( !empty($q) ){
            $qN = '&amp;q='.$q;
        }
        
        $valFilter = 'date';
        $outFilterAND = '';
        $outFilterORDER = ' '.$this->table.'.date_creation ASC ';
        $outGroupe = 'all';
        $outSqlGroupe = "  ".$this->table.".active = 1
        AND ".$this->table."_traduction.id_content = ".$this->table.".id
        AND ".$this->table."_traduction.langue = '".$this->GetLangue()."'
        AND ".$this->table.".ordre = 1 LIMIT 1  ";
        $sqlGroupe = '';
        $getGroupe = '';
        
        $outRub = 'r='.$this->uri;
        
        
        $outSqlGroupe = $outSqlGroupe.$sqlGroupe;
        
        $iUsers = $this->dbQ('SELECT COUNT(*) as counter FROM '.$this->table.', '.$this->table.'_traduction WHERE '.$outSqlGroupe);
        $cResultsInt = 0;
        if(!empty($iUsers)){
            $cResultsInt = (int)$iUsers[0]['counter'];
        }
        
        $urlPage = BASE."?$outRub$qN&amp;page=";
        
        $p = 1;
        $ini = 0;
        $per = $par;
        
        if(isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] <= (ceil($cResultsInt / $per))){
            
            $p = $_GET['page'];
            $ini = $p * $per - $per;
        }
        
        $sqlLimit = " $outSqlGroupe  ";
        $valPage = '';
        if($cResultsInt > $per){
            
            $valPage = PaginationFrontOffice::page($cResultsInt,$p,$per,$urlPage);
            
        }
        
        //$all = $this->dbQ('SELECT *  FROM '.$this->table.', '.$this->table.'_traduction '.$sqlLimit);
        
        $cAll = count($this->categorie);
        $all = array();
        foreach($this->categorie as $k=>$v){
            
            $allIn = $this->dbQ( "SELECT *  FROM ".$this->table.", ".$this->table."_traduction WHERE ".$this->table.".categorie = '".$k."' AND ".$sqlLimit);
            if(!empty($allIn)){
                $all[] = $allIn[0];
            }
        }
        $cAll = count($all);
        
        $finalPer = $ini+$per;
        if( $finalPer >  $cResultsInt){
            $finalPer = $cResultsInt;
        }
        
        $out = '';
        $q = '';
        
        if( isset($_GET['q']) && !empty($_GET['q']) ){
            
            $q = filter_input(INPUT_GET,'q',FILTER_SANITIZE_STRING);
            $q = mb_strtolower($q,'UTF-8');
        }
        
        
        $fTpl = TplTranslate::get($this->theme,'m.portefolio.home.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    }
    
    public function getRandumContent($par=3,$id){
        
        $par = $this->bynumavoiraussi;
        
        $fileTag = URL.'theme/'.$this->theme.'/img/tag.png';
        $fileComment = URL.'theme/'.$this->theme.'/img/comment_blog.png';
        $fileCalendar = URL.'theme/'.$this->theme.'/img/calendar.png';
        $q = '';
        
        
        $all = $this->dbQ('SELECT * FROM '.$this->table.', '.$this->table.'_traduction '."
                         WHERE ".$this->table.".id = ".$this->table."_traduction.id_content
                         AND ".$this->table.".active = 1 AND ".$this->table.".id != $id
                         AND ".$this->table."_traduction.langue = '".$this->GetLangue()."' ORDER BY RAND() LIMIT $par  ");
        $cAll = count($all);
        
        
        $out = '';
        
        $fTpl = TplTranslate::get($this->theme,'m.portefolio.randum.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    
    }


    
    
    public function loadCategorie($module=''){
        
        $out = array(0=>'Choisir...');
        $outs = array();
        
        $isAllRC = $this->dbQ("
        SELECT _categories.id as id,
        _categories.uri_module as module,
        _categories_traduction.nom as nom,
        _categories_traduction.uri as uri
        FROM _categories,_categories_traduction
        WHERE  _categories.id = _categories_traduction.id_cat
        AND _categories.uri_module = '$module'
        AND _categories_traduction.langue = '".$this->getLangueTradution()."'
        ORDER BY _categories.ordre ASC ");
        
        $cRC = count($isAllRC);
        if($cRC > 0){
            for($i=0;$i<$cRC;$i++){
                
                $out[$isAllRC[$i]['id']] = $isAllRC[$i]['nom'];
                
                $outs[$isAllRC[$i]['id']] = $isAllRC[$i]['uri'];
            }
        }
        $this->categorieSimple = $out;
        return $outs;
        
    }

    public function rubriqueCategorie(){
        
        $out = '';
        $rubrique = $this->categorieSimple;
        $categorie = $this->categorie;
        
        unset($rubrique[0]);
        
        $fTpl = TplTranslate::get($this->theme,'m.portefolio.rubrique.tpl.php');
        ob_start();
        include $fTpl;
        $out .= ob_get_clean();
        
        return $out;
        
    }
    
    private function formSearch(){
        
        $q = '';
        
        if( isset($_GET['q']) && !empty($_GET['q']) ){
            
            $q = filter_input(INPUT_GET,'q',FILTER_SANITIZE_STRING);
            $q = mb_strtolower($q,'UTF-8');
        }
        $out = '';
        
        $fTpl = TplTranslate::get($this->theme,'m.search.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
        
    }
    
}