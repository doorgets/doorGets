<?php

/**
 *
    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/
class ContactFrontOffice extends Langue{
    
    public $isSend = 1;
    
    private $get;
    
    private $message;
    
    private $name;
    
    public function __construct($name = '',$lg= 'fr'){
        
        $this->name = $name;
        $this->setLangue($lg);
        
        $this->get = $this->formContactIn();  
        
    }
    
    public function get(){
        
        return $this->get;
        
    }
    
    private function formContactIn(){
        
        $out = '';
        
        $idForm = uniqid();
        $this->isSend = 1;

        if(!array_key_exists('idForm',$_SESSION)){
            
            $_SESSION['idForm'] = $idForm;
            
        }
        $form = new Formulaire('contact');
        
        if(
           !empty($form->i)
           && $_SESSION['idForm'] !== $form->i['secureFormulaire']
        ){
            
            header("Location:".$_SERVER['REQUEST_URI']);
            
        }
        
        if(
           !empty($form->i)
           && $_SESSION['idForm'] === $form->i['secureFormulaire']
        ){
            
            $var = $form->i['email'];
            $isEmail = filter_var($var, FILTER_VALIDATE_EMAIL);
            if( empty($isEmail) ){
                
                $form->e['contact_email'] = 'ok';
                
            }
            if(empty($form->i['nom'])){
                $form->e['contact_nom'] = "ok";
            }
            if(empty($form->i['sujet'])){
                $form->e['contact_sujet'] = "ok";
            }
            if(empty($form->i['message'])){
                $form->e['contact_message'] = "ok";
            }
            
            if(empty($form->e)){
                

                
                $_SESSION['idForm'] = $idForm;
                $data['uri_module'] = $this->name;
                $data['sujet'] = $form->i['sujet'];
                $data['nom'] = $form->i['nom'];
                $data['email'] = $form->i['email'];
                $data['description'] = $form->i['descprition'];
                $data['message'] = $form->i['message'];
                $data['telephone'] = $form->i['telephone'];
                $data['date_creation'] = time();
                
                $idContactez = $this->dbQI($data,'contactezmoi');
                $this->isSend = 0;
                
                // Mail 
                $moduleInfo = $this->dbQS($this->name,'_modules','uri');
                if( !empty($moduleInfo) && !empty($moduleInfo['notification_mail'])){

                    $_email = $this->configInfo['email'];
                    $_sujet = $this->getWords("Contact").' / '.ucfirst($this->name).'['.$idContactez.']';

                    $newAlertAdmin = new SendMailAlert($_email,$_sujet,$this->getLangue());

                }

                $out .= $this->outContact();
            }
            
        }
        
        if(empty($this->isSend)){
            
            return $out;
        
        }
        
        $fTpl = TplTranslate::get($this->theme,'m.contactezmoi.form.tpl.php');
        ob_start();
        echo $form->open('post',$_SERVER['REQUEST_URI'],'');
        include $fTpl;
        echo $form->close();
        $out = ob_get_clean();
        
        return $out;
        
    }
    
    public function outContact(){
        
        $message = $this->message;
        $imgMessageOk = THM.'theme/img/message_envoye.jpg';
        $msgOK = $this->getWords("Votre message à bien été envoyé. Merci.");
        $msgReturn = $this->getWords("retour sur le site");
        
        $fTpl = TplTranslate::get($this->theme,'m.contactezmoi.val.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
        
    }
    
}