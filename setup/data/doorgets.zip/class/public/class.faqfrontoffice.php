<?php

/**

    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class FaqFrontOffice extends Langue{
    
    
    private $get;
    
    private $table;
    
    private $uri;
    
    public function __construct($table="faq",$uri="faq",$bynum = '10',$lg = 'fr'){
        
        $this->setLangue($lg);
        
        $this->table = $table;
        
        $this->uri = $uri;
        
        $this->get =   $this->listing($bynum);
        
    }
    
    public function get(){
        
        return $this->get;
        
    }
    
    
    private function listing($par=100){
        
        $lgActuel = $this->getLangueTradution();
        
        $iUsers = $this->dbQ('SELECT COUNT(*) as counter FROM '.$this->table);
        $cResultsInt = (int)$iUsers[0]['counter'];
        
        $outFilterORDER = ' '.$this->table.'.ordre ASC ';
        
        $ini = 0;
        $per = $par;
        
        $sqlLimit = " WHERE  ".$this->table."_traduction.langue = '".$lgActuel."' AND ".$this->table."_traduction.id_content = ".$this->table.".id  ORDER BY $outFilterORDER  LIMIT ".$ini.",".$per;
        
        $Faq = $this->dbQA($this->table.', '.$this->table.'_traduction',$sqlLimit);
        $countFaq = count($Faq);
        
        $out = '';
        $fTpl = TplTranslate::get($this->theme,'m.faq.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    
    }
    
    
}