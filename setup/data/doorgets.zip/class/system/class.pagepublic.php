<?php

/**
 *
    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/


class PagePublic extends Langue{
    
    /**
     *  load content and info of page
     *
     *  $data and $meta are arrays
     *
     *  $data = array();
     *  $data['domaine'] = "";
     *  $data['title'] = "";
     *  $data['copyright'] = "";
     *  $data['year'] = "";
     *  
     *  $meta = array();
     *  $meta['description'] = "description of this page";
     *  $meta['keywords'] = "keywords of this page";
     *  
     */
    private $getRubriquePublic = array();
    private $dataInfo = array();
    
    public function __construct( $lg = 'fr',$webtype = 'all',$data = array(),$meta = array() ){
        
		$this->setLangue($lg);
		$this->getRubriquePublic = $this->getRubriquePublic();
		
	    $isWebSite = $this->dbQS(1,'_website');
		$isWebSiteTrad = $this->dbQS($this->GetLangue(),'_website_traduction','langue');
		$this->_website = $isWebSite;
		if(!empty($isWebSiteTrad)){
		    
		    
		    
	            $data['domaine'] = URL;
	            $data['title'] = $isWebSiteTrad['title'];
	            $data['slogan'] = $isWebSiteTrad['slogan'];
	            $data['year'] = $isWebSiteTrad['year'];
		    
		    	$data['description'] = $isWebSiteTrad['description'];
	            $data['keywords'] = $isWebSiteTrad['keywords'];
	            $data['copyright'] = $isWebSiteTrad['copyright'];
		}
		
        if(empty($data)){
            
            $data['domaine'] = URL;
            $data['title'] = "doorgets.com";
            $data['slogan'] = "doorgets.com";
            $data['year'] = "2012";
            $data['description'] = "doorgets.com";
            $data['keywords'] = "doorgets.com";
            $data['copyright'] = "doorgets.com";
        }
        
        $this->dataInfo = $data;
	        
		$rubrique = array();
	        
        
        $rubriqueBottom['mentions'] = $this->getWords('Mentions lègales');
        $rubriqueBottom['cgu'] = $this->getWords("Conditions Générale D'utilisation");
        
        
		$allRubs = $this->getRubriquePublic;
		if(!empty($_GET)){
		    
		    foreach($_GET as $kk=>$vv){
			
				if( isset($_GET[$kk]) && array_key_exists($kk,$allRubs)) {
				    
				    $isIn = filter_input(INPUT_GET,$kk,FILTER_SANITIZE_STRING);
				    $isInTrad = $this->dbQS($isIn,'_m_'.$kk.'_traduction','uri'," AND langue = '".$this->GetLangue()."' LIMIT 1 ");
				    if(!empty($isInTrad)){
					
					$this->rub = $kk;
					if( !empty($isInTrad['meta_titre']) ){
					    $data['title'] = $isInTrad['meta_titre'].' - '.$data['title'];
					}
					if( !empty($isInTrad['meta_description']) ){
					    $data['description'] = $isInTrad['meta_description'];
					}
					if( !empty($isInTrad['meta_keys']) ){
					    $data['keywords'] = $isInTrad['meta_keys'];
					}
					
					break;
				    }
				}
			
		    }
		    
		    if( isset($_GET['in']) ) {
			
			$isModule = '';
			$isCat = filter_input(INPUT_GET,'in',FILTER_SANITIZE_STRING);
			
			$isInCat = $this->dbQS($isCat,'_categories_traduction','uri'," AND langue = '".$this->GetLangue()."' LIMIT 1 ");
			if(!empty($isInCat)){
			    
			    $isModule = $this->dbQS($isInCat['id_cat'],'_categories');
			    if(!empty($isModule)){
				
				$this->rub = $isModule['uri_module'];
				
				if( !empty($isInCat['meta_titre']) ){
				    $data['title'] = $isInCat['meta_titre'].' - '.$data['title'];
				}
				if( !empty($isInCat['meta_description']) ){
				    $data['description'] = $isInCat['meta_description'];
				}
				if( !empty($isInCat['meta_keys']) ){
				    $data['keywords'] = $isInCat['meta_keys'];
				}
			    }
			}
			
		    }
		    
		    if( isset($_GET['r']) ) {
			
			$isModule = '';
			$isModuleR = filter_input(INPUT_GET,'r',FILTER_SANITIZE_STRING);
			
			$isInModule = $this->dbQS($isModuleR,'_modules','uri');
			if(!empty($isInModule)){
			    
			    $isModule = $this->dbQS($isInModule['id'],'_modules_traduction','id_module'," AND langue = '".$this->GetLangue()."' LIMIT 1 ");
			    if(!empty($isModule)){
				
				$this->rub = $isModuleR;
				
				if( !empty($isModule['meta_titre']) ){
				    $data['title'] = $isModule['meta_titre'].' - '.$data['title'];
				}
				if( !empty($isModule['meta_description']) ){
				    $data['description'] = $isModule['meta_description'];
				}
				if( !empty($isModule['meta_keys']) ){
				    $data['keywords'] = $isModule['meta_keys'];
				}
			    }
			}
			
		    }
		    
		}
	
        foreach($data as $k=>$v){
            
            $this->$k = ucfirst(mb_strtolower($v, 'UTF-8'));
            
        }
	
    }
    
    public function getHeader(){
	
	$themes['alpha'] = 'frontmm_b.css';
	$themes['red'] = 'frontmm_r.css';
	$themes['orange'] = 'frontmm_o.css';
	$themes['verts'] = 'frontmm_v.css';
	$themes['gris'] = 'frontmm_g.css';
	
	$isWebSite = $this->dbQS(1,'_website');
	if(!empty($isWebSite)){
	    
	    $themeIn = 'frontmm_b.css';
	    
	    if( array_key_exists($isWebSite['theme'],$themes) ){
		$themeIn = $themes[$isWebSite['theme']];
	    }
	    
	    $uri = URL.'theme';
	    $url = URL;
	    $url = substr($url,0,-1);
	    $url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	    $copy = $this->copyright;
	    $keys = $this->keywords;
	    $description = $this->description;
	    $langue = $this->getLangue();
	    $idFacebookAdmin = $isWebSite['id_facebook'];
	    
	    
	    $lgFacebook = 'fr_FR';
	    switch($langue){
		case 'en':
		    $lgFacebook = 'en_US';
		    break;
		case 'de':
		    $lgFacebook = 'de_DE';
		    break;
		case 'it':
		    $lgFacebook = 'it_IT';
		    break;
		case 'ru':
		    $lgFacebook = 'ru_RU';
		    break;
		case 'pl':
		    $lgFacebook = 'pl_PL';
		    break;
		case 'tu':
		    $lgFacebook = 'tr_TR';
		    break;
		case 'su':
		    $lgFacebook = 'sv_SE';
		    break;
		case 'es':
		    $lgFacebook = 'es_LA';
		    break;
		case 'po':
		    $lgFacebook = 'pt_BR';
		    break;
	    }
	    
	    $fTpl = TplTranslate::get($this->theme,'header.tpl.php');
	    ob_start();
	    include $fTpl;
	    $out = ob_get_clean();
	    
	    
	}
        return $out;
    
    }
    
    public function getFooter(){
        
	$Facobook = '';
	$Youtube = '';
	$Twitter = '';
	$Google = '';
	
	$YeayNow = date("Y");
	$this->_website['year'] = (int)$this->dataInfo['year'];
	$YearStart = $this->dataInfo['year'];
	
	$copy = '<a style="font-size:9pt;"  href="'.BASE.'">'.$this->dataInfo['copyright'].'</a> <br />'.$this->getWords("Propulsé avec").' <a class="img_network_" target="blank" href="http://www.doorgets.com/?sources_cms">doorGets</a>';
	
	if(!empty($this->_website['facebook'])){
	    $Facobook = '<a target="blank" href="http://www.facebook.com/'.$this->_website['facebook'].'" class="img_network" ><img class="img_network_" src="'.URL.'theme/img/icone_facebook.png" /></a>';
	}
	if(!empty($this->_website['twitter'])){
	    $Youtube= '<a target="blank" href="http://www.twitter.com/'.$this->_website['twitter'].'" class="img_network" ><img class="img_network_" src="'.URL.'theme/img/icone_twitter.png" /></a>';
	}
	if(!empty($this->_website['google'])){
	    $Google = '<a target="blank" href="https://plus.google.com/u/0/'.$this->_website['google'].'" class="img_network" ><img class="img_network_" src="'.URL.'theme/img/icone_google.png" /></a>';
	}
	if(!empty($this->_website['youtube'])){
	    $Twitter = '<a target="blank" href="http://www.youtube.com/user/'.$this->_website['youtube'].'" class="img_network" ><img class="img_network_" src="'.URL.'theme/img/icone_youtube.png" /></a>';
	}
	
	$linksMentions = $linksCGU = $linksSitemap = '';
	// mentions legales
	if($this->_website['m_legacy']){
	
	    $linksMentions = '<a class="img_network" style="font-size:11pt;padding:3px 3px;float:right"  href="'.BASE.'?r=mentions">'.$this->getWords("Mentions lègales").'</a>';
	    
	}
	if($this->_website['m_terms']){
	    
	    $linksCGU = '<a class="img_network" style="font-size:11pt;padding:3px 3px;float:right"  href="'.BASE.'?r=cgu">'.$this->getWords("Conditions Générale D'utilisation").'</a>';
	    
	}
	if($this->_website['m_sitemap']){
	    
	    $linksSitemap = '<a class="img_network" style="font-size:11pt;padding:3px 3px;float:right"  href="'.BASE.'?r=sitemap">'.$this->getWords("Plan du site").'</a>';
	    
	}
	
	$linkYear = "<span > $YearStart - $YeayNow &copy; $copy </span>";
	
	$scriptAnalytics = $this->analytics();
	
	
	$fTpl = TplTranslate::get($this->theme,'footer.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
	
        return $out;

    }
    
    public function analytics(){
	
	$out = '';
	if(!empty($this->_website['analytics'])){
	    
	    $out .= <<<Q
	    <script type="text/javascript"> var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www."); document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E")); </script>
Q;
	    $out .= '<script type="text/javascript"> try { var pageTracker = _gat._getTracker("'.$this->_website['analytics'].'"); pageTracker._trackPageview(); } catch(err) {} </script>';
	
	}
	
	return $out;
    
    }
    
    
}
