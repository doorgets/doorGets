<?php

/**
 *
    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/


class PageAdmin extends Langue{
    
    
    private $dataInfo = array();

    public function __construct($lg='fr',$type = 'all',$data = array(),$meta = array()){
        
	$this->setLangue($lg);
    $isWebSite = $this->dbQS(1,'_website');
	$isWebSiteTrad = $this->dbQS($this->GetLangue(),'_website_traduction','langue');
	if(!empty($isWebSiteTrad)){
	    
	    $this->_website = $isWebSiteTrad;
	    
            $data['domaine'] = URL;
            $data['title'] = $isWebSiteTrad['title'];
            $data['slogan'] = $isWebSiteTrad['slogan'];
            $data['year'] = $isWebSiteTrad['year'];
	    
	    $meta['description'] = $isWebSiteTrad['description'];
            $meta['keywords'] = $isWebSiteTrad['keywords'];
            $meta['copyright'] = $isWebSiteTrad['copyright'];
	}
        
        if(empty($data)){
            
            $data = array();
            $data['domaine'] = URL;
            $data['title'] = "Professeur-php.com";
            $data['slogan'] = "Le php en toute simplicité";
            $data['year'] = "2012";
            
        }
        
        $this->dataInfo = $data;

        if(empty($meta)){
            
            $meta = array();
            $meta['description'] = "doorgets.com";
            $meta['keywords'] = "doorgets.com";
            $meta['copyright'] = "doorgets.com";
        }
        
        foreach($data as $k=>$v){
            
            $this->$k = ucwords(mb_strtolower($v, 'UTF-8'));
            
        }
        
        foreach($meta as $k=>$v){
            
            $this->meta[$k] = mb_strtolower($v, 'UTF-8');
            
        }        
        
    }
    
    public function getHeader(){
	
	$sMaxI = ini_get('post_max_size'); $sMax = str_replace('M','',$sMaxI); $sMax = (int)$sMax; $sMax = $sMax * 1024000;
	
    $uri = THM.'ad_';
	
    $fTpl = TplTranslate::getAdmin('doorgets','header.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
	
        return $out;
    
    }
    
    public function getFooter(){
        
	
	$fTpl = TplTranslate::getAdmin('doorgets','footer.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        return $out;

    }
}
