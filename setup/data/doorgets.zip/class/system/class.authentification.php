<?php

/**
 *
    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class Authentification extends Langue{
    
    private $table;
        
    private $get;
    
    public function __construct($table = 'administrateur',$lg= 'fr'){
        
        $this->setLangue($lg);
	
	$this->table = $table;
	
        if(isset($_GET['d'])){
            
            $_SESSION = array();
            header('Location:./');
            exit;
        
        }
        
        
        $this->get .= $this->formConnexion();  
        
    }
    
    public function get(){
        return $this->get;
    }
    
    
    
    private function formConnexion(){
        
        $out = '';
        
        $form = new formulaire('connexion');
        
        if(!empty($form->i)){
            
            // vérification champ vide
            foreach($form->i as $k=>$v){
                if(empty($v)){
		    
                    $form->e['connexion_login'] = 'ok';
                    $form->e['connexion_pwd'] = 'ok';
		    
                }
            }
            
            // verification de la taille du pwd
            if( strlen($form->i['pwd']) < 4 ){
                
                $form->e['connexion_login'] = 'ok';
                $form->e['connexion_pwd'] = 'ok';
                
            }
            
            if( empty($form->e) ){
                
                
		if( $form->i['login'] === USR_LOGIN && $form->i['pwd'] === USR_PWD ){
		    
		    $_SESSION['doorgets']['id'] = USR_LOGIN;
		    $_SESSION['doorgets']['password'] = USR_PWD;
                    
                    header('Location:'.$_SERVER['REQUEST_URI']);
                    // Utilisateur identifié
                    // transmision des données 
                    exit();
		    
		}else{
		    
                    $form->e['connexion_login'] = 'ok';
                    $form->e['connexion_pwd'] = 'ok';
                    
                }
                
            }
	    
	    
	    
        }
	
        
        
        $fTpl = TplTranslate::getAdmin('doorgets','z.authentification.form.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        
        return $out;
        
    }
    
    
    

    

    


}