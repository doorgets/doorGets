<?php

/**
 *
    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class ControllerPublic extends Langue{
    
    public $name = 'Admin';
    
    public $rub ;
    
    public $rubrique = array();
    
    public $rubriquePlus = array();
    
    public $get;
    
    public $infoWeb;
    
    public function __construct($lg= 'fr'){
        
        $name = '';
        
        $this->setLangue($lg);
        $infoWeb = $this->infoWeb = $this->loadConfigInfo();
        $rubrique = $this->getRubrique();
        
        $rubriqueBottom = array();
        
        if($infoWeb['m_legacy']){
            $rubriqueBottom['mentions'] = $this->getWords('Mentions lègales');
        }
        
        if($infoWeb['m_terms']){
            
            $rubriqueBottom['cgu'] = $this->getWords("Conditions Générale D'utilisation");
        }
        
        if($infoWeb['m_sitemap']){
            $rubriqueBottom['sitemap'] = $this->getWords("Plan du site");
        }
        
        $this->rub = 'error';
        
        $selFirstModule = $this->dbQS(1,'_modules','is_first');
        if(!empty($selFirstModule)){
            $isInRubrique = $this->dbQS($selFirstModule['id'],'_rubrique','idModule');
            if(!empty($isInRubrique)){
                $this->rub = $selFirstModule['uri'];
            }
        }
        if( isset($_GET['r']) && ( array_key_exists($_GET['r'],$rubrique)  || array_key_exists($_GET['r'],$rubriqueBottom) ) ) {
            $this->rub = filter_input(INPUT_GET,'r',FILTER_SANITIZE_STRING);
        }
        
        if(!empty($_GET)){
            foreach($_GET as $k=>$v){
                if(array_key_exists($k,$rubrique)){
                    
                    if( isset($_GET[$k]) ) {
                        
                        $isInBlog = filter_input(INPUT_GET,$k,FILTER_SANITIZE_STRING);
                        $isBlog = $this->dbQS($isInBlog,'_m_'.$k.'_traduction','uri');
                        if(!empty($isBlog)){
                            
                            $this->rub = $k;
                            
                        }
                        
                        if( empty($_GET[$k]) || empty($isBlog)  ){
                            
                            header('Location:'.BASE.'?r='.$k);
                            exit();
                        }
                        
                    }                    
                    
                    
                    
                }
                
            }
        }
        
        if( isset($_GET['in']) ) {
            
            $isModule = '';
            $isCat = filter_input(INPUT_GET,'in',FILTER_SANITIZE_STRING);
            
            $isInCat = $this->dbQS($isCat,'_categories_traduction','uri');
            if(!empty($isInCat)){
                
                $isModule = $this->dbQS($isInCat['id_cat'],'_categories');
                if(!empty($isModule)){
                    
                    $this->rub = $isModule['uri_module'];
                    
                }
            }
            
            if( empty($_GET['in']) || empty($isModule) ){
                
                header('Location:'.BASE.'?');
                exit();
            }
        }   
        
        if( $this->rub !== 'error' && !array_key_exists($this->rub,$rubrique) && !array_key_exists($this->rub,$rubriqueBottom) ){
            header('Location:'.BASE);
            exit();
        }
        
        $this->get = $this->page($name,$rubrique,$rubriqueBottom);
        
    }
    
    public function get(){
        return $this->get;
    }
    
    public function page($name,$rubrique,$rubriqueBottom){
        
        $out = '';
        
        $Facobook = '';
    	$Youtube = '';
    	$Twitter = '';
    	$Google = '';
            
    	$this->name = ucwords($name);
        $this->rubrique = $rubrique;
        $this->rubriquePlus = $rubriqueBottom;
        $contentHeader = '';

        if( empty($_GET) || ( isset($_GET['r']) && !empty($_GET['r']) ) ){
            
            $isPageModule = $this->dbQS($this->rub,'_modules','uri');
            
            if( !empty($isPageModule) ){

                $isPageModuleTrad = $this->dbQS($isPageModule['id'],'_modules_traduction','id_module'," AND langue = '".$this->GetLangue()."' LIMIT 1 ");
                
                if( !empty($isPageModuleTrad) ){
                    
                    $contentHeader = htmlspecialchars_decode(html_entity_decode($isPageModuleTrad['article_tinymce']));
                }  
            }  
        }
        


        $fTpl = TplTranslate::get($this->theme,'page.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    }
    
    public function rubrique(){
        
        $out = '';
        
        $fTpl = TplTranslate::get($this->theme,'rubrique.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    
    }
    
    public function titre(){
        
        $fileTuto = THM.'theme/img/tuto.png';
        $fileBlog = THM.'theme/img/article.gif';
        $fileLiens = THM.'theme/img/liens.png';
        $fileContact = THM.'theme/img/contact.png';
        $fileHome = THM.'theme/img/home.png';
        
        $rubriqueSub = $this->rubriquePlus;
        $rubrique = $this->rubrique;
        $rubriqueIn = $this->rub;
        
        $out = '';
        
        $fTpl = TplTranslate::get($this->theme,'title.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    
    }
    
    public function content(){
        
        
        $content = '';
        $name = $this->rub;
        
        switch($this->rub){
            
            case '404':
                $page = new PageHomeFrontOffice('404',$this->GetLangue());
                $content .= $page->get();
                break;
            
            case 'mentions':
                $page = new PageHomeFrontOffice('mentions',$this->GetLangue());
                $content .= $page->get();
                break;
            
            case 'cgu':
                $page = new PageHomeFrontOffice('cgu',$this->GetLangue());
                $content .= $page->get();
                break;
            
            case 'sitemap':
                $page = new SitemapFrontOffice($this->GetLangue());
                $content .= $page->Get();
                break;
            
        }
        
        $isModule = $this->dbQS($this->rub,'_modules','uri');
        if(empty($isModule)){ return $content;}
        
        
        $nameTable = '_m_'.$name;
        if($isModule['active'] === '1'){
            
            
            switch($isModule['type']){
                
                case 'blog':
                    $Blog = new BlogFrontOffice($nameTable,$name,$isModule['bynum'],$isModule['avoiraussi'],$this->GetLangue());
                    $content = $Blog->get();
                    break;
                
                case 'news':
                    $News = new NewsFrontOffice($nameTable,$name,$isModule['bynum'],$isModule['avoiraussi'],$this->GetLangue());
                    $content = $News->get();
                    break;
                
                case 'tuto':
                    $Tuto = new TutoFrontOffice($nameTable,$name,$isModule['bynum'],$isModule['avoiraussi'],$this->GetLangue());
                    $content = $Tuto->get();
                    break;
                
                case 'portefolio':
                    $Portefolio = new PortefolioFrontOffice($nameTable,$name,$isModule['bynum'],$isModule['avoiraussi'],$this->GetLangue());
                    $content = $Portefolio->get();
                    break;
                
                case 'liens':
                    $Liens = new LiensFrontOffice($nameTable,$name,$isModule['bynum'],$this->GetLangue());
                    $content = $Liens->Get();
                    break;
                
                case 'faq':
                    $Faq = new FaqFrontOffice($nameTable,$name,$isModule['bynum'],$this->GetLangue());
                    $content = $Faq->Get();
                    break;
                
                case 'page':
                    $Page = new PageHomeFrontOffice($name,$this->GetLangue());
                    $content = $Page->get();
                    break;
                
                case 'contact':
                    $ContactFrontOffice = new ContactFrontOffice($name,$this->GetLangue());
                    $content = $ContactFrontOffice->get();
                    break;
                
                case 'candidaturemodels':
                    $CandidatureFrontOffice = new CandidatureFrontOffice($name,$this->GetLangue());
                    $content = $CandidatureFrontOffice->get();
                    break;
                
                case 'link':
                    $isLink = $this->dbQS($name,'linkinfo','page'," AND langue = '".$this->GetLangue()."' LIMIT 1 ");
                    if(!empty($isLink)){
                        $content = '<SCRIPT language="javascript" type="text/javascript">document.location.href="'.$isLink['content'].'"</SCRIPT>';
                        $content .= '<a href="'.$isLink['content'].'">'.$isLink['content'].'</a>';
                    }
                    break;
            }
            
        }
        
        $fTpl = TplTranslate::get($this->theme,'content.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    
    }
    
    private function getRubrique(){
        
        $rubOut = array();
        $isGroupeRubrique = $this->dbQ("SELECT * FROM _rubrique ORDER BY ordre DESC");
        if( !empty($isGroupeRubrique) ){
            foreach($isGroupeRubrique as $v ){
                
                if( !empty($v['idModule']) ){
                    
                    $isModule = $this->dbQS($v['idModule'],'_modules');
                    
                    if( !empty($isModule) AND $isModule['active'] === '1' ){
                        
                        $isModuleTrad = $this->dbQS($v['idModule'],'_modules_traduction','id_module'," AND langue = '".$this->GetLangue()."'");
                        if( !empty($isModuleTrad) ){
                            
                            $rubOut[$isModule['uri']] = $isModuleTrad;
                            
                        }
                        
                    }
                }
                if( !empty($v['idModule']) ){
                    
                    $isModule = $this->dbQS($v['idModule'],'_modules');
                    
                    if( !empty($isModule) AND $isModule['active'] === '1' ){
                        
                        $isModuleTrad = $this->dbQS($v['idModule'],'_modules_traduction','id_module'," AND langue = '".$this->GetLangue()."'");
                        if( !empty($isModuleTrad) ){
                            
                            $rubOut[$isModule['uri']]['nom'] = $isModuleTrad['nom'];
                            $rubOut[$isModule['uri']]['type'] = $isModule['type'];
                            $rubOut[$isModule['uri']]['img'] = THM.'data/_gestion/'.$isModule['image'];
                            if(empty($isModule['image'])){
                                $rubOut[$isModule['uri']]['img'] = THM.'ad_/img/ico_module.png';
                            }
                            
                        }
                        
                    }
                }   
            }

        }
        
        return $rubOut;
        
    }
    
    
    
    private function pub(){
        
        $out = <<<Q
        
            <div style="width:100%;text-align:center;border-top:1px #ccc solid;padding-top:10px;margin-top:10px;">
            <script type="text/javascript">
            <!--
             google_ad_client = "pub-0462142586024615";google_ad_slot = "9763119580";google_ad_width = 728;google_ad_height = 90;
            //-->
            </script> <script type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js"> </script>
            </div>
        
Q;
        $out = '';
        
        return $out;
    
    }
}