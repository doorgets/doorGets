<?php

/**
*
    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    

     Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/


class ControllerAdmin extends Langue{
    
    public $name = 'Admin';
    
    public $rub ;
    
    public $langue;
    
    public $rubrique = array();
    
    public $rubriquePlus = array();
    
    public $get;

    public $conf;
    
    public $dataInfo = array();

    public function __construct($name,$config = "", $lg= 'fr'){
        
        $this->setLangue($lg);
        $this->conf = $infoWeb = $this->loadConfigInfo();
        $isWebSiteTrad = $this->dbQS($this->GetLangue(),'_website_traduction','langue');
        if(!empty($isWebSiteTrad)){
            $this->dataInfo = $isWebSiteTrad;
        }
        
        $rubrique['gestion'] = $this->getWords('Gestion');
        $rubrique['rubrique'] = $this->getWords('Rubrique');
        
        $rubrique['comment'] = $this->getWords('Commentaire');
        $rubrique['contactezmoi'] = $this->getWords('Message');
        
        $iComment = $this->dbQ('SELECT COUNT(*) as counter FROM _comments WHERE lu = 0');
        $cResultsIntComment = (int)$iComment[0]['counter'];
        
        $iMessage = $this->dbQ('SELECT COUNT(*) as counter FROM contactezmoi WHERE lu = 0');
        $cResultsIntMessage = (int)$iMessage[0]['counter'];
        
        if(!empty($cResultsIntMessage)){
            $rubrique['contactezmoi'] = $rubrique['contactezmoi'].' <small class="annuler padding">'.$cResultsIntMessage.'</small>';
        }
        if(!empty($cResultsIntComment)){
            $rubrique['comment'] = $rubrique['comment'].' <small class="annuler padding">'.$cResultsIntComment.'</small>';
        }
        
        
        $rubrique['config'] = $this->getWords('Configuration');
        
        $rubriqueHidden['fichier'] = $this->getWords('Fichier');
        $rubriqueHidden['newsletter'] = $this->getWords('Newsletter');
        $rubriqueHidden['modules'] = $this->getWords('Module');
        $this->rub = 'contactezmoi';
        if( isset($_GET['r']) && ( array_key_exists($_GET['r'],$rubrique) || array_key_exists($_GET['r'],$rubriqueHidden) ) ) {
            
            $this->rub = filter_input(INPUT_GET,'r',FILTER_SANITIZE_STRING);
            
        }
        if( isset($_GET['m']) ) {
            
            $this->rub = 'gestion';
            
        }
        
        
        $this->name = ucwords($name);
        $this->rubrique = $rubrique;
        $this->rubriquePlus = $rubriqueHidden;
        
        $this->get = $this->page($this->name,$this->rubrique,$this->rubriquePlus);
        
    }
    
    public function get(){
        return $this->get;
    }
    
    public function page($name,$rubrique,$rubriqueBottom){
        
        $fTpl = TplTranslate::getAdmin('doorgets','page.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
        
    }
    
    public function rubrique(){
        
        
        $fTpl = TplTranslate::getAdmin('doorgets','rubrique.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    }
    
    public function titre(){
        
        $rubss = $this->rubriquePlus;
        $rubs = $this->rubrique;
        $rub = $this->rub;
        
        $fTpl = TplTranslate::getAdmin('doorgets','title.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        
        
        return $out;
    
    }
    
    public function content(){
        
        $fTpl = TplTranslate::getAdmin('doorgets','content.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    
    }
    
    

}