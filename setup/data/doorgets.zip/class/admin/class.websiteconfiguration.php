<?php

/**
 *
    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class websiteConfiguration extends Langue{
    
    public $name;
    
    public $menu;
    
    public $page;
    
    public $info = array();
    
    public function __construct($lg= 'fr'){
        
        $this->setLangue($lg);
        
        $this->info = $this->loadConfigInfo();
	
        $inArr[] = 'media'; $inArr[] = 'adresse';
        $inArr[] = 'network'; $inArr[] = 'langue';
        $inArr[] = 'mentions'; $inArr[] = 'cgu';
        $inArr[] = 'sitemap'; $inArr[] = 'modules';
        $inArr[] = 'analytics';$inArr[] = 'pwd';
	$inArr[] = 'error';
        
        $this->name = 'siteweb';
        
        foreach($inArr as $v){
            
            if( isset($_GET[$v]) ){
            
                $this->name = $v;
                break;
            }
            
        }
        
        $this->page  = $this->getPage($this->name);
        
    }
    
    
    
    private function getMenu(){
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.config.rubrique.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        return $out;
        
    }
    
    private function getContent(){
        
        $configSettings['siteweb']['name'] = $this->getWords('Site Web');
        $configSettings['adresse']['name'] = $this->getWords('Addresse').' & '.$this->getWords('Contact');
        $configSettings['media']['name'] = $this->getWords('Logo').' & '.$this->getWords('Icône');
        $configSettings['network']['name'] = $this->getWords("Réseaux Sociaux");
        $configSettings['analytics']['name'] = $this->getWords("Google Analytics");
        $configSettings['langue']['name'] = $this->getWords("Langue");
        $configSettings['mentions']['name'] = $this->getWords("Mentions lègales");
        $configSettings['cgu']['name'] = $this->getWords("Conditions d'utilisations");
        $configSettings['sitemap']['name'] = $this->getWords("Plan du site");
        $configSettings['modules']['name'] = $this->getWords("Modules interne");
	$configSettings['pwd']['name'] = $this->getWords("Modifier votre mot de passe");
	$configSettings['error']['name'] = $this->getWords("Page introuvable");
	
	$configSettings['siteweb']['img'] = THM.'ad_/img/home.png';
        $configSettings['adresse']['img'] = THM.'ad_/img/icone-contact.png';
        $configSettings['media']['img'] = THM.'ad_/img/icone-website.png';
        $configSettings['network']['img'] = THM.'ad_/img/icone-network.png';
        $configSettings['analytics']['img'] = THM.'ad_/img/icone-stats.png';
        $configSettings['langue']['img'] = THM.'ad_/img/icone-langue.png';
        $configSettings['mentions']['img'] = THM.'ad_/img/icone-mentions.png';
        $configSettings['cgu']['img'] = THM.'ad_/img/icone-terms.png';
        $configSettings['sitemap']['img'] = THM.'ad_/img/icone-sitemap.png';
        $configSettings['modules']['img'] = THM.'ad_/img/icone-module.png';
	$configSettings['pwd']['img'] = THM.'ad_/img/icone-pwd.png';
	$configSettings['error']['img'] = THM.'ad_/img/icone-404.png';
	
        
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.config.content.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        return $out;
    
    }
    
    private function getPage(){
        
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.config.page.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        return $out;
    }
    
    private function getForm(){
        
        switch($this->name){
            
            case 'adresse':
                return $this->formAdresse();
            break;
            case 'media':
                return $this->formMedia();
            break;
            case 'network':
                return $this->formNetwork();
            break;
            case 'analytics':
                return $this->formAnalytics();
            break;
            case 'langue':
                return $this->formLangue();
            break;
            case 'mentions':
                return $this->formMentions();
            break;
            case 'cgu':
                return $this->formCGU();
            break;
            case 'sitemap':
                return $this->formSitemap();
            break;
            case 'modules':
                return $this->formModules();
            break;
	    case 'pwd':
                return $this->formPawwsord();
            break;
	    case 'error':
                return $this->formError();
            break;
        
            default:
                return $this->formSiteweb();
            break;
            
            
        }
        
    }
    
    private function formPawwsord(){
        
        $formPassword = new Formulaire('password');
        
        if(
           !empty($formPassword->i) && empty($formPassword->e)
        ){
            foreach($formPassword->i as $k=>$v){
                if(empty($v)){
                    
                    $formPassword->e['password_'.$k] = 'ok';
                    
                }
            }
	    
	    if( $formPassword->i['passwd_now'] !== USR_PWD ){
		
		$formPassword->e['password_passwd_now'] = 'ok';
		
	    }
	    if( (strlen($formPassword->i['passwd_new']) < 8) || $formPassword->i['passwd_new'] !== $formPassword->i['passwd_new_bis'] ){
		
		$formPassword->e['password_passwd_new'] = 'ok';
		$formPassword->e['password_passwd_new_bis'] = 'ok';
		
	    }
	    
	    if(empty($formPassword->e)){
		
		$iOut = '';
		$iOut .= "<?php"."\n";
		$iOut .= "define('URL','".URL."');"."\n";
		$iOut .= "define('SQL_HOST','".SQL_HOST."');"."\n";
		$iOut .= "define('SQL_LOGIN','".SQL_LOGIN."');"."\n";
		$iOut .= "define('SQL_PWD','".SQL_PWD."');"."\n";
		$iOut .= "define('SQL_DB','".SQL_DB."');"."\n";
		$iOut .= "define('SQL_PREFIX','".USR_NAME."');"."\n";
		$iOut .= "define('USR_NAME','".USR_NAME."');"."\n";
		$iOut .= "define('USR_LOGIN','".USR_LOGIN."');"."\n";
		$iOut .= "define('USR_PWD','".$formPassword->i['passwd_new']."');"."\n";
		
		$confFile = THM.'config/setting.conf.php';
		if(is_file($confFile)){
		    file_put_contents($confFile,$iOut);
		}
		
		new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
                $this->clearCache();
		header("Location:".$_SERVER['REQUEST_URI']);
		exit();
		
	    }
	    
            new FlashInfoPut($this->getWords("Veuillez remplir correctement le formulaire."),"error");
            
        }
        
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.config.form.pwd.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        return $out;
        
    }
    
    private function formSitemap(){
        
        $fileSitemap = THM.'sitemap.xml';
        $urlSitemap = URL.'sitemap.xml';
        
        $dateEdit = '-';
        if(is_file($fileSitemap)){
            $dateEdit = ucfirst(strftime("%A %d %B %Y %H:%M",filemtime($fileSitemap)));
        }
        
        $formSitemap = new Formulaire('sitemap');
        
        if(
           !empty($formSitemap->i) && empty($formSitemap->e)
        ){
            
            new GenSitemapXml();
            new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
            $this->clearCache();
            header("Location:".$_SERVER['REQUEST_URI']);
            exit();
            
        }
        
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.config.form.sitemap.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        return $out;
        
    }
    
    private function formModules(){
        
        $imgOk = '<img src="'.THM.'ad_/img/activer.png" > ';
        $imgNo = '<img src="'.THM.'ad_/img/pause.png" > ';
       
        $out = '';
        
        
        $formModule = new Formulaire('module');
        
        if(
           !empty($formModule->i) && empty($formModule->e)
        ){
            
            $data['m_terms'] = 0;
            $data['m_legacy'] = 0;
            $data['m_sitemap'] = 0;
            $data['m_newsletter'] = 0;
            
            if( array_key_exists('terms',$formModule->i) ){ $data['m_terms'] = 1; }
            if( array_key_exists('legacy',$formModule->i) ){ $data['m_legacy'] = 1; }
            if( array_key_exists('sitemap',$formModule->i) ){ $data['m_sitemap'] = 1; }
            if( array_key_exists('newsletter',$formModule->i) ){ $data['m_newsletter'] = 1; }
            
            new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
            $this->dbQU(1,$data,'_website');
            new GenSitemapXml();
            $this->clearCache();
            header("Location:".$_SERVER['REQUEST_URI']);
            exit();
            
        }
        $isActive = '';
        $isChecked = '';
        
        //$timezone_identifiers = DateTimeZone::listIdentifiers();
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.config.form.modules.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        return $out;
        
    }
    
    
    private function formSiteweb(){
        
        // Gestion des labels
        $lTitre = $this->getWords("Titre");
        $lSlogan = $this->getWords("Slogan");
        $lDescription = $this->getWords("Description");
        $lCopyright = $this->getWords("Copyright");
        $lCreation = $this->getWords("Année de création");
        $lKeywords = $this->getWords("Mots clés");
        
        $lSave = '';
        
        $out = '';
        $isInfoTrad = new WebsiteTraduction($this->GetLangue());
        $isContentTad = $isInfoTrad->content();
        
        $formWebsite = new Formulaire('website');
        
        if(
           !empty($formWebsite->i) && empty($formWebsite->e)
        ){
            
            foreach($formWebsite->i as $k=>$v){
                
                $formWebsite->i[$k] = filter_input(INPUT_POST,'website_'.$k,FILTER_SANITIZE_STRING);
                
            }
            
            $dTheme['theme'] = $formWebsite->i['theme'];
            $dTheme['id_facebook'] = $formWebsite->i['id_facebook'];
            $dTheme['id_disqus'] = $formWebsite->i['id_disqus'];

            $this->dbQU(1,$dTheme,'_website');

            unset($formWebsite->i['theme']);
            unset($formWebsite->i['id_facebook']);
            unset($formWebsite->i['id_disqus']);
            
            new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
            $this->dbQU($isContentTad['langue'],$formWebsite->i,'_website_traduction','langue');
	    
            $this->clearCache();
            header("Location:".$_SERVER['REQUEST_URI']);
            exit();
            
        }
        
        $this->info['title'] = $isContentTad['title'];
        $this->info['slogan'] = $isContentTad['slogan'];
        $this->info['description'] = $isContentTad['description'];
        $this->info['copyright'] = $isContentTad['copyright'];
        $this->info['year'] = $isContentTad['year'];
        $this->info['keywords'] = $isContentTad['keywords'];
        $this->info['id_facebook'] = $this->info['id_facebook'];
        $this->info['id_disqus'] = $this->info['id_disqus'];
        $isAllTheme = Theme::inDir();
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.config.form.siteweb.tpl.php');
    	ob_start();
    	include $fTpl;
    	$out = ob_get_clean();
        return $out;
        
    }
    



    private function formAdresse(){
        
        $out = '';
        
        $formContact = new Formulaire('contact');
        
        if(
            !empty($formContact->i) && empty($formContact->e)
        ){
            
            foreach($formContact->i as $k=>$v){
                
                $formContact->i[$k] = filter_input(INPUT_POST,'contact_'.$k,FILTER_SANITIZE_STRING);
                
            }
            
            new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
            $this->dbQU(1,$formContact->i,'_website','id');
            $this->clearCache();
            header("Location:".$_SERVER['REQUEST_URI']);
            exit();
        }
        
        
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.config.form.adresse.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        return $out;
        
    }

    private function formMedia(){
        
        // Update logo image, png image only.
    
        if(isset($_FILES['img_logo'])){
            
            if(
                $_FILES['img_logo']['type'] === 'image/png'
            ){
                list($fichier_larg, $fichier_haut, $fichier_type)= getimagesize($_FILES['img_logo']['tmp_name']);
                $newFileName = THM.'ad_/img/logo.png';
                @copy($_FILES['img_logo']['tmp_name'],$newFileName);
                
                new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
                $this->clearCache();
                header("Location:".$_SERVER['REQUEST_URI']);
                exit();
            }
        
        }
        
        // Update icone image, *.ico image only.
        
        if(isset($_FILES['icone_logo'])){
            
            if(
                $_FILES['icone_logo']['type'] === 'image/x-icon'
            ){
                
                list($fichier_larg, $fichier_haut, $fichier_type)= getimagesize($_FILES['icone_logo']['tmp_name']);
                $newFileName = THM.'favicon.ico';
                @copy($_FILES['icone_logo']['tmp_name'],$newFileName);
                
                new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
                header("Location:".$_SERVER['REQUEST_URI']);
                exit();
                
            }
        
        }
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.config.form.media.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        return $out;
        
    }
    
    private function formNetwork(){
        
        
        $formNetwork = new Formulaire('network');
        
        if(
            !empty($formNetwork->i) && empty($formNetwork->e)
        ){
            
            foreach($formNetwork->i as $k=>$v){
                $formNetwork->i[$k] = filter_input(INPUT_POST,'network_'.$k,FILTER_SANITIZE_STRING);
            }
            
            new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
            $this->dbQU(1,$formNetwork->i,'_website','id');
            $this->clearCache();
            header("Location:".$_SERVER['REQUEST_URI']);
            exit();
        }
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.config.form.network.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        return $out;
        
    }
    
    
    private function formAnalytics(){
        
        
        $formWebsite = new Formulaire('website');
        
        if(
           !empty($formWebsite->i) && empty($formWebsite->e)
        ){
            
            foreach($formWebsite->i as $k=>$v){
                
                $formWebsite->i[$k] = filter_input(INPUT_POST,'website_'.$k,FILTER_SANITIZE_STRING);
                
            }
            
            new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
            $this->dbQU(1,$formWebsite->i,'_website','id');
            $this->clearCache();
            header("Location:".$_SERVER['REQUEST_URI']);
            exit();
            
        }
        
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.config.form.analytics.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        return $out;
        
    }
    
    private function formLangue(){
        
        $out = '';
        
        $arrLangue = $this->lg;
        
        $formLangue = new Formulaire('langue');
        
        if(
           !empty($formLangue->i) && empty($formLangue->e)
        ){
            $arrLangueUp = array();
            
            foreach($this->lg as $k=>$v){
                if(array_key_exists('lg_groupe_'.$k,$formLangue->i)){
                    $arrLangueUp[$k] = $v;
                }
            }
            
            $groupeLangue = serialize($arrLangueUp);
            
            $data['langue'] = $formLangue->i['lg'];;
            $data['langue_front'] = $formLangue->i['lg_front'];
            $data['langue_groupe'] = $groupeLangue;
            
            $this->dbQU(1,$data,'_website','id');
            $this->setLangue($formLangue->i['lg']);
            new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
	    $this->clearCache();
            header("Location:".$_SERVER['REQUEST_URI']);
            exit();
            
        }
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.config.form.langue.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        
        return $out;
    }
    
    private function formMentions(){
        
        $page = new PageHome('mentions',$this->GetLangue());
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.config.form.legacy.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        return $out;
        
    }
    
    private function formError(){
        
        $page = new PageHome('404',$this->GetLangue());
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.config.form.404.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        return $out;
        
    }
    
    private function formCGU(){
        
        $page = new PageHome('cgu',$this->GetLangue());
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.config.form.terms.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        return $out;
        
    }
    
    
}