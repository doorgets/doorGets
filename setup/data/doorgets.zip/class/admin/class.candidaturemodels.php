<?php
/**
 *
    doorGets CMS V4.1 -  28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class CandidatureModels extends Langue {
    
    private $get;
    
    public $table;
    
    
    public function __construct($table = 'contactezmoi',$lg= 'fr'){
        
        $this->setLangue($lg);
        $this->table = $table;
        
        if(isset($_GET['id']) && is_numeric($_GET['id'])){
            
            
            if( isset($_GET['action']) && $_GET['action'] === 'voir' ){
                
                $this->get =   $this->voir($_GET['id']);

            }elseif( isset($_GET['action']) && $_GET['action'] === 'supprimer' ){
                
                $this->get =   $this->formSupprimer($_GET['id']);
            }
            
        }else{
            
            $this->get =   $this->listing();
            
        }
        
    }
    
    public function get(){
        
        return $this->get;
        
    }
    
    
    
    public function voir($id){
        
        $out = '';
        
        $isUser = $this->dbQS($id,'candidature');
        if(empty($isUser)){
            
            header('Location:./?m='.$this->table);
            exit;
            
        }else{
            
            $file = THM.'ad_/img/user.png';
            if($isUser['sexe'] === 'men'){
                $file = THM.'ad_/img/user-h.png';
            }elseif($isUser['sexe'] === 'women'){
                $file = THM.'ad_/img/user-f.png';
            }
            
            $fTpl = TplTranslate::getAdmin('doorgets','m.candidaturemodels.voir.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
            
            
        }
        
        return $out;
        
        
    }
    
    public function listing($par=20){
        
        $iUsers = $this->dbQ('SELECT COUNT(*) as counter FROM candidature'." WHERE uri_module = '".$this->table."'");
        $cResultsInt = (int)$iUsers[0]['counter'];
        
        $valFilter = 'date';
        $outFilterAND = '';
        $outFilterORDER = ' date_creation DESC ';
        $urlPage = "./?m=".$this->table."&page=";
        
        if(isset($_GET['filter'])){
            $getFilter = filter_input(INPUT_GET,'filter',FILTER_SANITIZE_STRING);
            
        }
        
        $p = 1;
        $ini = 0;
        $per = $par;
        
        if(isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] <= (ceil($cResultsInt / $per))){
            
            $p = $_GET['page'];
            $ini = $p * $per - $per;
        }
        
        $sqlLimit = " WHERE uri_module = '".$this->table."' ORDER BY $outFilterORDER  LIMIT ".$ini.",".$per;
        
        $LgPrem = 'Première page';
        $LgPrec = 'Page précédente';
        $LgSuiv = 'Page suivante';
        $LgDern = 'Page final';
        
        if($cResultsInt > $per){
            
            $valPage = '<div class="pagination">'.Pagination::page($cResultsInt,$p,$per,$urlPage,$LgPrem,$LgPrec,$LgSuiv,$LgDern).'</div>';
            
            
        }else{
            $valPage = '';
        }
        
        $all = $this->dbQA('candidature',$sqlLimit);
        $cAll = count($all);
        
        $finalPer = $ini+$per;
        if( $finalPer >  $cResultsInt){
            $finalPer = $cResultsInt;
        }
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.candidaturemodels.index.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();

        return $out;
    }
    
    public function formSupprimer($id){
        
        $out = '';
        
        $isUser = $this->dbQS($id,'candidature');
        if(empty($isUser)){
            
            header('Location:./?m='.$this->table);
            exit;
            
        }else{
            
            $form = new formulaire('supprimer_candidature');
            
            if(!empty($form->i)){
                
                if(empty($form->e)){
                    
                    $this->dbQD($isUser['id'],'candidature');
                    new FlashInfoPut("Vos informations on été corréctement supprimer.");
                    header('Location:./?m='.$this->table);
                    exit();
                }
            }
            
            $fTpl = TplTranslate::getAdmin('doorgets','m.candidaturemodels.form.delete.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
        }
        
        return $out;
        
    }

    
    

}