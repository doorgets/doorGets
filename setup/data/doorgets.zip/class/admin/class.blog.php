<?php

/**
 *
    doorGets CMS V4.1 -  28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class Blog extends Langue{
    
    
    
    private $get;
    public $table;
    public $categorie;
    public $categorieSimple;
    public $rubrique;
    public $uri;
    
    public function __construct($table = 'contenu',$uri = 'contenu',$lg= 'fr'){
        
        $this->setLangue($lg);
        
        $q = '';
        
        if( isset($_GET['q']) && !empty($_GET['q']) ){
            
            $q = filter_input(INPUT_GET,'q',FILTER_SANITIZE_STRING);
            $q = mb_strtolower($q,'UTF-8');
        }
        
        $this->table = $table;
        $this->uri = $uri;
        
        $this->categorie = $this->loadCategorie($this->uri);
        
        $this->rubrique = 'all';
        if( isset($_GET['categorie']) ){
            $this->rubrique = htmlentities($_GET['categorie'],ENT_QUOTES);
        }
        
        $out = '';
        
        $this->get .=  $this->getSubMenu($uri);
        
        
        $this->get .=  $this->formSearch();
        
        
        if(isset($_GET['add_contenu'])){
            
            $this->get .=  $this->formAjouter();
        
        }elseif(isset($_GET['id']) ){
            
            $idContent = ctype_alnum(str_replace('-','',$_GET['id']));
            if($idContent){
                
                if( isset($_GET['action']) && $_GET['action'] === 'voir' ){
                
                    $this->get .=   $this->voir($_GET['id']);
    
                }elseif( isset($_GET['action']) && $_GET['action'] === 'modifier' ){
                    
                    $this->get .=   $this->formModifier($_GET['id']);
    
                }elseif( isset($_GET['action']) && $_GET['action'] === 'supprimer' ){
                    
                    $this->get .=   $this->formSupprimer($_GET['id']);
                }
            }
            
            
            
        }else{
            
            
            if(empty($q)){
                
                $this->get .=  $this->rubriqueCategorie();
            }
            $this->get .=   $this->listing();
            
        }
        
    }
    
    public function get(){
        
        return $this->get;
        
    }
    
    private function getSubMenu(){
        
        $iCommentsAttente = $this->dbQ("SELECT COUNT(*) as counter FROM _comments  WHERE validation = 0 ");
        $cResultsIntAttente = (int)$iCommentsAttente[0]['counter'];
        $cResComm = '';
        
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.blog.rubrique.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        return $out;
        
    }
    
    public function voir($id){
        
        $out = '';
        $lgActuel = $this->getLangueTradution();
        
        $isContenu = $this->dbQS($id,$this->table,'id');
        if(empty($isContenu)){
            
            header('Location:./?m='.$this->uri);
            exit;
            
        }else{
            
            $contentComment = new ContentCommentaire($isContenu['id'],'_comments',$this->uri,$this->GetLangue());
            $sComm = $this->getWords('Commentaire');
            if($contentComment->countCommentaire > 1){ $sComm = $this->getWords('Commentaires'); }
            
            $lgGroupe = unserialize($isContenu['groupe_traduction']);
            $idTraduction = $lgGroupe[$lgActuel];
            
            $idContenuTrad = $this->dbQS($idTraduction,$this->table.'_traduction');
            if(!empty($idContenuTrad)){
                
                
                $this->rubrique = $isContenu['categorie'];
                
                $idContenuTrad['image'] = THM.'data/'.$this->uri.'/'.$idContenuTrad['image'];
                
                $fileActive = THM.'ad_/img/voir.png';
                if(!$isContenu['active']){
                    $fileActive = THM.'ad_/img/pasvoir.png';
                }
                
                $fTpl = TplTranslate::getAdmin('doorgets','m.blog.voir.tpl.php');
                ob_start();
                include $fTpl;
                $out = ob_get_clean();
                
                $out .= $contentComment->listingCommentaire($isContenu['id'],$this->uri);
                
            }
        }
        
        
        
        return $out;
        
        
    }
    
    public function listing($par=20){
        
        $q = '';
        $lgActuel = $this->getLangueTradution();
        
        if( isset($_GET['q']) && !empty($_GET['q']) ){
            
            $q = filter_input(INPUT_GET,'q',FILTER_SANITIZE_STRING);
            $q = mb_strtolower($q,'UTF-8');
        }
        
        $qN = '';
        if( !empty($q) ){
            $qN = '&q='.$q;
        }
        
        $valFilter = 'date';
        $outFilterAND = '';
        $outFilterORDER = ' '.$this->table.'.date_creation DESC ';
        $outGroupe = 'all';
        $outSqlGroupe = '  ';
        $sqlGroupe = '';
        $getGroupe = '';
        
        $outRub = 'm='.$this->uri;
        
        if(isset($_GET['filter'])){
            $getFilter = filter_input(INPUT_GET,'filter',FILTER_SANITIZE_STRING);
            
        }
        if(isset($_GET['categorie'])){
            $getGroupe = filter_input(INPUT_GET,'categorie',FILTER_SANITIZE_STRING);
            $outGroupe = $getGroupe;
            $outSqlGroupe = " WHERE ".$this->table.".categorie = '$getGroupe'  ";
            $outRub .= '&categorie='.$getGroupe;
        }
        
        if( !empty($q) ){
            $outSqlGroupe = " WHERE ".$this->table."_traduction.id_content = ".$this->table.".id
            AND ".$this->table."_traduction.langue = '".$lgActuel."' ";
        }
        
        $champsliste[] = $this->table.'_traduction.titre';
        $champsliste[] = $this->table.'_traduction.description';
        $champsliste[] = $this->table.'_traduction.uri';
        $champsliste[] = $this->table.'_traduction.article_tinymce';
        
        if( !empty($q) && !empty($champsliste) ){
            $sqlGroupe .= " AND (";
            foreach($champsliste as $v){
                $sqlGroupe .= " ".$v." LIKE '%".$q."%' OR";
            }
            $sqlGroupe = substr($sqlGroupe,0,-2);
            $sqlGroupe .= ") ";
        }
        
        $outSqlGroupe = $outSqlGroupe.$sqlGroupe;
        
        $tAll = $this->table;
        if( !empty($q) ){
            $tAll = $this->table." , ".$this->table."_traduction ";
        }
        
        $iUsers = $this->dbQ("SELECT COUNT(*) as counter FROM $tAll $outSqlGroupe ");
        $cResultsInt = (int)$iUsers[0]['counter'];
        
        $urlPage = "./?$outRub$qN&page=";
        
        $p = 1;
        $ini = 0;
        $per = $par;
        
        if(isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] <= (ceil($cResultsInt / $per))){
            
            $p = $_GET['page'];
            $ini = $p * $per - $per;
        }
        
        $sqlLimit = " $outSqlGroupe  ORDER BY $outFilterORDER  LIMIT ".$ini.",".$per;
        
        $valPage = '';
        
        if($cResultsInt > $per){
            
            $valPage = Pagination::page($cResultsInt,$p,$per,$urlPage);
        }
        
        $all = $this->dbQA($tAll,$sqlLimit);
        $cAll = count($all);
        
        $finalPer = $ini+$per;
        if( $finalPer >  $cResultsInt){
            $finalPer = $cResultsInt;
        }
        
        $out = '';
        $q = '';
        
        if( isset($_GET['q']) && !empty($_GET['q']) ){
            
            $q = filter_input(INPUT_GET,'q',FILTER_SANITIZE_STRING);
            $q = mb_strtolower($q,'UTF-8');
        }
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.blog.index.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    }
    
    public function formAjouter(){
        
        $out = '';
        
        
        
        $form = new formulaire('ajouter_contenu');
        
        if(!empty($form->i)){
            
            
            // gestion des champs vide
            foreach($form->i as $k=>$v){
                if( 
                    empty($v) && $k !== 'description' && $k !== 'image' 
                    && $k !== 'meta_titre' && $k !== 'meta_description' 
                    && $k !== 'meta_keys' && $k !== 'sendto' && $k !== 'id_disqus'
                ){
                    
                    $form->e['ajouter_contenu_'.$k] = 'ok';
                    
                }
            }
            
            
            // gestion de la photo du contenu
            $extension = '.png';
            
            if (    isset($_FILES['ajouter_contenu_image']) &&
                    (
                        $_FILES['ajouter_contenu_image']["type"] == "image/jpeg"
                        || $_FILES['ajouter_contenu_image']["type"] == "image/png"
                    )
                    && ($_FILES['ajouter_contenu_image']["error"] === 0 )
            ){
                
                if($_FILES['ajouter_contenu_image']["type"] == "image/jpeg"){
                    $extension = '.jpg';
                }
                list($fichier_larg, $fichier_haut)=getimagesize($_FILES['ajouter_contenu_image']['tmp_name']);
                if($fichier_larg !== 300 || $fichier_haut!== 200){
                    $form->e['ajouter_contenu_image'] = 'ok';
                }
                
            }else{
                
                $form->e['ajouter_contenu_image'] = 'ok';
            }
            
            if(empty($form->e)){
                
                $uni = time().'-'.uniqid('doorgets').'';
                
                $nameFileImage = $uni.'-'.$this->table.$extension;
                
                $uploaddir = THM.'data/'.$this->uri.'/';
                if(!is_dir($uploaddir)){
                    @mkdir($uploaddir);
                    @copy('../'.$uploaddir.'index.php',$uploaddir.'index.php');
                }
                
                $uploadfile = $uploaddir . $nameFileImage;
                if(
                   move_uploaded_file($_FILES['ajouter_contenu_image']['tmp_name'], $uploadfile)
                ){
                    $form->i['image'] = $nameFileImage;
                }
            }
            
            // gestion de l'ui
            $lenUri = strlen($form->i['uri']);
            $var = str_replace('-','',$form->i['uri']);
            
            $isUriValide = ctype_alnum($var);
            if( empty($isUriValide) || $lenUri > 250 ){
                
                $form->e['ajouter_contenu_uri'] = 'ok';
                
            }else{
                
                $isUriExist = $this->dbQS($form->i['uri'],$this->table.'_traduction','uri');
                if( !empty($isUriExist) ){
                    
                    $form->e['ajouter_contenu_uri'] = 'ok';
                }
                
            }

            
            // validation si aucune erreur
            if(empty($form->e)){
                
                $data['categorie'] = $form->i['categorie'];
                $data['active'] = $form->i['active'];
                $data['comments'] = $form->i['comments'];
                $data['partage'] = $form->i['partage'];
                $data['mailsender'] = $form->i['mailsender'];
                $data['facebook'] = $form->i['facebook'];
                $data['disqus'] = $form->i['disqus'];
                $data['sendto'] = $form->i['sendto'];
                $data['id_disqus'] = $form->i['id_disqus'];
                $data['date_creation'] = time();
                
                //

                $idContent = $this->dbQI($data,$this->table);
                
                //
                
                $dataNext = $form->i;
                $dataNext['date_creation'] = time();
                
                unset($dataNext['active']);
                unset($dataNext['comments']);
                unset($dataNext['partage']);
                unset($dataNext['mailsender']);
                unset($dataNext['facebook']);
                unset($dataNext['disqus']);
                unset($dataNext['sendto']);
                unset($dataNext['id_disqus']);

                
                foreach($this->lg as $k=>$v){
                    
                    $dataNext['id_content'] = $idContent;
                    $dataNext['langue'] = $k;
                    $dataNext['uri'] = $form->i['uri'].'-'.$k;
                    $idTraduction[$k] = $this->dbQI($dataNext,$this->table.'_traduction');
                    
                }
                
                $dataModification['groupe_traduction'] = serialize($idTraduction);
                $this->dbQU($idContent,$dataModification,$this->table);
                
                //
                
                new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
                header('Location:./?m='.$this->uri.'&action=voir&id='.$idContent);
                exit();
                
            }
            
            new FlashInfoPut($this->getWords("Veuillez remplir correctement le formulaire."),"error");
            
        }
        
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.blog.form.add.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
        
    }
    
    
    public function formModifier($id){
        
        $out = '';
        
        $isContenu = $this->dbQS($id,$this->table,'id');
        if(empty($isContenu)){
            
            header('Location:./?m='.$this->uri.'');
            exit;
            
        }else{
            
            
            $lgActuel = $this->getLangueTradution();
            $lgGroupe = unserialize($isContenu['groupe_traduction']);
            $idTraduction = $lgGroupe[$lgActuel];
            
            $idContenuTrad = $this->dbQS($idTraduction,$this->table.'_traduction');
            
            if(!empty($idContenuTrad)){
                
                $form = new formulaire('modifier_contenu');
                
                if(!empty($form->i)){
                    
                    foreach($form->i as $k=>$v){
                        if( 
                            empty($v)  && $k !== 'description' && $k !== 'image'  && $k !== 'active'  
                            && $k !== 'active' && $k !== 'meta_titre' && $k !== 'meta_description' 
                            && $k !== 'meta_keys' && $k !== 'sendto' && $k !== 'id_disqus'
                        ){
                            
                            $form->e['modifier_contenu_'.$k] = 'ok';
                            
                        }
                    }
                    
                    $extension = '.png';
                    
                    if (    isset($_FILES['modifier_contenu_image']) &&
                            (
                                $_FILES['modifier_contenu_image']["type"] == "image/jpeg"
                                || $_FILES['modifier_contenu_image']["type"] == "image/png"
                            )
                            && ($_FILES['modifier_contenu_image']["error"] === 0 )
                    ){
                        
                        if($_FILES['modifier_contenu_image']["type"] == "image/jpeg"){
                            $extension = '.jpg';
                        }
                        list($fichier_larg, $fichier_haut)=getimagesize($_FILES['modifier_contenu_image']['tmp_name']);
                        if($fichier_larg !== 300 || $fichier_haut!== 200){
                            $form->e['modifier_contenu_image'] = 'ok';
                        }
                    }
                    
                    
                    if(empty($form->e)){
                        
                        $uni = time().'-'.uniqid('doorgets').'';
                        
                        $nameFileImage = $uni.'-'.$this->uri.$extension;
                        
                        $uploaddir = '../data/'.$this->uri.'/';
                        if(!is_dir($uploaddir)){
                            @mkdir($uploaddir);
                            @copy('../'.$uploaddir.'index.php',$uploaddir.'index.php');
                        }
                        
                        $uploadfile = $uploaddir . $nameFileImage;
                        
                        if(
                            $_FILES['modifier_contenu_image']["error"] === 0 
                            && move_uploaded_file($_FILES['modifier_contenu_image']['tmp_name'], $uploadfile)
                        ){
                            $form->i['image'] = $nameFileImage;
                        }
                        
                    }
                    
                    
                    // gestion de l'uri
                    $lenUri = strlen($form->i['uri']);
                    $var = str_replace('-','',$form->i['uri']);
                    
                    $isUriValide = ctype_alnum($var);
                    if( empty($isUriValide) || $lenUri > 250 ){
                        
                        $form->e['modifier_contenu_uri'] = 'ok';
                        
                    }else{
                        
                        $isUriExist = $this->dbQS($form->i['uri'], $this->table.'_traduction','uri'," AND id != ".$idContenuTrad['id']." ");
                        
                        if( !empty($isUriExist) ){
                            
                            $form->e['modifier_contenu_uri'] = 'ok';
                        }
                        
                    }
                    
                    if(empty($form->e)){
                        
                        if( !array_key_exists('active',$form->i) ){
                            $form->i['active'] = 0;
                        }
                        if( !array_key_exists('comments',$form->i) ){
                            $form->i['comments'] = 0;
                        }
                        if( !array_key_exists('partage',$form->i) ){
                            $form->i['partage'] = 0;
                        }
                        if( !array_key_exists('mailsender',$form->i) ){
                            $form->i['mailsender'] = 0;
                        }
                        if( !array_key_exists('facebook',$form->i) ){
                            $form->i['facebook'] = 0;
                        }
                        if( !array_key_exists('disqus',$form->i) ){
                            $form->i['disqus'] = 0;
                        }
                        
                        $dataContenu['active'] = $form->i['active'];
                        $dataContenu['comments'] = $form->i['comments'];
                        $dataContenu['partage'] = $form->i['partage'];
                        $dataContenu['mailsender'] = $form->i['mailsender'];
                        $dataContenu['facebook'] = $form->i['facebook'];
                        $dataContenu['disqus'] = $form->i['disqus'];
                        $dataContenu['sendto'] = $form->i['sendto'];
                        $dataContenu['id_disqus'] = $form->i['id_disqus'];
                        
                        $data = $form->i;

                        unset($data['active']);
                        unset($data['comments']);
                        unset($data['partage']);
                        unset($data['mailsender']);
                        unset($data['facebook']);
                        unset($data['disqus']);
                        unset($data['sendto']);
                        unset($data['id_disqus']);
                        
                        if( $idContenuTrad['categorie'] !== $form->i['categorie'] ){
                            
                            $iPortefolio = $this->dbQ('SELECT COUNT(*) as counter FROM '.$this->table.' WHERE categorie = '.$form->i['categorie']);
                            $cResultsInt = (int)$iPortefolio[0]['counter'];
                            $this->dbQL("UPDATE ".$this->table."_traduction SET categorie = '".$form->i['categorie']."' WHERE id_content = '".$idContenuTrad['id_content']."'");
                            
                            $dataContenu['categorie'] = $form->i['categorie'];
                            
                            
                        }
                        
                        $this->dbQU($isContenu['id'],$dataContenu,$this->table,'id');
                        $this->dbQU($idContenuTrad['id'],$data,$this->table.'_traduction','id');
                        
                        $this->clearCache();
                        
                        new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
                        header('Location:./?m='.$this->uri.'&action=voir&&lg='.$lgActuel.'&id='.$isContenu['id']);
                        exit();
                        
                    }
                    new FlashInfoPut($this->getWords("Veuillez remplir correctement le formulaire."),"error");
                }
                
                $isActiveContent = '';
                $isActiveComments = '';
                $isActiveEmail = '';
                $isActivePartage = '';
                $isActiveFacebook = '';
                $isActiveDisqus = '';

                if(!empty($isContenu['active'])){ $isActiveContent = 'checked'; }
                if(!empty($isContenu['comments'])){ $isActiveComments = 'checked'; }
                if(!empty($isContenu['partage'])){ $isActivePartage = 'checked'; }
                if(!empty($isContenu['mailsender'])){ $isActiveEmail = 'checked'; }
                if(!empty($isContenu['facebook'])){ $isActiveFacebook = 'checked'; }
                if(!empty($isContenu['disqus'])){ $isActiveDisqus = 'checked'; }
                

                
                $fTpl = TplTranslate::getAdmin('doorgets','m.blog.form.edit.tpl.php');
                ob_start();
                include $fTpl;
                $out = ob_get_clean();
            
            }
            
        }
        
        return $out;
        
    }
    
    public function formSupprimer($id){
        
        $out = '';
        $lgActuel = $this->getLangueTradution();
        $isContenu = $this->dbQS($id,$this->table,'id');
        
        if(empty($isContenu)){
            
            header('Location:./?m='.$this->uri.'');
            exit;
            
        }else{
            
            $form = new formulaire('supprimer_contenu');
            
            if(!empty($form->i)){
                
                if(empty($form->e)){
                    
                    $lgGroupe = unserialize($isContenu['groupe_traduction']);
                    foreach($lgGroupe as $v){
                        @$this->dbQD($v,$this->table.'_traduction');
                    }
                    
                    $this->dbQD($isContenu['id'],$this->table,'id');
                    $this->dbQL("DELETE FROM _comments WHERE uri_module = '".$this->uri."' AND uri_content = '".$isContenu['id']."' ");
                    $this->clearCache();
                    new FlashInfoPut("Vos informations on été corréctement supprimer.");
                    header('Location:./?m='.$this->uri.'');
                    exit();
                }
                
            }
            
            
            $fTpl = TplTranslate::getAdmin('doorgets','m.blog.form.delete.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
        }
        
        return $out;
        
    }


    
    
    public function loadCategorie($module=''){
        
        $out = array(0=>'Choisir...');
        $outs = array();
        
        $isAllRC = $this->dbQ("
        SELECT _categories.id as id,
        _categories.uri_module as module,
        _categories_traduction.nom as nom,
        _categories_traduction.uri as uri
        FROM _categories,_categories_traduction
        WHERE  _categories.id = _categories_traduction.id_cat
        AND _categories.uri_module = '$module'
        AND _categories_traduction.langue = '".$this->getLangueTradution()."'
        ORDER BY _categories.ordre ASC ");
        
        $cRC = count($isAllRC);
        if($cRC > 0){
            for($i=0;$i<$cRC;$i++){
                
                $out[$isAllRC[$i]['id']] = $isAllRC[$i]['nom'];
                
                $outs[$isAllRC[$i]['id']] = $isAllRC[$i]['nom'];
            }
        }
        $this->categorieSimple = $out;
        return $outs;
        
    }


    public function rubriqueCategorie(){
        
        $out = '';
        $rubrique = $this->categorieSimple;
        
        unset($rubrique[0]);
        
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.blog.categorie.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        
        return $out;
        
    }

    private function formSearch(){
        
        $q = '';
        $lgActuel = $this->getLangueTradution();
        
        if( isset($_GET['q']) && !empty($_GET['q']) ){
            
            $q = filter_input(INPUT_GET,'q',FILTER_SANITIZE_STRING);
            $q = mb_strtolower($q,'UTF-8');
        }
        
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.blog.form.search.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        
        return $out;
        
    }
    

    

}