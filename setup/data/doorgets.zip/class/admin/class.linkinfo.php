<?php

/**
 *
    doorGets CMS V4.1 -  28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class LinkInfo extends Langue{
    
    private $name;
    
    private $content;
    
    private $get;
    
    public function __construct($name = 'home',$lg= 'fr'){
        
        $this->setLangue($lg);
        
        $this->name = $name;
        $this->load();
        
        $this->get = $this->modifier();
        
        
        
    }
    
    public function get(){
        
        return $this->get;
        
    }
    
    public function load(){
        
        $lgActuel = $this->getLangueTradution();
        
        $isPage = $this->dbQS($this->name,'linkinfo','page'," AND langue = '$lgActuel' LIMIT 1 ");
        if( empty($isPage) ){
            
            $data['langue'] = $lgActuel;
            $data['page'] = $this->name;
            $data['content'] = '';
            $data['date_modification'] = time();
            
            $data['id'] = $this->dbQI($data,'linkinfo');
            
            $this->content = $data;
            
        }else{
            
            $this->content = $isPage;
            
        }
        
        
        
    }
    
    public function voir(){
        
        $out = '';
        
        $out .= html_entity_decode($this->content['content']);
        $out .= '<p style="text-align:right;"><a href="./?r='.$this->name.'&action" class="annuler">'.$this->getWords('Modifier cette page').'</a></p>';
        
        return $out;
        
    }
    
    public function modifier(){
        
        $out = '';
        $content = '';
        if( isset($_POST['link_add']) ){
            
            $content = $_POST['link_add'];
            
            $data['content'] = htmlentities($content,ENT_QUOTES);
            $data['date_modification'] = time();
            
            $this->dbQU($this->content['id'],$data,'linkinfo');
            new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
            header("Location:".$_SERVER['REQUEST_URI']);
            exit();
            
        }
        $this->content['content'] = htmlspecialchars_decode(html_entity_decode($this->content['content']));
        //$out .= '<label>'.$this->getWords('Modifier cette page').'</label>';
        $out .= '<div style="padding:0 0 15px;">';
        $out .= $this->genLangueMenu();
        $out .= '</div>';
        $out .= '<form method="post" style="text-align:left;"><label>Url</label>';
        $out .= '<input type="text"  value="'.$this->content['content'].'" name="link_add" id="link_add" >';
        $out .= '<br /><input type="submit" value="'.$this->getWords('Sauvegarder').'" />';
        $out .= '</form>';
        
        return $out;
        
    }
    
}