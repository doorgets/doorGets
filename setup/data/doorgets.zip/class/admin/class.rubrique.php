<?php

/**

    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class Rubrique extends Langue{
    
    public $table;
    
    public $root;
    
    public $subRubrique;
    
    public $cSubRubrique;
    
    public $info = array();
    
    public $get;
    
    public $up = 0;
    
    public function __construct($nameTable='_rubriques',$lg= 'fr'){
        
        $this->table = $nameTable;
        $this->setLangue($lg);
        
        if(isset($_GET['add_rubrique'])){
            
            $this->get =  $this->formAjouter();
        
        }elseif(isset($_GET['id']) && is_numeric($_GET['id'])){
            
            $this->id = $_GET['id'];
            
            if( isset($_GET['action']) && $_GET['action'] === 'voir' ){
                
                $this->get =   $this->voir();
                
            }elseif( isset($_GET['action']) && $_GET['action'] === 'modifier' ){
                
                $this->get =   $this->formModifier();
                
            }elseif( isset($_GET['action']) && $_GET['action'] === 'supprimer' ){
                
                $this->get =   $this->formSupprimer();
                
            }
            
        }else{
            
            $this->get =   $this->index();
            
            
        }
       
        
    }
    
    public function get(){
        
        return $this->get;
    }
    
    private function index($par = 20){
        
        
        $iUsers = $this->dbQ('SELECT COUNT(*) as counter FROM '.$this->table);
        $cResultsInt = (int)$iUsers[0]['counter'];
        
        $lgActuel = $this->getLangueTradution();
        $valFilter = 'date';
        $outFilterORDER = ' ordre ';
        $urlPage = "./?r=rubrique&page=";
        
        if(isset($_GET['filter'])){
            
            $getFilter = filter_input(INPUT_GET,'filter',FILTER_SANITIZE_STRING);
            
        }
        
        $p = 1; $ini = 0; $per = $par;
        
        if(isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] <= (ceil($cResultsInt / $per))){
            
            $p = $_GET['page']; $ini = $p * $per - $per;
            
        }
        
        $sqlLimit = " ORDER BY $outFilterORDER  LIMIT ".$ini.",".$per;
        
        
        $valPage = '';
        if($cResultsInt > $per){
            
            $valPage = Pagination::page($cResultsInt,$p,$per,$urlPage);
            
        }
        
        $all = $this->dbQA($this->table,$sqlLimit);
        $cAll = count($all);
        
        $finalPer = $ini+$per;
        if( $finalPer >  $cResultsInt){
            $finalPer = $cResultsInt;
        }
        
        
        $fTpl = TplTranslate::getAdmin('doorgets','z.rubrique.index.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
        
    }
    
    
    public function voir(){
        
        $id = $this->id;
        $out = '';
        $lgActuel = $this->getLangueTradution();
        
        $isContenu = $this->dbQS($id,$this->table,'id');
        if(empty($isContenu)){
            
            header('Location:./?r=rubrique');
            exit;
            
        }else{
            
            $isModule = $this->dbQS($isContenu['idModule'],'_modules');
            
            $fTpl = TplTranslate::getAdmin('doorgets','z.rubrique.voir.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
        }
        
        
        
        return $out;
        
        
    }
    
    private function formAjouter(){
        
        $iRubrique = $this->dbQ('SELECT COUNT(*) as counter FROM _rubrique ');
        $cResultsInt = (int)$iRubrique[0]['counter'];
        
        $form = new Formulaire('ajouter_rubrique');
        if(!empty($form->i)){
                
            foreach($form->i as $k=>$v){
                if(empty($v)  && $k !== 'idModule'  ){
                    
                    $form->e['ajouter_rubrique_'.$k] = 'ok';
                    
                }
            }
            if(empty($form->e)){
                
                $data['name'] = $form->i['name'];
                $data['ordre'] = $cResultsInt + 1;
                $data['idModule'] = $form->i['idModule'];
                $data['date_creation'] = time();
                
                $idContent= $this->dbQI($data,$this->table);
                
                new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
                header('Location:./?r=rubrique&action=voir&id='.$idContent);
                exit();
            }
            
            new FlashInfoPut($this->getWords("Veuillez remplir correctement le formulaire."),"error");
        }
            
            
        // view
        $fTpl = TplTranslate::getAdmin('doorgets','z.rubrique.form.add.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
        
    }
    
    
    private function formModifier(){
        
        $id = $this->id;
        $out = '';
        $lgActuel = $this->getLangueTradution();
        $isContenu = $this->dbQS($id,$this->table,'id');
        if(empty($isContenu)){
            
            header('Location:./?r=rubrique');
            exit;
            
        }else{
            
            $form = new Formulaire('modifier_rubrique');
            if(!empty($form->i)){
                
                foreach($form->i as $k=>$v){
                    if(empty($v)  && $k !== 'idModule'  ){
                        
                        $form->e['modifier_rubrique_'.$k] = 'ok';
                        
                    }
                }
                if(empty($form->e)){
                    
                    $data = $form->i;
                    
                    $this->dbQU($isContenu['id'],$data,$this->table,'id');
                    new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
                    $this->clearCache();
                    header('Location:./?r=rubrique&action=voir&id='.$isContenu['id']);
                    exit();
                }
            }
            // view
            $fTpl = TplTranslate::getAdmin('doorgets','z.rubrique.form.edit.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
            
        }
        
        return $out;
        
        
    }
    
    private function formSupprimer(){
        
        $id = $this->id;
        $out = '';
        $isContenu = $this->dbQS($id,$this->table,'id');
        if(empty($isContenu)){
            
            header('Location:./?r=rubrique');
            exit;
            
        }else{
            
            $form = new Formulaire('supprimer_rubrique');
            if( !empty($form->i) && empty($form->e)){
                
                $this->dbQD($isContenu['id'],$this->table,'id');
                $this->dbQL("UPDATE ".$this->table." SET ordre = ordre - 1 WHERE ordre > ".$isContenu['ordre']." ");
                new FlashInfoPut("Vos informations on été corréctement supprimer.");
                header('Location:./?r=rubrique');
                exit();
                
            }
            // view
            $fTpl = TplTranslate::getAdmin('doorgets','z.rubrique.form.delete.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
            
        }
        
        return $out;
        
    }
    
    private function moveDown($id,$pos,$max){
        
        $out = '';
        $form = new formulaire('moveUp_'.$id);
        if( !empty($form->i) ){
            if($pos < $max){
            
                $this->dbQL("UPDATE  ".$this->table." SET ordre = ordre - 1 WHERE ordre = $pos + 1 LIMIT 1");
                $this->dbQL("UPDATE  ".$this->table." SET ordre = ordre + 1 WHERE ordre = $pos AND id = $id LIMIT 1");
                
            }
            new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
            header('Location:'.$_SERVER['REQUEST_URI']);
            exit();
        }
        
        $fTpl = TplTranslate::getAdmin('doorgets','z.rubrique.form.movedown.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        
        return $out;
    }
    
    private function moveUp($id,$pos,$max){
        
        $out = '';
        $form = new formulaire('moveDown_'.$id);
        if( !empty($form->i) ){
            if($pos > 1){
                
                $this->dbQL("UPDATE  ".$this->table." SET ordre = ordre + 1 WHERE ordre = $pos - 1 LIMIT 1");
                $this->dbQL("UPDATE  ".$this->table." SET ordre = ordre - 1 WHERE  id = $id LIMIT 1");
                
            }
            new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
            header('Location:'.$_SERVER['REQUEST_URI']);
            exit();
        }
        
        $fTpl = TplTranslate::getAdmin('doorgets','z.rubrique.form.moveup.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        
        return $out;
    
    }
    
    public function loadModule($module =""){
        
        $out = array('-');
        $outRubrique = array();

        $isAllRubrique = $this->dbQ("SELECT idModule FROM _rubrique LIMIT 200");
        $cAllRubrique = count($isAllRubrique);
        if(!empty($isAllRubrique)){
            for($i=0;$i<$cAllRubrique;$i++){
                $outRubrique[] = $isAllRubrique[$i]['idModule'];
            }
        }

        $isAllModule = $this->dbQ("SELECT id,uri FROM _modules LIMIT 200");
        $cAllModule = count($isAllModule);
        if(!empty($isAllModule)){
            for($i=0;$i<$cAllModule;$i++){
                if(
                    $module == $isAllModule[$i]['id'] 
                ){
                        $out[$isAllModule[$i]['id']] = $isAllModule[$i]['uri'];
                    
                }else{
                    if(!in_array($isAllModule[$i]['id'], $outRubrique)){
                        $out[$isAllModule[$i]['id']] = $isAllModule[$i]['uri'];
                    }
                }
                
            }
        }

        
        return $out;
        
    }
    
}