<?php

/**
 *
    doorGets CMS V4.1 -  28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class ContentCommentaireAdmin extends Langue{
    
    private $get;
    
    private $table;
    
    private $_module;
    
    private $module;
    
    public $moduleGroup = array();
    
    public function __construct($lg= 'fr', $table = '_comments'){
        
        $this->setLangue($lg);
        $this->moduleGroup = $this->getModuleName();
        $q = '';
        
        if( isset($_GET['q']) && !empty($_GET['q']) ){
            
            $q = filter_input(INPUT_GET,'q',FILTER_SANITIZE_STRING);
            $q = mb_strtolower($q,'UTF-8');
        }
        
        $this->table = $table;
        $this->module = str_replace('_comments','',$table);
        
        $out = '';
        if(empty($q)){
            $this->get .=  $this->getSubMenu($q);
        }
        
        if(isset($_GET['id']) && is_numeric($_GET['id'])){
            
            
            if( isset($_GET['action']) && $_GET['action'] === 'voir' ){
                $this->get =   $this->rubrique($q);
                $this->get .=   $this->voir($_GET['id']);
                
            }elseif( isset($_GET['action']) && $_GET['action'] === 'supprimer' ){
                
                $this->get .=   $this->formSupprimer($_GET['id']);
                
            }
            
        }else{
            
            
            $this->get =   $this->rubrique($q);
            $this->get .=   $this->listing(20,$q);
            
        }
        
        
    }
    
    public function get(){
        
        return $this->get;
        
    }
    
    private function rubrique($q){
        
        $valFilter = 'all';
        if(isset($_GET['filter']) && !empty($_GET['filter'])){

            $getFilter = filter_input(INPUT_GET,'filter',FILTER_SANITIZE_STRING);
            
            if( in_array($getFilter,$this->moduleGroup) ){
                
                $valFilter = $getFilter;
                
            }
        }
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.module.commentaire.rubrique.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
            
        return $out;
        
        
    }
    
    private function getSubMenu($q){
        
        $out = '';
        
        $iCommentsAttente = $this->dbQ("SELECT COUNT(*) as counter FROM ".$this->module."_comments  WHERE validation = 0 ");
        $cResultsIntAttente = (int)$iCommentsAttente[0]['counter'];
        
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.module.commentaire.subrubrique.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
        
    }
    
    private function formSearch($q){
        
        $out = '';
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.module.commentaire.form.search.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
        
    }
    
    private function voir($id){
        
        $out = '';
        
        $isCommentaire = $this->dbQS($id,$this->table);
        if(empty($isCommentaire)){
            
            header('Location:./?r=comment');
            exit;
            
        }else{
            
            $isArchive = $this->getWords('Archiver');
            $isDeleted = '';
            $isLu = '';
            
            
            if(empty($isCommentaire['lu'])){
                
                $data['lu'] = 1;
                $this->dbQU($id,$data,$this->table);
            }
            
            $colorBack = '';
            if($isCommentaire['validation'] == 1){
                $colorBack = "background-color:#d4ffd8;";
            }
            if($isCommentaire['validation'] == 2){
                $colorBack = "background-color:#fec9cf;";
            }
            if($isCommentaire['archive'] == 1){
                $colorBack = "background-color:#cccccc;";
            }
            
            $ImageStatut = THM.'ad_/img/puce-orange.png';
            if($isCommentaire['validation'] == 1){
                $ImageStatut = THM.'ad_/img/puce-verte.png';
            }elseif($isCommentaire['validation'] == 2){
                $ImageStatut = THM.'ad_/img/puce-rouge.png';
            }
            
            $fTpl = TplTranslate::getAdmin('doorgets','m.module.commentaire.voir.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
            
            if(!$isCommentaire['archive']){
                
                $out .= $this->formValidation($id);
                
            }
            
            //$out .= $this->voirArticle($isCommentaire['uri_content']);
            
        }
        
        return $out;
        
        
    }
    
    private function listing($par=10,$q = ''){
        
        $qN = '';
        if( !empty($q) ){
            $qN = '&q='.$q;
        }
        $qV = '';
        $valFilter = 'all';
        $outFilterAND = '';
        $outFilterORDER = ' date_creation DESC ';
        $outGroupe = 'all';
        $outSqlGroupe = ' WHERE 0=0 ';
        $sqlGroupe = '';
        $getGroupe = '';
        
        if(isset($_GET['filter'])){
            
            $getFilter = filter_input(INPUT_GET,'filter',FILTER_SANITIZE_STRING);
            
            if( in_array($getFilter,$this->moduleGroup) ){
                
                $valFilter = $getFilter;
                $outFilterAND = " AND uri_module = '".$getFilter."' ";
                $qV = '&filter='.$getFilter;                
            }
            
        }
        
        $outSqlGroupe = ' WHERE 0=0 '.$outFilterAND;
        
        if( !empty($q) ){
            $outSqlGroupe = ' WHERE 0=0 ';
        }
        
        $champsliste[] = 'nom';
        $champsliste[] = 'email';
        $champsliste[] = 'comment';
        
        if( !empty($q) && !empty($champsliste) ){
            $sqlGroupe .= " AND (";
            foreach($champsliste as $v){
                $sqlGroupe .= " ".$v." LIKE '%".$q."%' OR";
            }
            $sqlGroupe = substr($sqlGroupe,0,-2);
            $sqlGroupe .= ") ";
        }
        
        $outSqlGroupe = $outSqlGroupe.$sqlGroupe;
        
        $iUsers = $this->dbQ('SELECT COUNT(*) as counter FROM '.$this->table.' '.$outSqlGroupe);
        $cResultsInt = (int)$iUsers[0]['counter'];
        
        $urlPage = "./?r=comment$qV$qN&page=";
        
        $p = 1;
        $ini = 0;
        $per = $par;
        
        if(isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] <= (ceil($cResultsInt / $per))){
            
            $p = $_GET['page'];
            $ini = $p * $per - $per;
        }
        
        $sqlLimit = " $outSqlGroupe  ORDER BY $outFilterORDER  LIMIT ".$ini.",".$per;
        
        
        
        if($cResultsInt > $per){
            
            $valPage = Pagination::page($cResultsInt,$p,$per,$urlPage);
            
        }else{
            
            $valPage = '';
        }
        
        $all = $this->dbQA($this->table,$sqlLimit);
        $cAll = count($all);
        
        $finalPer = $ini+$per;
        if( $finalPer >  $cResultsInt){
            $finalPer = $cResultsInt;
        }
        
        $iCommentsAttente = $this->dbQ("SELECT COUNT(*) as counter FROM ".$this->module."_comments  WHERE validation = 0 ");
        $cResultsIntAttente = (int)$iCommentsAttente[0]['counter'];
        $groupe = '';
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.module.commentaire.index.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    }
    
    


    private function formValidation($id){
        
        $out = '';
        
        $form = new formulaire('validation_commentaire');
        if(!empty($form->i)){
            
            if(empty($form->e)){
                
                $data = $form->i;
                $data['date_validation'] = time();
                
                $this->dbQU($id,$data,$this->table);
                new FlashInfoPut($this->getWords("Votre commentaire est maintenant accepté."));
                header('Location:'.$_SERVER['REQUEST_URI']);
                exit;
            }
            
        }
        $formno = new formulaire('validation_commentaire_no');
        if(!empty($formno->i)){
            
            if(empty($formno->e)){
                
                $data = $formno->i;
                $data['date_validation'] = time();
                
                $this->dbQU($id,$data,$this->table);
                new FlashInfoPut($this->getWords("Votre commentaire est maintenant refusé."));
                header('Location:'.$_SERVER['REQUEST_URI']);
                exit;
            }
            
        }
        
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.module.commentaire.form.validation.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    
        
    }

    private function formSupprimer($id){
        
        $out = '';
        $lgActuel = $this->getLangueTradution();
        $isCommentaire = $this->dbQS($id,$this->table,'id');
        if(empty($isCommentaire)){
            
            header('Location:./?r=comment');
            exit;
            
        }else{
            
            $form = new formulaire('supprimer_comment');
            
            if(!empty($form->i)){
                
                if(empty($form->e)){
                    
                    $this->dbQD($isCommentaire['id'],$this->table);
                    new FlashInfoPut($this->getWords("Suppression effectuée avec succès."));
                    header('Location:./?r=comment');
                    exit();
                }
            }
            
            
            $fTpl = TplTranslate::getAdmin('doorgets','m.module.commentaire.form.delete.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
            
            
        }
        
        return $out;
        
    }
    private function formArchiver($id){
        
        $out = '';
        
        $isCommentaire = $this->dbQS($id,$this->table);
        if(empty($isCommentaire)){
            
            header('Location:./?r=comment');
            exit;
            
        }else{
            
            $isArchive = $this->getWords('Archiver');
            $isDeleted = '';
            $isLu = '';
            
            if($isCommentaire['archive']){
                $isArchive = 'Désarchiver';
                $isDeleted = ' - <a href="./?r=comment&action=supprimer&id='.$isCommentaire['id'].'">'.$this->getWords('Supprimer définitivement').'</a>';
            }
            if(empty($isCommentaire['lu'])){
                
                $data['lu'] = 1;
                $this->dbQU($id,$data,$this->table);
            }
            $colorBack = '';
            if($isCommentaire['validation'] == 1){
                $colorBack = "background-color:#d4ffd8;";
            }
            if($isCommentaire['validation'] == 2){
                $colorBack = "background-color:#fec9cf;";
            }
            if($isCommentaire['archive'] == 1){
                $colorBack = "background-color:#cccccc;";
            }
            
            $form = new formulaire('archiver_comment');
            
            if(!empty($form->i)){
                
                if(empty($form->e)){
                    
                    $data['archive'] = $form->i['archive'];
                    $data['date_archive'] = time();
                    
                    $this->dbQU($isCommentaire['id'],$data,$this->table);
                    new FlashInfoPut($this->getWords("Votre commentaire est maintenant archiver."));
                    header('Location:./?r=comment&action=voir&id='.$id);
                    exit();
                }
            }
            
            $fTpl = TplTranslate::getAdmin('doorgets','m.module.commentaire.form.archive.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
            
            //$out .= $this->voirArticle($isCommentaire['uri_content']);
            
        }
        
        return $out;
        
    }

    private function getModuleName(){
        
        $out = array();
        $iModules = $this->dbQ("SELECT uri_module FROM _comments GROUP BY uri_module ORDER BY uri_module");
        $cModules = count($iModules);
        if(!empty($iModules)){
            for($i=0;$i<$cModules;$i++){
               $out[$iModules[$i]['uri_module']] = $iModules[$i]['uri_module'];
            }
        }
        return $out;

    }
    

}