<?php

/**
 *
    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/


class Uploader extends Langue{
    
    private $Get;
    
    private $sizeMax = 8192000;
    
    private $typeFile = array();
    private $typeExtension = array();
    private $typeImage = array();
    
    private $table;
    
    public function __construct($table='uploader',$lg= 'fr'){
        
        $this->setLangue($lg);
        $this->table = $table;
        $typeFile["image/png"] = "data/upload/png/";
        $typeFile["image/jpeg"] = "data/upload/jpg/";
        $typeFile["image/gif"] = "data/upload/gif/";
        
        $typeFile["application/zip"] = "data/upload/zip/";
        $typeFile["application/pdf"] = "data/upload/pdf/";
        $typeFile["application/x-shockwave-flash"] = "data/upload/swf/";
        
        $typeExtension["image/png"] = "png";
        $typeExtension["image/jpeg"] = "jpg";
        $typeExtension["image/gif"] = "gif";
        
        $typeExtension["application/zip"] = "zip";
        $typeExtension["application/pdf"] = "pdf";
        $typeExtension["application/x-shockwave-flash"] = "swf";
        
        $typeImage["image/png"] = '<img src="'.THM.'ad_/img/png.png" class="ico_fichier" >';
        $typeImage["image/jpeg"] = '<img src="'.THM.'ad_/img/jpg.png" class="ico_fichier" >';
        $typeImage["image/gif"] = '<img src="'.THM.'ad_/img/gif.png" class="ico_fichier" >';
        
        $typeImage["application/zip"] = '<img src="'.THM.'ad_/img/zip.png" class="ico_fichier" >';
        $typeImage["application/pdf"] = '<img src="'.THM.'ad_/img/pdf.png" class="ico_fichier" >';
        $typeImage["application/x-shockwave-flash"] = '<img src="'.THM.'ad_/img/swf.png" class="ico_fichier" >';
        
        $this->typeFile = $typeFile;
        $this->typeExtension = $typeExtension;
        $this->typeImage = $typeImage;
        
        if(isset($_GET['add_file'])){
            
            $this->Get = $this->formAdd();
        
        }elseif(isset($_GET['id']) && is_numeric($_GET['id'])){
            
            
            if( isset($_GET['action']) && $_GET['action'] === 'voir' ){
                
                $this->Get =   $this->voir($_GET['id']);
                $this->Get .=   '<br />';

            }elseif( isset($_GET['action']) && $_GET['action'] === 'modifier' ){
                
                $this->Get =   $this->formEdit($_GET['id']);
                $this->Get .=   '<br /><br />';
            }elseif( isset($_GET['action']) && $_GET['action'] === 'supprimer' ){
                
                $this->Get =   $this->formSupprimer($_GET['id']);
                $this->Get .=   '<br /><br />';
            }
            
        }else{
            
            $this->Get =   $this->listing(25);
            $this->Get .=   '<br /><br />';
            
        }
        
        
    }
    
    public function Get(){
        
        return $this->Get;
        
    }
    
    public function formAdd(){
        
        $out = '';
        
        $form = new formulaire('uploader');
        
        if( !empty($form->i) && empty($form->e) ){
            
            if( empty($form->i['name']) ){
                
                new FlashInfoPut($this->getWords("Veuillez saisir le nom du fichier."),"error");
                $form->e['uploader_name'] = 'ok';
                
            }
            if(  isset($_FILES['uploader_fichier']) &&  $_FILES['uploader_fichier']['error'] != 0  ){
                new FlashInfoPut($this->getWords("Veuillez importer un fichier valide."),"error");
                $form->e['uploader_fichier'] = 'ok';
            }
            
            if ( isset($_FILES['uploader_fichier']) && empty($form->e) ){
                
                if( !array_key_exists($_FILES['uploader_fichier']["type"],$this->typeFile)  ){
                    
                    new FlashInfoPut($this->getWords("Veuillez importer un fichier valide."),"error");
                    
                    $form->e['uploader_fichier'] = 'ok';
                
                }
                if( $_FILES['uploader_fichier']["size"] > $this->sizeMax ){
                    
                    new FlashInfoPut($this->getWords("Votre fichier est trop lourd."),"error");
                    
                    $form->e['uploader_fichier'] = 'ok';
                
                }
            }
            
            if(empty($form->e)){
                
                $ttff = $_FILES['uploader_fichier']["type"];
                
                $sSize = $_FILES['uploader_fichier']['size'];
                $ttf = $this->typeExtension[$ttff];
                $uni = time().'-'.uniqid($ttf);
                
                $nameFileImage = $uni.'-doorgets.'.$ttf;
                
                $uploaddir = $this->typeFile[$ttff];
                $uploadfile = THM.$uploaddir.$nameFileImage;
                
                if(
                    move_uploaded_file($_FILES['uploader_fichier']['tmp_name'], $uploadfile)
                ){
                    $form->i['fichier'] = $nameFileImage;
                }
                
                $data['type'] = $ttff;
                $data['nom'] = $form->i['name'];
                $data['description'] = $form->i['description'];
                
                $data['fichier'] = $nameFileImage;
                $data['poid'] = $sSize;
                $data['date_creation'] = time();
                
                new FlashInfoPut($this->getWords("Le fichier a bien été télécharger."));
                $idUser = $this->dbQI($data,$this->table);
                header('Location:'.$_SERVER['REQUEST_URI']);
                exit();
                
            }
            
        }
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.uploader.form.add.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        return $out;
    
    }
    
    public function formEdit($id){
        
        $out = '';
        
        $isFichier = $this->dbQS($id,$this->table,'id');
        if(empty($isFichier)){
            
            header('Location:./?r=fichier');
            exit;
            
        }else{
            
            
            $urlFile = URL.$this->typeFile[$isFichier['type']].$isFichier['fichier'];
            
            $form = new formulaire('modifier_fichier');
            
            if(!empty($form->i)){
                
                
                foreach($form->i as $k=>$v){
                    if(empty($v)  && $k !== 'description'  ){
                        
                        $form->e['modifier_fichier_'.$k] = 'ok';
                        
                    }
                }
                
                
                if(empty($form->e)){
                    
                    $data = $form->i;
                    
                    $this->dbQU($isFichier['id'],$data,$this->table);
                    new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
                    header('Location:./?r=fichier&action=voir&id='.$isFichier['id']);
                    exit();
                }
                
                new FlashInfoPut($this->getWords("Veuillez remplir correctement le formulaire."),"error");
            }
            
            $fTpl = TplTranslate::getAdmin('doorgets','m.uploader.form.edit.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
            
        }
        
        return $out;
    
    }
    
    public function listing($par=20){
        
        
        
        $valFilter = 'date';
        $outFilterAND = '';
        $outFilterORDER = ' nom ';
        $outGroupe = 'all';
        $outSqlGroupe = '  ';
        $sqlGroupe = '';
        $getGroupe = '';
        
        if(isset($_GET['filter'])){
            $getFilter = filter_input(INPUT_GET,'filter',FILTER_SANITIZE_STRING);
            
        }
        if(isset($_GET['groupe']) && $_GET['groupe'] != 'all'){
            $getGroupe = filter_input(INPUT_GET,'groupe',FILTER_SANITIZE_STRING);
            $outGroupe = $getGroupe;
            $outSqlGroupe = " WHERE type='$getGroupe' ";
        }
        $outSqlGroupe = $outSqlGroupe.$sqlGroupe;
        
        $iUsers = $this->dbQ('SELECT COUNT(*) as counter FROM '.$this->table." $outSqlGroupe  ");
        $cResultsInt = (int)$iUsers[0]['counter'];
        
        $p = 1;
        $ini = 0;
        $per = $par;
        
        if(isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] <= (ceil($cResultsInt / $per))){
            
            $p = $_GET['page'];
            $ini = $p * $per - $per;
        }
        
        $sqlLimit = " $outSqlGroupe ORDER BY $outFilterORDER  LIMIT ".$ini.",".$per;
        $urlPage = "./?r=fichier&groupe=$outGroupe&page=";
        
        
        
        if($cResultsInt > $per){
            
            $valPage = Pagination::page($cResultsInt,$p,$per,$urlPage);
            
            
        }else{
            $valPage = '';
        }
        
        $all = $this->dbQA($this->table,$sqlLimit);
        $cAll = count($all);
        
        $finalPer = $ini+$per;
        if( $finalPer >  $cResultsInt){
            $finalPer = $cResultsInt;
        }
        
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.uploader.index.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        return $out;
    }
    
    public function voir($id){
        
        $out = '';
        
        $isFile = $this->dbQS($id,$this->table,'id');
        if(empty($isFile)){
            
            header('Location:./?r=fichier');
            exit;
            
        }else{
            
            $urlFile = URL.$this->typeFile[$isFile['type']].$isFile['fichier'];
            $outGroupe = $isFile['type'];
            
            $fTpl = TplTranslate::getAdmin('doorgets','m.uploader.voir.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
            
        }
        
        return $out;
        
        
    }
    
    public function formSupprimer($id){
        
        $out = '';
        
        $isFichier = $this->dbQS($id,$this->table,'id');
        if(empty($isFichier)){
            
            header('Location:./?r=fichier');
            exit;
            
        }else{
            
            $urlFile = THM.$this->typeFile[$isFichier['type']].$isFichier['fichier'];
            
            $form = new formulaire('supprimer_fichier');
            
            if(!empty($form->i)){
                
                if(empty($form->e)){
                    
                    $this->dbQD($isFichier['id'],$this->table);
                    if(is_file($urlFile)){
                        @unlink($urlFile);
                    }
                    
                    new FlashInfoPut("Le fichier à été corréctement supprimer.");
                    header('Location:./?r=fichier');
                    exit();
                    
                }
            }
            
            $fTpl = TplTranslate::getAdmin('doorgets','m.uploader.form.delete.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
            
            
        }
        
        return $out;
        
    }
    
}
