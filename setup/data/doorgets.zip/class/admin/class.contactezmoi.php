<?php

/**
 *
    doorGets CMS V4.1 -  28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class contactezmoi extends Langue{
    
    private $get;
    
    public $table;
    
    public $module = array();
    
    public function __construct($table = 'contactezmoi',$lg= 'fr'){
        
        $this->setLangue($lg);
        $this->table = $table;
        $this->module = $this->getModuleName();
        
        $q = '';
        
        if( isset($_GET['q']) && !empty($_GET['q']) ){
            
            $q = filter_input(INPUT_GET,'q',FILTER_SANITIZE_STRING);
            $q = mb_strtolower($q,'UTF-8');
        }
        
        if(isset($_GET['id']) && is_numeric($_GET['id'])){
            
            
            if( isset($_GET['action']) && $_GET['action'] === 'voir' ){
                
                $this->get =   $this->rubrique($q);
                $this->get .=   $this->voir($_GET['id']);
                
            }elseif( isset($_GET['action']) && $_GET['action'] === 'supprimer' ){
                
                $this->get .=   $this->formSupprimer($_GET['id']);
                
            }
            
        }else{
            
            
            $this->get =   $this->rubrique($q);
            $this->get .=   $this->listing(10,$q);
            
            
        }
        
    }
    
    public function get(){
        
        return $this->get;
        
    }
    
    
    
    private function voir($id){
        
        $out = '';
        
        $isMessage = $this->dbQS($id,$this->table);
        if(empty($isMessage)){
            
            header('Location:./?r=contactezmoi');
            exit;
            
        }else{
            
            if(empty($isMessage['lu'])){
    
                $data['lu'] = 1;
                $data['date_lu'] = time();
                $this->dbQU($id,$data,$this->table);
            }

            $fTpl = TplTranslate::getAdmin('doorgets','m.contactezmoi.voir.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
            
        }
        
        return $out;
        
        
    }
    
    private function rubrique($q){
        
        $valFilter = 'all';
        if(isset($_GET['filter']) && !empty($_GET['filter'])){

            $getFilter = filter_input(INPUT_GET,'filter',FILTER_SANITIZE_STRING);
            
            if( in_array($getFilter,$this->module) ){
                
                $valFilter = $getFilter;
                
            }
        }
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.contactezmoi.rubrique.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
            
        return $out;
        
        
    }
    
    
    private function listing($par=10,$q = ''){
        
        $qN = '';
        if( !empty($q) ){
            $qN = '&q='.$q;
        }
        $qV = '';
        $valFilter = 'all';
        $outFilterAND = '';
        $outFilterORDER = ' date_creation DESC ';
        $outGroupe = 'all';
        $outSqlGroupe = ' WHERE archive = 0 ';
        $sqlGroupe = '';
        $getGroupe = '';
        
        if(isset($_GET['filter'])){

            $getFilter = filter_input(INPUT_GET,'filter',FILTER_SANITIZE_STRING);
            
            if( in_array($getFilter,$this->module) ){
                
                $valFilter = $getFilter;
                $outFilterAND = " AND uri_module = '".$getFilter."' ";
                $qV = '&filter='.$getFilter;                
            }
        }
        
        $outSqlGroupe = ' WHERE 0=0 '.$outFilterAND;
        
        if( !empty($q) ){
            $outSqlGroupe = ' WHERE 0=0 ';
        }
        
        $champsliste[] = 'nom';
        $champsliste[] = 'email';
        $champsliste[] = 'description';
        $champsliste[] = 'message';
        
        if( !empty($q) && !empty($champsliste) ){
            $sqlGroupe .= " AND (";
            foreach($champsliste as $v){
                $sqlGroupe .= " ".$v." LIKE '%".$q."%' OR";
            }
            $sqlGroupe = substr($sqlGroupe,0,-2);
            $sqlGroupe .= ") ";
        }
        
        $outSqlGroupe = $outSqlGroupe.$sqlGroupe;
        
        $iUsers = $this->dbQ('SELECT COUNT(*) as counter FROM '.$this->table.' '.$outSqlGroupe);
        $cResultsInt = (int)$iUsers[0]['counter'];
        
        $urlPage = "./?r=contactezmoi$qV$qN&page=";
        
        $p = 1;
        $ini = 0;
        $per = $par;
        
        if(isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] <= (ceil($cResultsInt / $per))){
            
            $p = $_GET['page'];
            $ini = $p * $per - $per;
        }
        
        $sqlLimit = " $outSqlGroupe  ORDER BY $outFilterORDER  LIMIT ".$ini.",".$per;
        
        
        
        if($cResultsInt > $per){
            
            $valPage = '<div class="pagination">'.Pagination::page($cResultsInt,$p,$per,$urlPage).'</div>';
            
            
        }else{
            $valPage = '';
        }
        
        $all = $this->dbQA($this->table,$sqlLimit);
        $cAll = count($all);
        
        $finalPer = $ini+$per;
        if( $finalPer >  $cResultsInt){
            $finalPer = $cResultsInt;
        }
        
        $groupe = '';
       
        $fTpl = TplTranslate::getAdmin('doorgets','m.contactezmoi.index.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();


        return $out;
    }
    
    
    
    private function formSupprimer($id){
        
        $out = '';
        
        $isMessage = $this->dbQS($id,$this->table,'id');
        if(empty($isMessage)){
            
            header('Location:./?r=contactezmoi');
            exit;
            
        }else{
            
            $form = new formulaire('supprimer_contactezmoi');
            
            if(!empty($form->i)){
                
                if(empty($form->e)){
                    
                    $this->dbQD($isMessage['id'],$this->table);
                    new FlashInfoPut($this->getWords("Suppression effectuée avec succès."));
                    header('Location:./?r=contactezmoi');
                    exit();
                }
            }
            
            $fTpl = TplTranslate::getAdmin('doorgets','m.contactezmoi.form.delete.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
        }
        
        return $out;
        
    }
    
    private function formSearch($q){
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.contactezmoi.form.search.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        return $out;
        
    }

    private function getModuleName(){
        
        $out = array();
        $iModules = $this->dbQ("SELECT uri_module FROM ".$this->table." GROUP BY uri_module ORDER BY uri_module");
        $cModules = count($iModules);
        if(!empty($iModules)){
            for($i=0;$i<$cModules;$i++){
               $out[$iModules[$i]['uri_module']] = $iModules[$i]['uri_module'];
            }
        }
        return $out;

    }

}