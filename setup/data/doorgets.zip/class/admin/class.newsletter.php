<?php

/**
 *
    doorGets CMS V4.1 - 28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class newsletter extends Langue {
    
    private $get;
    
    public $table;
    
    
    public function __construct($idUser=0,$table = 'newsletter',$lg= 'fr'){
        
        $this->setLangue($lg);
        $this->idUser = $idUser;
        
        $this->table = $table;
        
        if(isset($_GET['add_newsletter'])){
            
            $this->get =  $this->formAjouter($idUser);
        
        }elseif(isset($_GET['import_newsletter'])){
            
            $this->get =  $this->formImporter($idUser);
        
        }elseif(isset($_GET['id']) && is_numeric($_GET['id'])){
            
            
            if( isset($_GET['action']) && $_GET['action'] === 'voir' ){
                
                $this->get =   $this->voir($_GET['id']);

            }elseif( isset($_GET['action']) && $_GET['action'] === 'modifier' ){
                
                $this->get =   $this->formModifier($_GET['id']);
                

            }elseif( isset($_GET['action']) && $_GET['action'] === 'supprimer' ){
                
                $this->get =   $this->formSupprimer($_GET['id']);
                
            }
            
        }else{
            
            $this->get =   $this->listing();
            
            
        }
        
    }
    
    public function get(){
        
        return $this->get;
        
    }
    
    
    
    public function voir($id){
        
        $out = '';
        
        $isUser = $this->dbQS($id,$this->table,'id');
        if(empty($isUser)){
            
            header('Location:./?r=newsletter');
            exit;
            
        }else{
            
            $fTpl = TplTranslate::getAdmin('doorgets','m.newsletter.voir.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
        }
        
        return $out;
        
        
    }
    
    public function listing($par=20){
        
        $iUsers = $this->dbQ('SELECT COUNT(*) as counter FROM '.$this->table."  WHERE id_user = '".$this->idUser."'  ");
        $cResultsInt = (int)$iUsers[0]['counter'];
        
        $valFilter = 'date';
        $outFilterAND = '';
        $outFilterORDER = ' date_creation DESC ';
        $urlPage = "./?r=newsletter&page=";
        
        if(isset($_GET['filter'])){
            $getFilter = filter_input(INPUT_GET,'filter',FILTER_SANITIZE_STRING);
            
        }
        
        $p = 1;
        $ini = 0;
        $per = $par;
        
        if(isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] <= (ceil($cResultsInt / $per))){
            
            $p = $_GET['page'];
            $ini = $p * $per - $per;
        }
        
        $sqlLimit = " WHERE  id_user = '".$this->idUser."'  ORDER BY $outFilterORDER  LIMIT ".$ini.",".$per;
        
        
        
        if($cResultsInt > $per){
            
            $valPage = Pagination::page($cResultsInt,$p,$per,$urlPage);
            
            
        }else{
            $valPage = '';
        }
        
        $all = $this->dbQA($this->table,$sqlLimit);
        $cAll = count($all);
        
        $finalPer = $ini+$per;
        if( $finalPer >  $cResultsInt){
            $finalPer = $cResultsInt;
        }
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.newsletter.index.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();

        return $out;
    }
    
    public function formImporter($idUser=0){
        
        $out = '';
        
        $form = new formulaire('import_newsletter');
        
        $err = '';
        
        if(!empty($form->i)){
            
           
                if (    isset($_FILES['import_newsletter_fichier']) &&
                    (
                        $_FILES['import_newsletter_fichier']["type"] == "application/msword"
                        || $_FILES['import_newsletter_fichier']["type"] == "application/vnd.ms-excel"
                        || $_FILES['import_newsletter_fichier']["type"] == "text/plain"
                        || $_FILES['import_newsletter_fichier']["type"] == "text/csv"
                    )
                    && ($_FILES['import_newsletter_fichier']["error"] === 0 )
                ){
                    
                    
                    $uploaddir = '../data/temp/';
                    if(!is_dir($uploaddir)){
                        @mkdir($uploaddir);
                        @copy('../'.$uploaddir.'index.php',$uploaddir.'index.php');
                    }
                    
                    $uploadfile = $uploaddir .'co'.$idUser.'-'.time().'-'.$_FILES['import_newsletter_fichier']['name'];
                    
                    if(
                       move_uploaded_file($_FILES['import_newsletter_fichier']['tmp_name'], $uploadfile)
                    ){
                        
                        $extractMail = extractMail::file($uploadfile);
                        if(empty($extractMail)){
                            $err = $this->getWords("Aucune adresse mail trouvé dans le fichier importer.");
                            new FlashInfoPut($this->getWords("Aucune adresse mail trouvé dans le fichier importer."),"error");
                        }
                        
                    }
                    
                }else{
                    
                    $err = $this->getWords("Votre fichier n'est pas compatible");
                    //$form->e['import_newsletter_fichier'] = 'ok';
                    new FlashInfoPut($this->getWords("Veuillez importer un fichier valide."),"error");
                }
        }
        if(isset($extractMail) && !empty($extractMail)){
        
            new FlashInfoPut($this->getWords("Vos contacts ont été importés."));
            
            $cInMail = 0;
            $cOutMail = 0;
            foreach($extractMail as $k=>$v){
                
                $v = str_replace(',','',$v);
                
                $data['id_user'] = $this->idUser;
                $data['nom'] = $v;
                $data['email'] = $v;
                $data['date_creation'] = time();
                
                $isMail = $this->dbQS($v,'newsletter','email'," AND id_user = '".$this->idUser."' LIMIT 1 ");
                if(empty($isMail)){
                    
                    $this->dbQI($data,'newsletter');
                    $cInMail++;
                    
                }else{
                    
                    $cOutMail++;
                }
                
            }
            
            $sMail = $sEnMail = '';
            if($cInMail > 1){
                $sMail = $this->getWords('adresses emails importés.');
            }else{
                $sMail = $this->getWords('adresse e-mail importé.');
            }
            if($cOutMail > 0){
                $sMail = $sEnMail = '';
                if($cOutMail > 1){
                    $sMail = $this->getWords('adresses mails déja dans vos contacts.');
                }else{
                    $sMail = $this->getWords('adresse e-mail déja dans vos contacts.');
                }
            }
        
        }
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.newsletter.form.import.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        return $out;
    }
    
    public function formAjouter($idUser=0){
        
        $out = '';
        
        $form = new formulaire('ajouter_newsletter');
        
        if(!empty($form->i)){
            
            foreach($form->i as $k=>$v){
                if(empty($v) && $k !== 'description'){
                    
                    $form->e['ajouter_newsletter_'.$k] = 'ok';
                    
                }
            }
            $var = $form->i['email'];
            $isEmail = filter_var($var, FILTER_VALIDATE_EMAIL);
            $isEmailExist = $this->dbQS($var,'newsletter','email'," AND id_user = '".$this->idUser."' LIMIT 1 ");
            if( !empty($isEmailExist) ){
                
                $form->e['ajouter_newsletter_email'] = 'ok';
                
            }
            if( empty($isEmail) ){
                
                $form->e['ajouter_newsletter_email'] = 'ok';
                
            }
            if( empty($form->e )){
                
                $data = $form->i;
                $data['date_creation'] = time();
                
                $idUser = $this->dbQI($data,$this->table);
                new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
                header('Location:./?r=newsletter&action=voir&id='.$idUser);
                exit();
            }
            
            new FlashInfoPut($this->getWords("Veuillez remplir correctement le formulaire."),"error");
            
        }
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.newsletter.form.add.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        return $out;
        
    }
    
    
    public function formModifier($id){
        
        $out = '';
        
        $isUser = $this->dbQS($id,$this->table,'id',"  AND id_user = '".$this->idUser."' LIMIT 1 ");
        if(empty($isUser)){
            
            header('Location:./?r=newsletter');
            exit;
            
        }else{
            
            
            
            $form = new formulaire('modifier_newsletter');
            
            if(!empty($form->i)){
                
                
                foreach($form->i as $k=>$v){
                    if(empty($v)  && $k !== 'description'  ){
                        
                        $form->e['modifier_newsletter_'.$k] = 'ok';
                        
                    }
                }
                
                $var = $form->i['email'];
                $isEmail = filter_var($var, FILTER_VALIDATE_EMAIL);
                $isEmailExist = $this->dbQS($var,'newsletter','email'," AND id_user = '".$this->idUser."' AND id != '$id' LIMIT 1 ");
                if( !empty($isEmailExist) ){
                    
                    $form->e['modifier_newsletter_email'] = 'ok';
                    
                }
                if( empty($isEmail) ){
                    
                    $form->e['modifier_newsletter_email'] = 'ok';
                    
                }
                
                if(empty($form->e)){
                    
                    $data = $form->i;
                    
                    $this->dbQU($isUser['id'],$data,$this->table);
                    new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
                    header('Location:./?r=newsletter&action=voir&id='.$isUser['id']);
                    exit();
                }
                
                new FlashInfoPut($this->getWords("Veuillez remplir correctement le formulaire."),"error");
            }
            
            
            
            $fTpl = TplTranslate::getAdmin('doorgets','m.newsletter.form.edit.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
            
        }
        
        return $out;
        
    }
    
    public function formSupprimer($id){
        
        $isUser = $this->dbQS($id,$this->table,'id',"  AND id_user = '".$this->idUser."' LIMIT 1 ");
        if(empty($isUser)){
            
            header('Location:./?r=newsletter');
            exit;
            
        }else{
            
            $form = new formulaire('supprimer_newsletter');
            
            if(!empty($form->i)){
                
                if(empty($form->e)){
                    
                    $this->dbQD($isUser['id'],$this->table);
                    new FlashInfoPut("Le contact à été corréctement supprimer.");
                    header('Location:./?r=newsletter');
                    exit();
                }
            }
            
            
            
            
            $fTpl = TplTranslate::getAdmin('doorgets','m.newsletter.form.delete.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
            
        }
        
        return $out;
        
    }
    

}