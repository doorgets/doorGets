<?php

/**

    doorGets CMS V4.1 -  28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/


class Modules extends Langue{
    
    
    private $id;
    private $get;
    private $table;
    private $table_trad;
    private $liste;
    
    
    public function __construct($table = '_modules',$lg= 'fr'){
        
        $this->setLangue($lg);
        $this->table = $table;
        $this->table_trad = $table.'_traduction';
        
        $liste['page'] = $this->getWords('Page Static');
        $liste['news'] = $this->getWords('Actualité');
        $liste['blog'] = $this->getWords('Blog Articles');
        $liste['tuto'] = $this->getWords('Blog Vidéos');
        $liste['portefolio'] = $this->getWords("Galerie d'images");
        $liste['faq'] = $this->getWords('FAQ');
        $liste['liens'] = $this->getWords('Partenaires');
        $liste['link'] = $this->getWords('Lien externe');
        $liste['contact'] = $this->getWords('Formulaire de contact');
        $liste['candidaturemodels'] = $this->getWords('Formulaire de candidature').' ['.$this->getWords('Models').']';
        
        $this->liste = $liste;
        
        if(isset($_GET['add_module'])){
            
            $this->get =  $this->formAjouter();
        
        }elseif(isset($_GET['id']) && is_numeric($_GET['id'])){
            
            $this->id = $_GET['id'];
            
            if( isset($_GET['action']) && $_GET['action'] === 'voir' ){
                
                $this->get =   $this->voir();
                
            }elseif( isset($_GET['action']) && $_GET['action'] === 'modifier' ){
                
                $this->get =   $this->formModifier();
                
            }elseif( isset($_GET['action']) && $_GET['action'] === 'dupliquer' ){
                
                $this->get =   $this->formDupliquer();
                
            }elseif( isset($_GET['action']) && $_GET['action'] === 'supprimer' ){
                
                $this->get =   $this->formSupprimer();
                
            }
            
        }else{
            
            $this->get =   $this->index(20);
            
            
        }
        
    }
    
    public function get(){
        
        return $this->get;
        
    }
    
    private function index($par = 20){
        
        
        $iUsers = $this->dbQ('SELECT COUNT(*) as counter FROM '.$this->table);
        $cResultsInt = (int)$iUsers[0]['counter'];
        
        $lgActuel = $this->getLangueTradution();
        $valFilter = 'date';
        $outFilterORDER = ' uri ';
        $urlPage = "./?r=gestion&page=";
        
        if(isset($_GET['filter'])){
            
            $getFilter = filter_input(INPUT_GET,'filter',FILTER_SANITIZE_STRING);
            
        }
        
        $p = 1; $ini = 0; $per = $par;
        
        if(isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] <= (ceil($cResultsInt / $per))){
            
            $p = $_GET['page']; $ini = $p * $per - $per;
            
        }
        
        $sqlLimit = " ORDER BY $outFilterORDER  LIMIT ".$ini.",".$per;
        
        
        $valPage = '';
        if($cResultsInt > $per){
            
            $valPage = Pagination::page($cResultsInt,$p,$per,$urlPage);
            
        }
        
        $all = $this->dbQA($this->table,$sqlLimit);
        $cAll = count($all);
        
        $finalPer = $ini+$per;
        if( $finalPer >  $cResultsInt){
            $finalPer = $cResultsInt;
        }
        
        
        $fTpl = TplTranslate::getAdmin('doorgets','z.modules.index.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
        
    }
    
    
    public function voir(){
        
        $id = $this->id;
        $out = '';
        $lgActuel = $this->getLangueTradution();
        
        $isContenu = $this->dbQS($id,$this->table,'id');
        if(empty($isContenu)){
            
            header('Location:./?r=gestion');
            exit;
            
        }else{
            
            $lgGroupe = unserialize($isContenu['groupe_traduction']);
            $idTraduction = $lgGroupe[$lgActuel];
            
            $idContenuTrad = $this->dbQS($idTraduction,$this->table.'_traduction');
            if(!empty($idContenuTrad)){
                
                $fileActive = THM.'ad_/img/voir.png';
                if(!$isContenu['active']){
                    $fileActive = THM.'ad_/img/pasvoir.png';
                }
                
                $fTpl = TplTranslate::getAdmin('doorgets','z.modules.voir.tpl.php');
                ob_start();
                include $fTpl;
                $out = ob_get_clean();
                
                
            }
        }
        
        
        
        return $out;
        
        
    }
    
    private function formAjouter(){
        
        $form = new Formulaire('ajouter_module');
        
        // model
        if(!empty($form->i)){
            
            foreach($form->i as $k=>$v){
                if(empty($v) && $k !== 'description' && $k !== 'article_tinymce' && $k !== 'image'  && $k !== 'meta_titre' && $k !== 'meta_description' && $k !== 'meta_keys' ){
                    
                    $form->e['ajouter_module_'.$k] = 'ok';
                    
                }
            }
            // gestion de l'image
            $extension = '.png';
            
            if (    isset($_FILES['ajouter_module_image']) &&
                    (
                        $_FILES['ajouter_module_image']["type"] == "image/jpeg"
                        || $_FILES['ajouter_module_image']["type"] == "image/png"
                    )
                    && ($_FILES['ajouter_module_image']["error"] === 0 )
            ){
                
                if($_FILES['ajouter_module_image']["type"] == "image/jpeg"){
                    $extension = '.jpg';
                }
                list($fichier_larg, $fichier_haut)=getimagesize($_FILES['ajouter_module_image']['tmp_name']);
                if($fichier_larg !== 50 || $fichier_haut!== 50){
                    $form->e['ajouter_module_image'] = 'ok';
                }
                
            }
            
            
            if(empty($form->e)){
                
                $uni = time().'-'.uniqid('doorgets').'';
                
                $nameFileImage = $uni.'-'.$extension;
                
                $uploaddir = THM.'data/_gestion/';
                if(!is_dir($uploaddir)){
                    @mkdir($uploaddir);
                    @copy('../'.$uploaddir.'index.php',$uploaddir.'index.php');
                }
                
                $uploadfile = $uploaddir . $nameFileImage;
                if(
                   move_uploaded_file($_FILES['ajouter_module_image']['tmp_name'], $uploadfile)
                ){
                    $form->i['image'] = $nameFileImage;
                }
            }
            
            // gestion de l'ui
            $lenUri = strlen($form->i['uri']);
            $isUriValide = ctype_alnum($form->i['uri']);
            if( empty($isUriValide) || $lenUri > 250 ){
                
                $form->e['ajouter_module_uri'] = 'ok';
                
            }else{
                 
                $isUriExist = $this->dbQS($form->i['uri'],$this->table,'uri');
                if( !empty($isUriExist) ){
                    
                    $form->e['ajouter_module_uri'] = 'ok';
                }
                
            }
            
            if(empty($form->e)){
                
                if( !array_key_exists('active',$form->i) ){
                    $form->i['active'] = 0;
                }
                if( !array_key_exists('notification_mail',$form->i) ){
                    $form->i['notification_mail'] = 0;
                }
                if( !array_key_exists('is_first',$form->i) ){
                    $form->i['is_first'] = 0;
                }
                if( !array_key_exists('image',$form->i) ){
                    $form->i['image'] = '';
                }
                
                $data['uri'] = $form->i['uri'];
                $data['type'] = $form->i['type'];
                $data['active'] = $form->i['active'];
                $data['is_first'] = $form->i['is_first'];
                $data['bynum'] = $form->i['bynum'];
                $data['avoiraussi'] = $form->i['avoiraussi'];
                $data['image'] = $form->i['image'];
                $data['notification_mail'] = $form->i['notification_mail'];
                $data['date_creation'] = time();
                if($data['is_first'] == 1){
                       
                    $this->dbQL("UPDATE ".$this->table." SET is_first = 0 WHERE id >= 1");
                  
                }
                $idModule = $this->dbQI($data,$this->table);
                
                //
                
                $dataNext = $form->i;
                
                unset($dataNext['active']);
                unset($dataNext['type']);
                unset($dataNext['uri']);
                unset($dataNext['is_first']);
                unset($dataNext['bynum']);
                unset($dataNext['avoiraussi']);
                unset($dataNext['notification_mail']);
                unset($dataNext['image']);
                
                foreach($this->lg as $k=>$v){
                    
                    $dataNext['id_module'] = $idModule;
                    $dataNext['langue'] = $k;
                    $dataNext['date_modification'] = time();
                    $idTraduction[$k] = $this->dbQI($dataNext,$this->table_trad);
                    
                }
                
                $dataModification['groupe_traduction'] = serialize($idTraduction);
                $this->dbQU($idModule,$dataModification,$this->table);
                
                switch($data['type']){
                    
                    case 'tuto':
                        $sql = $this->getSqlTuto($data['uri']);
                        $this->dbQL($sql);
                        break;
                    case 'blog':
                        $sql = $this->getSqlBlog($data['uri']);
                        $this->dbQL($sql);
                        break;
                    case 'portefolio':
                        $sql = $this->getSqlPortefolio($data['uri']);
                        $this->dbQL($sql);
                        break;
                    case 'faq':
                        $sql = $this->getSqlFaq($data['uri']);
                        $this->dbQL($sql);
                        break;
                    case 'liens':
                        $sql = $this->getSqlLiens($data['uri']);
                        $this->dbQL($sql);
                        break;
                    case 'news':
                        $sql = $this->getSqlNews($data['uri']);
                        $this->dbQL($sql);
                        break;
                    
                }
                
                //
                
                new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
                header('Location:./?r=gestion');
                exit();
                
            }
            
            new FlashInfoPut($this->getWords("Veuillez remplir correctement le formulaire."),"error");
            
        }
        $numGroupe = array();
        for($i=1;$i<100;$i++){
            $numGroupe[$i] = $i;
        }
        
        
        // view
        $fTpl = TplTranslate::getAdmin('doorgets','z.modules.form.add.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
        
    }
    
    private function formDupliquer(){
        
        $id = $this->id;
        $out = '';
        
        $isContenu = $this->dbQS($id,$this->table,'id');
        if(empty($isContenu)){
            
            header('Location:./?r=gestion');
            exit;
            
        }else{
            
            $lgActuel = $this->getLangueTradution();
            $lgGroupe = unserialize($isContenu['groupe_traduction']);
            $idTraduction = $lgGroupe[$lgActuel];
            
            $idContenuTrad = $this->dbQS($idTraduction,$this->table.'_traduction');
            
            if(!empty($idContenuTrad)){
                
                $numGroupe = array();
                for($i=1;$i<100;$i++){
                    $numGroupe[$i] = $i;
                }
                
                $form = new Formulaire('dupliquer_module');
                
                // model
                if(!empty($form->i)){
                    
                    foreach($form->i as $k=>$v){
                        if(empty($v) && $k !== 'description' && $k !== 'article_tinymce' && $k !== 'image'  && $k !== 'meta_titre' && $k !== 'meta_description' && $k !== 'meta_keys' ){
                            
                            $form->e['dupliquer_module_'.$k] = 'ok';
                            
                        }
                    }
                    // gestion de l'image
                    $extension = '.png';
                    
                    if (    isset($_FILES['dupliquer_module_image']) &&
                            (
                                $_FILES['dupliquer_module_image']["type"] == "image/jpeg"
                                || $_FILES['dupliquer_module_image']["type"] == "image/png"
                            )
                            && ($_FILES['dupliquer_module_image']["error"] === 0 )
                    ){
                        
                        if($_FILES['dupliquer_module_image']["type"] == "image/jpeg"){
                            $extension = '.jpg';
                        }
                        list($fichier_larg, $fichier_haut)=getimagesize($_FILES['dupliquer_module_image']['tmp_name']);
                        if($fichier_larg !== 50 || $fichier_haut!== 50){
                            $form->e['dupliquer_module_image'] = 'ok';
                        }
                        
                    }
                    
                    
                    if(empty($form->e)){
                        
                        $uni = time().'-'.uniqid('doorgets').'';
                        
                        $nameFileImage = $uni.'-'.$extension;
                        
                        $uploaddir = THM.'data/_gestion/';
                        if(!is_dir($uploaddir)){
                            @mkdir($uploaddir);
                            @copy('../'.$uploaddir.'index.php',$uploaddir.'index.php');
                        }
                        
                        $uploadfile = $uploaddir . $nameFileImage;
                        if(
                           move_uploaded_file($_FILES['dupliquer_module_image']['tmp_name'], $uploadfile)
                        ){
                            $form->i['image'] = $nameFileImage;
                        }
                    }
                    
                    // gestion de l'ui
                    $lenUri = strlen($form->i['uri']);
                    $isUriValide = ctype_alnum($form->i['uri']);
                    if( empty($isUriValide) || $lenUri > 250 ){
                        
                        $form->e['dupliquer_module_uri'] = 'ok';
                        
                    }else{
                         
                        $isUriExist = $this->dbQS($form->i['uri'],$this->table,'uri');
                        if( !empty($isUriExist) ){
                            
                            $form->e['dupliquer_module_uri'] = 'ok';
                        }
                        
                    }
                    
                    if(empty($form->e)){
                        
                        if( !array_key_exists('is_first',$form->i) ){
                            $form->i['is_first'] = 0;
                        }
                        if( !array_key_exists('notification_mail',$form->i) ){
                            $form->i['notification_mail'] = 0;
                        }
                        if( !array_key_exists('image',$form->i) ){
                            $form->i['image'] = '';
                        }
                        
                        $data['uri'] = $form->i['uri'];
                        $data['type'] = $isContenu['type'];
                        $data['active'] = $form->i['active'];
                        $data['is_first'] = $form->i['is_first'];
                        $data['bynum'] = $form->i['bynum'];
                        $data['avoiraussi'] = $form->i['avoiraussi'];
                        $data['image'] = $isContenu['image'];
                        $data['notification_mail'] = $form->i['notification_mail'];
                        $data['date_creation'] = time();
                        if($data['is_first'] == 1){
                               
                            $this->dbQL("UPDATE ".$this->table." SET is_first = 0 WHERE id >= 1");
                          
                        }
                        $idModule = $this->dbQI($data,$this->table);
                        
                        //
                        
                        $dataNext = $form->i;
                        
                        unset($dataNext['active']);
                        unset($dataNext['type']);
                        unset($dataNext['uri']);
                        unset($dataNext['is_first']);
                        unset($dataNext['bynum']);
                        unset($dataNext['avoiraussi']);
                        unset($dataNext['notification_mail']);
                        unset($dataNext['image']);
                        
                        foreach($this->lg as $k=>$v){
                            
                            $dataNext['id_module'] = $idModule;
                            $dataNext['langue'] = $k;
                            $dataNext['date_modification'] = time();
                            $idTraductionGo[$k] = $this->dbQI($dataNext,$this->table_trad);
                            
                        }
                        
                        $dataModification['groupe_traduction'] = serialize($idTraductionGo);
                        $this->dbQU($idModule,$dataModification,$this->table);
                        if( $isContenu['type'] !== 'page' && $isContenu['type'] !== 'link'){
                            $sql = $this->getSqlCopy($isContenu['uri'],$data['uri']);
                            $this->dbQL($sql);
                        }
                        
                        
                        //
                        
                        new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
                        header('Location:./?r=gestion');
                        exit();
                        
                    }
                    
                    new FlashInfoPut($this->getWords("Veuillez remplir correctement le formulaire."),"error");
                    
                }
                
                
                $imageIcone = THM.'data/_gestion/'.$isContenu['image'];
                
                if(!is_file($imageIcone)){
                    $imageIcone = THM.'ad_/img/ico_module.png';
                }
                $isActiveModule = '';
                if(!empty($isContenu['active'])){ $isActiveModule = 'checked'; }
                $isActiveNotification = '';
                if(!empty($isContenu['notification_mail'])){ $isActiveNotification = 'checked'; }
                $isHomePage = '';
                if(!empty($isContenu['is_first'])){ $isHomePage = 'checked'; }
                
                $fTpl = TplTranslate::getAdmin('doorgets','z.modules.form.copy.tpl.php');
                ob_start();
                include $fTpl;
                $out = ob_get_clean();
                
            }
        }
        
        return $out;
        
    }
    
    private function formModifier(){
        
        $id = $this->id;
        $isContenu = $this->dbQS($id,$this->table,'id');
        if(empty($isContenu)){
            
            header('Location:./?r=gestion');
            exit;
            
        }else{
            
            
            $lgActuel = $this->getLangueTradution();
            $lgGroupe = unserialize($isContenu['groupe_traduction']);
            $idTraduction = $lgGroupe[$lgActuel];
            
            $idContenuTrad = $this->dbQS($idTraduction,$this->table.'_traduction');
            
            if(!empty($idContenuTrad)){
                
                $numGroupe = array();
                for($i=1;$i<100;$i++){
                    $numGroupe[$i] = $i;
                }
                
                $form = new Formulaire('modifier_module');
                if(!empty($form->i)){
                    
                    foreach($form->i as $k=>$v){
                        if(empty($v)  && $k !== 'description' && $k !== 'article_tinymce' && $k !== 'image'  && $k !== 'active' && $k !== 'meta_titre' && $k !== 'meta_description' && $k !== 'meta_keys' ){
                            
                            $form->e['modifier_module_'.$k] = 'ok';
                            
                        }
                    }
                    
                    $extension = '.png';
                    
                    if (    isset($_FILES['modifier_module_image']) &&
                            (
                                $_FILES['modifier_module_image']["type"] == "image/jpeg"
                                || $_FILES['modifier_module_image']["type"] == "image/png"
                            )
                            && ($_FILES['modifier_module_image']["error"] === 0 )
                    ){
                        
                        if($_FILES['modifier_module_image']["type"] == "image/jpeg"){
                            $extension = '.jpg';
                        }
                        list($fichier_larg, $fichier_haut)=getimagesize($_FILES['modifier_module_image']['tmp_name']);
                        if($fichier_larg !== 50 || $fichier_haut!== 50){
                            $form->e['modifier_module_image'] = 'ok';
                        }
                    }
                    
                    if(empty($form->e) && isset($_FILES['modifier_module_image'])){
                        
                        $uni = time().'-'.uniqid('doorgets').'';
                        
                        $nameFileImage = $uni.'-'.$extension;
                        
                        $uploaddir = THM.'data/_gestion/';
                        if(!is_dir($uploaddir)){
                            @mkdir($uploaddir);
                            @copy('../'.$uploaddir.'index.php',$uploaddir.'index.php');
                        }
                        
                        $uploadfile = $uploaddir . $nameFileImage;
                        
                        if(
                            $_FILES['modifier_module_image']["error"] === 0 
                            && move_uploaded_file($_FILES['modifier_module_image']['tmp_name'], $uploadfile)
                        ){
                            $form->i['image'] = $nameFileImage;
                        }
                        
                    }
                    
                    if(empty($form->e)){
                        
                        if( !array_key_exists('active',$form->i) ){
                            $form->i['active'] = 0;
                        }

                        if( !array_key_exists('notification_mail',$form->i) ){
                            $form->i['notification_mail'] = 0;
                        }
                        if( array_key_exists('image',$form->i) ){
                            $dataContenu['image'] = $form->i['image'];
                        }
                        if( !array_key_exists('is_first',$form->i) ){
                            $form->i['is_first'] = 0;
                        }
                        
                        $dataContenu['active'] = $form->i['active'];
                        $dataContenu['bynum'] = $form->i['bynum'];
                        $dataContenu['avoiraussi'] = $form->i['avoiraussi'];
                        $dataContenu['notification_mail'] = $form->i['notification_mail'];
                        $dataContenu['is_first'] = $form->i['is_first'];
                        
                        
                        if($dataContenu['is_first'] == 1){
                       
                            $this->dbQL("UPDATE ".$this->table." SET is_first = 0 WHERE id >= 1");
                          
                        }
                        
                        
                        $data = $form->i;
                        unset($data['active']);
                        unset($data['bynum']);
                        unset($data['avoiraussi']);
                        unset($data['notification_mail']);
                        unset($data['is_first']);
                        unset($data['image']);
                        
                        $this->dbQU($isContenu['id'],$dataContenu,$this->table,'id');
                        $this->dbQU($idContenuTrad['id'],$data,$this->table_trad,'id');
                        
                        $this->clearCache();
                        
                        new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
                        header('Location:./?r=gestion');
                        exit();
                        
                    }
                    new FlashInfoPut($this->getWords("Veuillez remplir correctement le formulaire."),"error");
                }
                
                $imageIcone = THM.'data/_gestion/'.$isContenu['image'];
            
                if(!is_file($imageIcone)){
                    $imageIcone = THM.'ad_/img/ico_module.png';
                }
                $isActiveModule = '';
                if(!empty($isContenu['active'])){ $isActiveModule = 'checked'; }
                $isActiveNotification = '';
                if(!empty($isContenu['notification_mail'])){ $isActiveNotification = 'checked'; }
                $isHomePage = '';
                if(!empty($isContenu['is_first'])){ $isHomePage = 'checked'; }
                
                $fTpl = TplTranslate::getAdmin('doorgets','z.modules.form.edit.tpl.php');
                ob_start();
                include $fTpl;
                $out = ob_get_clean();
            }
        }
        
        return $out;
        
        
    }
    
    private function formSupprimer(){
        
        $id = $this->id;
        
        $out = '';
        $lgActuel = $this->getLangueTradution();
        $isContenu = $this->dbQS($id,$this->table,'id');
        
        if(empty($isContenu)){
            
            header('Location:./?r=gestion');
            exit;
            
        }else{
            
            $form = new formulaire('supprimer_module');
            
            if(!empty($form->i)){
                
                if(empty($form->e)){
                    
                    $lgGroupe = unserialize($isContenu['groupe_traduction']);
                    foreach($lgGroupe as $v){
                        @$this->dbQD($v,$this->table_trad);
                    }
                    
                    $this->dbQD($isContenu['id'],$this->table,'id');
                    $this->dbQL("DELETE FROM _comments WHERE uri_module = '".$isContenu['uri']."'; ");
                    $this->dbQL("DELETE FROM _categories WHERE uri_module = '".$isContenu['uri']."'; ");
                    $this->dbQL("DELETE FROM linkinfo WHERE page = '".$isContenu['uri']."'; ");
                    $this->dbQL("DELETE FROM page WHERE page = '".$isContenu['uri']."'; ");
                    $this->dbQL("DROP TABLE IF EXISTS _m_".$isContenu['uri']."  ");
                    $this->dbQL("DROP TABLE IF EXISTS _m_".$isContenu['uri']."_traduction  ");
                    
                    new FlashInfoPut("Vos informations on été corréctement supprimer.");
                    header('Location:./?r=gestion');
                    exit();
                }
                
            }
            
            $fTpl = TplTranslate::getAdmin('doorgets','z.modules.form.delete.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
            
        }
        
        return $out;
        
    }
    
    private function getSqlBlog($name){
        
        $nameBlog = '_m_'.$name;
        $nameBlogTrad = '_m_'.$name.'_traduction';
        
        $out = "
        
        CREATE TABLE IF NOT EXISTS $nameBlog (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `categorie` varchar(255) DEFAULT NULL,
            `active` int(11) NOT NULL DEFAULT '0',
            `comments` int(11) NOT NULL DEFAULT '0',
            `partage` int(11) NOT NULL DEFAULT '1',
            `facebook` int(11) DEFAULT '0',
            `id_facebook` varchar(255) DEFAULT NULL,
            `disqus` int(11) DEFAULT '0',
            `id_disqus` varchar(255) DEFAULT NULL,
            `mailsender` int(11) DEFAULT '0',
            `sendto` varchar(255) DEFAULT NULL,
            `groupe_traduction` text,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
        
        CREATE TABLE IF NOT EXISTS $nameBlogTrad (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `id_content` int(11) NOT NULL DEFAULT '0',
            `langue` varchar(10) NOT NULL DEFAULT 'fr',
            `categorie` varchar(255) DEFAULT NULL,
            `titre` varchar(255) DEFAULT NULL,
            `description` text,
            `image` varchar(255) DEFAULT NULL,
            `article_tinymce` text,
            `uri` varchar(255) DEFAULT NULL,
            `meta_titre` varchar(255) DEFAULT NULL,
            `meta_description` varchar(255) DEFAULT NULL,
            `meta_keys` varchar(255) DEFAULT NULL,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";
        return $out;
    }
    
    private function getSqlTuto($name){
        
        $nameTuto = '_m_'.$name;
        $nameTutoTrad = '_m_'.$name.'_traduction';
        
        $out = "
        CREATE TABLE IF NOT EXISTS $nameTuto (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `categorie` varchar(255) DEFAULT NULL,
            `active` int(11) NOT NULL DEFAULT '0',
            `comments` int(11) NOT NULL DEFAULT '0',
            `partage` int(11) NOT NULL DEFAULT '1',
            `facebook` int(11) DEFAULT '0',
            `id_facebook` varchar(255) DEFAULT NULL,
            `disqus` int(11) DEFAULT '0',
            `id_disqus` varchar(255) DEFAULT NULL,
            `mailsender` int(11) DEFAULT '0',
            `sendto` varchar(255) DEFAULT NULL,
            `groupe_traduction` text,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
        
        CREATE TABLE IF NOT EXISTS $nameTutoTrad (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `id_content` int(11) NOT NULL DEFAULT '0',
            `langue` varchar(255) DEFAULT NULL,
            `categorie` varchar(255) DEFAULT NULL,
            `youtube` varchar(255) DEFAULT NULL,
            `temps` int(11) NOT NULL DEFAULT '1',
            `titre` varchar(255) DEFAULT NULL,
            `description` text,
            `uri` varchar(255) DEFAULT NULL,
            `meta_titre` varchar(255) DEFAULT NULL,
            `meta_description` varchar(255) DEFAULT NULL,
            `meta_keys` varchar(255) DEFAULT NULL,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";
        
        return $out;
        
    }
    
    private function getSqlPortefolio($name){
        
        $namePortefolio = '_m_'.$name;
        $namePortefolioTrad = '_m_'.$name.'_traduction';
        
        $out = "
        CREATE TABLE IF NOT EXISTS $namePortefolio (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `categorie` varchar(255) DEFAULT NULL,
            `active` int(11) NOT NULL DEFAULT '0',
            `comments` int(11) NOT NULL DEFAULT '0',
            `partage` int(11) NOT NULL DEFAULT '1',
            `facebook` int(11) DEFAULT '0',
            `id_facebook` varchar(255) DEFAULT NULL,
            `disqus` int(11) DEFAULT '0',
            `id_disqus` varchar(255) DEFAULT NULL,
            `mailsender` int(11) DEFAULT '0',
            `sendto` varchar(255) DEFAULT NULL,
            `groupe_traduction` text,
            `ordre` int(11) DEFAULT NULL,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
        
        CREATE TABLE IF NOT EXISTS $namePortefolioTrad (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `id_content` int(11) NOT NULL DEFAULT '0',
            `langue` varchar(255) DEFAULT NULL,
            `categorie` varchar(255) DEFAULT NULL,
            `image` varchar(255) DEFAULT NULL,
            `titre` varchar(255) DEFAULT NULL,
            `description` text,
            `uri` varchar(255) DEFAULT NULL,
            `meta_titre` varchar(255) DEFAULT NULL,
            `meta_description` varchar(255) DEFAULT NULL,
            `meta_keys` varchar(255) DEFAULT NULL,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";
        
        return $out;
        
    }
    
    private function getSqlFaq($name){
        
        $nameFaq = '_m_'.$name;
        $nameFaqTrad = '_m_'.$name.'_traduction';
        
        $out = "
        CREATE TABLE IF NOT EXISTS $nameFaq (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `ordre` int(11) DEFAULT NULL,
            `groupe_traduction` text,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
        
        CREATE TABLE IF NOT EXISTS $nameFaqTrad (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `id_content` int(11) DEFAULT NULL,
            `langue` varchar(255) DEFAULT NULL,
            `uri` varchar(255) DEFAULT NULL,
            `question` text,
            `reponse_tinymce` text,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";
        
        return $out;
        
    }
    
    private function getSqlLiens($name){
        
        $nameLiens = '_m_'.$name;
        $nameLiensTrad = '_m_'.$name.'_traduction';
        
        $out = "
        CREATE TABLE IF NOT EXISTS $nameLiens (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `ordre` int(11) DEFAULT NULL,
            `groupe_traduction` text,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
        
        CREATE TABLE IF NOT EXISTS $nameLiensTrad (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `id_content` int(11) DEFAULT NULL,
            `langue` varchar(255) DEFAULT NULL,
            `image` varchar(255) DEFAULT NULL,
            `titre` varchar(255) DEFAULT NULL,
            `url` varchar(255) DEFAULT NULL,
            `description` text,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";
        
        return $out;
        
    }
    
    private function getSqlNews($name){
        
        $nameNews = '_m_'.$name;
        $nameNewsTrad = '_m_'.$name.'_traduction';
        
        $out = "
        CREATE TABLE IF NOT EXISTS $nameNews (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `categorie` varchar(255) DEFAULT NULL,
            `active` int(11) NOT NULL DEFAULT '0',
            `comments` int(11) NOT NULL DEFAULT '0',
            `partage` int(11) NOT NULL DEFAULT '1',
            `facebook` int(11) DEFAULT '0',
            `id_facebook` varchar(255) DEFAULT NULL,
            `disqus` int(11) DEFAULT '0',
            `id_disqus` varchar(255) DEFAULT NULL,
            `mailsender` int(11) DEFAULT '0',
            `sendto` varchar(255) DEFAULT NULL,
            `groupe_traduction` text,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
        
        CREATE TABLE IF NOT EXISTS $nameNewsTrad (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `id_content` int(11) NOT NULL DEFAULT '0',
            `langue` varchar(255) DEFAULT NULL,
            `categorie` varchar(255) DEFAULT NULL,
            `titre` varchar(255) DEFAULT NULL,
            `description` text,
            `article_tinymce` text,
            `uri` varchar(255) DEFAULT NULL,
            `meta_titre` varchar(255) DEFAULT NULL,
            `meta_description` varchar(255) DEFAULT NULL,
            `meta_keys` varchar(255) DEFAULT NULL,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";
        
        return $out;
        
    }
    
    private function getSqlCopy($name,$newName,$withFields = 0){
        
        
        
        $nameCopy = '_m_'.$name;
        $nameCopyTrad = '_m_'.$name.'_traduction';
        
        $newNameCopy = '_m_'.$newName;
        $newNameCopyTrad = '_m_'.$newName.'_traduction';
        
        $out = "
        CREATE TABLE $newNameCopy LIKE $nameCopy;
        CREATE TABLE $newNameCopyTrad LIKE $nameCopyTrad;
        ";
        
        return $out;
        
    }
    
}