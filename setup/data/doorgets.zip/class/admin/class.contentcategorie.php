<?php


/**

    doorGets CMS V4.1 -  28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/


class ContentCategorie extends Langue{
    
    private $get;
    
    public $table = '_categories';
    
    public $tableModule;
    
    public $uri;
    
    public $module;
    
    public function __construct($module = 'blog',$lg= 'fr'){
        
        $this->setLangue($lg);
        $this->module = $module;
        $this->tableModule = '_m_'.$module;
        
        $this->uri = $this->table;
        
        
        $this->get .=  $this->getSubMenu();
        
        if(isset($_GET['add_categorie'])){
            
            $this->get .=  $this->formAjouter();
        
        }elseif( isset($_GET['id']) ){
            
            
            $idContent = ctype_alnum(str_replace('-','',$_GET['id']));
            if($idContent){
                
                if( isset($_GET['action']) && $_GET['action'] === 'voir' ){
                
                    $this->get .=   $this->voir($_GET['id']);
    
                }elseif( isset($_GET['action']) && $_GET['action'] === 'modifier' ){
                    
                    $this->get .=   $this->formModifier($_GET['id']);
    
                }elseif( isset($_GET['action']) && $_GET['action'] === 'supprimer' ){
                    
                    $this->get .=   $this->formSupprimer($_GET['id']);
                    
                }
            }
            
        }else{
            
            $this->get .=   $this->listing();
            
        }
        
    }
    
    public function get(){
        
        return $this->get;
        
    }
    
    private function getSubMenu(){
        
        $out = '';
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.module.categorie.rubrique.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
        
    }
    
    
    public function voir($id){
        
        $out = '';
        
        $isBlogCat = $this->dbQS($id,$this->table,'id');
        if(empty($isBlogCat)){
            
            header('Location:./?m='.$this->module.'cat');
            exit;
            
        }else{
            
            $lgActuel = $this->getLangueTradution();
            $lgGroupe = unserialize($isBlogCat['groupe_traduction']);
            $idTraduction = $lgGroupe[$lgActuel];
            
            $idCatTrad = $this->dbQS($idTraduction,$this->table.'_traduction');
            
            if(!empty($idCatTrad)){
                
                $fTpl = TplTranslate::getAdmin('doorgets','m.module.categorie.voir.tpl.php');
                ob_start();
                include $fTpl;
                $out = ob_get_clean();
            }
            
        }
        
        return $out;
        
        
    }
    
    public function listing($par=20){
        
        $iUsers = $this->dbQ('SELECT COUNT(*) as counter FROM '.$this->table." WHERE uri_module = '".$this->module."'");
        $cResultsInt = (int)$iUsers[0]['counter'];
        
        $valFilter = 'date';
        $outFilterAND = '';
        $outFilterORDER = ' ordre ASC ';
        $urlPage = "./?m=blogcat&filter=date&page=";
        
        if(isset($_GET['filter'])){
            $getFilter = filter_input(INPUT_GET,'filter',FILTER_SANITIZE_STRING);
            
        }
        
        $p = 1;
        $ini = 0;
        $per = $par;
        
        if(isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] <= (ceil($cResultsInt / $per))){
            
            $p = $_GET['page'];
            $ini = $p * $per - $per;
        }
        
        $sqlLimit = " WHERE uri_module = '".$this->module."'  ORDER BY $outFilterORDER  LIMIT ".$ini.",".$per;
        
        
        
        if($cResultsInt > $per){
            
            $valPage = '<div class="pagination">'.Pagination::page($cResultsInt,$p,$per,$urlPage).'</div>';
            
            
        }else{
            $valPage = '';
        }
        
        $all = $this->dbQA($this->table,$sqlLimit);
        $cAll = count($all);
        
        $finalPer = $ini+$per;
        if( $finalPer >  $cResultsInt){
            $finalPer = $cResultsInt;
        }
        
        $out = '';
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.module.categorie.index.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    }
    
    public function formAjouter(){
        
        $iCat = $this->dbQ('SELECT COUNT(*) as counter FROM '.$this->table." WHERE uri_module = '".$this->module."'");
        $cResultsInt = (int)$iCat[0]['counter'];
        
        $out = '';
        
        $form = new formulaire('ajouter_categorie');
        
        if(!empty($form->i)){
            
            
            
            foreach($form->i as $k=>$v){
                if(empty($v) && $k !== 'description' && $k !== 'image' && $k !== 'meta_titre' && $k !== 'meta_description' && $k !== 'meta_keys'  ){
                    
                    $form->e['ajouter_categorie_'.$k] = 'ok';
                    
                }
            }
            
            // gestion de l'ui
            
            $lenUri = strlen($form->i['uri']);
            $var = str_replace('-','',$form->i['uri']);
            
            $isUriValide = ctype_alnum($var);
            if( empty($isUriValide) || $lenUri > 250 ){
                
                $form->e['ajouter_categorie_uri'] = 'ok';
                
            }else{
                
                $isUriExist = $this->dbQS($form->i['uri'],'_categories_traduction','uri');
                if( !empty($isUriExist) ){
                    
                    $form->e['ajouter_categorie_uri'] = 'ok';
                }
                
            }

            
            if(empty($form->e)){
                
                $data['uri_module'] = $this->module;
                $data['ordre'] = $cResultsInt + 1;
                $data['date_creation'] = time();
                
                $idCat= $this->dbQI($data,$this->table);
                
                $dataNext = $form->i;
                $dataNext['date_creation'] = time();
                
                foreach($this->lg as $k=>$v){
                    
                    $dataNext['id_cat'] = $idCat;
                    $dataNext['langue'] = $k;
                    $dataNext['uri'] = $form->i['uri'].'-'.$this->module.'-'.$k;
                    $idTraduction[$k] = $this->dbQI($dataNext,$this->table.'_traduction');
                    
                }
                
                $dataModification['groupe_traduction'] = serialize($idTraduction);
                $this->dbQU($idCat,$dataModification,$this->table);
                
                new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
                header('Location:./?m='.$this->module.'cat&action=voir&id='.$idCat);
                exit();
            }
            
            new FlashInfoPut($this->getWords("Veuillez remplir correctement le formulaire."),"error");
            
        }
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.module.categorie.form.add.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        return $out;
        
    }
    
    
    public function formModifier($id){
        
        $out = '';
        
        $isBlogCat = $this->dbQS($id,$this->table,'id');
        if(empty($isBlogCat)){
            
            header('Location:./?m='.$this->module.'cat');
            exit;
            
        }else{
            
            $lgActuel = $this->getLangueTradution();
            $lgGroupe = unserialize($isBlogCat['groupe_traduction']);
            $idTraduction = $lgGroupe[$lgActuel];
            
            $idCatTrad = $this->dbQS($idTraduction,$this->table.'_traduction');
            
            if(!empty($idCatTrad)){
                
            
                $form = new formulaire('modifier_categorie');
                
                if(!empty($form->i)){
                    
                    foreach($form->i as $k=>$v){
                        if(empty($v)  && $k !== 'description' && $k !== 'image' && $k !== 'meta_titre' && $k !== 'meta_description' && $k !== 'meta_keys'  ){
                            
                            $form->e['modifier_categorie_'.$k] = 'ok';
                            
                        }
                    }
                    
                    // gestion de l'uri
                
                    $lenUri = strlen($form->i['uri']);
                    $var = str_replace('-','',$form->i['uri']);
                    
                    $isUriValide = ctype_alnum($var);
                    if( empty($isUriValide) || $lenUri > 250 ){
                        
                        $form->e['modifier_categorie_uri'] = 'ok';
                        
                    }else{
                        
                        $isUriExist = $this->dbQS($form->i['uri'],'_categories_traduction','uri');
                        if( !empty($isUriExist) && $isUriExist['id'] != $id){
                            
                            $form->e['modifier_categorie_uri'] = 'ok';
                        }
                        
                    }
                    
                    if(empty($form->e)){
                        
                        $data = $form->i;
                        
                        $this->dbQU($idCatTrad['id'],$data,$this->table.'_traduction','id');
                        new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
                        header('Location:./?m='.$this->module.'cat&action=voir&lg='.$lgActuel.'&id='.$isBlogCat['id']);
                        exit();
                    }
                    
                    new FlashInfoPut($this->getWords("Veuillez remplir correctement le formulaire."),"error");
                    
                }
                
                $fTpl = TplTranslate::getAdmin('doorgets','m.module.categorie.form.edit.tpl.php');
                ob_start();
                include $fTpl;
                $out = ob_get_clean();
            }
            
        }
        
        return $out;
        
    }
    
    public function formSupprimer($id){
        
        $out = '';
        
        $isBlogCat = $this->dbQS($id,$this->table);
        if(empty($isBlogCat)){
            
            header('Location:./?m='.$this->module.'cat');
            exit;
            
        }else{
            
            $lgActuel = $this->getLangueTradution();
            
            $form = new formulaire('supprimer_blog');
            
            if(!empty($form->i)){
                
                if(empty($form->e)){
                    
                    $lgGroupe = unserialize($isBlogCat['groupe_traduction']);
                    foreach($lgGroupe as $v){
                        @$this->dbQD($v,$this->table.'_traduction');
                    }
                    $this->dbQD($isBlogCat['id'],$this->table);
                    $this->dbQL("UPDATE ".$this->table." SET ordre = ordre - 1 WHERE ordre > ".$isBlogCat['ordre']." AND uri_module = '".$this->module."'");
                    new FlashInfoPut($this->getWords("Suppression effectuée avec succès."));
                    header('Location:./?m='.$this->module.'cat');
                    exit();
                }
            }
            
            $isArcticleIn = $this->dbQ("SELECT * FROM ".$this->tableModule." WHERE categorie = '".$isBlogCat['id']."' LIMIT 1 ");
            
            
            $fTpl = TplTranslate::getAdmin('doorgets','m.module.categorie.form.delete.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
        }
        
        return $out;
        
    }
    
    private function moveDown($id,$pos,$max){
        
        $out = '';
        $form = new formulaire('moveUp_'.$id);
        if( !empty($form->i) ){
            if($pos < $max){
            
                $this->dbQL("UPDATE  ".$this->table." SET ordre = ordre - 1 WHERE ordre = $pos + 1  AND uri_module = '".$this->module."' LIMIT 1");
                $this->dbQL("UPDATE  ".$this->table." SET ordre = ordre + 1 WHERE ordre = $pos AND id = $id  AND uri_module = '".$this->module."' LIMIT 1");
                
            }
            new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
            header('Location:'.$_SERVER['REQUEST_URI']);
            exit();
        }
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.module.categorie.form.movedown.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    }
    
    private function moveUp($id,$pos,$max){
        
        $out = '';
        $form = new formulaire('moveDown_'.$id);
        if( !empty($form->i) ){
            if($pos > 1){
                
                $this->dbQL("UPDATE  ".$this->table." SET ordre = ordre + 1 WHERE ordre = $pos - 1  AND uri_module = '".$this->module."' LIMIT 1");
                $this->dbQL("UPDATE  ".$this->table." SET ordre = ordre - 1 WHERE  id = $id  AND uri_module = '".$this->module."' LIMIT 1");
                
            }
            new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
            header('Location:'.$_SERVER['REQUEST_URI']);
            exit();
        }
        
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.module.categorie.form.moveup.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    
    }
    
    
    


}



