<?php

/**

    doorGets CMS V4.1 -  28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class Liens extends Langue{
    
    
    private $get;
    
    private $table;
    
    private $uri;
    
    public function __construct($table="liens",$uri = 'liens',$lg = 'fr'){
        
        $this->setLangue($lg);
        
        $this->table = $table;
        $this->uri = $uri;
        
        if(isset($_GET['add_liens'])){
            
            $this->get .=  $this->formAjouter();
        
        }elseif(isset($_GET['id']) ){
            
            $idContent = ctype_alnum(str_replace('-','',$_GET['id']));
            if($idContent){
                
                if( isset($_GET['action']) && $_GET['action'] === 'modifier' ){
                    
                    $this->get .=   $this->formModifier($_GET['id']);
    
                }elseif( isset($_GET['action']) && $_GET['action'] === 'supprimer' ){
                    
                    $this->get .=   $this->formSupprimer($_GET['id']);
                }
            }
            
        }else{
            
            $this->get .=   $this->listing();
            
        }
        
    }
    
    public function get(){
        
        return $this->get;
        
    }
    
    
    private function formAjouter(){
        
        $iLiens = $this->dbQ('SELECT COUNT(*) as counter FROM '.$this->table);
        $cResultsInt = (int)$iLiens[0]['counter'];
        
        
        $out = '';
        
        $form = new formulaire('ajouter_liens');
        
        if(!empty($form->i)){
            
            
            
            foreach($form->i as $k=>$v){
                if(empty($v) ){
                    
                    $form->e['ajouter_liens_'.$k] = 'ok';
                    
                }
            }
            
            $var = $form->i['url'];
            $varUrl = filter_var($var,FILTER_VALIDATE_URL);
            
            if( empty($varUrl) ){
                
                $form->e['ajouter_liens_url'] = 'ok';
                
            }
            
            // gestion de la photo du blog
            $extension = '.png';
            
            if (    isset($_FILES['ajouter_liens_image']) &&
                    (
                        $_FILES['ajouter_liens_image']["type"] == "image/jpeg"
                        || $_FILES['ajouter_liens_image']["type"] == "image/png"
                    )
                    && ($_FILES['ajouter_liens_image']["error"] === 0 )
            ){
                
                if($_FILES['ajouter_liens_image']["type"] == "image/jpeg"){
                    $extension = '.jpg';
                }
                
            }else{
                
                $form->e['ajouter_liens_image'] = 'ok';
            }
            
            if(empty($form->e)){
                
                $uni = time().'-'.uniqid('doorgets').'';
                
                $nameFileImage = $uni.'-liens'.$extension;
                
                $uploaddir = THM.'data/'.$this->uri.'/';
                if(!is_dir($uploaddir)){
                    @mkdir($uploaddir);
                    @copy('../'.$uploaddir.'index.php',$uploaddir.'index.php');
                }
                
                $uploadfile = $uploaddir . $nameFileImage;
                if(
                   move_uploaded_file($_FILES['ajouter_liens_image']['tmp_name'], $uploadfile)
                ){
                    $form->i['image'] = $nameFileImage;
                }
            }

            
            if(empty($form->e)){
                
                //
                
                $data['ordre'] = $cResultsInt + 1;
                $data['date_creation'] = time();
                
                $idCat= $this->dbQI($data,$this->table);
                
                $dataNext = $form->i;
                $dataNext['date_creation'] = time();
                
                foreach($this->lg as $k=>$v){
                    
                    $dataNext['id_content'] = $idCat;
                    $dataNext['langue'] = $k;
                    $idTraduction[$k] = $this->dbQI($dataNext,$this->table.'_traduction');
                    
                }
                
                $dataModification['groupe_traduction'] = serialize($idTraduction);
                $this->dbQU($idCat,$dataModification,$this->table);
                
                new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
                header('Location:./?m='.$this->uri);
                exit();
                
            }
            
            new FlashInfoPut($this->getWords("Veuillez remplir correctement le formulaire."),"error");
            
        }
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.liens.form.add.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        
        return $out;
        
    }
    
    private function listing($par=100){
        
        $lgActuel = $this->getLangueTradution();
        $iUsers = $this->dbQ('SELECT COUNT(*) as counter FROM '.$this->table);
        $cResultsInt = (int)$iUsers[0]['counter'];
        
        $valFilter = 'date';
        $outFilterAND = '';
        $outFilterORDER = ' '.$this->table.'.ordre ASC ';
        
        $p = 1;
        $ini = 0;
        $per = $par;
        
        
        $sqlLimit = " WHERE  ".$this->table."_traduction.langue = '".$lgActuel."' AND ".$this->table."_traduction.id_content = ".$this->table.".id  ORDER BY $outFilterORDER  LIMIT ".$ini.",".$per;
        
        
        $all = $this->dbQA($this->table.', '.$this->table.'_traduction',$sqlLimit);
        $cAll = count($all);
        
        $finalPer = $ini+$per;
        if( $finalPer >  $cResultsInt){
            $finalPer = $cResultsInt;
        }
        
        $out = '';
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.liens.index.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        
        return $out;
    
    }
    
    private function formModifier($id){
        
        $out = '';
        $isLiens = $this->dbQS($id,$this->table);
        if(empty($isLiens)){
            
            header('Location:./?m='.$this->uri);
            exit;
            
        }else{
            
            $lgActuel = $this->getLangueTradution();
            $lgGroupe = unserialize($isLiens['groupe_traduction']);
            $idTraduction = $lgGroupe[$lgActuel];
            
            $idLiensTrad = $this->dbQS($idTraduction,$this->table.'_traduction');
            
            if(!empty($idLiensTrad)){
            
                $form = new formulaire('modifier_liens');
                
                if(!empty($form->i)){
                    
                    foreach($form->i as $k=>$v){
                        if( empty($v) ){
                            
                            $form->e['modifier_liens_'.$k] = 'ok';
                            
                        }
                    }
                    
                    $var = $form->i['url'];
                    $varUrl = filter_var($var,FILTER_VALIDATE_URL);
                    
                    if( empty($varUrl) ){
                        
                        $form->e['modifier_liens_url'] = 'ok';
                        
                    }
                    
                    
                    if(empty($form->e)){
                        
                        $data = $form->i;
                        
                        $this->dbQU($idLiensTrad['id'],$data,$this->table.'_traduction');
                        new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
                        header('Location:./?m='.$this->uri.'&lg='.$lgActuel);
                        exit();
                    }
                    
                    new FlashInfoPut($this->getWords("Veuillez remplir correctement le formulaire."),"error");
                    
                }
                
                $fTpl = TplTranslate::getAdmin('doorgets','m.liens.form.edit.tpl.php');
                ob_start();
                include $fTpl;
                $out = ob_get_clean();
                
            }
            
        }
        
        return $out;
        
    }
    
    private function formSupprimer($id){
        
        $lgActuel = $this->getLangueTradution();
        $out = '';
        
        $isLiens = $this->dbQS($id,$this->table,'id');
        if(empty($isLiens)){
            
            header('Location:./?m='.$this->uri);
            exit;
            
        }else{
            
            $form = new formulaire('supprimer_liens');
            
            if(!empty($form->i)){
                
                if(empty($form->e)){
                    
                    $lgGroupe = unserialize($isLiens['groupe_traduction']);
                    foreach($lgGroupe as $v){
                        @$this->dbQD($v,$this->table.'_traduction');
                    }
                    
                    $this->dbQD($isLiens['id'],$this->table);
                    $this->dbQL("UPDATE ".$this->table." SET ordre = ordre - 1 WHERE ordre > ".$isLiens['ordre']);
                    new FlashInfoPut($this->getWords("Suppression effectuée avec succès."));
                    header('Location:./?m='.$this->uri.'&lg='.$lgActuel);
                    exit();
                }
            }
            
            $fTpl = TplTranslate::getAdmin('doorgets','m.liens.form.delete.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
            
        }
        
        return $out;
        
    }
    
    private function moveDown($id,$pos,$max){
        
        $out = '';
        $form = new formulaire('moveUp_'.$id);
        if( !empty($form->i) ){
            if($pos < $max){
            
                $this->dbQL("UPDATE ".$this->table." SET ordre = ordre - 1 WHERE ordre = $pos + 1 LIMIT 1");
                $this->dbQL("UPDATE ".$this->table." SET ordre = ordre + 1 WHERE ordre = $pos AND id = $id LIMIT 1");
                
            }
            new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
            header('Location:./?m='.$this->uri);
            exit();
        }
        
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.liens.form.movedown.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    }
    
    private function moveUp($id,$pos,$max){
        
        $out = '';
        $form = new formulaire('moveDown_'.$id);
        if( !empty($form->i) ){
            if($pos > 1){
                
                $this->dbQL("UPDATE ".$this->table." SET ordre = ordre + 1 WHERE ordre = $pos - 1 LIMIT 1");
                $this->dbQL("UPDATE ".$this->table." SET ordre = ordre - 1 WHERE  id = $id LIMIT 1");
                
            }
            new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
            header('Location:./?m='.$this->uri);
            exit();
        }
        
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.liens.form.moveup.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    
    }
    

}