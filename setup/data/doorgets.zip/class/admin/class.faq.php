<?php

/**

    doorGets CMS V4.1 -  28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class Faq extends Langue{
    
    
    private $get;
    
    private $table;
    
    private $uri;
    
    public function __construct($table="faq",$uri = 'faq',$lg = 'fr'){
        
        $this->setLangue($lg);
        
        $this->table = $table;
        $this->uri = $uri;
        
        if(isset($_GET['add_faq'])){
            
            $this->get .=  $this->formAjouter();
        
        }elseif(isset($_GET['id']) ){
            
            $idContent = ctype_alnum(str_replace('-','',$_GET['id']));
            if($idContent){
                
                if( isset($_GET['action']) && $_GET['action'] === 'modifier' ){
                    
                    $this->get .=   $this->formModifier($_GET['id']);
    
                }elseif( isset($_GET['action']) && $_GET['action'] === 'supprimer' ){
                    
                    $this->get .=   $this->formSupprimer($_GET['id']);
                }
            }
            
        }else{
            
            $this->get .=   $this->listing();
            
        }
        
    }
    
    public function get(){
        
        return $this->get;
        
    }
    
    
    private function formAjouter(){
        
        $iFaq = $this->dbQ('SELECT COUNT(*) as counter FROM '.$this->table);
        $cResultsInt = (int)$iFaq[0]['counter'];
        
        $out = '';
        
        $form = new formulaire('ajouter_faq');
        
        if(!empty($form->i)){
            
            foreach($form->i as $k=>$v){
                if(empty($v) ){
                    
                    $form->e['ajouter_faq_'.$k] = 'ok';
                    
                }
            }
            
            if(empty($form->e)){
                
                //
                
                $data['ordre'] = $cResultsInt + 1;
                $data['date_creation'] = time();
                
                $idCat= $this->dbQI($data,$this->table);
                
                $dataNext = $form->i;
                $dataNext['date_creation'] = time();
                
                foreach($this->lg as $k=>$v){
                    
                    $dataNext['id_content'] = $idCat;
                    $dataNext['langue'] = $k;
                    $idTraduction[$k] = $this->dbQI($dataNext,$this->table.'_traduction');
                    
                }
                
                $dataModification['groupe_traduction'] = serialize($idTraduction);
                $this->dbQU($idCat,$dataModification,$this->table);
                
                new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
                header('Location:./?m='.$this->uri);
                exit();
                
            }
            
            new FlashInfoPut($this->getWords("Veuillez remplir correctement le formulaire."),"error");
            
        }
        
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.faq.form.add.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        
        return $out;
        
    }
    
    private function listing($par=100){
        
        $lgActuel = $this->getLangueTradution();
        $iUsers = $this->dbQ('SELECT COUNT(*) as counter FROM '.$this->table);
        $cResultsInt = (int)$iUsers[0]['counter'];
        
        $valFilter = 'date';
        $outFilterAND = '';
        $outFilterORDER = ' '.$this->table.'.ordre ASC ';
        
        $p = 1;
        $ini = 0;
        $per = $par;
        
        
        $sqlLimit = " WHERE  ".$this->table."_traduction.langue = '".$lgActuel."' AND ".$this->table."_traduction.id_content = ".$this->table.".id  ORDER BY $outFilterORDER  LIMIT ".$ini.",".$per;
        
        
        $all = $this->dbQA($this->table.', '.$this->table.'_traduction',$sqlLimit);
        $cAll = count($all);
        
        $finalPer = $ini+$per;
        if( $finalPer >  $cResultsInt){
            $finalPer = $cResultsInt;
        }
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.faq.index.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        
        return $out;
    
    }
    
    private function formModifier($id){
        
        $out = '';
        $isFaq = $this->dbQS($id,$this->table);
        if(empty($isFaq)){
            
            header('Location:./?m='.$this->uri);
            exit;
            
        }else{
            
            $lgActuel = $this->getLangueTradution();
            $lgGroupe = unserialize($isFaq['groupe_traduction']);
            $idTraduction = $lgGroupe[$lgActuel];
            
            $idFaqTrad = $this->dbQS($idTraduction,$this->table.'_traduction');
            
            if(!empty($idFaqTrad)){

                $form = new formulaire('modifier_faq');
                
                if(!empty($form->i)){
                    
                    foreach($form->i as $k=>$v){
                        if( empty($v) ){
                            
                            $form->e['modifier_faq_'.$k] = 'ok';
                            
                        }
                    }
                    
                    
                    if(empty($form->e)){
                        
                        $data = $form->i;
                        
                        $this->dbQU($idFaqTrad['id'],$data,$this->table.'_traduction');
                        new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
                        $this->clearCache();
                        header('Location:./?m='.$this->uri.'&lg='.$lgActuel);
                        exit();
                    }
                    
                    new FlashInfoPut($this->getWords("Veuillez remplir correctement le formulaire."),"error");
                    
                }
            }
            
            $fTpl = TplTranslate::getAdmin('doorgets','m.faq.form.edit.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
            
            
            
        }
        
        return $out;
        
    }
    
    private function formSupprimer($id){
        
        $lgActuel = $this->getLangueTradution();
        $out = '';
        $isFaq = $this->dbQS($id,$this->table,'id');
        if(empty($isFaq)){
            
            header('Location:./?m='.$this->uri);
            exit;
            
        }else{
            
            $form = new formulaire('supprimer_faq');
            
            if(!empty($form->i)){
                
                if(empty($form->e)){
                    
                    $lgGroupe = unserialize($isFaq['groupe_traduction']);
                    foreach($lgGroupe as $v){
                        @$this->dbQD($v,$this->table.'_traduction');
                    }
                    
                    $this->dbQD($isFaq['id'],$this->table);
                    $this->dbQL("UPDATE ".$this->table." SET ordre = ordre - 1 WHERE ordre > ".$isFaq['ordre']);
                    new FlashInfoPut($this->getWords("Suppression effectuée avec succès."));
                    header('Location:./?m='.$this->uri.'&lg='.$lgActuel);
                    exit();
                }
            }
            
            $fTpl = TplTranslate::getAdmin('doorgets','m.faq.form.delete.tpl.php');
            ob_start();
            include $fTpl;
            $out = ob_get_clean();
            
        }
        
        return $out;
        
    }
    
    private function moveDown($id,$pos,$max){
        
        $out = '';
        $form = new formulaire('moveUp_'.$id);
        if( !empty($form->i) ){
            if($pos < $max){
            
                $this->dbQL("UPDATE ".$this->table." SET ordre = ordre - 1 WHERE ordre = $pos + 1 LIMIT 1");
                $this->dbQL("UPDATE ".$this->table." SET ordre = ordre + 1 WHERE ordre = $pos AND id = $id LIMIT 1");
                
            }
            new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
            header('Location:./?m='.$this->uri);
            exit();
        }
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.faq.form.movedown.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        
        return $out;
    }
    
    private function moveUp($id,$pos,$max){
        
        $out = '';
        $form = new formulaire('moveDown_'.$id);
        if( !empty($form->i) ){
            if($pos > 1){
                
                $this->dbQL("UPDATE ".$this->table." SET ordre = ordre + 1 WHERE ordre = $pos - 1 LIMIT 1");
                $this->dbQL("UPDATE ".$this->table." SET ordre = ordre - 1 WHERE  id = $id LIMIT 1");
                
            }
            new FlashInfoPut($this->getWords("Vos informations ont bien été mises à jour."));
            header('Location:./?m='.$this->uri);
            exit();
        }
        
        $fTpl = TplTranslate::getAdmin('doorgets','m.faq.form.moveup.tpl.php');
	ob_start();
	include $fTpl;
	$out = ob_get_clean();
        
        return $out;
    
    }
    
}