<?php
/**
 *
    doorGets CMS V4.1 -  28 feb 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    
    Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class Gestion extends Langue{
    
    
    private $get;
    
    
    public function __construct($lg = 'fr'){
        
        $this->setLangue($lg);
        
        if( isset($_GET['m']) && !empty($_GET['m']) ){
            
            $name = filter_input(INPUT_GET,'m',FILTER_SANITIZE_STRING);
            $this->get =   $this->whereIam($name);
            $this->get .=   $this->getModule($name);
            
        }else{
            $this->get =   $this->whereIam();
            $this->get .=   $this->index(200);
        }
        
        
    }
    
    public function get(){
        
        return $this->get;
        
    }
    
    private function whereIam($name=""){
        
        $lgActuel = $this->getLangueTradution();
        $nameModule = '';
        $cName = strlen($name);
        $isCat = false;
        $isModuleCat['type'] = '';
        if($cName >= 3){
            
            $restName = substr($name,$cName - 3,3);
            if($restName === 'cat'){
                
                $nameModule = substr($name,0,-3);
                $isModuleCat = $this->dbQS($nameModule,'_modules','uri');
                
                if($isModuleCat['type'] === 'blog' || $isModuleCat['type'] === 'tuto' || $isModuleCat['type'] === 'portefolio' || $isModuleCat['type'] === 'news'){
                    
                    $isCat = true;
                }
                
            }else{
                
                $isModuleCat = $this->dbQS($name,'_modules','uri');
                
            }
            
        }
        
        $fTpl = TplTranslate::getAdmin('doorgets','z.gestion.whereiam.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    }
    private function index($par = 200){
        
        $out = '';
        
        $iUsers = $this->dbQ("SELECT COUNT(*) as counter FROM _modules ");
        $cResultsInt = (int)$iUsers[0]['counter'];
        
        $lgActuel = $this->getLangueTradution();
        $valFilter = 'date';
        $outFilterORDER = ' uri ';
        $urlPage = "./?r=gestion&page=";
        
        if(isset($_GET['filter'])){
            
            $getFilter = filter_input(INPUT_GET,'filter',FILTER_SANITIZE_STRING);
            
        }
        
        $p = 1; $ini = 0; $per = $par;
        
        if(isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] <= (ceil($cResultsInt / $per))){
            
            $p = $_GET['page']; $ini = $p * $per - $per;
            
        }
        
        $sqlLimit = "  ORDER BY $outFilterORDER  LIMIT ".$ini.",".$per;
        
        
        $valPage = '';
        if($cResultsInt > $per){
            
            $valPage = Pagination::page($cResultsInt,$p,$per,$urlPage);
            
        }
        
        $all = $this->dbQA('_modules',$sqlLimit);
        $cAll = count($all);
        
        $finalPer = $ini+$per;
        if( $finalPer >  $cResultsInt){
            $finalPer = $cResultsInt;
        }
        
        $iNewsletter = 0;
        $iMNewsletter = $this->dbQ("SELECT COUNT(*) as counters FROM newsletter  ");
        $iNewsletter = (int)$iMNewsletter[0]['counters'];
        
        $iFile = 0;
        $iMFile = $this->dbQ("SELECT COUNT(*) as counters FROM uploader  ");
        $iFile = (int)$iMFile[0]['counters'];
        
        $fTpl = TplTranslate::getAdmin('doorgets','z.gestion.index.tpl.php');
        ob_start();
        include $fTpl;
        $out = ob_get_clean();
        
        return $out;
    
    }
    
    public function getModule($name){
        
        $out = '';
        $cName = strlen($name);
        $isCat = false;
        if($cName >= 3){
            
            $restName = substr($name,$cName - 3,3);
            if($restName === 'cat'){
                
                $nameModule = substr($name,0,-3);
                $isModuleCat = $this->dbQS($nameModule,'_modules','uri');
                if(empty($isModuleCat)){ return $out;}
                
                if($isModuleCat['type'] === 'blog' || $isModuleCat['type'] === 'tuto' || $isModuleCat['type'] === 'portefolio' || $isModuleCat['type'] === 'news'){
                    
                    $Categorie = new ContentCategorie($nameModule,$this->GetLangue());
                    $out = $Categorie->get();
                    $isCat = true;
                }
            }
            
        }
        if(!$isCat){
            
            $isModule = $this->dbQS($name,'_modules','uri');
            if(empty($isModule)){ return $out;}
            
            $nameTable = '_m_'.$name;
            
            
            switch($isModule['type']){
                
                case 'blog':
                    $Blog = new Blog($nameTable,$name,$this->GetLangue());
                    $out = $Blog->get();
                    break;
                
                case 'tuto':
                    $Tuto = new Tuto($nameTable,$name,$this->GetLangue());
                    $out = $Tuto->get();
                    break;
                
                case 'portefolio':
                    $Portefolio = new Portefolio($nameTable,$name,$this->GetLangue());
                    $out = $Portefolio->get();
                    break;
                
                case 'liens':
                    $Liens = new Liens($nameTable,$name,$this->GetLangue());
                    $out .= $Liens->Get();
                    break;
                
                case 'faq':
                    $Faq = new Faq($nameTable,$name,$this->GetLangue());
                    $out .= $Faq->Get();
                    break;
                
                case 'page':
                    $Page = new PageHome($name,$this->GetLangue());
                    $out = $Page->get();
                    break;
                
                case 'contact':
                    header("Location:./?r=contactezmoi&filter=".$name);
                    exit;
                    break;
                
                case 'candidaturemodels':
                    $PageCandidatureModels = new CandidatureModels($name);
                    $out = $PageCandidatureModels->get();
                    break;
                
                case 'link':
                    $PageLink = new LinkInfo($name,$this->GetLangue());
                    $out = $PageLink->get();
                    break;
                
                case 'news':
                    $News = new News($nameTable,$name,$this->GetLangue());
                    $out = $News->get();
                    break;
            }            
        }
        

        return $out;
    
    }
}