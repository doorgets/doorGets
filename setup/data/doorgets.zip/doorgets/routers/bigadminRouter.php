<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 07, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

@set_time_limit(0);

// Authentification BigAdmin
$Auth = new Auth();
$bigAdmin = $Auth->isConnected();

// create doorGets object
$doorGets = new doorGets('dashboard',$Auth->configWeb['langue']);

// If is not logged set authentication controller 
if( empty($bigAdmin) && $doorGets->getIsLogged() )
{
    if(!isset($_GET['controller']) || (isset($_GET['controller']) && $_GET['controller'] !== 'authentification'))
    {
        
        header('Location:?controller=authentification'); exit();
        
    }
}

// Check if connected and print header
if( !empty($bigAdmin) && $doorGets->getIsLogged() )
{
    
    $tplHeader = Template::getView('bigadmin/bigadmin_header');
    include $tplHeader;
    
    $tplChangeLangue = Template::getView('bigadmin/bigadmin_changelangue');
    
    ob_start();
    include $tplChangeLangue;
    $outChangeLangue = ob_get_clean();
    
    $modules = $allModules = $doorGets->loadModules(true);
    $modulesBlocks = $doorGets->loadModulesBlocks();
    $canAddType = array('blog','news','multipage','video','faq','image','partner');
    $iCountContents = 0;
    
    foreach($modules as $k => $v){
        
        $allModules[$k]['url_edit'] = "?controller=modules&action=edit".$v['type']."&id=".$v['id'];
        
        if(!in_array($v['type'],$canAddType)){
            
            unset($modules[$k]);
            $allModules[$k]['count']    = '';
            $allModules[$k]['url']      = "?controller=module".$v['type']."&uri=".$v['uri'];
            
            
        }else{
            
            $allModules[$k]['count']    = $doorGets->getCountTable('_m_'.$v['uri']);
            $allModules[$k]['url']      = "?controller=module".$v['type']."&uri=".$v['uri'];
            
        }
        
        if($v['type'] === 'inbox'){
            
            $allModules[$k]['count']    = $doorGets->getCountTable('_dg_inbox',array(array('key'=>'uri_module','type'=>'=','value'=>$v['uri'])));
            $allModules[$k]['url']      = "?controller=inbox&doorGets_search_filter_q_uri_module=".$v['uri'];
        }
        
        if($v['type'] === 'applicationjob'){
            
            $allModules[$k]['count'] = $doorGets->getCountTable('_dg_applicationjob',array(array('key'=>'uri_module','type'=>'=','value'=>$v['uri'])));
                
            }
            
            $iCountContents += $allModules[$k]['count'];
        }
        
        $liste['page']              = $doorGets->l('Page Statique');
        $liste['multipage']         = $doorGets->l('Multi-Pages Statiques');
        $liste['blog']              = $doorGets->l("Blog");
        $liste['news']              = $doorGets->l("Fil d'actualités");
        $liste['video']             = $doorGets->l('Galerie vidéos');
        $liste['image']             = $doorGets->l("Galerie d'images");
        $liste['faq']               = $doorGets->l('FAQ');
        $liste['partner']           = $doorGets->l('Partenaires');
        $liste['link']              = $doorGets->l('Lien de redirection');
        $liste['inbox']             = $doorGets->l('Formulaire de contact');
        $liste['block']             = $doorGets->l('Bloc Statique');
        $liste['genform']           = $doorGets->l('Formulaire');
        
        $listeInfos = array(
        'block' => array(
            'description' => $doorGets->l('Créer des blocs statiques'),
            'image' => BASE_IMG.'mod_block.png',
        ),
        'page' => array(
            'description' => $doorGets->l('Créer une page simple'),
            'image' => BASE_IMG.'mod_page.png',
        ),
        'multipage' => array(
            'description' => $doorGets->l('Créer plusieurs pages simple'),
            'image' => BASE_IMG.'mod_multipage.png',
        ),
        'news' => array(
            'description' => $doorGets->l("Créer un fil d'actualités"),
            'image' => BASE_IMG.'mod_news.png',
        ),
        'blog' => array(
            'description' => $doorGets->l("Créer un blog"),
            'image' => BASE_IMG.'mod_blog.png',
        ),
        'inbox' => array(
            'description' => $doorGets->l('Un formulaire pour prendre contact avec vous'),
            'image' => BASE_IMG.'mod_inbox.png',
        ),
        'link' => array(
            'description' => $doorGets->l('Lien de redirection à ajouter au menu'),
            'image' => BASE_IMG.'mod_link.png',
        ),
        'video' => array(
            'description' => $doorGets->l('Créer une galerie vidéos youtube'),
            'image' => BASE_IMG.'mod_video.png',
        ),
        'image' => array(
            'description' => $doorGets->l("Créer votre galerie d'images"),
            'image' => BASE_IMG.'mod_image.png',
        ),
        'faq' => array(
            'description' => $doorGets->l('Liste de questions fréquentes'),
            'image' => BASE_IMG.'mod_faq.png',
        ),
        'partner' => array(
            'description' => $doorGets->l('Afficher la liste de vos partenaires'),
            'image' => BASE_IMG.'mod_partner.png',
        ),
        'genform' => array(
            'description' => $doorGets->l('Formulaire'),
            'image' => BASE_IMG.'mod_genform.png',
        ),
    );
    
    $tplRubrique = Template::getView('bigadmin/bigadmin_rubrique');
    include $tplRubrique;
    
}else{
    
    $tplHeader = Template::getView('index_header');
    include $tplHeader;
    
}

echo  $doorGets->Controller()->getContent();

// Check if connected and print footer
if( !empty($bigAdmin) && $doorGets->getIsLogged() )
{
    
    $tplFooter = Template::getView('bigadmin/bigadmin_footer');
    include $tplFooter;
    
}else{
    
    $tplFooter = Template::getView('index_footer');
    include $tplFooter;
    
}
