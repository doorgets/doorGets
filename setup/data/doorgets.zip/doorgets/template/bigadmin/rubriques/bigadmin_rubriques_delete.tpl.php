<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.2 - 13, January 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title">
        {{!$this->l('Menu')!}}
        <br />
        <span>{{!$this->l('Gérer le menu de votre site')!}}</span>
        <span class="create" ><a class="doorGets-comebackform" href="?controller=rubriques">{{!$this->l('retour');}}</a></span>
    </div>
    <div class="doorGets-rubrique-center-title">
        {{!$this->l('Supprimer une rubrique')!}} 
    </div>
    <div class="doorGets-rubrique-center-content  doorGets-rubriques-rubriques">
        <div class="title-box">
            ID : <span  class="title-name">{{!$isContent['id']!}}</span>
        </div>
        {{!$this->Controller->form->open('post','','')!}}
        {{!$this->Controller->form->input('','id','hidden',$isContent['id'])!}}
        {{!$this->Controller->form->submit($this->l("Supprimer"))!}}
        <a class="doorGets-comebackform" href="./?controller=rubriques">{{!$this->l('annuler')!}}</a>
        {{!$this->Controller->form->close()!}}
    </div>
</div>