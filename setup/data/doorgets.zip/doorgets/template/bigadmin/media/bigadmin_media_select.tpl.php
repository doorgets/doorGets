<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.0 #!#!#
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title">
        {{!$this->l('Media')!}} 
        <br />
        <span>{{!$this->l('Gérer vos medias.')!}}</span>
        <span style="float: right;" ><a class="doorGets-comebackform" href="?controller={{!$nameController!}}">{{!$this->l('retour')!}}</a></span>
    </div>
    <div class="doorGets-rubrique-center-title">
        {{!$this->l("Détails d'un fichier")!}}
        <div class="box-action-content">
            <a href="?controller={{!$nameController!}}&action=edit&id={{!$isContent['id']!}}" title="{{!$this->l('Modifier')!}}">
                <img src="{{!BASE_IMG.'modifier.png'!}}" alt="{{!$this->l("Modifier")!}}" class="ico-image" />
                {{!$this->l("Modifier")!}}
            </a>
            <a href="?controller={{!$nameController!}}&action=delete&id={{!$isContent['id']!}}"  title="{{!$this->l("Supprimer")!}}" >
                <img src="{{!BASE_IMG.'supprimer.png'!}}" alt="{{!$this->l("Supprimer")!}}" class="ico-image" />
                {{!$this->l("Supprimer")!}}
            </a>
        </div>
    </div>
    <div class="doorGets-rubrique-center-content  doorGets-rubriques-rubriques " >
        <div class="separateur-tb"></div>
        <input type="text" disabled="disabled" value="{{!$urlFile!}}" >
        <div class="separateur-tb"></div>
        <div class="box-image-media">
            {{!$printImage!}}
        </div>
        <div class="separateur-tb"></div>
        {{!$this->l('Label')!}} : <b>{{!$isContent['nom']!}}</b>
        <div class="separateur-tb"></div>
        {{!$this->l('Taille du fichier')!}} : <b>{{!$isContent['poid']!}}</b>
        <div class="separateur-tb"></div>
        {{!$this->l('Type de fichier')!}} : <b>{{!$typeExtension[$isContent['type']]!}}</b>
        <div class="separateur-tb"></div>
        {{!$this->l('Date de création')!}} : <b>{{!GetDate::in($isContent['date_creation'],1,$this->myLanguage)!}}</b>
        
    </div>
</div>