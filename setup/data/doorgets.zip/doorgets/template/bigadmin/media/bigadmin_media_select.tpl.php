<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 07, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-content">
        <div class="doorGets-rubrique-left-center-title page-header">
            <span class="create" ><a class="doorGets-comebackform" href="?controller={{!$nameController!}}"><img src="{{!BASE_IMG!}}retour.png" class="retour-img"> {{!$this->l('retour')!}}</a></span>
            <span class="create" ><a href="?controller={{!$nameController!}}&action=delete&id={{!$isContent['id']!}}"  title="{{!$this->l("Supprimer")!}}" >
                <b class="glyphicon glyphicon-remove"></b>
                {{!$this->l("Supprimer")!}}
            </a>
            </span>
            <span class="create" ><a href="?controller={{!$nameController!}}&action=edit&id={{!$isContent['id']!}}" title="{{!$this->l('Modifier')!}}">
                <b class="glyphicon glyphicon-pencil"></b>
                {{!$this->l("Modifier")!}}
            </a>
            </span>
            <h2>
                <img src="{{!BASE_IMG!}}icone_media.png" > <a href="?controller=media">{{!$this->l('Media')!}}</a> 
                <small>{{!$this->l('Gérer vos medias')!}}.</small>
            </h2>
        </div>
        
        <legend>
            {{!$this->l("Détails d'un fichier")!}} 
        </legend>
        
        <label>
            <a href="{{!$urlFile!}}" target="blank">{{!$urlFile!}}</a>
        </label>
        <div class="separateur-tb"></div>
        <div class="box-image-media">
            {{!$printImage!}}
        </div>
        <div class="separateur-tb"></div>
        {{!$this->l('Label')!}} : <b>{{!$isContent['nom']!}}</b>
        <div class="separateur-tb"></div>
        {{!$this->l('Taille du fichier')!}} : <b>{{!$isContent['poid']!}}</b>
        <div class="separateur-tb"></div>
        {{!$this->l('Type de fichier')!}} : <b>{{!$typeExtension[$isContent['type']]!}}</b>
        <div class="separateur-tb"></div>
        {{!$this->l('Date de création')!}} : <b>{{!GetDate::in($isContent['date_creation'],1,$this->myLanguage)!}}</b>
        
    </div>
</div>