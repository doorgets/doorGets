<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 17 December, 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/



?>  </div>
  </div>
</div>
<script type="text/javascript">
  
  $(".nav-off").click(function(){
    var pos = $('.p-left').width();
    if(pos === 250){
      
      $('.p-left-top img').hide();
      $('.nav-off').css('width','50px');
      $('.nav-off .nav-off-c').css('width','40px');
      $('.nav-off .nav-off-c').css('top','0');
      $('.nav-off .nav-off-c').html('&#8594;');
      $('.p-left-bottom ul li span').hide();
      
        $('.p-left').animate({ width: "-=200" }, 100, function() {
            var wcontent = $( window ).width() - $('.p-left').width();
            var wcontents = wcontent + "px";
            $('.p-content').width(wcontents);    
        });
        
      $('.p-content').animate({ left: "-=200" }, 100, function() { });
      $('.params-out').animate({ left: "-=200", width: "+=200" }, 100, function() { });
      
      
    }else{
      
      $('.nav-off').css('width','250px');
      $('.nav-off .nav-off-c').css('width','240px');
      $('.nav-off .nav-off-c').html('&#8592;');
      
        $('.p-left').animate({ width: "+=200"}, 100, function() {
        
            $('.p-left-bottom ul li span').fadeIn();
            var wcontent = $( window ).width() - $('.p-left').width() ;
            var wcontents = wcontent + "px";
            $('.p-content').width(wcontents);
            
        });
        
      $('.p-content').animate({ left: "+=200" }, 100, function() { });
      $('.params-out').animate({ left: "+=200", width: "-=200"  }, 100, function() { });
      $('.p-left-top img').fadeIn();
      
      
      
    }
    
  });
  
  $('.tools-bt').click(function(){
    
    if($('.params-out').is(':hidden')){
      
        $('.params-out').animate({ left: "+=251" }, 100, function() {
            
            var wcontent = $( window ).width() - $('.p-left').width() - 252;
            var wcontents = wcontent + "px";
            $('.p-content').width(wcontents);    
        });
        
        $('.params-out').fadeIn();
        $('.p-content').animate({ left: "+=251" }, 100, function() { });
        $(this).css({"background":"#373737","color":"#ffffff"});
        
    }else{
      
        $('.params-out').animate({ left: "-=251" }, 100, function() {
            var wcontent = $( window ).width() - $('.p-left').width();
            var wcontents = wcontent + "px";
            $('.p-content').width(wcontents); 
        });
        
        $('.p-content').animate({ left: "-=251" }, 100, function() { });
        $('.params-out').fadeOut();
        $(this).css({"background-color":"#EDEDED","color":"#555"});
      
    }
    
    
  });
  
  var isHiddenOut = 252;
  if($('.params-out').is(':hidden')){ isHiddenOut = 0; }
  
  var wcontent = $( window ).width() - $('.p-left').width() - isHiddenOut;
  var wcontents = wcontent + "px";
  $('.p-content').width(wcontents);
  
  $( window ).resize(function() {
    
    var wcontent = $( window ).width() - $('.p-left').width() - isHiddenOut;
    var wcontents = wcontent + "px";
    $('.p-content').width(wcontents);
    
  });
  
</script>
    </body>
</html>