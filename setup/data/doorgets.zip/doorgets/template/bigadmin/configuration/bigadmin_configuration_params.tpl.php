<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 07, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/



?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title-breadcrumb page-header">
        <ol class="breadcrumb">
            <li><a href="./?controller=configuration">{{!$this->l('Configuration')!}}</a></li>
            <li class="active">{{!$this->l('Paramètres')!}}</li>
        </ol>
    </div>
    <div class="doorGets-rubrique-center-content">
        <div class="doorGets-rubrique-left-center-title page-header">
            <h2>
                <b class="glyphicon glyphicon-cog"></b> {{!$this->l('Paramètres')!}}
                <small>{{!$this->l('Paramètres de votre site')!}}.</small>
            </h2>
        </div>
    
        {{!$this->Controller->form->open('post','','')!}}
            {{!$this->Controller->form->input('URL'.' <span class="cp-obli">*</span>','url','text',URL)!}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->select($this->l('Activer le cache'),'cache',$ouinon,$valCache)!}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->select($this->l('Activer le mode démo'),'demo',$ouinon,$valDemo)!}}
            <p><small><i>{{!$this->l('Identifiant')!}} : <b>doorgets</b>, {{!$this->l('Mot de passe')!}} : <b>doorgets</b></i></small></p>
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->input($this->l('Mot de passe').' <span class="cp-obli">*</span>','password','password')!}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->submit($this->l('Sauvegarder'))!}}
        {{!$this->Controller->form->close()!}}
    </div>
</div>