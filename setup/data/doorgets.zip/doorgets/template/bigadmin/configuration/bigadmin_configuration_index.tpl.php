<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.0 #!#!#
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

 
?>
<div class="doorGets-rubrique-left-right">
    <div class="doorGets-rubrique-left-right-title">
        {{!$this->l('Site internet')!}}
        <br />
        <span>{{!$this->l('Configurer les informations globales de votre site.')!}}</span>
    </div>
    <div class="doorGets-rubrique-left-right-content">
        
        {{!$this->genLangueMenuAdmin()!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->open('post','','')!}}
        {{!$this->Controller->form->select($statutImage.$this->l('Statut du site'),'statut',$aValidation,$this->configWeb['statut'])!}}
        <div class="box-statut-config">
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->input($this->l('Adresses IP autorisé lors de la désactivation, séparer par ')."','",'statut_ip','text',$this->configWeb['statut_ip'])!}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->textarea($this->l('Message lors de la désactivation du site'),'statut_tinymce',$this->configWeb['statut_tinymce'],'tinymce')!}}   
        </div>
        <script type="text/javascript">
            if($('#configuration_siteweb_statut').val() == 1){
                $('.box-statut-config').hide();
            }
            $('#configuration_siteweb_statut').change(function(){
                if($(this).val() == 1){
                    $('.box-statut-config').fadeOut();
                }
                if($(this).val() == 2){
                    $('.box-statut-config').fadeIn();
                }
            });
        </script>
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->input($this->l('Titre'),'title','text',$this->configWeb['title'])!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->input($this->l('Slogan'),'slogan','text',$this->configWeb['slogan'])!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->input($this->l('Description'),'description','text',$this->configWeb['description'])!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->input($this->l('Copyright'),'copyright','text',$this->configWeb['copyright'])!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->select($this->l('Année de création'),'year',$dateCreation,$this->configWeb['year'])!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->input($this->l('Mots clés'),'keywords','text',$this->configWeb['keywords'])!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->input($this->l('Id Facebook'),'id_facebook','text',$this->configWeb['id_facebook'])!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->input($this->l('Id Disqus'),'id_disqus','text',$this->configWeb['id_disqus'])!}}
        <div class="separateur-tb"></div>
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->submit($this->l('Sauvegarder'))!}}
        {{!$this->Controller->form->close()!}}
        
    </div>
</div>