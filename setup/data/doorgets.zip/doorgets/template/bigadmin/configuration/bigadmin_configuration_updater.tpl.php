<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 07, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title-breadcrumb page-header">
        <ol class="breadcrumb">
            <li><a href="./?controller=configuration">{{!$this->l('Configuration')!}}</a></li>
            <li class="active">{{!$this->l('Mise à jour doorGets')!}}</li>
        </ol>
    </div>
    <div class="doorGets-rubrique-center-content">
        <div class="doorGets-rubrique-left-center-title page-header">
            <h2>
                <b class="glyphicon glyphicon-open"></b> {{!$this->l('Mise à jour doorGets')!}}
                <small>{{!$this->l("Garder votre système doorGets à jour")!}}.</small>
            </h2>
        </div>
    
        {{?($dgVersion > $myVersion):}}
            <div class="alert alert-info">
                {{!$this->l("Vous n'avez pas la dernière version de doorGets")!}} / {{!$this->l("Votre version")!}} : <b>doorGets {{!$myVersion!}}</b>
            </div>
            <div class="separateur-tb"></div>
            {{!$this->l("Dernière version disponible")!}} : <b>doorGets {{!$dgVersion!}}</b>
            <div class="separateur-tb"></div>
            {{?($isForDownload):}}
		{{?($isOkForCurl):}}
		    <div class="action-bottom-inworks" style="display: none;">
			<img src="{{!BASE_IMG.'loader.gif'!}}" class="icon-image" style="width:25px;height: 25px;vertical-align: middle;">
			{{!$this->l("Téléchargement en cours")!}}...{{!$this->l("Veuillez patienter")!}}...
		    </div>
		    <div class="action-bottom-form">
			{{!$this->Controller->form->open('post','','')!}}
			{{!$this->Controller->form->input('','version','hidden',$myVersion.'-to-'.$dgVersion)!}}
			{{!$this->Controller->form->submit($this->l('Télécharger').' doorGets '.$dgVersion)!}}
			{{!$this->Controller->form->close()!}}
		    </div>
		    <script type="text/javascript">
			$("#configuration_updater_submit").click(function(){
			    $(".action-bottom-inworks").fadeIn();
			    $(".action-bottom-form").fadeOut();
			    $(".doorGets-comebackform").fadeOut();
			});
		    </script>
		{??}
		    <div class="alert alert-info">
			{{!$this->l("Vous devez activer l'extension CURL de PHP pour faire les mises à jour !")!}}
		    </div>
		{?}
            {??}
                <div class="info-found">
                    {{!$this->l("Vous pouvez maintenant commencer l'installation")!}}
                </div>
                <div class="action-bottom-inworks" style="display: none;">
                    <img src="{{!BASE_IMG.'loader.gif'!}}" class="icon-image" style="width:25px;height: 25px;vertical-align: middle;">
                    {{!$this->l("Installation en cours")!}}...{{!$this->l("Veuillez patienter")!}}...
                </div>
                <div class="action-bottom-form">
                    {{!$this->Controller->form->open('post','','')!}}
                    {{!$this->Controller->form->input('','version','hidden',$myVersion.'-to-'.$dgVersion)!}}
                    {{!$this->Controller->form->submit($this->l('Installer').' dooGets '.$dgVersion)!}}
                    {{!$this->Controller->form->close()!}}
                </div>
                <script type="text/javascript">
                    $("#configuration_updater_submit").click(function(){
                        $(".action-bottom-inworks").fadeIn();
                        $(".action-bottom-form info-found").fadeOut();
                        $(".doorGets-comebackform").fadeOut();
                    });
                </script>
            {?}
	{??}
            <div class="info-found">
                {{!$this->l("Vous avez la dernière version de doorGets")!}} / {{!$this->l("Version")!}} : <b>doorGets {{!$dgVersion!}}</b>
            </div>
	{?}
        
    </div>
</div>