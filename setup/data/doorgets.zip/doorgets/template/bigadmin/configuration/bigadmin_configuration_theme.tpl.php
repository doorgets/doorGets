<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 11 November, 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

    
?>
<div class="doorGets-rubrique-left-right">
    <div class="doorGets-rubrique-left-right-title">
        {{!$this->l('Thème')!}}
        <br />
        <span>{{!$this->l('Configurer le thème de votre site.')!}}</span>
    </div>
    <div class="doorGets-rubrique-left-right-content">
        
        <div class="separateur-tb"></div>
        <div class="doorGets-rubrique-left-right-title">
        {{!$this->l('Choisir votre theme')!}}
        </div>
        {{!$this->Controller->form->open('post','','')!}}
        <div style="overflow: hidden;">
        {{/($isAllTheme as $theme):}}
            <div class="radio-theme-select theme-{{!$theme!}}">
                {{!$this->Controller->form->radio($theme.' ','theme',$theme,$nameTheme)!}}
            </div>
        {/}
        </div>
        <div class="separateur-tb"></div>
        <div class="other-box" >
            <div class="separateur-tb"></div>
            <div class="doorGets-rubrique-left-right-sub-title">
                {{!$this->l('Gérer le CSS')!}} : {{!$nameTheme!}}
            </div>
            <a href="{{!$urlCSS!}}" target="blank">{{!$urlCSS!}}</a>
            <div class="separateur-tb"></div>
            {{/($eContent as $k => $v):}}
                {{!$this->Controller->form->input('','css_key_'.$k,'text',$v[0])!}}
                {{!$this->Controller->form->textarea('','css_value_'.$k,$v[1],'min-content-textarea')!}}
                <div class="separateur-tb"></div>
            {/}
            {{!$this->Controller->form->textarea($this->l('Autre'),'css_other','','min-content-textarea')!}}
            <div class="separateur-tb"></div>
        </div>
        {{!$this->Controller->form->submit($this->l('Sauvegarder'))!}}
        {{!$this->Controller->form->close()!}}
        
    </div>
</div>
<script type="text/javascript">
    
    var selection = $("input[type='radio']:checked").val();
    
    $(".radio-theme-select label").css('background-color','rgb(200,200,200)');
    $(".radio-theme-select label").css('color','rgb(0,0,0)');
    
    $(".theme-" + selection + " label").css('background-color','rgb(15,99,30)');
    $(".theme-" + selection + " label").css('color','rgb(255,255,255)');
    
    $('input[type=radio]').click(function(){
        
        var selection1 = $("input[type='radio']:checked").val();
        
        $(".radio-theme-select label").css('background-color','rgb(200,200,200)');
        $(".radio-theme-select label").css('color','rgb(0,0,0)');
        
        $(".theme-" + selection1 + " label").css('background-color','rgb(15,99,30)');
        $(".theme-" + selection1 + " label").css('color','rgb(255,255,255)');
        
        if( $(this).val() !== "{{!$nameTheme!}}" ){
            $('.other-box').hide();
        }else{
            
            $('.other-box').show();
        }
    });
</script>