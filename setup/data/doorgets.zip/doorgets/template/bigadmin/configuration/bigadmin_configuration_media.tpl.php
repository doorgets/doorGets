<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 21, December 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


?>
<div class="doorGets-rubrique-left-right">
    <div class="doorGets-rubrique-left-right-title">
        {{!$this->l('Logo')!}} & {{!$this->l('Icône')!}}
        <br />
        <span>{{!$this->l("Modifier le logo et l'icône de votre site.")!}}</span>
    </div>
    <div class="doorGets-rubrique-left-right-content">
        
        {{!$this->Controller->form['configuration_media_logo']->open('post')!}}
        <b>{{!$this->l('Choisir une image pour votre logo').' :</b> '.$this->l('Format .PNG seulement')!}}
        <div class="doorGets-configuration-box-media">
            <img src="{{!BASE_IMG.'logo.png'!}}" class="doorGets-img-ico" >
            {{!$this->Controller->form['configuration_media_logo']->file('','img_logo')!}}
            {{!$this->Controller->form['configuration_media_logo']->submit($this->l('Sauvegarder'))!}}
        </div>
        {{!$this->Controller->form['configuration_media_logo']->close()!}}
        
        <div class="separateur-tb"></div>
        <div class="separateur-tb"></div>
        
       {{!$this->Controller->form['configuration_media_icone']->open('post')!}}
       <b>{{!$this->l('Choisir une image pour votre icône').' :</b> '.$this->l('Format .ICO seulement')!}}
        <div class="doorGets-configuration-box-media">
            <img src="{{!URL.'favicon.ico'!}}"  >
            {{!$this->Controller->form['configuration_media_logo']->file('','icone_logo')!}}
            {{!$this->Controller->form['configuration_media_icone']->submit($this->l('Sauvegarder'))!}}
        </div>
        
        {{!$this->Controller->form['configuration_media_icone']->close()!}}
        
    </div>
</div>