<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 17 December, 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


$nFace = 'http://www.facebook.com/<span style="color:#000099;">'.$this->configWeb['facebook'].'</span>';
$nTwitter = 'http://www.twitter.com/<span style="color:#000099;">'.$this->configWeb['twitter'].'</span>';
$nYoutube = 'http://www.youtube.com/user/<span style="color:#000099;">'.$this->configWeb['youtube'].'</span>';
$nGoogle = 'https://plus.google.com/u/0/<span style="color:#000099;">'.$this->configWeb['google'].'</span>';
$nPinterest = 'https://www.pinterest.com/<span style="color:#000099;">'.$this->configWeb['pinterest'].'</span>';
$nLinkedin = 'http://www.linkedin.com/in/<span style="color:#000099;">'.$this->configWeb['linkedin'].'</span>';
$nMyspace = 'http://www.myspace.com/<span style="color:#000099;">'.$this->configWeb['myspace'].'</span>';

?>
<div class="doorGets-rubrique-left-right">
    <div class="doorGets-rubrique-left-right-title">
        {{!$this->l('Réseaux sociaux')!}}
        <br />
        <span>{{!$this->l('Connecter les réseaux sociaux à votre site.')!}}</span>
    </div>
    <div class="doorGets-rubrique-left-right-content">
        {{!$this->Controller->form->open('post','','')!}}
            {{!$this->Controller->form->input($nFace,'facebook','text',$this->configWeb['facebook'])!}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->input($nTwitter,'twitter','text',$this->configWeb['twitter'])!}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->input($nYoutube,'youtube','text',$this->configWeb['youtube'])!}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->input($nGoogle,'google','text',$this->configWeb['google'])!}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->input($nPinterest,'pinterest','text',$this->configWeb['pinterest'])!}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->input($nLinkedin,'linkedin','text',$this->configWeb['linkedin'])!}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->input($nMyspace,'myspace','text',$this->configWeb['myspace'])!}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->submit($this->l('Sauvegarder'))!}}
        {{!$this->Controller->form->close()!}}
    </div>
</div>