<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 20, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

 
?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title-breadcrumb page-header">
        <ol class="breadcrumb">
            <li><a href="./?controller=configuration">{{!$this->l('Configuration')!}}</a></li>
            <li class="active">{{!$this->l('Langue')!}} / {{!$this->l('Heure')!}}</li>
        </ol>
    </div>
    <div class="doorGets-rubrique-center-content">
        <div class="doorGets-rubrique-left-center-title page-header">
            <h2>
                <b class="glyphicon glyphicon-globe"></b> {{!$this->l('Langue')!}} / {{!$this->l('Heure')!}}
                <small>{{!$this->l('Configurer les langues du site')!}}.</small>
            </h2>
        </div>
        {{!$this->Controller->form->open('post','','')!}}
        {{!$this->Controller->form->select($this->l('Zone horaire').' : ','horaire',$this->getArrayForms('times_zone'),$this->configWeb['horaire'])!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->select($this->l('Langue du backoffice').' : ','lg',$arrLangue,$this->configWeb['langue'])!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->select($this->l('Langue du FrontOffice par defaut').' : ','lg_front',$arrLangue,$this->configWeb['langue_front'])!}}
        <div class="separateur-tb"></div>
        <label>{{!$this->l('Langues actives sur le FrontOffice')!}} :</label>
        <ul>
        {{/($arrLangue as $k=>$v):}}
            {{$isChecked = '';}}
            <li>
                {{?( array_key_exists($k,$this->configWeb['langue_groupe']) ):}}{{ $isChecked = 'checked'; }}{?}
                {{!$this->Controller->form->checkbox($v,'lg_groupe_'.$k,$k,$isChecked)!}}
            </li>
        {/}
        </ul>
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->submit($this->l('Sauvegarder'))!}}
        {{!$this->Controller->form->close()!}}
    </div>
</div>