<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 07, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title-breadcrumb page-header">
        <ol class="breadcrumb">
            <li><a href="./?controller=configuration">{{!$this->l('Configuration')!}}</a></li>
            <li class="active">{{!$this->l('reCaptcha')!}}</li>
        </ol>
    </div>
    <div class="doorGets-rubrique-center-content">
        <div class="doorGets-rubrique-left-center-title page-header">
            <span class="create">
                <a href="https://www.google.com/recaptcha/admin/list" target="_blank" class="btn">Générer une nouvelle clé</a>
            </span>
            <h2>
                <b class="glyphicon glyphicon-warning-sign"></b> {{!$this->l('reCaptcha')!}}
                <small>{{!$this->l('Configurer la sécurité de vos formulaires avec reCaptcha')!}}.</small>
            </h2>
        </div>
    
        {{!$this->Controller->form->open('post','','')!}}
            {{!$this->Controller->form->input($this->l('Clé publique'),'public_key','text',RECAPTCHA_PUBLIC_KEY)!}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->input($this->l('Clé privée'),'private_key','text',RECAPTCHA_PRIVATE_KEY)!}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->submit($this->l('Sauvegarder'))!}}
        {{!$this->Controller->form->close();}}
        <div class="separateur-tb"></div>
        <div>
        </div>
    </div>
</div>