<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.2 - 13, January 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title">
        {{!$this->l('Commentaire')!}} 
        <br />
        <span>{{!$this->l('Gérer les commentaires de vos modules.')!}}</span>
        <span class="create" ><a class="doorGets-comebackform" href="?controller={{!$nameController!}}">{{!$this->l('retour')!}}</a></span>
    </div>
    <div class="doorGets-rubrique-center-title">
        {{!$this->l("Supprimer par groupe")!}} 
    </div>
    <div class="doorGets-rubrique-center-content  doorGets-rubriques-rubriques">
        
        {{?(empty($varListeFile)):}}
            
            <div class="info-not-found">
                {{!$this->l("Aucun élement dans votre séléction.")!}}  <a class="doorGets-comebackform" href="./?controller={{!$nameController!}}">{{!$this->l('retour')!}}</a>
            </div>
           
        {??}
            {{!$this->Controller->form['massdelete_index']->open('post','','')!}}
            {{!$this->Controller->form['massdelete_index']->input('','groupe_delete_index','hidden',$varListeFile)!}}
            <div class="separateur-tb"></div>
            {{!$cListe!}} {{?($cListe > 1):}}  {{!$this->l('éléments')!}} {??} {{!$this->l('élément')!}} {?}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form['massdelete_index']->submit($this->l("Supprimer"))!}}
            <a class="doorGets-comebackform" href="./?controller={{!$nameController!}}">{{!$this->l('annuler')!}}</a>
            {{!$this->Controller->form['massdelete_index']->close()!}}
        {?}   
    </div>
</div>