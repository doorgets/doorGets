<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 11 November, 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

$urlContent = URL.'t/'.$isContent['langue'].'/?'.$isContent['uri_module'].'='.$isContent['uri_content'];

?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title">
        {{!$this->l('Commentaire')!}} 
        <br />
        <span>{{!$this->l('Gérer les commentaires de vos modules.')!}}</span>
        <span class="create" ><a class="doorGets-comebackform" href="?controller={{!$nameController!}}">{{!$this->l('retour')!}}</a></span>
    </div>
    <div class="doorGets-rubrique-center-title">
        {{!$this->l("Modération d'un commentaire")!}}
        <div class="box-action-content">
            <a href="?controller={{!$nameController!}}&action=delete&id={{!$isContent['id']!}}"  title="{{!$this->l("Supprimer")!}}" >
                <img src="{{!BASE_IMG.'supprimer.png'!}}" alt="{{!$this->l("Supprimer")!}}" class="ico-image" />
                {{!$this->l("Supprimer")!}}
            </a>
        </div>
    </div>
    <div>
        {{!$formActivation!}}
    </div>
    <div class="doorGets-rubrique-center-content  doorGets-rubriques-rubriques " >
        <div class="separateur-tb"></div>
        {{!$this->l('Par')!}} : <b>{{!$isContent['nom']!}} / {{!$isContent['email']!}} / {{!$isContent['adress_ip']!}}</b>
        <div class="separateur-tb"></div>
        <div class="i-box">{{!$isContent['comment']!}}</div>
        <div class="separateur-tb"></div>
        {{!$this->l('Date')!}} : <b>{{!GetDate::in($isContent['date_creation'],1,$this->myLanguage)!}}</b>
        <div class="separateur-tb"></div>
        {{!$this->l('Url de la page')!}}  : <b><a href="{{!$urlContent!}}" title="{{!$urlContent!}}" target="blank">{{!$urlContent!}}</a></b>
    </div>
</div>