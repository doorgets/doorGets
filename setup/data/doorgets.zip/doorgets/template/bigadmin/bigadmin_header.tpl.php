<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 21, December 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

$sMaxI = ini_get('post_max_size');
$sMax = str_replace('M','',$sMaxI);
$sMax = (int)$sMax; $sMax = $sMax * 1024000;

?><!doctype html>
<html lang="{{$doorGets->myLanguage()}}">
    <head>
        
        <title>doorGets</title>
        
        <meta charset="utf-8" />
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta http-equiv="Content-Style-Type" content="text/css" />
	<META NAME="robots" CONTENT="noindex,nofollow,noarchive">
        
        <link href="{{!BASE_CSS.'jquery.css'!}}" rel="stylesheet" type="text/css" />
	
	<script  src="{{!BASE_JS.'jquery.js'!}}" type="text/javascript"></script>
	<script  src="{{!BASE_JS.'jquery.ui.js'!}}" type="text/javascript"></script>
	
	<script  src="//tinymce.cachefly.net/4.0/tinymce.min.js"></script>
	
	<link href="{{!BASE_CSS.'bigadmin.css'!}}" rel="stylesheet" type="text/css" />
        
	
	<script type="text/javascript">
	    tinymce.init({
		selector: ".tinymce",
		plugins: [
			"advlist autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
			"searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
			"table contextmenu directionality emoticons textcolor paste textcolor"
		],
		toolbar1: "classe | bold italic underline strikethrough | styleselect formatselect fontselect fontsizeselect | forecolor backcolor | code | fullscreen",
		toolbar2: "undo redo | table | cut copy paste | searchreplace | alignleft aligncenter alignright alignjustify | bullist numlist | outdent indent blockquote | link unlink | anchor image media",
		toolbar3: "inserttime | charmap emoticons | ltr rtl | visualchars visualblocks | nonbreaking template pagebreak restoredraft | hr removeformat | subscript superscript | preview",
		relative_urls: true,
		remove_script_host: false,
		convert_urls: false,
		menubar: false,
		toolbar_items_size: 'small',
		
	    });
	    
	    window.onload=Init;
	    function Init()
	    {
		
		var myFile = document.getElementById("media_add_fichier");
		if(myFile != null){
		    //binds to onchange event of the input field
		    myFile.addEventListener('change', function() {
			
			if( (this.files[0].size) > {{!$sMax!}} ){
			    myFile.value = "";
			    alert("2M  max");
			}
			
		    });			
		}

	    }
	    
	</script>
        <script  src="{{!BASE_JS.'bigadmin.js'!}}" type="text/javascript"></script>
    </head>
    <body>
        <div class="wrapper-tools">
	    {{!FlashInfo::get()!}}