<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 20, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title page-header">
        <h1>
            <b class="glyphicon glyphicon-dashboard"></b> {{!$this->l('Tableau de bord')!}}
            <small>{{!$this->l("Vue d'ensemble de votre site")!}}.</small>
        </h1>
    </div>
    <div class="doorGets-rubrique-center-content row">
        <div class="col-md-6">
            <div class="panel panel-default box-dash">
                <div class="box-dash-title panel-heading">
                    <a href="?controller=comment">
                        <b class="glyphicon glyphicon-comment"></b>  {{!$this->l("Commentaire")!}}
                    </a>
                </div>
                <div class="panel-body box-dash-content">
                    {{?(!empty($lastComments)):}}
                        <ul class="list-group">  
                        {{/($lastComments as $v):}}
                            {{
                                $imgVal = '<img src="'.BASE_IMG.'puce-rouge.png" title="'.$this->l('Bloquer').'" />';
                                if($v['validation'] === '2'){
                                    $imgVal = '<img src="'.BASE_IMG.'puce-verte.png" title="'.$this->l('Activer').'" />';
                                }
                                if($v['validation'] === '3'){
                                    $imgVal = '<img src="'.BASE_IMG.'puce-orange.png" title="'.$this->l('En attente de modération').'" />';
                                }
                            }}
                            <li class="list-group-item">
                                <a href="?controller=comment&action=select&id={{!$v['id']!}}">
                                    <div class="media">
                                        <span class="pull-left" href="?controller=comment&action=select&id={{!$v['id']!}}">
                                          <b class="glyphicon glyphicon-comment"></b>
                                        </span>
                                        <div class="media-body">
                                            <h4 class="media-heading">
                                              <span class="right"><small>{{!$imgVal!}} {{!GetDate::in($v['date_creation'],1,$this->myLanguage)!}}</small></span>
                                              {{!$this->_truncate($v['nom'])!}} <small>({{!$this->_truncate($v['email'])!}})</small>
                                            </h4>
                                            <div>{{!$this->_truncate($v['comment'])!}}</div>
                                        </div>
                                    </div>
                                </a>
                            </li>
                        {/}
                        </ul>
                    {??}
                        <div class="comment-center">{{!$this->l("Il n'y a pas encore de commentaire")!}}.</div>
                    {?}
                </div>
                <div class="panel-footer text-right">
                    &nbsp;
                    <span>{{!$this->l("Total")!}} : {{!$iComments!}}</span>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="panel panel-default box-dash">
                <div class="box-dash-title panel-heading">
                    <a href="?controller=inbox">
                        <b class="glyphicon glyphicon-envelope"></b>  {{!$this->l("Message")!}}
                    </a>
                </div>
                <div class="panel-body box-dash-content">
                    {{?(!empty($lastInbox)):}}
                        <ul class="list-group">  
                        {{/($lastInbox as $v):}}
                            {{
                                $imgVal = '<img src="'.BASE_IMG.'puce-orange.png" title="'.$this->l('Non lu').'" />';
                                if($v['lu'] === '1'){
                                    $imgVal = '<img src="'.BASE_IMG.'puce-verte.png" title="'.$this->l('Lu').'" />';
                                }
                            }}
                            <li class="list-group-item">
                                <a href="?controller=inbox&action=select&id={{!$v['id']!}}">
                                    <div class="media">
                                        <span class="pull-left" href="?controller=comment&action=select&id={{!$v['id']!}}">
                                          <b class="glyphicon glyphicon-envelope"></b>
                                        </span>
                                        <div class="media-body">
                                            <h4 class="media-heading">
                                              <span class="right"><small>{{!$imgVal!}} {{!GetDate::in($v['date_creation'],1,$this->myLanguage)!}}</small></span>
                                              {{!$this->_truncate($v['nom'],'30')!}} - {{!$this->_truncate($v['sujet'],'30')!}} <small>({{!$this->_truncate($v['email'])!}})</small>
                                            </h4>
                                            <div>{{!$this->_truncate($v['message'])!}}</div>
                                        </div>
                                    </div>
                                </a>
                            </li>
                        {/}
                        </ul>
                    {??}
                        <div class="comment-center">{{!$this->l("Il n'y a pas encore de message")!}}.</div>
                    {?}
                </div>
                <div class="panel-footer text-right">
                    &nbsp;
                    <span>{{!$this->l("Total")!}} : {{!$iInbox!}}</span>
                </div>
            </div>
        </div>
        <div class=" col-md-6">
            <div class="panel panel-default box-dash">
                <div class="box-dash-title panel-heading">
                    <a href="?controller=modules">
                        <b class="glyphicon glyphicon-asterisk"></b> {{!$this->l("Module")!}}
                    </a>
                </div>
                <div class="panel-body box-dash-content">
                    {{?(!empty($allModules)):}}
                        <ul class="list-group">  
                        {{/($allModules as $v):}}
                            {{
                                $imgVal = '<img src="'.BASE_IMG.'puce-verte.png" title="'.$this->l('Active').'" />';
                                if($v['active'] === '0'){
                                    $imgVal = '<img src="'.BASE_IMG.'puce-rouge.png" title="'.$this->l('Désactivé').'" />';
                                }
                                $imgType = '<img src="'.$listeInfos[$v['type']]['image'].'" >';
                            }}
                            <li class="list-group-item">
                                <a href="{{!$v['url']!}}" title="{{!$this->l('Gérer le contenu')!}}" style="display: block;">
                                    {{!$imgVal!}} {{!$imgType!}} {{!$this->_truncate($v['label'])!}}
                                    {{?(!empty($v['count'])):}}<span class="badge right">{{!$this->_truncate($v['count'])!}}</span>{?}
                                </a>
                                
                            </li>
                        {/}
                        </ul>
                    {??}
                        <div class="comment-center">{{!$this->l("Il n'y a pas encore de module")!}}.</div>
                    {?}
                </div>
                <div class="panel-footer text-right">
                    <span>{{!$this->l("Total")!}} [ {{!$this->l("Module")!}} : {{!$iModules!}} - {{!$this->l("Contenu")!}} : {{!$iCountContents!}} ]</span>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="panel panel-default box-dash">
                <div class="box-dash-title panel-heading">
                    <img src="{{!BASE_IMG!}}mod_block.png" /> {{!$this->l("Bloc Statique")!}}
                    /
                    <img src="{{!BASE_IMG!}}mod_genform.png" /> {{!$this->l("Formulaire")!}}
                </div>
                <div class="panel-body box-dash-content">
                    <ul class="list-group"> 
                    {{?(!empty($modulesBlocks)):}}
                         
                        {{/($modulesBlocks as $v):}}
                            {{
                                $imgVal = '<img src="'.BASE_IMG.'puce-verte.png" title="'.$this->l('Active').'" />';
                                if($v['active'] === '0'){
                                    $imgVal = '<img src="'.BASE_IMG.'puce-rouge.png" title="'.$this->l('Désactivé').'" />';
                                }
                                $imgType = '<img src="'.$listeInfos[$v['type']]['image'].'" >';
                            }}
                            <li class="list-group-item">
                                <a href="?controller=moduleblock&uri={{!$v['uri']!}}" title="{{!$this->l('Gérer le contenu')!}}" style="display: block;">
                                    {{!$imgVal!}} {{!$imgType!}} {{!$this->_truncate($v['label'])!}}
                                </a>
                            </li>
                        {/}
                    {?}
                    {{?(!empty($modulesGenforms)):}} 
                        {{/($modulesGenforms as $v):}}
                            {{
                                $imgVal = '<img src="'.BASE_IMG.'puce-verte.png" title="'.$this->l('Active').'" />';
                                if($v['active'] === '0'){
                                    $imgVal = '<img src="'.BASE_IMG.'puce-rouge.png" title="'.$this->l('Désactivé').'" />';
                                }
                                $imgType = '<img src="'.$listeInfos[$v['type']]['image'].'" >';
                            }}
                            <li class="list-group-item">
                                <a href="?controller=modulegenform&uri={{!$v['uri']!}}" title="{{!$this->l('Gérer le contenu')!}}" style="display: block;">
                                    {{!$imgVal!}} {{!$imgType!}} {{!$this->_truncate($v['label'])!}}
                                    {{?(!empty($v['count'])):}}<span class="badge right">{{!$this->_truncate($v['count'])!}}</span>{?}
                                </a>
                            </li>
                        {/}
                        
                    {?}
                    </ul>
                    {{?(empty($modulesGenforms) && empty($modulesBlocks)):}} 
                        <div class="comment-center">{{!$this->l("Il n'y a pas encore de bloc statique ou de formulaire")!}}.</div>
                    {?}
                </div>
                <div class="panel-footer text-right">
                    <span>{{!$this->l("Total")!}} : {{!$iModulesBlocks + $iModulesGenforms!}}</span>
                </div>
            </div>
        </div>
    </div>
</div>