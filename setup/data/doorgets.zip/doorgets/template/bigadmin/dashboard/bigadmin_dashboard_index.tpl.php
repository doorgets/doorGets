<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.2 - 05, January 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title">
        <div  id="go-to-racc">
            <img src="{{!BASE_IMG!}}flash_edit.png" />
            <select>
                <option value="">{{!$this->l("Edition rapide")!}}</option>
                <optgroup LABEL="{{!$this->l("Créer un nouveau module")!}} :">
                    {{/($liste as $uri_module => $label):}}
                        <option value="?controller=modules&action=add{{!$uri_module!}}">&nbsp;&nbsp;&nbsp;{{!$label!}}</option>
                    {/}
                </optgroup>
                {{?(!empty($modules)):}}
                <optgroup LABEL="{{!$this->l("Ajouter du contenu dans")!}} :">
                    {{/($modules as $value):}}
                        <option value="?controller=module{{!$value['type']!}}&uri={{!$value['uri']!}}&action=add">&nbsp;&nbsp;&nbsp;{{!$value['label']!}}</option>
                    {/}
                </optgroup>
                {?}
            </select>
        </div>

        {{!$this->l('Tableau de bord')!}} 
        <br />
        <span>{{!$this->l("Vue d'ensemble de votre site")!}}.</span>
        
    </div>
    <div class="doorGets-rubrique-center-content">
        <div class="box-dash">
            <div class="box-dash-title">
                <a href="?controller=comment">
                    <img src="{{!BASE_IMG!}}icone_comment.png" />
                    {{!$this->l("Commentaire")!}}
                </a>
            </div>
            <div class="box-dash-content">
                {{?(!empty($lastComments)):}}
                    <ul>  
                    {{/($lastComments as $v):}}
                        {{
                            $imgVal = '<img src="'.BASE_IMG.'puce-rouge.png" title="'.$this->l('Bloquer').'" />';
                            if($v['validation'] === '2'){
                                $imgVal = '<img src="'.BASE_IMG.'puce-verte.png" title="'.$this->l('Activer').'" />';
                            }
                            if($v['validation'] === '3'){
                                $imgVal = '<img src="'.BASE_IMG.'puce-orange.png" title="'.$this->l('En attente de modération').'" />';
                            }
                        }}
                        <li>
                            <a href="?controller=comment&action=select&id={{!$v['id']!}}" >
                                {{!$imgVal!}} {{!$this->_truncate($v['nom'])!}}
                                <small>({{!$this->_truncate($v['email'])!}})</small>
                                <span class="right">{{!GetDate::in($v['date_creation'],1,$this->myLanguage)!}}</span>
                                <div class="i-box-comment">
                                    {{!$this->_truncate($v['comment'])!}}
                                </div>
                            </a>
                        </li>
                    {/}
                    </ul>
                {??}
                    <div class="comment-center">{{!$this->l("Il n'y a pas encore de commentaire")!}}.</div>
                {?}
            </div>
            <div class="box-dash-bottom">
                &nbsp;
                <span class="left">{{!$this->l("Total")!}} : {{!$iComments!}}</span>
            </div>
        </div>
        <div class="box-dash">
            <div class="box-dash-title">
                <a href="?controller=inbox">
                    <img src="{{!BASE_IMG!}}mod_inbox.png" />
                    {{!$this->l("Message")!}}
                </a>
            </div>
            <div class="box-dash-content">
                {{?(!empty($lastInbox)):}}
                    <ul>  
                    {{/($lastInbox as $v):}}
                        {{
                            $imgVal = '<img src="'.BASE_IMG.'puce-orange.png" title="'.$this->l('Non lu').'" />';
                            if($v['lu'] === '1'){
                                $imgVal = '<img src="'.BASE_IMG.'puce-verte.png" title="'.$this->l('Lu').'" />';
                            }
                        }}
                        <li>
                            <a href="?controller=inbox&action=select&id={{!$v['id']!}}" >
                                {{!$imgVal!}} {{!$this->_truncate($v['nom'],'30')!}} - {{!$this->_truncate($v['sujet'],'30')!}}
                                <small>({{!$this->_truncate($v['email'])!}})</small>
                                <span class="right">{{!GetDate::in($v['date_creation'],1,$this->myLanguage)!}}</span>
                                <div class="i-box-comment">
                                    {{!$this->_truncate($v['message'])!}}
                                </div>
                            </a>
                        </li>
                    {/}
                    </ul>
                {??}
                    <div class="comment-center">{{!$this->l("Il n'y a pas encore de message")!}}.</div>
                {?}
            </div>
            <div class="box-dash-bottom">
                &nbsp;
                <span class="left">{{!$this->l("Total")!}} : {{!$iInbox!}}</span>
            </div>
        </div>
        <div class="box-dash">
            <div class="box-dash-title">
                <a href="?controller=modules">
                    <img src="{{!BASE_IMG!}}ico_module.png" />
                    {{!$this->l("Module")!}}
                </a>
            </div>
            <div class="box-dash-content">
                {{?(!empty($allModules)):}}
                    <ul>  
                    {{/($allModules as $v):}}
                        {{
                            $imgVal = '<img src="'.BASE_IMG.'puce-verte.png" title="'.$this->l('Active').'" />';
                            if($v['active'] === '0'){
                                $imgVal = '<img src="'.BASE_IMG.'puce-rouge.png" title="'.$this->l('Désactivé').'" />';
                            }
                            $imgType = '<img src="'.$listeInfos[$v['type']]['image'].'" >';
                        }}
                        <li>
                            <a href="{{!$v['url']!}}" title="{{!$this->l('Gérer le contenu')!}}" style="display: block;">
                                {{!$imgVal!}} {{!$imgType!}} {{!$this->_truncate($v['label'])!}}
                                {{?(!empty($v['count'])):}}<span class="puce">{{!$this->_truncate($v['count'])!}}</span>{?}
                            </a>
                            
                        </li>
                    {/}
                    </ul>
                {??}
                    <div class="comment-center">{{!$this->l("Il n'y a pas encore de module")!}}.</div>
                {?}
            </div>
            <div class="box-dash-bottom">
                <span class="left">{{!$this->l("Total")!}} [ {{!$this->l("Module")!}} : {{!$iModules!}} - {{!$this->l("Contenu")!}} : {{!$iCountContents!}} ]</span>
                <a href="?controller=modules&action=type"><img src="{{!BASE_IMG.'add.png'!}}" alt="{{!$this->l("Créer un nouveau module")!}}" class="ico-image" />  {{!$this->l('Créer un nouveau module')!}}</a>
            </div>
        </div>
        <div class="box-dash">
            <div class="box-dash-title">
                <img src="{{!BASE_IMG!}}mod_block.png" />
                {{!$this->l("Bloc Statique")!}}
            </div>
            <div class="box-dash-content">
                {{?(!empty($modulesBlocks)):}}
                    <ul>  
                    {{/($modulesBlocks as $v):}}
                        {{
                            $imgVal = '<img src="'.BASE_IMG.'puce-verte.png" title="'.$this->l('Active').'" />';
                            if($v['active'] === '0'){
                                $imgVal = '<img src="'.BASE_IMG.'puce-rouge.png" title="'.$this->l('Désactivé').'" />';
                            }
                        }}
                        <li>
                            <a href="?controller=moduleblock&uri={{!$v['uri']!}}" title="{{!$this->l('Gérer le contenu')!}}" style="display: block;">
                                {{!$imgVal!}} {{!$this->_truncate($v['label'])!}}
                            </a>
                        </li>
                    {/}
                    </ul>
                {??}
                    <div class="comment-center">{{!$this->l("Il n'y a pas encore de bloc statique")!}}.</div>
                {?}
            </div>
            <div class="box-dash-bottom">
                <span class="left">{{!$this->l("Total")!}} : {{!$iModulesBlocks!}}</span>
                <a href="?controller=modules&action=addblock"><img src="{{!BASE_IMG.'add.png'!}}" alt="{{!$this->l("Ajouter un bloc statique")!}}" class="ico-image" />  {{!$this->l('Ajouter un bloc statique')!}}</a>
            </div>
        </div>

    </div>
</div>