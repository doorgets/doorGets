<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 20, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-content">
        <div class="doorGets-rubrique-left-center-title page-header">
            <span class="create" ><a href="?controller=theme&action=add"><img src="{{!BASE_IMG.'add.png'!}}" alt="{{!$this->l("Générer un nouveau thème")!}}" class="ico-image" />  {{!$this->l('Générer un nouveau thème')!}}</a></span>
            <h2>
                <img src="{{!BASE_IMG!}}icone_theme.png" > <a href="?controller=theme">{{!$this->l('Thème')!}} </a> 
                <small>{{!$this->l('Configurer le thème de votre site')!}}.</small>
            </h2>
        </div>
        {{!$this->Controller->form->open('post','','')!}}
        <div style="overflow: hidden;">
        {{/($isAllTheme as $theme):}}
            <div class="box-theme-index {{?($nameTheme === $theme):}}box-theme-index-select{?}">
                {{!$this->Controller->form->radio(ucfirst($theme).' ','theme',$theme,$nameTheme)!}}
                {{?($countTheme > 1):}}
                    <a class="right" href="?controller=theme&action=delete&name={{!$theme!}}" title="{{!$this->l("Supprimer")!}}">
                        <img src="{{!BASE_IMG.'icone-delete.png'!}}"  />
                    </a>
                {?}
                <a class="right" href="?controller=theme&action=edit&name={{!$theme!}}" title="{{!$this->l("Editer")!}}">
                    <img src="{{!BASE_IMG.'edit.png'!}}" />
                </a>
                {{?($nameTheme === $theme):}}<span class="right"><img src="{{!BASE_IMG.'activer.png'!}}" /> <small>{{!$this->l('Thème par défaut')!}}</small></span>{?}
                
            </div>
        {/}
        </div>
        {{?($countTheme > 1):}}{{!$this->Controller->form->submit($this->l('Sauvegarder'))!}}{?}
        {{!$this->Controller->form->close()!}}
    </div>
</div>