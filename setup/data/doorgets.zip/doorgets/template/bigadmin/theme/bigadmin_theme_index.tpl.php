<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.2 - 05, January 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title">
        {{!$this->l('Thème')!}} 
        <br />
        <span>{{!$this->l('Configurer le thème de votre site.')!}}</span>
        <span class="create" ><a href="?controller=theme&action=add"><img src="{{!BASE_IMG.'add.png'!}}" alt="{{!$this->l("Générer un nouveau thème")!}}" class="ico-image" />  {{!$this->l('Générer un nouveau thème')!}}</a></span>
    </div>
    <div class="doorGets-rubrique-center-content">
        
        {{!$this->Controller->form->open('post','','')!}}
        <div style="overflow: hidden;">
        {{/($isAllTheme as $theme):}}
            <div class="box-theme-index {{?($nameTheme === $theme):}}box-theme-index-select{?}">
                {{!$this->Controller->form->radio(ucfirst($theme).' ','theme',$theme,$nameTheme)!}}
                {{?($countTheme > 1):}}
                    <a class="right" href="?controller=theme&action=delete&name={{!$theme!}}" title="{{!$this->l("Supprimer")!}}">
                        <img src="{{!BASE_IMG.'icone-delete.png'!}}"  />
                    </a>
                {?}
                <a class="right" href="?controller=theme&action=edit&name={{!$theme!}}" title="{{!$this->l("Editer")!}}">
                    <img src="{{!BASE_IMG.'edit.png'!}}"   />
                </a>
                {{?($nameTheme === $theme):}}<span class="right"><img src="{{!BASE_IMG.'activer.png'!}}" /> <small>{{!$this->l('Thème par défaut')!}}</small></span>{?}
                
            </div>
        {/}
        </div>
        {{?($countTheme > 1):}}{{!$this->Controller->form->submit($this->l('Sauvegarder'))!}}{?}
        {{!$this->Controller->form->close()!}}
    </div>
</div>