<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.2 - 05, January 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title">
        <a  href="?controller=theme">{{!$this->l('Thème')!}}</a> / {{!ucfirst($theme)!}}
        <br />
        <span>{{!$this->l('Configurer le thème de votre site.')!}}</span>
        <span class="create" ><a class="doorGets-comebackform" href="?controller=theme"><img src="{{!BASE_IMG!}}retour.png" class="retour-img"> {{!$this->l('retour')!}}</a></span>
    </div>
    <div class="doorGets-rubrique-center-title">
        {{!$this->l('Modifier un thème')!}}
        {{?($nameTheme === $theme):}}<div class="right-theme-title "><img src="{{!BASE_IMG.'activer.png'!}}"  /> <small>{{!$this->l('Thème par défaut')!}}</small></div>{?}
    </div>
    <div class="doorGets-sub-rubrique doorGets-rubrique-left-theme">
        {{?(array_key_exists('css',$themeListe)):}}
            <div class="title-theme-rub">CSS</div>
            {{/($themeListe['css'] as $file):}}
                <div class="content-theme-rub"><a {{?($fileSelected === $file):}}class="active"{?} href="?controller=theme&action=edit&name={{!$theme!}}&file={{!$file!}}">{{!$file!}}</a></div>
            {/}
        {?}
        {{?(array_key_exists('js',$themeListe)):}}
            <div class="title-theme-rub">JavaScript</div>
            {{/($themeListe['js'] as $file):}}
                <div class="content-theme-rub"><a {{?($fileSelected === $file):}}class="active"{?} href="?controller=theme&action=edit&name={{!$theme!}}&file={{!$file!}}">{{!$file!}}</a></div>
            {/}
        {?}
        
        {{?(array_key_exists('tpl',$themeListe)):}}
            <div class="title-theme-rub">Template</div>
            {{/($themeListe['tpl'] as $dirFile=>$file):}}
                <div class="content-theme-rub"><a title="{{!$dirFile!}}" {{?($fileSelected === $file):}}class="active"{?} href="?controller=theme&action=edit&name={{!$theme!}}&file={{!$file!}}">{{!$file!}}</a></div>
            {/}
        {?}
    </div>
    <div class="doorGets-rubrique-left-right-theme">
        <div class="doorGets-rubrique-left-right-content">
            <div class="u-title"><label>{{!$this->l('Fichier')!}} &#187; {{!$urlFile!}}</label></div>
            {{!$this->Controller->form->open('post','','')!}}
            {{!$this->Controller->form->textarea('','content_nofi',$fileContent)!}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->submit($this->l("Sauvegarder"))!}}
            {{!$this->Controller->form->close()!}}
        </div>
    </div>
</div>
