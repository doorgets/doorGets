<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.0 #!#!#
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/
 

?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title">
        <a href="?controller=modules">{{!$this->l('Module')!}}</a>
        <br />
        <span><a href="./?controller=modules">{{!$this->l('Gérer vos modules doorGets')!}}</a></span>
        <span style="float: right;" ><a class="doorGets-comebackform" href="?controller=modules&action=type">{{!$this->l('Retour')!}}</a></span>
        
    </div>
    <div class="doorGets-rubrique-center-title">
        {{!$this->l("Nouveau module")!}} : {{!$liste['faq']!}} <img src="{{!$listeInfos['faq']['image']!}}" class="px25" />
    </div>
    <div class="doorGets-rubrique-center-content  doorGets-rubriques-rubriques">
        {{!$this->Controller->form->open('post','')!}}
        {{!$this->Controller->form->input('','type','hidden','faq')!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->input($this->l('Nom'),'nom')!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->input($this->l('Titre'),'titre')!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->textarea($this->l('Description'),'description')!}}
        <div class="hidden-no-block-inbox">
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->textarea($this->l('Haut de page'),'top_tinymce','','tinymce')!}}
            <div class="separateur-tb"></div>
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->textarea($this->l('Bas de page'),'bottom_tinymce','','tinymce')!}}
            <div class="separateur-tb"></div>
        </div>
        <div class="separateur-tb"></div>
        <div class="title-box">
            {{!$this->l('Référencement')!}}
        </div>
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->input($this->l("Clé d'URL").' <small style="font-weight:100;">('.$this->l("Caractères alpha numérique seulement").')</small>','uri');}}
        <div class="separateur-tb"></div>
        <div class="hidden-no-block-inbox">
            {{!$this->Controller->form->input($this->l('Meta Titre'),'meta_titre');}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->input($this->l('Meta Description'),'meta_description');}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->input($this->l('Meta mots clés'),'meta_keys');}}
            <div class="separateur-tb"></div>
        </div>
        <div class="separateur-tb"></div>
        <div class="title-box">
            {{!$this->l('Paramêtres')!}}
        </div>
        <div class="separateur-tb"></div>        
        {{!$this->Controller->form->checkbox($this->l('Activé').'','active','1','checked');}}
        <div class="separateur-tb"></div>
        <div class="hidden-no-block-inbox ">
            {{!$this->Controller->form->checkbox($this->l("Page d'accueil du site").'','is_first',1);}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->checkbox($this->l('Reçevoir les notifications par e-mail').'','notification_mail','1','');}}
            <div class="separateur-tb"></div>
        </div>
        {{!$this->Controller->form->submit($this->l('Sauvegarder'))!}}
        <a class="doorGets-comebackform" href="./?controller=modules&action=type">{{!$this->l('annuler')!}}</a>
        {{!$this->Controller->form->close();}}
    </div>
</div>
<script type="text/javascript">
$("#modules_addfaq_nom").keyup(function(){

    var str = $(this).val();
    str = str.replace(/^\s+|\s+$/g, ''); // trim
    str = str.toLowerCase();
    
    // remove accents, swap ñ for n, etc
    var from = "ãàáäâẽèéëêìíïîõòóöôùúüûñç·/_,:;";
    var to   = "aaaaaeeeeeiiiiooooouuuunc      ";
    for (var i=0, l=from.length ; i<l ; i++) {
      str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
    }
    
    str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
      .replace(/\s+/g, '') // collapse whitespace and replace by -
      .replace(/-+/g, ''); // collapse dashes
      
    $("#modules_addfaq_uri").val(str);        
});
$("#modules_addfaq_titre").keyup(function(){

    var str = $(this).val();
    $("#modules_addfaq_meta_titre").val(str);
    
});
$("#modules_addfaq_description").keyup(function(){

    var str = $(this).val();
    var lendesc =  str.length;
    if(lendesc >= 250){
        str = str.substr(0,250);
    }
    $("#modules_addfaq_meta_description").val(str);
    
});


</script>