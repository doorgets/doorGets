<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 17 December, 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

    

?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title">
        <a href="?controller=modules">{{!$this->l('Module')!}}</a>
        <br />
        <span><a href="./?controller=modules">{{!$this->l('Gérer vos modules doorGets')!}}</a></span>
        <span class="create" ><a href="?controller=modules" class="doorGets-comebackform"><img src="{{!BASE_IMG!}}retour.png" class="retour-img"> {{!$this->l('Retour')!}}</a></span>
        
    </div>
    <div class="doorGets-rubrique-center-title">
        {{!$this->l("Modifier un module")!}} : {{!$liste['block']!}} <img src="{{!$listeInfos['block']['image']!}}" class="px25" />
    </div>
    <div class="doorGets-rubrique-center-content  doorGets-rubriques-rubriques">
        
        {{!$this->genLangueMenuAdmin()!}}
        {{!$this->Controller->form->open('post','')!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->checkbox($this->l('Activé').'','active','1',$isActiveModule);}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->input($this->l('Titre').'<br />','titre','text',$isContent['titre'])!}}
        <div class="separateur-tb"></div>
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->submit($this->l('Sauvegarder'))!}}
        <a class="doorGets-comebackform" href="./?controller=modules">{{!$this->l('annuler')!}}</a>
        {{!$this->Controller->form->close();}}
        
    </div>
</div>