<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.0 #!#!#
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/
 

?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title">
        <a href="?controller=modules">{{!$this->l('Module')!}}</a>
        <br />
        <span><a href="./?controller=modules">{{!$this->l('Gérer vos modules doorGets')!}}</a></span>
        <span style="float: right;" ><a class="doorGets-comebackform" href="?controller=modules">{{!$this->l('Retour')!}}</a></span>
        
    </div>
    <div class="doorGets-rubrique-center-title">
        {{!$this->l("Choisir un type de module")!}} 
    </div>
    <div class="doorGets-rubrique-center-content  doorGets-rubriques-rubriques">
        <div class="separateur-tb"></div>
        <div class="liste-modules-type">
            <ul>
            {{/($liste as $uri_module => $label):}}
                <li>
                    <a href="?controller=modules&action=add{{!$uri_module!}}">
                        <p><img src="{{!$listeInfos[$uri_module]['image']!}}" /></p>
                        <p>{{!$label!}}</p>
                        <p><small><i>{{!$listeInfos[$uri_module]['description']!}}</i></small></p>
                    </a>
                </li>
            {/}
            </ul>
        </div>
    </div>
</div>