<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 20, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

    

?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title page-header">
        <span class="create" ><a class="doorGets-comebackform" href="?controller=modules"><img src="{{!BASE_IMG!}}retour.png" class="retour-img"> {{!$this->l('Retour')!}}</a></span>
        <span class="create" ><a  href="?controller=modulepartner&uri={{!$isContent['uri']!}}&lg={{!$lgActuel!}}"><b class="glyphicon glyphicon-pencil"></b> {{!$this->l('Gérer le contenu')!}}</a></span>
        <h1>
            <b class="glyphicon glyphicon-asterisk"></b> <a href="?controller=modules">{{!$this->l('Module')!}} </a> / {{!$isContent['nom']!}}
            <br /><small>{{!$this->l('Gérer vos modules doorGets')!}}.</small>
        </h1>
    </div>
    <div class="doorGets-rubrique-center-content">
        <legend>
            {{!$this->l("Modifier un module")!}} : {{!$liste['partner']!}} <img src="{{!$listeInfos['partner']['image']!}}" class="px25" />
        </legend>
        <div class="trad-lg">
            {{!$this->genLangueMenuAdmin()!}}
        </div>
        
        {{!$this->Controller->form->open('post','')!}}
        <div id="tabs">
            <ul>
                <li><a href="#tabs-1">{{!$this->l('Information')!}}</a></li>
                <li><a href="#tabs-2">{{!$this->l('Bloc Statique')!}}</a></li>
                <li><a href="#tabs-3">{{!$this->l('META')!}}</a></li>
                <li><a href="#tabs-4">{{!$this->l('Template')!}}</a></li>
                <li><a href="#tabs-5">{{!$this->l('Paramètres')!}}</a></li>
            </ul>
            <div id="tabs-1">
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->input($this->l('Nom').' <span class="cp-obli">*</span><br />','nom','text',$isContent['nom'])!}}
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->input($this->l('Titre').' <span class="cp-obli">*</span><br />','titre','text',$isContent['titre'])!}}
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->textarea($this->l('Description').'<br />','description',$isContent['description'])!}}
                <div class="separateur-tb"></div>
            </div>
            <div id="tabs-2">
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->textarea($this->l('Haut de page').'<br />','top_tinymce',htmlspecialchars_decode(html_entity_decode($isContent['top_tinymce'])),'tinymce')!}}
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->textarea($this->l('Bas de page').'<br />','bottom_tinymce',htmlspecialchars_decode(html_entity_decode($isContent['bottom_tinymce'])),'tinymce')!}}
                <div class="separateur-tb"></div>
            </div>
            <div id="tabs-3">
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->input($this->l('Meta Titre').'<br />','meta_titre','text',$isContent['meta_titre']);}}
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->input($this->l('Meta Description').'<br />','meta_description','text',$isContent['meta_description']);}}
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->input($this->l('Meta mots clés').'<br />','meta_keys','text',$isContent['meta_keys']);}}
                <div class="separateur-tb"></div>
            </div>
            <div id="tabs-4">
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->input('Index','template_index','text',$isContent['template_index'].'.tpl.php');}}
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->input('','template_content','hidden',$isContent['template_content'].'.tpl.php');}}
                <div class="separateur-tb"></div>
            </div>
            <div id="tabs-5">
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->checkbox($this->l('Activé').'','active','1',$isActiveModule);}}
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->checkbox($this->l("Page d'accueil du site").'','is_first',1,$isHomePage);}}
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->checkbox($this->l('Reçevoir les notifications par e-mail').'','notification_mail','1',$isActiveNotification);}}
                <div class="separateur-tb"></div>
            </div>
        </div>
        {{!$this->Controller->form->submit($this->l('Sauvegarder'))!}}
        
        {{!$this->Controller->form->close();}}
        
    </div>
</div>