<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 04 December, 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

    

?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title">
        <a href="?controller=modules">{{!$this->l('Module')!}}</a>
        <br />
        <span><a href="./?controller=modules">{{!$this->l('Gérer vos modules doorGets')!}}</a></span>
        <span class="create" ><a href="?controller=modules" class="doorGets-comebackform"><img src="{{!BASE_IMG!}}retour.png" class="retour-img"> {{!$this->l('Retour')!}}</a></span>
        
    </div>
    <div class="doorGets-rubrique-center-title">
        {{!$this->l("Modifier un module")!}} : {{!$liste['partner']!}} <img src="{{!$listeInfos['partner']['image']!}}" class="px25" />
    </div>
    <div class="doorGets-rubrique-center-content  doorGets-rubriques-rubriques">
        
        {{!$this->genLangueMenuAdmin()!}}
        {{!$this->Controller->form->open('post','')!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->input($this->l('Nom').'<br />','nom','text',$isContent['nom'])!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->input($this->l('Titre').'<br />','titre','text',$isContent['titre'])!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->textarea($this->l('Description').'<br />','description',$isContent['description'])!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->textarea($this->l('Haut de page').'<br />','top_tinymce',htmlspecialchars_decode(html_entity_decode($isContent['top_tinymce'])),'tinymce')!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->textarea($this->l('Bas de page').'<br />','bottom_tinymce',htmlspecialchars_decode(html_entity_decode($isContent['bottom_tinymce'])),'tinymce')!}}
        <div class="separateur-tb"></div>
        <div class="separateur-tb"></div>
        <div class="title-box">
            {{!$this->l('Référencement')!}}
        </div>
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->input($this->l('Meta Titre').'<br />','meta_titre','text',$isContent['meta_titre']);}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->input($this->l('Meta Description').'<br />','meta_description','text',$isContent['meta_description']);}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->input($this->l('Meta mots clés').'<br />','meta_keys','text',$isContent['meta_keys']);}}
        <div class="separateur-tb"></div>
        <div class="title-box">
            {{!$this->l('Paramêtres')!}}
        </div>
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->checkbox($this->l('Activé').'','active','1',$isActiveModule);}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->checkbox($this->l("Page d'accueil du site").'','is_first',1,$isHomePage);}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->checkbox($this->l('Reçevoir les notifications par e-mail').'','notification_mail','1',$isActiveNotification);}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->submit($this->l('Sauvegarder'))!}}
        <a class="doorGets-comebackform" href="./?controller=modules">{{!$this->l('annuler')!}}</a>
        {{!$this->Controller->form->close();}}
        
    </div>
</div>