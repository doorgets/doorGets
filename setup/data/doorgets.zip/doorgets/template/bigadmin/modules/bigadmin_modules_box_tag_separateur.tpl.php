<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 07, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life for One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


?>
<div class="cp-text">
    <div class="cp-title">
    
        <img  src="{{!BASE_IMG!}}genform_separateur.png" title="Séparateur"> {{!$this->l('Séparateur')!}}
        <div class="right hid"  {{?($displayDelete):}}  style="display: none;" {?} >
            <span class="right close-me"><img  src="{{!BASE_IMG!}}delete.png" title="{{!$this->l('Suppimer')!}}"></span>
        </div>
        <div class=" right hid"   {{?($displayBox):}}  style="display: none;" {?}  >
            <select class="input-active"  {{?($i):}} name="input-active-{{!$i!}}" {?}  >
                <option value="yes"  {{?($lActive === 'yes'):}} selected="selected" {?} >{{!$this->l('Visible')!}}</option>
                <option value="no"  {{?($lActive === 'no'):}} selected="selected" {?} >{{!$this->l('Invisible')!}}</option>
            </select>
        </div>
    </div>
    <div class="hid"   {{?($displayBox):}}  style="display: none;" {?}  >
        
        <input class="input-label"  value=" 1 " type="hidden">
        <input class="input-filter" value="" type="hidden"  >
        <input class="input-type" value="tag-separateur" type="hidden" {{?($i):}} name="input-type-{{!$i!}}" {?}  >
        <div class="btn-plus">+ {{!$this->l('Plus')!}}</div>
        <div  class="box-moins" style="display: none;"  >
            <div class="btn-moins">- {{!$this->l('Masquer')!}}</div>
            <table class="tb-cp">
                <tr>
                    <td>
                        <label>{{!$this->l('Classe CSS')!}}</label>
                        <input class="input-css"  {{?($i):}} name="input-css-{{!$i!}}" {?} value="{{!$lCss!}}"   >
                    </td>
                </tr>
            </table>
        </div>
    </div>
    </div>