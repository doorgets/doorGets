<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 20, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

?>
    <div class="doorGets-box-login-header">
        <h3>
            {{!$this->l('Identifiez-vous')!}}
            {{?(ACTIVE_DEMO):}}<small>{{!$this->l('Mode démo')!}}</small>{?}
        </h3>
    </div>
    <div class="doorGets-box-login-content">
        <div>
            {{!$this->Controller->form->open('post','','')!}}
            <div class="form-group">
                {{!$this->Controller->form->input($this->l('Identifiant'),'login','text',$valLogin,'form-control')!}}
            </div>
            <div class="form-group">
                {{!$this->Controller->form->input($this->l('Mot de passe'),'password','password',$valPass,'form-control')!}}
            </div>
            {{!$this->Controller->form->submit($this->l('Se connecter'),'','btn btn-primary')!}}
            {{!$this->Controller->form->close()!}}
        </div>
        {{?(ACTIVE_DEMO):}}
        <div class="alert alert-info"">
            <i>{{!$this->l('Identifiant')!}} : <b>doorGets</b>
            <br />
            {{!$this->l('Mot de passe')!}} : <b>doorGets</b></i>
        </div>
        {?}
    </div>
    <div class="doorGets-box-login-footer">
        <a href="http://www.doorgets.com" title="http://www.doorgets.com" target="blank">doorGets &trade;</a>
    </div>
</div>