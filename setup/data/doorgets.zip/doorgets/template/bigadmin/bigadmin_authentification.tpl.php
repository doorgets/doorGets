<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 11 November, 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

?>
<div class="doorGets-box-login">
    <h3>{{!$this->l('Identifiez-vous')!}} {{?(ACTIVE_DEMO):}} / {{!$this->l('Mode démo')!}} {?}</h3>
    {{!$this->Controller->form->open('post','','')!}}
    {{!$this->Controller->form->inputt($this->l('Identifiant'),'login','text',$valLogin)!}}
    <div class="doorGets-box-login-left">
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->inputt($this->l('Mot de passe'),'password','password',$valPass)!}}
        <div class="connexion">
            {{!$this->Controller->form->submit($this->l('Se connecter'))!}}
        </div>
    </div>
    {{!$this->Controller->form->close()!}}
    {{?(ACTIVE_DEMO):}}
        <br />
        <small><i>{{!$this->l('Identifiant')!}} : <b>doorGets</b>, {{!$this->l('Mot de passe')!}} : <b>doorGets</b></i></small>
    {?}
    <script type="text/javascript">
        $("#recaptcha_widget_div").hide();
        $(".doorGets-box-login-left").hide();
        $("#authentification_login").click(function(){
            $("#recaptcha_widget_div").fadeIn();
            $(".doorGets-box-login-left").fadeIn();
        });
    </script>
</div>