<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 17 December, 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title">
        {{!$this->l('Newsletter')!}} / {{!$this->l('Inscription')!}}
        <br />
        <span>{{!$this->l('Gérer la liste des inscriptions à la newsletter.')!}}</span>
        <span class="create" >
            <a href="?controller=emailing&action=add"><img src="{{!BASE_IMG.'add.png'!}}" alt="{{!$this->l("Ajouter")!}}" class="ico-image" />  {{!$this->l('Créer un contact')!}}</a>
        </span>
    </div>
    <div class="doorGets-rubrique-left-right-content">
        <div class="width-listing">
            {{?(!empty($cAll)):}}
                <div style="overflow: hidden;border-bottom: solid 1px #BBB;">
                    <div style="float: left;padding: 7px 0 ">
                        <i>
                            {{?(!empty($cAll)):}} {{!($ini+1)!}} {{!$this->l("à")!}} {{!$finalPer!}} {{!$this->l("sur")!}} {?}
                            <b>{{!$cResultsInt.' '!}} {{?( $cResultsInt > 1 ):}}{{!$this->l('Contacts')!}} {??} {{!$this->l('Contact')!}} {?}</b>
                            {{?(!empty($q)):}} {{!$this->l('pour la recherche : ').' <b>'.$q.'</b>'!}} {?}
                        </i>
                        <span id="doorGets-sort-count">
                            {{!$this->l('Par')!}}
                            <a href="{{!$urlPagePosition!}}&gby=10" {{?($per=='10'):}} class="active" {?}>10</a>
                            <a href="{{!$urlPagePosition!}}&gby=20" {{?($per=='20'):}} class="active" {?}>20</a>
                            <a href="{{!$urlPagePosition!}}&gby=50" {{?($per=='50'):}} class="active" {?}>50</a>
                            <a href="{{!$urlPagePosition!}}&gby=100" {{?($per=='100'):}} class="active" {?}>100</a>
                        </span>
                         
                    </div>
                    <div  class="doorGets-box-search-module">
                        {{!$this->Controller->form['_search_filter']->open('post',$urlPageGo,'')!}}
                        {{!$this->Controller->form['_search_filter']->submit($this->l('Chercher'),'','doorGets-filter-bt')!}}
                    </div>
                </div>
                <div class="separateur-tb"></div>
                {{!$block->getHtml()!}}
                {{!$this->Controller->form['_search']->close()!}}
                
            
                {{!$formMassDelete!}}
                <div class="separateur-tb"></div>
                {{!$valPage!}}
                <span class="right">
                    {{!$this->Controller->form['_tocsv']->open('post',$urlPageGo,'')!}}
                        {{!$this->Controller->form['_tocsv']->input('','i','hidden')!}}
                        {{!$this->Controller->form['_tocsv']->submit($this->l('Exporter au format CSV'),'','doorGets-export-csv-bt')!}}
                    {{!$this->Controller->form['_tocsv']->close('post')!}}
                </span>
            {??}
               
                {{?(!empty($aGroupeFilter)):}}
                    <div class="info-not-found">
                        {{!$this->l("Aucun contact trouvé pour votre recherche.");}}
                    </div>
                {??}
                    <div class="info-not-found">
                        {{!$this->l("Il n'y a actuellement aucun contact dans la base")!}}
                    </div>
                {?}
                
            {?} 
        </div>

        
    </div>
</div>