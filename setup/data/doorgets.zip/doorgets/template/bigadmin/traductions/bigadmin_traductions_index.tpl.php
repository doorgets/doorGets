<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 21, December 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com 
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


?>
<div class="doorGets-rubrique-left-right">
    <div class="doorGets-rubrique-left-right-content">
        {{?(!empty($cFields)):}}
            {{!$this->l('Nombre de phrases traduites')!}} : {{!$cFieldsTo!}} / <b>{{!$cFields!}}</b>
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->open('post','','');}}
            {{/($wTranslate as $k => $v):}}
                {{$valCss = '';}}
                {{?(!array_key_exists($k,$_w)):}}{{
                    
                    $valCss = 'doorGets-no-value';
                    $_w[$k] = $v;
                    
                }}{?}
                <div style="margin-bottom:5px;border-left: solid 5px #ccc;padding: 5px;">
                    {{!$this->Controller->form->input($k." : <b>$v</b>",'words_'.$k,'text',$_w[$k],$valCss)!}}    
                </div>
                
            {/}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->submit($this->l('Sauvegarder'));}}
            {{!$this->Controller->form->close();}}
        {??}
            <div class="info-not-found">
                {{!$this->l('Aucune phrase à traduire.')!}}
            </div>
        {?}
    </div>
</div>