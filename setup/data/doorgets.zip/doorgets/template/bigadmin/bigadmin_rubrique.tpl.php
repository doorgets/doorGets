<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 11 November, 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/



    // Init $menu from Name Controller
    $menu = $doorGets->Controller()->controllerName;
    $action = $doorGets->Controller()->Action();
    
    // Init rubrique for module
    $isModuleRubriques      = array('modules','modulenews','modulecategory','modulepage','modulemultipage','moduleblock',
                                    'modulelink','moduleimage','modulevideo','modulefaq','modulepartner','moduleapplicationjob');
    $isRubriquesRubriques   = array('rubriques','rubriquesusers');
    $isEmailingRubriques    = array('emailing');
    
    $iCommentNotRead    = $doorGets->getCountCommentNotRead();
    if(empty($iCommentNotRead)){ $iCommentNotRead = '';}
    if(!empty($iCommentNotRead)){ $iCommentNotRead    = '<small class="info-counts">'.$iCommentNotRead.'</small>'; }
    
    $iInboxNotRead      = $doorGets->getCountInboxNotRead();
    if(empty($iInboxNotRead)){ $iInboxNotRead = '';}
    if(!empty($iInboxNotRead)){ $iInboxNotRead      = '<small class="info-counts">'.$iInboxNotRead.'</small>'; }
    
    $version = $doorGets->_newVersion();
    $c = $doorGets->Controller()->thisController
?>
<div class="p-left">
    <div class="p-left-top">
      <div class="pad-5">
        <a href="./"><img  src="{{!BASE_IMG!}}logo.png" /></a>
      </div> 
    </div>
    <div class="p-left-bottom">
      <div >
            <ul>
                <li class="first <?php if( in_array($menu,$isModuleRubriques) ){ echo 'active'; } ?>">
                    <a href="?controller=modules">
                        <img src="{{!BASE_IMG!}}ico_module.png" />
                        <span>{{!$c->l('Module')!}}</span>
                    </a>
                </li>
                <li class="<?php if( in_array($menu,$isRubriquesRubriques) ){ echo 'active'; } ?>">
                    <a href="?controller=rubriques">
                        <img src="{{!BASE_IMG!}}list-rubrique.png" />
                        <span>{{!$c->l('Menu')!}}</span>
                    </a>
                </li>
                <li class="<?php if($menu === 'inbox'){ echo 'active'; } ?>">
                    <a href="?controller=inbox">
                        <img src="{{!BASE_IMG!}}mod_inbox.png" />
                        <span>{{!$c->l('Message')!}}</span>
                        {{!$iInboxNotRead!}}
                    </a>
                </li>
                <li class="<?php if($menu === 'comment'){ echo 'active'; } ?>">
                    <a href="?controller=comment">
                        <img src="{{!BASE_IMG!}}icone_comment.png" />
                        <span>{{!$c->l('Commentaire')!}}</span>
                        {{!$iCommentNotRead!}}
                    </a>
                </li>
                <li class="<?php if($menu === 'media'){ echo 'active'; } ?>">
                    <a href="?controller=media">
                        <img src="{{!BASE_IMG!}}icone_media.png" />
                        <span>{{!$c->l('Média')!}}</span>
                    </a>
                </li>
                <li class="<?php if( in_array($menu,$isEmailingRubriques) ){ echo 'active'; } ?>">
                    <a href="?controller=emailing">
                        <img src="{{!BASE_IMG!}}icone_emailing.png" />
                        <span>{{!$c->l('Newsletter')!}}</span>
                    </a>
                </li>
                <li class="<?php if($menu === 'traductions'){ echo 'active'; } ?>">
                    <a href="?controller=traductions">
                        <img src="{{!BASE_IMG!}}icone_traductions.png" />
                        <span>{{!$c->l('Traductions')!}}</span>
                    </a>
                </li>
                <li class="<?php if($menu === 'configuration'){ echo 'active'; } ?>">
                    <a href="?controller=configuration">
                        <img src="{{!BASE_IMG!}}icone_configuration.png" />
                        <span>{{!$c->l('Configuration')!}}</span>
                    </a>
                </li>
                <li class="tools-bt">
                    <img src="{{!BASE_IMG!}}icone_plus.png" /> <span>{{!$c->l('Plus')!}}</span>
                </li>
            </ul>
            {{?(!empty($version) && $action !== 'updater'):}}
                <div class="super-info">{{!$c->l('Une mise à jour importante est disponible !')!}}
                <br />
                <a href="?controller=configuration&action=updater">{{!$c->l('Cliquez ici')!}}</a></div>
            {?}
        </div>
    </div>
    <div class="nav-off">
      <div class="nav-off-c">&#8592;</div>
    </div>
  </div>
  <div class="p-left params-out">
    <div class="">
      <div class="t-title">{{!$c->l('Que voulez vous faire ?')!}}</div>
      <ul>
          <li><a href="{{!BASE!}}"><span>{{!$c->l('Accéder au site')!}}</span></a></li>
          <li><a href="?controller=authentification&action=logout"><span>{{!$c->l('Me déconnecter')!}}</span></a></li>
      </ul>
    </div>
  </div>
  <div class="p-content">
    <div class="p-content-c pad-10">
    