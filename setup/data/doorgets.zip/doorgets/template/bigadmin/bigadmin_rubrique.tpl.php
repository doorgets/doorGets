<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.0 #!#!#
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/



    // Init $menu from Name Controller
    $menu = $doorGets->Controller()->controllerName;
    $action = $doorGets->Controller()->Action();
    
    // Init rubrique for module
    $isModuleRubriques      = array('modules','modulenews','modulecategory','modulepage','modulemultipage','moduleblock',
                                    'modulelink','moduleimage','modulevideo','modulefaq','modulepartner','moduleapplicationjob');
    $isRubriquesRubriques   = array('rubriques','rubriquesusers');
    $isEmailingRubriques    = array('emailing');
    
    $iCommentNotRead    = $doorGets->getCountCommentNotRead();
    if(empty($iCommentNotRead)){ $iCommentNotRead = '';}
    if(!empty($iCommentNotRead)){ $iCommentNotRead    = '<small class="info-counts">'.$iCommentNotRead.'</small>'; }
    
    $iInboxNotRead      = $doorGets->getCountInboxNotRead();
    if(empty($iInboxNotRead)){ $iInboxNotRead = '';}
    if(!empty($iInboxNotRead)){ $iInboxNotRead      = '<small class="info-counts">'.$iInboxNotRead.'</small>'; }
    
    $version = $doorGets->_newVersion();
    
?>
<div class="header-top">
    <a href="./">doorGets</a>
    <a href="?controller=authentification&action=logout" class="right" title="{{!$doorGets->Controller()->thisController->l('Se déconnecter')!}}"><img src="{{!BASE_IMG.'top_deco.png'!}}" /></a>
    <a href="{{!BASE!}}" target="blank" class="right" title="{{!$doorGets->Controller()->thisController->l('Accéder au site')!}}"><img src="{{!BASE_IMG.'top_siteweb.png'!}}"  /></a>
</div>
<div class="doorGets-top-rubrique">
    <ul>
        <li class="first <?php if( in_array($menu,$isModuleRubriques) ){ echo 'active'; } ?>"><a href="?controller=modules">{{!$doorGets->Controller()->thisController->l('Module')!}}</a></li>
        <li class="<?php if( in_array($menu,$isRubriquesRubriques) ){ echo 'active'; } ?>"><a href="?controller=rubriques">{{!$doorGets->Controller()->thisController->l('Menu')!}}</a></li>
        <li class="<?php if($menu === 'inbox'){ echo 'active'; } ?>"><a href="?controller=inbox">{{!$doorGets->Controller()->thisController->l('Message')!}}{{!$iInboxNotRead!}}</a></li>
        <li class="<?php if($menu === 'comment'){ echo 'active'; } ?>"><a href="?controller=comment">{{!$doorGets->Controller()->thisController->l('Commentaire')!}}{{!$iCommentNotRead!}}</a></li>
        <li class="<?php if($menu === 'media'){ echo 'active'; } ?>"><a href="?controller=media">{{!$doorGets->Controller()->thisController->l('Média')!}}</a></li>
        <li class="<?php if( in_array($menu,$isEmailingRubriques) ){ echo 'active'; } ?>"><a href="?controller=emailing">{{!$doorGets->Controller()->thisController->l('Newsletter')!}}</a></li>
        <li class="<?php if($menu === 'traductions'){ echo 'active'; } ?>"><a href="?controller=traductions">{{!$doorGets->Controller()->thisController->l('Traductions')!}}</a></li> 
        <li class="<?php if($menu === 'configuration'){ echo 'active'; } ?>"><a href="?controller=configuration">{{!$doorGets->Controller()->thisController->l('Configuration')!}}</a></li>
    </ul>
    
</div>
<div class="doorGets-content-center">
    {{?(!empty($version) && $action !== 'updater'):}}
        <div class="super-info">{{!$doorGets->Controller()->thisController->l('Une mise à jour importante est disponible !')!}} -
        <a href="?controller=configuration&action=updater">{{!$doorGets->Controller()->thisController->l('Cliquez ici')!}}</a></div>
    {?}