<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 20, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/



    // Init $menu from Name Controller
    $menu = $doorGets->Controller()->controllerName;
    $action = $doorGets->Controller()->Action();
    
    // Init rubrique for module
    $isModuleRubriques      = array('modules','modulenews','modulecategory','modulepage','modulemultipage','moduleblock',
                                    'modulelink','moduleimage','modulevideo','modulefaq','modulepartner','moduleapplicationjob');
    $isRubriquesRubriques   = array('rubriques');
    $isEmailingRubriques    = array('emailing');
    $isDashboardRubriques   = array('dashboard');
    $isDashboardTheme       = array('theme');
    $isUsersRubriques       = array('users','groupes','rubriquesusers');
    
    $iCommentNotRead    = $doorGets->getCountCommentNotRead();
    if(empty($iCommentNotRead)){ $iCommentNotRead = '';}
    if(!empty($iCommentNotRead)){ $iCommentNotRead    = '<small class="info-counts">'.$iCommentNotRead.'</small>'; }
    
    $iInboxNotRead      = $doorGets->getCountInboxNotRead();
    if(empty($iInboxNotRead)){ $iInboxNotRead = '';}
    if(!empty($iInboxNotRead)){ $iInboxNotRead      = '<small class="info-counts">'.$iInboxNotRead.'</small>'; }
    
    $Rubriques = array(
            
        'siteweb'       => $doorGets->l('Site Web'),
        'langue'        => $doorGets->l('Langue').' / '.$doorGets->l('Heure'),
        'media'         => $doorGets->l('Logo').' & '.$doorGets->l('Icône'),
        'modules'       => $doorGets->l('Modules interne'),
        'adresse'       => $doorGets->l('Addresse').' & '.$doorGets->l('Contact'),
        'network'       => $doorGets->l('Réseaux sociaux'),
        'analytics'     => $doorGets->l('Google analytics'),
        'sitemap'       => $doorGets->l('Plan du site'),
        'backups'       => $doorGets->l('Sauvegardes'),
        'updater'       => $doorGets->l('Mise à jour'),
        'cache'         => $doorGets->l('Cache'),
        'pwd'           => $doorGets->l('Mot de passe'),
        'params'        => $doorGets->l('Paramètres'),
        
    );
    
    $RubriquesImage = array(
            
        'siteweb'         => '<b class="glyphicon glyphicon-home"></b>',
        'langue'        => '<b class="glyphicon glyphicon-globe"></b>',
        'media'         => '<b class="glyphicon glyphicon-picture"></b>',
        'modules'       => '<b class="glyphicon glyphicon-asterisk"></b>',
        'adresse'       => '<b class="glyphicon glyphicon-envelope"></b>',
        'network'       => '<b class="glyphicon glyphicon-link"></b>',
        'analytics'     => '<b class="glyphicon glyphicon-stats"></b>',
        'sitemap'       => '<b class="glyphicon glyphicon-tree-deciduous"></b>',
        'backups'       => '<b class="glyphicon glyphicon-floppy-disk"></b>',
        'updater'       => '<b class="glyphicon glyphicon-open"></b>',
        'cache'         => '<b class="glyphicon glyphicon-refresh"></b>',
        'pwd'           => '<b class="glyphicon glyphicon-edit"></b>',
        'params'        => '<b class="glyphicon glyphicon-cog"></b>'
        
    );
    
    $c = $doorGets->Controller()->thisController;
    
?>

<nav class="navbar navbar-default" role="navigation">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand"  href="./"><img  src="{{!BASE_IMG!}}logo.png" /></a>
    </div>
    <div class="collapse navbar-collapse " id="bs-navbar">
        <ul class="nav navbar-nav">
            <li class="first <?php if( in_array($menu,$isDashboardRubriques) ){ echo 'active'; } ?>">
                <a href="./"  title="{{!$c->l('Tableau de bord')!}}">
                    <b class="glyphicon glyphicon-dashboard"></b>
                    <span>{{!$c->l('Tableau de bord')!}}</span>
                </a>
            </li>
            <li class="dropdown <?php if( in_array($menu,$isModuleRubriques) ){ echo 'active'; } ?>">
                <a href="?controller=modules"  title="{{!$c->l('Module')!}}"  class="dropdown-toggle" data-toggle="dropdown">
                    <b class="glyphicon glyphicon-asterisk"></b>
                    <span>{{!$c->l('Module')!}}</span>
                    <b class="caret"></b>
                </a>
                <ul class="dropdown-menu">
                    <li ><a href="?controller=modules"><b class="glyphicon glyphicon-list-alt"></b> {{!$c->l('Afficher la liste')!}}</a></li>
                    <li class="divider"></li>
                    <li ><a href="?controller=modules&action=type"><b class="glyphicon glyphicon-plus"></b> {{!$c->l('Créer un module')!}}</a></li>
                    
                    {{?(!empty($allModules)):}}
                        <li class="divider"></li>
                        {{/($allModules as $v):}}
                            {{
                                $imgVal = '<img src="'.BASE_IMG.'puce-verte.png" title="'.$doorGets->l('Active').'"  />';
                                if($v['active'] === '0'){
                                    $imgVal = '<img src="'.BASE_IMG.'puce-rouge.png" title="'.$doorGets->l('Désactivé').'" />';
                                }
                                $imgType = '<img src="'.$listeInfos[$v['type']]['image'].'" class="px15" >';
                            }}
                            <li >
                                <a href="{{!$v['url']!}}" title="{{!$doorGets->l('Gérer le contenu')!}}" style="display: block;">
                                    {{!$imgVal!}} {{!$imgType!}} {{!$doorGets->_truncate($v['label'])!}}
                                </a>
                                
                            </li>
                        {/}
                        
                    {?}
                    
                </ul>
            </li>
            <li class="<?php if( in_array($menu,$isRubriquesRubriques) ){ echo 'active'; } ?>">
                <a href="?controller=rubriques"  title="{{!$c->l('Menu')!}}">
                    <span class="hidden-sm ">
                        <b class="glyphicon glyphicon-align-justify"></b>
                        <span>{{!$c->l('Menu')!}}</span>
                    </span>
                    <span class="visible-sm ">
                        <b class="glyphicon glyphicon-align-justify"></b>
                    </span>
                    
                </a>
                
            </li>
            <li class="divider-vertical hidden-xs"></li>
            <li class="dropdown hidden-xs">
                <a href="#" class="dropdown-toggle" title="{{!$c->l("Edition rapide")!}}" data-toggle="dropdown">
                    <span class="hidden-sm ">
                        <b class="glyphicon glyphicon-flash"></b>
                        {{!$c->l("Edition rapide")!}}
                        <b class="caret"></b>
                    </span>
                    <span class="visible-sm ">
                        <b class="glyphicon glyphicon-flash"></b>
                        <b class="caret"></b>
                    </span>
                </a>
                <ul class="dropdown-menu">
                    <li class="dropdown-submenu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"  tabindex="-1">{{!$c->l("Créer un module")!}}</a>
                        <ul class="dropdown-menu">
                        {{/($liste as $uri_module => $label):}}
                            <li>
                                <a href="?controller=modules&action=add{{!$uri_module!}}">
                                    <img src="{{!$listeInfos[$uri_module]['image']!}}"  class="px15" >
                                    {{!$label!}}
                                </a>
                            </li>
                        {/}
                        </ul>
                    </li>
                    {{?(!empty($modules)):}}
                    <li class="divider"></li>
                    <li class="dropdown-submenu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"  tabindex="-1">{{!$c->l("Ajouter du contenu dans")!}}</a>
                        <ul class="dropdown-menu">
                            {{/($modules as $value):}}
                                <li>
                                    <a href="?controller=module{{!$value['type']!}}&uri={{!$value['uri']!}}&action=add">
                                        <img src="{{!$listeInfos[$value['type']]['image']!}}"  class="px15" >
                                        {{!$value['label']!}}
                                    </a>
                                </li>
                            {/}
                        </ul>
                    </li>
                    {?}
                </ul>
            </li>
            <li class="divider-vertical hidden-xs"></li>
        </ul>
    
        <ul class="nav navbar-nav navbar-right">
            
            <li class="<?php if($menu === 'inbox'){ echo 'active'; } ?>">
                <a href="?controller=inbox" title="{{!$c->l('Message')!}}">
                    <span class="hidden-sm">
                        <b class="glyphicon glyphicon-envelope"></b>
                        {{!$c->l('Message')!}}
                        <span class="badge badge-important">{{!$iInboxNotRead!}}</span>
                    </span>
                    <span class="visible-sm">
                        <b class="glyphicon glyphicon-envelope"></b>
                        <span class="badge badge-important">{{!$iInboxNotRead!}}</span>
                    </span>
                </a>
            </li>
            <li class="<?php if($menu === 'comment'){ echo 'active'; } ?>">
                <a href="?controller=comment" title="{{!$c->l('Commentaire')!}}">
                    <span class="hidden-sm ">
                        <b class="glyphicon glyphicon-comment"></b>
                        {{!$c->l('Commentaire')!}}
                        <span class="badge badge-important">{{!$iCommentNotRead!}}</span>
                    </span>
                    <span class="visible-sm ">
                        <b class="glyphicon glyphicon-comment"></b>
                        <span class="badge badge-important">{{!$iCommentNotRead!}}</span>
                    </span>
                </a>
            </li>
            
            <li class="dropdown <?php if($menu === 'configuration'){ echo 'active'; } ?>">
                <a class="dropdown-toggle" title="{{!$c->l('Configuration')!}}" data-toggle="dropdown" href="?controller=configuration">
                    <span class="hidden-sm ">
                        <img src="{{!BASE_IMG!}}icone_configuration.png" class="px15" />
                        <span>{{!$c->l('Configuration')!}}</span> <b class="caret"></b>
                    </span>
                    <span class="visible-sm ">
                        <img src="{{!BASE_IMG!}}icone_configuration.png" class="px15" />
                        <b class="caret"></b>
                    </span>
                </a>
                <ul class="dropdown-menu">
                    <?php foreach($Rubriques as $act=>$label): ?>
                        <li class="<?php if($menu === $act){ echo 'active'; } ?>" >
                            <a href="?controller=configuration&action=<?php echo $act; ?>">
                                {{!$RubriquesImage[$act]!}}
                                <?php echo $label; ?>
                            </a>
                            </li>
                    <?php endforeach; ?>
                </ul>
            </li>
            {{!$outChangeLangue!}}
            
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <b class="glyphicon glyphicon-plus"></b>
                </a>
                <ul class="dropdown-menu">
                    <li>
                        <a target="_blank" href="{{!BASE!}}">
                            <span>{{!$c->l('Accéder au site')!}}</span>
                        </a>
                    </li>
                    <li class="divider"></li>
                    <li class="<?php if($menu === 'media'){ echo 'active'; } ?>">
                        <a href="?controller=media">
                            <img src="{{!BASE_IMG!}}icone_media.png" class="px15" />
                            <span>{{!$c->l('Média')!}}</span>
                        </a>
                    </li>
                    <li class="<?php if( in_array($menu,$isEmailingRubriques) ){ echo 'active'; } ?>">
                        <a href="?controller=emailing">
                            <img src="{{!BASE_IMG!}}icone_emailing.png" class="px15" />
                            <span>{{!$c->l('Newsletter')!}}</span>
                        </a>
                    </li>
                    <li class="<?php if($menu === 'traductions'){ echo 'active'; } ?>">
                        <a href="?controller=traductions">
                            <img src="{{!BASE_IMG!}}icone_traductions.png" class="px15" />
                            <span>{{!$c->l('Traductions')!}}</span>
                        </a>
                    </li>
                    <li class="<?php if($menu === 'theme'){ echo 'active'; } ?>">
                        <a href="?controller=theme">
                            <img src="{{!BASE_IMG!}}icone_theme.png" class="px15" />
                            <span>{{!$c->l('Thème')!}}</span>
                        </a>
                    </li>
                    <li class="divider"></li>
                    <li>
                        <a href="?controller=authentification&action=logout">
                            <span>{{!$c->l('Me déconnecter')!}}</span>
                        </a>
                    </li>
                </ul>
            </li>
            
        </ul>
    </div>
</nav>
{{?(!empty($version) && $action !== 'updater'):}}
    <div class="alert alert-info" >
        <div class="text-center">
            {{!$doorGets->l('Une mise à jour importante est disponible')!}} : 
            <a class="btn btn-success" href="?controller=configuration&action=updater">{{!$doorGets->l('Cliquez ici')!}}</a>
        </div>
    </div>
{?}