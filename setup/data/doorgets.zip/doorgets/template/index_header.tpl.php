<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 07, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/



?><!doctype html>
<html lang="{{$doorGets->myLanguage()}}">
    <head>
        
        <title>doorGets</title>
        
        <meta charset="utf-8" />
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta http-equiv="Content-Style-Type" content="text/css" />
	<META NAME="robots" CONTENT="noindex,nofollow,noarchive">
	    
        <script  src="{{!BASE_JS.'jquery.js'!}}" type="text/javascript"></script>
        <script  src="{{!BASE_JS.'jquery.ui.js'!}}" type="text/javascript"></script>
	<link href="{{!BASE_CSS.'jquery.css'!}}" rel="stylesheet" type="text/css" />
	
        <!-- <link href="{{!BASE_CSS.'bigadmin.css'!}}" rel="stylesheet" type="text/css" /> -->
        <link href="{{!BASE.'skin/bootstrap/css/bootstrap.min.css'!}}" rel="stylesheet" type="text/css" />
	<link href="{{!BASE_CSS.'bigadmin.m.css'!}}" rel="stylesheet" type="text/css" />
	
	
	
	<script  src="{{!BASE_JS.'bigadmin.js'!}}" type="text/javascript"></script>
	
    </head>
    <body>
        
        <div class="doorGets-wrapper-index">