<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 07, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


    $activeCategory = '';
    if(array_key_exists('categorie',$params['GET'])){
        $activeCategory = $params['GET']['categorie'];
    }
    
    
    $urlToCategorie = '?controller='.$this->Controller->controllerName.'&uri='.$this->uri;
    $urlToNewCategorie = '?controller=modulecategory&uri='.$this->uri;
    $categorieList = $this->categorieSimple;
    unset($categorieList[0]);
    $isActiveAll = 'active';
    if(array_key_exists($activeCategory,$categorieList)){
        $isActiveAll = '';
    }
 
?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title page-header">
        <span class="create" ><a class="doorGets-comebackform" href="?controller=modules"><img src="{{!BASE_IMG!}}retour.png" class="retour-img"> {{!$this->l('Retour')!}}</a></span>
        <span class="create" ><a  href="?controller=modules&action=editmultipage&id={{!$moduleInfos['id']!}}&lg={{!$lgActuel!}}"><b class="glyphicon glyphicon-cog"></b> {{!$this->l('Paramètres')!}}</a></span>
        <span class="create" > <a href="?controller=module{{!$moduleInfos['type']!}}&uri={{!$this->uri!}}&action=add"><img src="{{!BASE_IMG.'add.png'!}}" alt="{{!$this->l("Ajouter")!}}" class="ico-image" />  {{!$this->l('Ajouter une page')!}}</a></span>
        <h1>
            <b class="glyphicon glyphicon-asterisk"></b> <a href="?controller=modules">{{!$this->l('Module')!}} </a> / {{!$moduleInfos['nom']!}}
            <br /><small>{{!$this->l('Gérer vos modules doorGets')!}}.</small>
        </h1>
    </div>
    <div class="doorGets-rubrique-center-content">
        <legend>
            <img src="{{!BASE_IMG.'mod_multipage.png'!}}" title="{{!$this->l("Multipage statique")!}}" class="doorGets-img-ico px25" />{{!$moduleInfos['nom']!}}
            {<small>{{!$this->uri!}}</small>}
        </legend>
        <div class="trad-lg">
            {{!$this->genLangueMenuAdmin()!}}
        </div>
        
        <div style="width: 100%;padding: 10px 0 0;border-bottom: solid 1px #ccc;overflow: hidden;">
            {{?(!empty($cAll)):}}
            <div style="overflow: hidden;">
                <div style="float: left;padding: 7px 0 ">
                    <i>
                        {{?(!empty($cAll)):}} {{!($ini+1)!}} {{!$this->l("à")!}} {{!$finalPer!}} {{!$this->l("sur")!}} {?}
                        <b>{{!$cResultsInt.' '!}} {{?( $cResultsInt > 1 ):}}{{!$this->l('Pages')!}} {??} {{!$this->l('Page')!}} {?}</b>
                        {{?(!empty($q)):}} {{!$this->l('pour la recherche : ').' <b>'.$q.'</b>'!}} {?}
                    </i>
                    <span id="doorGets-sort-count">
                        {{!$this->l('Par')!}}
                        <a href="{{!$urlPagePosition!}}&gby=10" {{?($per=='10'):}} class="active" {?}>10</a>
                        <a href="{{!$urlPagePosition!}}&gby=20" {{?($per=='20'):}} class="active" {?}>20</a>
                        <a href="{{!$urlPagePosition!}}&gby=50" {{?($per=='50'):}} class="active" {?}>50</a>
                        <a href="{{!$urlPagePosition!}}&gby=100" {{?($per=='100'):}} class="active" {?}>100</a>
                    </span>
                     
                </div>
                <div  class="doorGets-box-search-module">
                    {{!$this->Controller->form['_search_filter']->open('post',$urlPageGo,'')!}}
                    {{!$this->Controller->form['_search_filter']->submit($this->l('Chercher'),'','doorGets-filter-bt')!}}
                </div>
            </div>
            <div class="separateur-tb"></div>
                {{!$block->getHtml()!}}
            {?}
            {{!$this->Controller->form['_search']->close()!}}
            {{?(!empty($cAll)):}}
            
                {{!$formMassDelete!}}
                <br />
                {{!$valPage!}}
                <br /><br />
                
            {??}
               
                {{?(!empty($aGroupeFilter)):}}
                    <div class="alert alert-info">
                        {{!$this->l("Aucune page trouvé pour votre recherche.");}}
                    </div>
                {??}
                    <div class="alert alert-info">
                        {{!$this->l("Il n'y a actuellement aucune page dans la base")!}} 
                    </div>
                {?}
                
            {?} 
        </div>
    </div>
</div>