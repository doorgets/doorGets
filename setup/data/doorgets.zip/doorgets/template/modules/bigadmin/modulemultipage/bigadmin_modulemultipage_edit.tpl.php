<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.0 #!#!#
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

    
    $listeCategories = $this->categorieSimple;
    unset($listeCategories[0]);
    $listeCategoriesContent = $this->_toArray($isContent['categorie']);
    
    $phpOpen = '[[php/o]]';
    $phpClose = '[[php/c]]';
    
    $article = $isContent['article_tinymce'];
    
    $article = str_replace(";?",$phpOpen,$article);
    $article = str_replace("?&",$phpClose,$article);
    $article = htmlspecialchars_decode(html_entity_decode($article));
    $article = str_replace($phpOpen,"; ?",$article); 
    $article = str_replace($phpClose,"? &",$article); 
    
?><div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title">
        <a href="?controller=modules">{{!$this->l('Module')!}}</a> /
        <a href="?controller=modulemultipage&uri={{!$this->uri!}}&lg={{!$lgActuel!}}">
            {{!$moduleInfos['nom']!}} 
            <img src="{{!BASE_IMG.'mod_multipage.png'!}}" title="{{!$this->l("Multipage statique")!}}" class="doorGets-img-ico px25" />
        </a>
        <br />
        <span><a href="?controller=modules">{{!$this->l('Gérer vos modules doorGets')!}}</a></span>
        <span style="float: right;" ><a class="doorGets-comebackform" href="{{!$this->goBackUrl()!}}">{{!$this->l('Retour')!}}</a></span>
    </div>
    <div class="doorGets-rubrique-center-title">
        {{!$this->l('Modifier une page')!}} 
    </div>
    <div class="doorGets-rubrique-center-content doorGets-rubriques-rubriques">
        {{!$formEditTop!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->textarea($this->l('Contenu de la page'),'article_tinymce',$article,'tinymce')!}}
        <div class="separateur-tb"></div>
        {{!$formEditBottom!}}

    </div>
</div>