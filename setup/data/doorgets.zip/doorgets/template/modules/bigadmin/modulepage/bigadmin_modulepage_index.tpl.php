<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 11 November, 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

$phpOpen = '[[php/o]]';
$phpClose = '[[php/c]]';

$article = $isContent['article_tinymce'];

$article = str_replace(";?",$phpOpen,$article);
$article = str_replace("?&",$phpClose,$article);
$article = htmlspecialchars_decode(html_entity_decode($article));
$article = str_replace($phpOpen,"; ?",$article); 
$article = str_replace($phpClose,"? &",$article); 
 
 
?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title">
        <a href="?controller=modules">{{!$this->l('Module')!}}</a> / {{!$moduleInfos['nom']!}} 
        <img src="{{!BASE_IMG.'mod_page.png'!}}" title="{{!$this->l("Page statique")!}}" class="doorGets-img-ico px25" />
        <br />
        <span class="go-to-modules"><a href="?controller=modules">{{!$this->l('Gérer vos modules doorGets')!}}</a></span>
        <span class="create" ><a class="doorGets-comebackform" href="?controller=modules"><img src="{{!BASE_IMG!}}retour.png" class="retour-img"> {{!$this->l('Retour')!}}</a></span>
    </div>
    <div class="doorGets-rubrique-center-content">
            
        <div class="doorGets-module-rubrique-left-right-content">
            
            <div class="doorGets-rubrique-center-title">
                {{!$this->l('Modifier une page')!}} {<span class="name-uri">{{!$isContent['uri_module']!}}</span>}
            </div>
            <div class="doorGets-rubrique-center-content doorGets-rubriques-rubriques">
                
                {{!$this->genLangueMenuAdmin()!}}
                
                {{!$this->Controller->form->open('post','','');}}
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->input($this->l('Titre'),'titre','text',$isContent['titre']);}}
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->textarea($this->l('Description courte'),'description',$isContent['description']);}}
                <div class="separateur-tb"></div>
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->textarea($this->l('Contenu de la page'),'article_tinymce',$article,'tinymce')!}}
                <div class="separateur-tb"></div>
                
                <div class="separateur-tb"></div>
                <div class="title-box">
                    {{!$this->l('Référencement')!}}
                </div>
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->input($this->l('Meta Titre'),'meta_titre','text',$isContent['meta_titre']);}}
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->input($this->l('Meta Description'),'meta_description','text',$isContent['meta_description']);}}
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->input($this->l('Meta mots clés'),'meta_keys','text',$isContent['meta_keys']);}}
                <div class="separateur-tb"></div>
                <div class="separateur-tb"></div>
                <div class="title-box">
                    {{!$this->l('Commentaires')!}} 
                </div>
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->checkbox($this->l('Autoriser les commentaires doorGets'),'comments',1,$isActiveComments)!}}
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->checkbox($this->l('Autoriser les commentaires').' Disqus ','disqus','1',$isActiveDisqus)!}}
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->checkbox($this->l('Autoriser les commentaires').' Facebook ','facebook','1',$isActiveFacebook)!}}
                <div class="separateur-tb"></div>
                <div class="separateur-tb"></div>
                <div class="title-box">
                    {{!$this->l('Paramêtres')!}}
                </div>
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->checkbox($this->l('Autoriser le partage').' ShareThis','partage',1,$isActivePartage)!}}
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->checkbox($this->l('Ajouter au flux RSS').'','in_rss',1,$isActiveRss)!}}
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->submit($this->l('Sauvegarder'));}}
                <a class="doorGets-comebackform" href="{{!$this->goBackUrl()!}}">{{!$this->l('annuler')!}}</a>
                {{!$this->Controller->form->close();}}
                
                <script type="text/javascript">
                    
                    $("#module{{!$moduleInfos['type']!}}_edit_titre").keyup(function(){
                    
                        var str = $(this).val();
                        $("#module{{!$moduleInfos['type']!}}_edit_meta_titre").val(str);
                        
                    });
                    $("#module{{!$moduleInfos['type']!}}_edit_description").keyup(function(){
                    
                        var str = $(this).val();
                        var lendesc =  str.length;
                        if(lendesc >= 250){
                            str = str.substr(0,250);
                        }
                        $("#module{{!$moduleInfos['type']!}}_edit_meta_description").val(str);
                        
                    });
                </script>
                
            </div> 
            
        </div>
    </div>
</div>