<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 21, December 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


   
    
?><div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title">
        {{!$this->l('Module')!}} / {{!$moduleInfos['nom']!}}
        <img src="{{!BASE_IMG.'mod_video.png'!}}" title="{{!$this->l("Galerie vidéos")!}}" class="doorGets-img-ico px20" />
        <br />
        <span class="go-to-modules"><a href="?controller=modules">{{!$this->l('Gérer vos modules doorGets')!}}</a></span>
        <span class="create" ><a class="doorGets-comebackform" href="?controller=module{{!$moduleInfos['type']!}}&uri={{!$this->uri!}}"><img src="{{!BASE_IMG!}}retour.png" class="retour-img"> {{!$this->l('Retour')!}}</a></span>
    </div>
    <div class="doorGets-rubrique-center-title">
        {{!$this->l('Ajouter une vidéo')!}} 
    </div>
    <div class="doorGets-rubrique-center-content  doorGets-rubriques-rubriques">
        
        {{?( !empty($this->categorie) ):}}
            
            {{!$this->Controller->form->open('post','')!}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->select($this->l('Statut'),'active',$aActivation,2);}}
            <div class="separateur-tb"></div>
            <label>{{!$this->l('Catégories')!}} </label>
            <div class="separateur-tb"></div>
            {{/($listeCategories as $key=>$label):}}
                {{!$this->Controller->form->checkbox($label,'categories_'.$key,'1')!}}
            {/}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->input($this->l('Titre'),'titre');}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->input($this->l('Code Youtube'),'youtube')!}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->select($this->l('Temps').' ('.$this->l('minute').')','temps',$this->timer)!}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form->textarea($this->l('Description'),'article_tinymce','','tinymce')!}}
            <div class="separateur-tb"></div>
            {{!$formAddBottom!}}
            
        {??}
                <div class="info-not-found">
                    {{!$this->l("Il n'existe aucune catégorie")!}} : <a href="?controller=modulecategory&uri={{!$this->uri!}}&action=add">{{!$this->l('Ajouter une catégorie')!}}</a>
                </div>
                
            
        {?}  
        
    </div>
</div>