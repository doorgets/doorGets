<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 04 December, 2013
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


?>

<div class="separateur-tb"></div>
<div class="title-box">
    {{!$this->l('Référencement')!}}
</div>
<div class="separateur-tb"></div>
{{!$this->Controller->form->input($this->l("Clé d'url").' <small style="font-weight:100; ">('.$this->l("Caractères alpha numérique seulement").')</small><br />','uri','text',$isContent['uri']);}}
<div class="separateur-tb"></div>
{{!$this->Controller->form->input($this->l('Meta Titre'),'meta_titre','text',$isContent['meta_titre']);}}
<div class="separateur-tb"></div>
{{!$this->Controller->form->input($this->l('Meta Description'),'meta_description','text',$isContent['meta_description']);}}
<div class="separateur-tb"></div>
{{!$this->Controller->form->input($this->l('Meta mots clés'),'meta_keys','text',$isContent['meta_keys']);}}
<div class="separateur-tb"></div>
<div class="separateur-tb"></div>
<div class="title-box">
    {{!$this->l('Commentaires')!}} 
</div>
<div class="separateur-tb"></div>
{{!$this->Controller->form->checkbox($this->l('Autoriser les commentaires doorGets'),'comments',1,$isActiveComments)!}}
<div class="separateur-tb"></div>
{{!$this->Controller->form->checkbox($this->l('Autoriser les commentaires').' Disqus ','disqus','1',$isActiveDisqus)!}}
<div class="separateur-tb"></div>
{{!$this->Controller->form->checkbox($this->l('Autoriser les commentaires').' Facebook ','facebook','1',$isActiveFacebook)!}}
<div class="separateur-tb"></div>
<div class="separateur-tb"></div>
<div class="title-box">
    {{!$this->l('Paramêtres')!}}
</div>
<div class="separateur-tb"></div>
{{!$this->Controller->form->checkbox($this->l('Autoriser le partage').' ShareThis','partage',1,$isActivePartage)!}}
<div class="separateur-tb"></div>
{{!$this->Controller->form->checkbox($this->l('Ajouter au flux RSS').'','in_rss',1,$isActiveRss)!}}
<div class="separateur-tb"></div>
{{!$this->Controller->form->submit($this->l('Sauvegarder'));}}
<a class="doorGets-comebackform" href="{{!$this->goBackUrl()!}}">{{!$this->l('annuler')!}}</a>
{{!$this->Controller->form->close();}}

<script type="text/javascript">
    
    
    $("#module{{!$moduleInfos['type']!}}_edit_titre").keyup(function(){
    
        var str = $(this).val();
        $("#module{{!$moduleInfos['type']!}}_edit_meta_titre").val(str);
        
    });
    $("#module{{!$moduleInfos['type']!}}_edit_description").keyup(function(){
    
        var str = $(this).val();
        var lendesc =  str.length;
        if(lendesc >= 250){
            str = str.substr(0,250);
        }
        $("#module{{!$moduleInfos['type']!}}_edit_meta_description").val(str);
        
    });
</script>