<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 20, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

    $phpOpen = '[[php/o]]';
    $phpClose = '[[php/c]]';
    
    $article = $isContent['reponse_tinymce'];
    
    $article = str_replace(";?",$phpOpen,$article);
    $article = str_replace("?&",$phpClose,$article);
    $article = htmlspecialchars_decode(html_entity_decode($article));
    $article = str_replace($phpOpen,"; ?",$article); 
    $article = str_replace($phpClose,"? &",$article);
    
    
?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title page-header">
        <span class="create" ><a class="doorGets-comebackform" href="{{!$this->goBackUrl()!}}"><img src="{{!BASE_IMG!}}retour.png" class="retour-img"> {{!$this->l('Retour')!}}</a></span>
        <h1>
            <b class="glyphicon glyphicon-asterisk"></b> <a href="?controller=modules">{{!$this->l('Module')!}} </a> / {{!$moduleInfos['nom']!}}
            <br /><small>{{!$this->l('Gérer vos modules doorGets')!}}.</small>
        </h1>
    </div>
    <div class="doorGets-rubrique-center-content">
        <legend>
            <img src="{{!BASE_IMG.'mod_faq.png'!}}" title="{{!$this->l("FAQ")!}}" class="doorGets-img-ico px25" />
           {{!$moduleInfos['nom']!}} : {{!$this->l('Modifier une question')!}}  : id[{{!$isContent['id_content']!}}]
        </legend>
        <ul class="pager">
            <li class="previous {{?(empty($urlPrevious)):}}disabled{?}"><a href="{{!$urlPrevious!}}">&larr; {{!$this->l('Précèdent')!}}</a></li>
            <li class="next {{?(empty($urlNext)):}}disabled{?}"><a href="{{!$urlNext!}}">{{!$this->l('Suivant')!}} &rarr;</a></li>
        </ul>
        <div class="trad-lg">
            {{!$this->genLangueMenuAdmin()!}}
        </div>
        {{!$this->Controller->form->open('post','');}}
        <div id="tabs">
            <ul>
                <li><a href="#tabs-1">{{!$this->l('Information')!}}</a></li>
                <li><a href="#tabs-2">{{!$this->l('Paramètres')!}}</a></li>
            </ul>
            <div id="tabs-1">
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->textarea($this->l('Question'),'question',$isContent['question'])!}}
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->textarea($this->l('Réponse'),'reponse_tinymce',$article,'tinymce')!}}
                <div class="separateur-tb"></div>
            </div>
            <div id="tabs-2">
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->select($this->l('Statut'),'active',$aActivation,2);}}
                <div class="separateur-tb"></div>
            </div>
        </div>
        {{!$this->Controller->form->submit($this->l('Sauvegarder'));}}
        <a class="doorGets-comebackform" href="./?controller=modulefaq&uri={{!$this->uri!}}">{{!$this->l('annuler')!}}</a>
        {{!$this->Controller->form->close();}}
        
    </div>
</div>