<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.2 - 13, January 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


    $activeCategory = '';
    if(array_key_exists('categorie',$params['GET'])){
        $activeCategory = $params['GET']['categorie'];
    }
    
    
    $urlToCategorie = '?controller='.$this->Controller->controllerName.'&uri='.$this->uri;
    $urlToNewCategorie = '?controller=modulecategory&uri='.$this->uri;
    $categorieList = $this->categorieSimple;
    unset($categorieList[0]);
    $isActiveAll = 'active';
    if(array_key_exists($activeCategory,$categorieList)){
        $isActiveAll = '';
    }
    
?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title">
        <a href="?controller=modules">{{!$this->l('Module')!}}</a> / {{!$moduleInfos['nom']!}}
        <img src="{{!BASE_IMG.'mod_news.png'!}}" title="{{!$this->l("Actualité")!}}" class="doorGets-img-ico px20" />
        <br />
        <span class="go-to-modules"><a href="?controller=modules">{{!$this->l('Gérer vos modules doorGets')!}}</a></span>
        <span class="create" >
            <a href="?controller=module{{!$moduleInfos['type']!}}&uri={{!$this->uri!}}&action=add"><img src="{{!BASE_IMG.'add.png'!}}" title="{{!$this->l("Ajouter un article")!}}" class="ico-image" />  {{!$this->l('Ajouter un article')!}}</a>
        </span>
    </div>
    <div class="doorGets-rubrique-center-content">
        {{!$this->genLangueMenuAdmin()!}}
            
            <div class="doorGets-sub-rubrique doorGets-rubrique-left">
                <ul>
                    <li class="{{!$isActiveAll!}}"><a href="{{!$urlToCategorie!}}&lg={{!$lgActuel!}}">{{!$this->l('Toutes catégories')!}}</a></li>
                    {{?(!empty($categorieList)):}}
                        {{/($categorieList as $key=>$label):}}
                        
                            <li class="{{?($key == $activeCategory):}} active {?}" >
                                <a  href="{{!$urlToCategorie!}}&categorie={{!$key!}}&lg={{!$lgActuel!}}">
                                    <img src="{{!BASE_IMG!}}list-rubrique.png" class="doorGets-ico-min">
                                    {{!$label!}}
                                </a>
                            </li>
                        {/}
                    {?}
                    <li ><a href="{{!$urlToNewCategorie!}}&action=add"><img src="{{!BASE_IMG.'add.png'!}}" alt="{{!$this->l("Ajouter")!}}" class="ico-image" />  {{!$this->l('Ajouter une catégorie')!}}</a></li>
                    <li ><a href="{{!$urlToNewCategorie!}}&lg={{!$lgActuel!}}">{{!$this->l('Gérer les catégories')!}}</a></li>
                </ul>
            </div>
            <div class="doorGets-module-rubrique-left-right">
                {{?(!empty($cAll)):}}
                <div style="overflow: hidden;border-bottom: solid 1px #BBB;">
                    
                    <div style="float: left;padding: 7px 0 ">
                        <i>
                            {{?(!empty($cAll)):}} {{!($ini+1)!}} {{!$this->l("à")!}} {{!$finalPer!}} {{!$this->l("sur")!}} {?}
                            <b>{{!$cResultsInt.' '!}} {{?( $cResultsInt > 1 ):}}{{!$this->l('Actualités')!}} {??} {{!$this->l('Actualité')!}} {?}</b>
                            {{?(!empty($q)):}} {{!$this->l('pour la recherche : ').' <b>'.$q.'</b>'!}} {?}
                        </i>
                        <span id="doorGets-sort-count">
                            {{!$this->l('Par')!}}
                            <a href="{{!$urlPagePosition!}}&gby=10" {{?($per=='10'):}} class="active" {?}>10</a>
                            <a href="{{!$urlPagePosition!}}&gby=20" {{?($per=='20'):}} class="active" {?}>20</a>
                            <a href="{{!$urlPagePosition!}}&gby=50" {{?($per=='50'):}} class="active" {?}>50</a>
                            <a href="{{!$urlPagePosition!}}&gby=100" {{?($per=='100'):}} class="active" {?}>100</a>
                        </span>
                         
                    </div>
                    <div  class="doorGets-box-search-module">
                        {{!$this->Controller->form['_search_filter']->open('post',$urlPageGo,'')!}}
                        {{!$this->Controller->form['_search_filter']->submit($this->l('Chercher'),'','doorGets-filter-bt')!}}
                    </div>
                </div>
                <div class="separateur-tb"></div>
                {{!$block->getHtml()!}}
                {{!$this->Controller->form['_search']->close()!}}
                
                
                    {{!$formMassDelete!}}
                    <br />
                    {{!$valPage!}}
                    <br /><br />
                    
                {??}
                   
                    {{?(isset($_GET['categorie'])):}}
                        <div class="info-not-found">
                            {{!$this->l("Il n'y a actuellement aucun article pour cette catégorie.")!}} : <a href="?controller=module{{!$moduleInfos['type']!}}&uri={{!$this->uri!}}&action=add">{{!$this->l('Ajouter un article')!}}</a>
                        </div>
                    {{???(!empty($aGroupeFilter)):}}
                        <div class="info-not-found">
                            {{!$this->l("Aucun article trouvé pour votre recherche.");}}
                        </div>
                    {??}
                        <div class="info-not-found">
                            {{!$this->l("Il n'y a actuellement aucun article dans la base")!}} : <a href="?controller=module{{!$moduleInfos['type']!}}&uri={{!$this->uri!}}&action=add">{{!$this->l('Ajouter un article')!}}</a>
                        </div>
                    {?}
                    
                {?}
            </div>
        </div>
    </div>
</div>