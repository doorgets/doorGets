<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 5.2 - 13, January 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


   
    
?><div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title">
        {{!$this->l('Module')!}} / {{!$moduleInfos['nom']!}}
        <img src="{{!BASE_IMG.'mod_news.png'!}}" title="{{!$this->l("Actualité")!}}" class="doorGets-img-ico px20" />
        <br />
        <span class="go-to-modules"><a href="?controller=modules">{{!$this->l('Gérer vos modules doorGets')!}}</a></span>
        <span class="create" ><a class="doorGets-comebackform" href="?controller=module{{!$moduleInfos['type']!}}&uri={{!$this->uri!}}"><img src="{{!BASE_IMG!}}retour.png" class="retour-img"> {{!$this->l('Retour')!}}</a></span>
    </div>
    <div class="doorGets-rubrique-center-title">
        {{!$this->l('Ajouter un article')!}} 
    </div>
    <div class="doorGets-rubrique-center-content  doorGets-rubriques-rubriques">
        {{!$formAddTop!}}
        {{!$this->Controller->form->file($this->l('Image de couverture').' <span class="cp-obli">*</span>','image');}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->textarea($this->l('Article').' <span class="cp-obli">*</span>','article_tinymce','','tinymce')!}}
        <div class="separateur-tb"></div>
        {{?(!empty($listeCategories)):}}
            <label>{{!$this->l('Catégories')!}} </label>
            <div class="separateur-tb"></div>
            {{/($listeCategories as $key=>$label):}}
                {{!$this->Controller->form->checkbox($label,'categories_'.$key,'1')!}}
            {/}
            <div class="separateur-tb"></div>
        {?}
        {{!$formAddBottom!}}
    </div>
</div>