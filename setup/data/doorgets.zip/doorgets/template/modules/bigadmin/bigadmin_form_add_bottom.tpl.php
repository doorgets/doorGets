<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 07, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


?>
    </div>
    <div id="tabs-2">
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->input($this->l('Meta Titre'),'meta_titre');}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->input($this->l('Meta Description'),'meta_description');}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->input($this->l('Meta mots clés'),'meta_keys');}}
        <div class="separateur-tb"></div>  
    </div>
    <div id="tabs-3">
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->checkbox($this->l('Autoriser les commentaires doorGets'),'comments','1','checked')!}}
        <div class="separateur-tb"></div>
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->checkbox($this->l('Autoriser les commentaires').' Disqus ','disqus','1','')!}}
        <div class="separateur-tb"></div>
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->checkbox($this->l('Autoriser les commentaires').' Facebook ','facebook','1','')!}}
        <div class="separateur-tb"></div>
    </div>
    <div id="tabs-4">
        {{!$this->Controller->form->checkbox($this->l('Autoriser le partage').' ShareThis','partage','1','checked')!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->checkbox($this->l('Ajouter au flux RSS').'','in_rss','1','checked')!}}
        <div class="separateur-tb"></div>
        {{!$this->Controller->form->select($this->l('Statut'),'active',$aActivation,2);}}
    </div>
</div>
    {{!$this->Controller->form->submit($this->l('Sauvegarder'));}}
    <a class="doorGets-comebackform" href="./?controller=module{{!$moduleInfos['type']!}}&uri={{!$this->uri!}}">{{!$this->l('annuler')!}}</a>
    {{!$this->Controller->form->close();}}
        
        <script type="text/javascript">
        
          $("#module{{!$moduleInfos['type']!}}_add_titre").keyup(function(){
          
              var str = $(this).val();
              str = str.replace(/^\s+|\s+$/g, ''); // trim
              str = str.toLowerCase();
            
              // remove accents, swap ñ for n, etc
              var from = "ãàáäâẽèéëêìíïîõòóöôùúüûñç·/_,:;";
              var to   = "aaaaaeeeeeiiiiooooouuuunc------";
              for (var i=0, l=from.length ; i<l ; i++) {
                str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
              }
            
              str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
                .replace(/\s+/g, '-') // collapse whitespace and replace by -
                .replace(/-+/g, '-'); // collapse dashes
                
              $("#module{{!$moduleInfos['type']!}}_add_uri").val(str);        
          });
          $("#module{{!$moduleInfos['type']!}}_add_titre").keyup(function(){
          
              var str = $(this).val();
              $("#module{{!$moduleInfos['type']!}}_add_meta_titre").val(str);
              
          });
          $("#module{{!$moduleInfos['type']!}}_add_description").keyup(function(){
          
              var str = $(this).val();
              var lendesc =  str.length;
              if(lendesc >= 250){
                str = str.substr(0,250);
              }
              $("#module{{!$moduleInfos['type']!}}_add_meta_description").val(str);
              
          });
        </script>
