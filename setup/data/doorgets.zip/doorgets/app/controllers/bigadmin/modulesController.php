<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 17 December, 2013
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class ModulesController extends doorgetsController{
    
    public function __construct( $Name,$doorGetsController){
        
        $this->controllerName = $Name;
        parent::__construct($doorGetsController);
        
    }
    
    public function typeAction(){
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function addblockAction(){
        
        $this->form = new Formulaire('modules_addblock');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function addpageAction(){
        
        $this->form = new Formulaire('modules_addpage');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function addmultipageAction(){
        
        $this->form = new Formulaire('modules_addmultipage');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function addnewsAction(){
        
        $this->form = new Formulaire('modules_addnews');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function addinboxAction(){
        
        $this->form = new Formulaire('modules_addinbox');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function addlinkAction(){
        
        $this->form = new Formulaire('modules_addlink');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function addvideoAction(){
        
        $this->form = new Formulaire('modules_addvideo');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function addimageAction(){
        
        $this->form = new Formulaire('modules_addimage');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function addfaqAction(){
        
        $this->form = new Formulaire('modules_addfaq');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function addpartnerAction(){
        
        $this->form = new Formulaire('modules_addpartner');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    
    public function addapplicationjobAction(){
        
        $this->form = new Formulaire('modules_addapplicationjob');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    
    public function editblockAction(){
        
        $this->form = new Formulaire('modules_editblock');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function editpageAction(){
        
        $this->form = new Formulaire('modules_editpage');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function editmultipageAction(){
        
        $this->form = new Formulaire('modules_editmultipage');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function editnewsAction(){
        
        $this->form = new Formulaire('modules_editnews');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function editinboxAction(){
        
        $this->form = new Formulaire('modules_editinbox');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function editlinkAction(){
        
        $this->form = new Formulaire('modules_editlink');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function editvideoAction(){
        
        $this->form = new Formulaire('modules_editvideo');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function editimageAction(){
        
        $this->form = new Formulaire('modules_editimage');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function editfaqAction(){
        
        $this->form = new Formulaire('modules_editfaq');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function editpartnerAction(){
        
        $this->form = new Formulaire('modules_editpartner');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    
    public function editapplicationjobAction(){
        
        $this->form = new Formulaire('modules_editapplicationjob');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    
    public function deleteAction(){
        
        $this->form = new Formulaire('modules_delete');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
}