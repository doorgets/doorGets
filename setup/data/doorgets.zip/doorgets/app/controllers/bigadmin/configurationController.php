<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 20, February 2014
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/



class ConfigurationController extends doorgetsController {
    
    
    public function __construct( $Name,$doorGetsController){
        
        $this->controllerName = $Name;
        parent::__construct($doorGetsController);
        
        
    }
    
    public function backupsAction(){
        
        $this->form['backups_create'] = new Formulaire('backups_create');
        $this->form['backups_install'] = new Formulaire('backups_install');
        $this->form['backups_delete'] = new Formulaire('backups_delete');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    }
    
    public function recaptchaAction(){
        
        
        $this->form = new Formulaire('configuration_recaptcha');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    }
    
    public function paramsAction(){
        
        $this->form = new Formulaire('configuration_params');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    }
    
    public function langueAction(){
        
        $this->form = new Formulaire('configuration_langue');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    }
    
    public function cacheAction(){
        
        $this->form = new Formulaire('configuration_cache');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    }
    
    public function mediaAction(){
        
        $this->form['configuration_media_logo'] = new Formulaire('configuration_media_logo');
        $this->form['configuration_media_icone'] = new Formulaire('configuration_media_icone');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    }
    
    public function modulesAction(){
        
        $this->form = new Formulaire('configuration_modules');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    }
    
    public function adresseAction(){
        
        $this->form = new Formulaire('configuration_adresse');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    }
    
    public function networkAction(){
        
        $this->form = new Formulaire('configuration_network');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    }
    
    public function analyticsAction(){
        
        $this->form = new Formulaire('configuration_analytics');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    }
    
    public function sitemapAction(){
        
        $this->form = new Formulaire('configuration_sitemap');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    }
    
    
    public function pwdAction(){
        
        $this->form = new Formulaire('configuration_password');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    }
    
    public function updaterAction(){
        
        $this->form = new Formulaire('configuration_updater');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    }
    
    public function indexAction()
    {
        
        $this->form = new Formulaire('configuration_index');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
        
    }
    public function sitewebAction()
    {
        
        $this->form = new Formulaire('configuration_siteweb');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
        
    }
    
}