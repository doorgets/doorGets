<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 04 December, 2013
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class ModuleCategoryController extends doorgetsController{
    
    public function __construct( $Name,$doorGetsController){
        
        // Test if $uri module is valid
        $isUri = array();
        $params = $doorGetsController->Params();
        if( array_key_exists('uri',$params['GET']) )
        {
            
            $uri = $params['GET']['uri'];
            $isUri = $doorGetsController->dbQS($uri,'_modules','uri');
            
        }
        
        $this->controllerName = $Name;
        parent::__construct($doorGetsController);
        
        $this->table = '_categories';
            
        $lgActuel = $doorGetsController->getLangueTradution();
        $redirectUrl = './?controller='.$this->controllerName.'&uri='.$this->uri.'&lg='.$lgActuel;
        $redirectUrlModule = './?controller=modules&lg='.$lgActuel;
        
        // If isn't valid uri do rediction to modules controller
        if(!array_key_exists('uri',$params['GET']) || empty($params['GET']['uri']) || empty($this->uri) ){
            
            FlashInfo::set($this->l("Le module n'existe pas."),"error");
            header('Location:'.$redirectUrlModule);
            exit();
            
        }
        
        // get Content for edit / delete
        if(array_key_exists('id',$params['GET'])){
            
            $id = $params['GET']['id'];
            $isContent = $doorGetsController->dbQS($id,$this->table);
            if(!is_numeric($id)){ $id = '-!-'; }
            if(empty($isContent)){
                
                FlashInfo::set($this->l("Le contenu '$id' n'existe pas."),"error");
                header('Location:'.$redirectUrl);
                exit();
                
            }
            
        }
        
        
    }
    
    public function indexAction(){
        
        $this->form['_position_down'] = new Formulaire('_position_down');
        $this->form['_position_up'] = new Formulaire('_position_up');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    
    public function addAction(){
        
        $this->form = new Formulaire('modulecategory_add');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function editAction(){
        
        $this->form = new Formulaire('modulecategory_edit');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function deleteAction(){
        
        $this->form = new Formulaire('modulecategory_delete');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    
}