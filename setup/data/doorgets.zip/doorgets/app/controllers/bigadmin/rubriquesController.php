<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 20, February 2014
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class RubriquesController extends doorgetsController{
    
    public function __construct( $Name,$doorGetsController){
        
        $this->controllerName = $Name;
        parent::__construct($doorGetsController);
        
    }
    
    public function indexAction(){
        
        $this->form['_position_down'] = new Formulaire('_position_down');
        $this->form['_position_up'] = new Formulaire('_position_up');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function addAction(){
        
        $this->form = new Formulaire('rubriques_add');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function editAction(){
        
        $this->form = new Formulaire('rubriques_edit');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    
    public function deleteAction(){
        
        $this->form = new Formulaire('rubriques_delete');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
}