<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 5.2 - 05, January 2014
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class ThemeModel extends doorgetsModel{
    
    
    public function __construct($action,$controller,$lg="fr"){
        
        parent::__construct($action,$controller,$lg);
        
    }
    
    public function doAction(){
        
        
        $isAllTheme = $this->getAllThemesName();
        $nameTheme  = $this->configWeb['theme'];
        
        $controllerName = 'theme';
        
        
        
        // get Content for edit / delete
        $params = $this->Controller->Params();
        if(
           ( $this->Action === 'edit' || $this->Action === 'delete'  )
           && !array_key_exists('name',$params['GET'])
        ){
            
            header('Location:./?controller='.$controllerName); exit();
            
        }
        $fileSelectedTo = '';
        if(array_key_exists('name',$params['GET'])){
            
            $name = $params['GET']['name'];
            if(!in_array($name,$isAllTheme)){
                header('Location:./?controller='.$controllerName); exit();
            }
            $themeListe = $this->listThemeFiles($name);
            
            $fileContent = '';
            $urlFile = '';
            $fileSelected = 'doorgets.css';
            
            if(array_key_exists('file',$params['GET'])){
                
                $fileSelectedTo = $params['GET']['file'];
                
            }
            if( in_array($fileSelectedTo,$themeListe['js']) ){
                
                $urlFile = array_search($fileSelectedTo,$themeListe['js']);
                $fileContent = file_get_contents(THEME.$urlFile);
            }
            
            if( in_array($fileSelectedTo,$themeListe['css']) ){
                
                $urlFile = array_search($fileSelectedTo,$themeListe['css']);
                $fileContent = file_get_contents(THEME.$urlFile);
            }
            
            if( in_array($fileSelectedTo,$themeListe['tpl']) ){
                
                $urlFile = array_search($fileSelectedTo,$themeListe['tpl']);
                $fileContent = file_get_contents(THEME.$urlFile);
            }
        }
        
        if(
           $this->Action === 'edit' && empty($urlFile)
        ){
            
            header('Location:?controller=theme&action=edit&name='.$name.'&file=doorgets.css'); exit();
            
        }
        
        
        switch($this->Action){
            
            case 'index':
                
                if(!empty($this->Controller->form->i)){
                    
                    $this->Controller->checkMode();
                    if(empty($this->Controller->form->e)){
                        
                        $dDefault['theme']       = $this->Controller->form->i['theme'];
                        
                        $this->dbQU(1,$dDefault,'_website');
                        $this->clearDBCache();
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header("Location:".$_SERVER['REQUEST_URI']);
                        exit();
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }
                
                break;
            
            case 'add':
                
                $form = $this->Controller->form;
                if(!empty($form->i)){
                    
                    $this->Controller->checkMode();
                    
                    // gestion de l'uri
                    $lenUri = strlen($form->i['titre']);
                    $isUriValide = ctype_alnum($form->i['titre']);
                    
                    if( empty($isUriValide) || $lenUri > 250 ){
                        
                        $this->Controller->form->e['add_theme_titre'] = 'ok';
                        
                    }
                    if( in_array($form->i['titre'],$isAllTheme) ){
                        
                        $this->Controller->form->e['add_theme_titre'] = 'ok';
                        
                    }
                    
                    if( in_array($form->i['theme'],$isAllTheme) && empty($this->Controller->form->e)){
                        
                        $form->i['titre'] = strtolower($form->i['titre']);
                        
                        // add to default theme
                        if(array_key_exists('defaut',$form->i)){
                            
                            $data['theme'] = $form->i['titre'];
                            $this->dbQU(1,$data,'_website');
                            $this->clearDBCache();
                            
                        }
                        
                        // Duplicate theme
                        $this->duplicateTheme($form->i['theme'],$form->i['titre']);
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header('Location:./?controller=theme&action=edit&name='.$form->i['titre']);
                        exit();
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }
                
                
                break;
            
            case 'edit':
                
                $form = $this->Controller->form;
                if(!empty($form->i)){
                    
                    $this->Controller->checkMode();
                    
                    
                    
                    
                    $urlFile = THEME.$urlFile;
                    $fileContent = $form->i['content_nofi'];
                    
                    @file_put_contents($urlFile,$fileContent);
                    
                    FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                    header("Location:".$_SERVER['REQUEST_URI']);
                    exit();
                }
                break;
            
            case 'delete':
                
                $form = $this->Controller->form;
                if(!empty($form->i)){
                    
                    $this->Controller->checkMode();
                    
                    $this->deleteTheme($form->i['theme']);
                    FlashInfo::set($this->l("Un thème a été supprimé."));
                    header('Location:./?controller=theme');
                    
                    
                }
                break;
        }
    }
    
}