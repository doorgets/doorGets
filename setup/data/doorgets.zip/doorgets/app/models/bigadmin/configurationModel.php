<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 17 December, 2013
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class ConfigurationModel extends doorgetsModel{
    
    
    public function __construct($action,$controller,$lg="fr"){
        
        parent::__construct($action,$controller,$lg);
        
    }
    
    public function doAction(){
        
        $out = '';
        $lgTraduction = $this->getLangueTradution();
        
        switch($this->Action){
            
            case 'index':
                
                if( !empty($this->Controller->form->i)  ){
                    
                    $this->Controller->checkMode();
                    
                    // vérification champ vide
                    foreach($this->Controller->form->i as $k=>$v){
                        if(
                            empty($v)
                            && $k !== 'statut'
                            && $k !== 'statut_ip'
                            && $k !== 'statut_tinymce'
                            && $k !== 'id_facebook'
                            && $k !== 'id_disqus'
                        ){
                            
                            $this->Controller->form->e['configuration_siteweb_'.$k] = 'ok';
                            
                        }
                    }
                    
                    if(empty($this->Controller->form->e)){
                        
                        $dDefault['statut']      = $this->Controller->form->i['statut'];
                        $dDefault['statut_ip']   = $this->Controller->form->i['statut_ip'];
                        $dDefault['id_facebook'] = $this->Controller->form->i['id_facebook'];
                        $dDefault['id_disqus']   = $this->Controller->form->i['id_disqus'];
                        
                        unset($this->Controller->form->i['statut']);
                        unset($this->Controller->form->i['statut_ip']);
                        unset($this->Controller->form->i['id_facebook']);
                        unset($this->Controller->form->i['id_disqus']);
                        
                        $this->dbQU(1,$dDefault,'_website');
                        $this->dbQU($lgTraduction,$this->Controller->form->i,'_website_traduction','langue');
                        $this->clearDBCache();
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header("Location:".$_SERVER['REQUEST_URI']);
                        exit();
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }
                
                
                break;
            
            case 'theme':
                
                $nameTheme  = $this->configWeb['theme'];
                $incCSS     = BASE.'themes/'.$nameTheme.'/css/doorgets.css';
                
                
                
                if( !empty($this->Controller->form->i)  ){
                    
                    $this->Controller->checkMode();
                    
                    $nbFields = (count($this->Controller->form->i) - 2) / 2;
                    $outFile = '';
                    for($i=0;$i<$nbFields;$i++){
                        if(
                            array_key_exists('css_key_'.$i,$this->Controller->form->i)
                            && array_key_exists('css_value_'.$i,$this->Controller->form->i)
                        ){
                            $key = trim($this->Controller->form->i['css_key_'.$i]);
                            $value = trim($this->Controller->form->i['css_value_'.$i]);
                            if(!empty($key)){
                                $outFile .= $key.'{'.$value.'}'."\n";
                            }
                        }
                    }
                    
                    $cssContent = $outFile.trim($this->Controller->form->i['css_other']);
                    
                    if(empty($this->Controller->form->e)){
                        
                        $dDefault['theme']       = $this->Controller->form->i['theme'];
                        
                        // Write css and js files
                        if($nameTheme === $dDefault['theme']){
                            
                            @file_put_contents($incCSS,$cssContent);
                            
                        }
                        
                        $this->dbQU(1,$dDefault,'_website');
                        $this->clearDBCache();
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header("Location:".$_SERVER['REQUEST_URI']);
                        exit();
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }
                break;
            
            case 'langue':
                
                if( !empty($this->Controller->form->i) )
                {
                    $this->Controller->checkMode();
                    
                    $arrLangueUp = array();
                    
                    foreach($this->getAllLanguages() as $k=>$v){
                        if(array_key_exists('lg_groupe_'.$k,$this->Controller->form->i)){
                            $arrLangueUp[$k] = $v;
                        }
                    }
                    
                    $groupeLangue = serialize($arrLangueUp);
                    
                    $data['horaire'] = $this->Controller->form->i['horaire'];
                    $data['langue'] = $this->Controller->form->i['lg'];
                    $data['langue_front'] = $this->Controller->form->i['lg_front'];
                    $data['langue_groupe'] = $groupeLangue;
                    
                    if(empty($this->Controller->form->e)){
                        
                        $this->clearDBCache();
                        $this->dbQU(1,$data,'_website');
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header("Location:".$_SERVER['REQUEST_URI']);
                        exit();
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }
                
                break;
            
            case 'media':
                
                
                
                // Update logo image, png image only.
    
                if(isset($_FILES['configuration_media_logo_img_logo'])){
                    
                    $this->Controller->checkMode();
                    
                    if(
                        $_FILES['configuration_media_logo_img_logo']['type'] === 'image/png'
                    ){
                        list($fichier_larg, $fichier_haut, $fichier_type)= getimagesize($_FILES['configuration_media_logo_img_logo']['tmp_name']);
                        $newFileName = BASE_IMG.'logo.png';
                        @copy($_FILES['configuration_media_logo_img_logo']['tmp_name'],$newFileName);
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header("Location:".$_SERVER['REQUEST_URI']);
                        exit();
                    }
                
                }
                
                // Update icone image, *.ico image only.
                
                if(isset($_FILES['configuration_media_logo_icone_logo'])){
                    
                    $this->Controller->checkMode();
                    
                    if(
                        $_FILES['configuration_media_logo_icone_logo']['type'] === 'image/x-icon'
                    ){
                        
                        list($fichier_larg, $fichier_haut, $fichier_type)= getimagesize($_FILES['configuration_media_logo_icone_logo']['tmp_name']);
                        $newFileName = BASE.'favicon.ico';
                        @copy($_FILES['configuration_media_logo_icone_logo']['tmp_name'],$newFileName);
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header("Location:".$_SERVER['REQUEST_URI']);
                        exit();
                        
                    }
                
                }
                
                break;
            
            case 'params':
                
                if(
                    !empty($this->Controller->form->i) && empty($this->Controller->form->e)
                ){
                    
                    $iForm =$this->Controller->form->i;
                    
                    if(USR_PWD != $iForm['password']){
                        
                        FlashInfo::set($this->l("Le mot de passe est incorrect"),"error");
                        $this->Controller->form->e['configuration_params_password'] = 'ok';
                        
                    }
                    
                    if(!filter_var($iForm['url'], FILTER_VALIDATE_URL)){
                        FlashInfo::set($this->l("L'url n'est pas valide"),"error");
                        $this->Controller->form->e['configuration_params_url'] = 'ok';
                    }
                    
                    if(empty($this->Controller->form->e)){
                        
                        $val_url = $iForm['url'];
                        
                        $val_cache = 'false';
                        $val_demo = 'false';
                        
                        if($iForm['cache'] == 1){ $val_cache = 'true'; }
                        if($iForm['demo'] == 1){ $val_demo = 'true'; }
                        
                        $iOut = '';
                        $iOut .= "<?php"."\n\n";
                        
                        $iOut .= "define('ACTIVE_CACHE',".$val_cache.");"."\n";
                        $iOut .= "define('ACTIVE_DEMO',".$val_demo.");"."\n";
                        $iOut .= "define('KEY_SECRET','".KEY_SECRET."');"."\n\n";
                        $iOut .= "define('KEY_DOORGETS','".KEY_DOORGETS."');"."\n\n";
                        
                        $iOut .= "define('APP',BASE.'doorgets/app/');"."\n";
                        $iOut .= "define('CORE',BASE.'doorgets/core/');"."\n";
                        $iOut .= "define('LIB',BASE.'doorgets/lib/');"."\n";
                        $iOut .= "define('CONFIG',BASE.'doorgets/config/');"."\n";
                        $iOut .= "define('TEMPLATE',BASE.'doorgets/template/');"."\n";
                        $iOut .= "define('ROUTER',BASE.'doorgets/routers/');"."\n";
                        $iOut .= "define('CONFIGURATION',BASE.'config/');"."\n";
                        
                        $iOut .= "define('THEME',BASE.'themes/');"."\n";
                        
                        $iOut .= "define('RECAPTCHA_PRIVATE_KEY','".RECAPTCHA_PRIVATE_KEY."');"."\n";
                        $iOut .= "define('RECAPTCHA_PUBLIC_KEY','".RECAPTCHA_PUBLIC_KEY."');"."\n\n";
                        
                        $iOut .= "define('LANGUE',BASE.'doorgets/locale/');"."\n";
                        $iOut .= "define('LANGUE_DEFAULT_FILE',BASE.'doorgets/locale/temp.lg.php');"."\n";
                        
                        $iOut .= "define('CONTROLLERS',BASE.'doorgets/app/controllers/');"."\n";
                        $iOut .= "define('MODELS',BASE.'doorgets/app/models/');"."\n";
                        $iOut .= "define('VIEW',BASE.'doorgets/app/views/');"."\n";
                        
                        $iOut .= "define('MODULES',BASE.'doorgets/app/modules/');"."\n";
                        
                        $iOut .= "define('BASE_DATA',BASE.'data/');"."\n";
                        
                        $iOut .= "define('BASE_IMG',BASE.'skin/img/');"."\n";
                        $iOut .= "define('BASE_CSS',BASE.'skin/css/');"."\n";
                        $iOut .= "define('BASE_JS',BASE.'skin/js/');"."\n";
                        
                        $iOut .= "define('CACHE_DB',BASE.'cache/database/');"."\n";
                        $iOut .= "define('CACHE_TEMPLATE',BASE.'cache/template/');"."\n";
                        
                        $iOut .= "define('CACHE_THEME',BASE.'cache/themes/');"."\n";
                        
                        $iOut .= "define('URL','".$val_url."');"."\n";
                        $iOut .= "define('SQL_HOST','".SQL_HOST."');"."\n";
                        $iOut .= "define('SQL_LOGIN','".SQL_LOGIN."');"."\n";
                        $iOut .= "define('SQL_PWD','".SQL_PWD."');"."\n";
                        $iOut .= "define('SQL_DB','".SQL_DB."');"."\n";
                        $iOut .= "define('SQL_PREFIX','".USR_NAME."');"."\n";
                        $iOut .= "define('USR_NAME','".USR_NAME."');"."\n";
                        $iOut .= "define('USR_LOGIN','".USR_LOGIN."');"."\n";
                        $iOut .= "define('USR_PWD','".USR_PWD."');"."\n\n";
                        
                        $iOut .= "require_once CORE.'doorgets.php';";
                        
                        $confFile = CONFIGURATION.'config.php';
                        if(is_file($confFile)){
                            file_put_contents($confFile,$iOut);
                        }
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        $this->clearDBCache();
                        
                        header("Location:".$_SERVER['REQUEST_URI']);
                        exit();
                    }
                    
                }
                break;
            
            case 'modules':
                
                if(
                    !empty($this->Controller->form->i) && empty($this->Controller->form->e)
                ){
                    
                    $this->Controller->checkMode();
                    
                    $iForm =$this->Controller->form->i;
                    
                    $data['m_sitemap'] 		= 0;
                    $data['m_comment'] 		= 0;
                    $data['m_comment_facebook'] = 0;
                    $data['m_comment_disqus'] 	= 0;
                    $data['m_sharethis'] 	= 0;
                    $data['m_newsletter'] 	= 0;
                    $data['m_rss'] 		= 0;
                    
                    if( array_key_exists('sitemap',$iForm) ){ $data['m_sitemap'] = 1; }
                    if( array_key_exists('newsletter',$iForm) ){ $data['m_newsletter'] = 1; }
                    if( array_key_exists('rss',$iForm) ){ $data['m_rss'] = 1; }
                    if( array_key_exists('comment',$iForm) ){ $data['m_comment'] = 1; }
                    if( array_key_exists('comment_facebook',$iForm) ){ $data['m_comment_facebook'] = 1; }
                    if( array_key_exists('comment_disqus',$iForm) ){ $data['m_comment_disqus'] = 1; }
                    if( array_key_exists('sharethis',$iForm) ){ $data['m_sharethis'] = 1; }
                    
                    FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                    $this->dbQU(1,$data,'_website');
                    
                    $this->clearDBCache();
                    header("Location:".$_SERVER['REQUEST_URI']);
                    exit();
                    
                }
                
                break;
            
            case 'adresse':
                
                if(
                    !empty($this->Controller->form->i)
                ){
                    
                    $this->Controller->checkMode();
                    
                    foreach($this->Controller->form->i as $k=>$v){
                        $this->Controller->form->i[$k] = filter_input(INPUT_POST,'configuration_adresse_'.$k,FILTER_SANITIZE_STRING);
                    }
                    
                    $var = $this->Controller->form->i['email'];
                    $isEmail = filter_var($var, FILTER_VALIDATE_EMAIL);
                    if(empty($isEmail)){ $this->Controller->form->e['configuration_adresse_email'] = 'ok'; }
                    
                    if(empty($this->Controller->form->e)){
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        $this->dbQU(1,$this->Controller->form->i,'_website','id');
                        $this->clearDBCache();
                        header("Location:".$_SERVER['REQUEST_URI']);
                        exit();
                        
                    }
                    
                    FlashInfo::set($this->l("Veuillez saisir correctement votre adresse e-mail."),"error");
                }
                
                break;
            
            case 'network':
                
                if(
                    !empty($this->Controller->form->i) 
                ){
                    
                    $this->Controller->checkMode();
                    
                    foreach($this->Controller->form->i as $k=>$v){
                        $this->Controller->form->i[$k] = filter_input(INPUT_POST,'configuration_network_'.$k,FILTER_SANITIZE_STRING);
                    }
                    
                    FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                    $this->dbQU(1,$this->Controller->form->i,'_website','id');
                    $this->clearDBCache();
                    
                    header("Location:".$_SERVER['REQUEST_URI']);
                    exit();
                }
                
                break;
            
            case 'cache':
                
                if(
                    !empty($this->Controller->form->i) 
                ){
                    
                    $this->Controller->checkMode();
                    
                    FlashInfo::set($this->l("Les caches sont vides."));
                    $this->clearAllCache();
                    
                    header("Location:".$_SERVER['REQUEST_URI']);
                    exit();
                }
                
                break;
            
            case 'analytics':
                
                if(
                    !empty($this->Controller->form->i) 
                ){
                    
                    $this->Controller->checkMode();
                    
                    foreach($this->Controller->form->i as $k=>$v){
                        
                        $this->Controller->form->i[$k] = filter_input(INPUT_POST,'configuration_analytics_'.$k,FILTER_SANITIZE_STRING);
                        
                    }
                    
                    FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                    $this->dbQU(1,$this->Controller->form->i,'_website','id');
                    $this->clearDBCache();
                    header("Location:".$_SERVER['REQUEST_URI']);
                    exit();
                 
                }
                
                break;
            
            case 'sitemap':
                
                $fileSitemap    = BASE.'sitemap.xml';
                $urlSitemap     = URL.'sitemap.xml';
                
                if(
                   !empty($this->Controller->form->i) && empty($this->Controller->form->e)
                ){
                    
                    $this->Controller->checkMode();
                    
                    new GenSitemapXml();
                    FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                    $this->clearDBCache();
                    header("Location:".$_SERVER['REQUEST_URI']);
                    exit();
                    
                }
                
                break;
            
            case 'pwd':
                
                if(
                    !empty($this->Controller->form->i)
                ){
                    
                    $this->Controller->checkMode();
                    
                    foreach($this->Controller->form->i as $k=>$v){
                        
                        if(empty($v)){
                            
                            $this->Controller->form->e['configuration_password_'.$k] = 'ok';
                            
                        }
                        
                    }
                    
                    if( $this->Controller->form->i['passwd_now'] !== USR_PWD ){
                        
                        $this->Controller->form->e['configuration_password_passwd_now'] = 'ok';
                        
                    }
                    if( (strlen($this->Controller->form->i['passwd_new']) < 8) || $this->Controller->form->i['passwd_new'] !== $this->Controller->form->i['passwd_new_bis'] ){
                        
                        $this->Controller->form->e['configuration_password_passwd_new'] = 'ok';
                        $this->Controller->form->e['configuration_password_passwd_new_bis'] = 'ok';
                        
                    }
                    
                    if(empty($this->Controller->form->e)){
                        
                        $val_cache = 'false';
                        $val_demo = 'false';
                        
                        if(ACTIVE_CACHE){ $val_cache = 'true'; }
                        if(ACTIVE_DEMO){ $val_demo = 'true'; }
                        
                        $iOut = '';
                        $iOut .= "<?php"."\n\n";
                        
                        $iOut .= "define('ACTIVE_CACHE',".$val_cache.");"."\n";
                        $iOut .= "define('ACTIVE_DEMO',".$val_demo.");"."\n";
                        $iOut .= "define('KEY_SECRET','".KEY_SECRET."');"."\n\n";
                        $iOut .= "define('KEY_DOORGETS','".KEY_DOORGETS."');"."\n\n";
                        
                        $iOut .= "define('APP',BASE.'doorgets/app/');"."\n";
                        $iOut .= "define('CORE',BASE.'doorgets/core/');"."\n";
                        $iOut .= "define('LIB',BASE.'doorgets/lib/');"."\n";
                        $iOut .= "define('CONFIG',BASE.'doorgets/config/');"."\n";
                        $iOut .= "define('TEMPLATE',BASE.'doorgets/template/');"."\n";
                        $iOut .= "define('ROUTER',BASE.'doorgets/routers/');"."\n";
                        $iOut .= "define('CONFIGURATION',BASE.'config/');"."\n";
                        
                        $iOut .= "define('THEME',BASE.'themes/');"."\n";
                        
                        $iOut .= "define('RECAPTCHA_PRIVATE_KEY','".RECAPTCHA_PRIVATE_KEY."');"."\n";
                        $iOut .= "define('RECAPTCHA_PUBLIC_KEY','".RECAPTCHA_PUBLIC_KEY."');"."\n\n";
                        
                        $iOut .= "define('LANGUE',BASE.'doorgets/locale/');"."\n";
                        $iOut .= "define('LANGUE_DEFAULT_FILE',BASE.'doorgets/locale/temp.lg.php');"."\n";
                        
                        $iOut .= "define('CONTROLLERS',BASE.'doorgets/app/controllers/');"."\n";
                        $iOut .= "define('MODELS',BASE.'doorgets/app/models/');"."\n";
                        $iOut .= "define('VIEW',BASE.'doorgets/app/views/');"."\n";
                        
                        $iOut .= "define('MODULES',BASE.'doorgets/app/modules/');"."\n";
                        
                        $iOut .= "define('BASE_DATA',BASE.'data/');"."\n";
                        
                        $iOut .= "define('BASE_IMG',BASE.'skin/img/');"."\n";
                        $iOut .= "define('BASE_CSS',BASE.'skin/css/');"."\n";
                        $iOut .= "define('BASE_JS',BASE.'skin/js/');"."\n";
                        
                        $iOut .= "define('CACHE_DB',BASE.'cache/database/');"."\n";
                        $iOut .= "define('CACHE_TEMPLATE',BASE.'cache/template/');"."\n";
                        
                        $iOut .= "define('CACHE_THEME',BASE.'cache/themes/');"."\n";
                        
                        $iOut .= "define('URL','".URL."');"."\n";
                        $iOut .= "define('SQL_HOST','".SQL_HOST."');"."\n";
                        $iOut .= "define('SQL_LOGIN','".SQL_LOGIN."');"."\n";
                        $iOut .= "define('SQL_PWD','".SQL_PWD."');"."\n";
                        $iOut .= "define('SQL_DB','".SQL_DB."');"."\n";
                        $iOut .= "define('SQL_PREFIX','".USR_NAME."');"."\n";
                        $iOut .= "define('USR_NAME','".USR_NAME."');"."\n";
                        $iOut .= "define('USR_LOGIN','".USR_LOGIN."');"."\n";
                        $iOut .= "define('USR_PWD','".$this->Controller->form->i['passwd_new']."');"."\n\n";
                        
                        $iOut .= "require_once CORE.'doorgets.php';";
                        
                        $confFile = CONFIGURATION.'config.php';
                        if(is_file($confFile)){
                            file_put_contents($confFile,$iOut);
                        }
                        
                        FlashInfo::set($this->l("Votre mot de passe à bien été modifié."));
                        $this->clearDBCache();
                        
                        header("Location:".$_SERVER['REQUEST_URI']);
                        exit();
                        
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }
                
                break;
            
            case 'recaptcha':
                
                if(
                    !empty($this->Controller->form->i)
                ){
                    
                    $this->Controller->checkMode();
                    
                    $private_key = $this->Controller->form->i['private_key'];
                    $public_key  = $this->Controller->form->i['public_key'];
                    
                    if(empty($this->Controller->form->e)){
                        
                        $val_cache = 'false';
                        $val_demo = 'false';
                        
                        if(ACTIVE_CACHE){ $val_cache = 'true'; }
                        if(ACTIVE_DEMO){ $val_demo = 'true'; }
                        
                        $iOut = '';
                        $iOut .= "<?php"."\n\n";
                        
                        $iOut .= "define('ACTIVE_CACHE',".$val_cache.");"."\n";
                        $iOut .= "define('ACTIVE_DEMO',".$val_demo.");"."\n";
                        $iOut .= "define('KEY_SECRET','".KEY_SECRET."');"."\n\n";
                        $iOut .= "define('KEY_DOORGETS','".KEY_DOORGETS."');"."\n\n";
                        
                        $iOut .= "define('APP',BASE.'doorgets/app/');"."\n";
                        $iOut .= "define('CORE',BASE.'doorgets/core/');"."\n";
                        $iOut .= "define('LIB',BASE.'doorgets/lib/');"."\n";
                        $iOut .= "define('CONFIG',BASE.'doorgets/config/');"."\n";
                        $iOut .= "define('TEMPLATE',BASE.'doorgets/template/');"."\n";
                        $iOut .= "define('ROUTER',BASE.'doorgets/routers/');"."\n";
                        $iOut .= "define('CONFIGURATION',BASE.'config/');"."\n";
                        
                        $iOut .= "define('THEME',BASE.'themes/');"."\n";
                        
                        $iOut .= "define('RECAPTCHA_PRIVATE_KEY','".$private_key."');"."\n";
                        $iOut .= "define('RECAPTCHA_PUBLIC_KEY','".$public_key."');"."\n\n";
                        
                        $iOut .= "define('LANGUE',BASE.'doorgets/locale/');"."\n";
                        $iOut .= "define('LANGUE_DEFAULT_FILE',BASE.'doorgets/locale/temp.lg.php');"."\n";
                        
                        $iOut .= "define('CONTROLLERS',BASE.'doorgets/app/controllers/');"."\n";
                        $iOut .= "define('MODELS',BASE.'doorgets/app/models/');"."\n";
                        $iOut .= "define('VIEW',BASE.'doorgets/app/views/');"."\n";
                        
                        $iOut .= "define('MODULES',BASE.'doorgets/app/modules/');"."\n";
                        
                        $iOut .= "define('BASE_DATA',BASE.'data/');"."\n";
                        
                        $iOut .= "define('BASE_IMG',BASE.'skin/img/');"."\n";
                        $iOut .= "define('BASE_CSS',BASE.'skin/css/');"."\n";
                        $iOut .= "define('BASE_JS',BASE.'skin/js/');"."\n";
                        
                        $iOut .= "define('CACHE_DB',BASE.'cache/database/');"."\n";
                        $iOut .= "define('CACHE_TEMPLATE',BASE.'cache/template/');"."\n";
                        
                        $iOut .= "define('CACHE_THEME',BASE.'cache/themes/');"."\n";
                        
                        $iOut .= "define('URL','".URL."');"."\n";
                        $iOut .= "define('SQL_HOST','".SQL_HOST."');"."\n";
                        $iOut .= "define('SQL_LOGIN','".SQL_LOGIN."');"."\n";
                        $iOut .= "define('SQL_PWD','".SQL_PWD."');"."\n";
                        $iOut .= "define('SQL_DB','".SQL_DB."');"."\n";
                        $iOut .= "define('SQL_PREFIX','".USR_NAME."');"."\n";
                        $iOut .= "define('USR_NAME','".USR_NAME."');"."\n";
                        $iOut .= "define('USR_LOGIN','".USR_LOGIN."');"."\n";
                        $iOut .= "define('USR_PWD','".USR_PWD."');"."\n\n";
                        
                        $iOut .= "require_once CORE.'doorgets.php';";
                        
                        $confFile = CONFIGURATION.'config.php';
                        if(is_file($confFile)){
                            file_put_contents($confFile,$iOut);
                        }
                        
                        FlashInfo::set($this->l("Vos clés reCaptcha publique et privée sont modifiées."));
                        $this->clearDBCache();
                        
                        header("Location:".$_SERVER['REQUEST_URI']);
                        exit();
                        
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }
                
                break;
            
            case 'backups':
                
                $params = $this->Controller->Params();
                $form   = $this->Controller->form;
                
                if(array_key_exists('do',$params['GET'])){
                    
                    $file = '';
                    $actionBackups = $params['GET']['do'];
                    if(array_key_exists('file',$params['GET']))
                    {
                        $file = $params['GET']['file'];
                    }
                    
                    switch($actionBackups){
                        
                        case 'create':
                            
                            if( !empty($form['backups_create']->i) && empty($form['backups_create']->e) ){
                                
                                $this->Controller->checkMode();
                                
                                $backupExportToZip = new doorgetsBackupsIO($this->myLanguage);
                                $backupExportToZip->genExport();
                                FlashInfo::set($this->l("Une nouvelle sauvegarde est disponible."));
                                header("Location:./?controller=configuration&action=backups"); exit();
                                
                            }
                            
                            break;
                        
                        case 'install':
                            
                            if(!empty($file)){
                                
                                if( !empty($form['backups_install']->i) && empty($form['backups_install']->e) ){
                                    
                                    $this->Controller->checkMode();
                                    
                                    $backupExportToZip = new doorgetsBackupsIO($this->myLanguage);
                                    $backupExportToZip->genExport();
                                    $backupExportToZip->doImport($file);
                                    
                                }		
                            }
        
                            break;
                        
                        case 'delete':
                            
                            if(!empty($file)){
                                
                                if( !empty($form['backups_delete']->i) && empty($form['backups_delete']->e) ){
                                    
                                    $this->Controller->checkMode();
                                    
                                    $fileToDelete = BASE.'io/'.$file;
                                    
                                    if(is_file($fileToDelete)){  unlink($fileToDelete); }
                                    FlashInfo::set($this->l("La sauvegarde a bien été supprimée."));
                                    header("Location:./?controller=configuration&action=backups"); exit();
                                    
                                }
                            }
                            break;
                    }
                    
                }
                
            case 'updater':
                
                $checkNow = $this->Controller->thisController->_ckeckVersion();
                extract($checkNow);
                
                if($isForDownload){
                    
                    if(
                       !empty($this->Controller->form->i) && empty($this->Controller->form->e)
                    ){
                        $this->Controller->checkMode();
                        
                        $version = $this->Controller->form->i['version'];
                        
                        try{
                            if(function_exists('curl_version')){
                                $ch = curl_init();
                                $source = "http://www.doorgets.com/checkversion/update/doorgets_update_".$version.".zip";
                                curl_setopt($ch, CURLOPT_URL, $source);
                                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                                $data = curl_exec ($ch);
                                curl_close ($ch);
                                
                                $destination = BASE."update/doorgets_update_".$version.".zip";
                                $file = fopen($destination, "w+");
                                fputs($file, $data);
                                fclose($file);
                            }
                            
                        }catch(Exception $e){ }
                        
                        FlashInfo::set($this->l("Le téléchargement est terminé."));
                        
                        $this->clearDBCache();
                        header("Location:".$_SERVER['REQUEST_URI']);
                        exit();
                        
                    }
                    
                }else{
                    
                    if(
                       !empty($this->Controller->form->i) && empty($this->Controller->form->e)
                    ){
                        
                        $this->Controller->checkMode();
                        
                        $zipDoorgets = new ZipArchive;
                        $res = $zipDoorgets->open($destination);
                        if ($res === TRUE) { $zipDoorgets->extractTo(BASE); }
                        $zipDoorgets->close();
                        
                        @unlink($destination);
                        
                        $data['version_doorgets']   = "$dgVersion";
                        $data['statut_version']     = 0;
                        
                        $this->dbQU(1,$data,'_website');
                        
                        FlashInfo::set($this->l("L'installation de la sauvegarde est terminé."));
                        $this->clearDBCache();
                        header("Location:".$_SERVER['REQUEST_URI']);
                        exit();
                        
                    }
                    
                }
                
                break;
            
        }
        
        return $out;
        
    }
    
    public function clearAllCache() {
        
        $dir = CACHE_DB;
        if(is_dir($dir)){
            $this->destroy_dir($dir);
        }
        
        $dir = BASE.'cache/template';
        if(is_dir($dir)){
            $this->destroy_dir($dir);
        }
        
        $dir = BASE.'cache/themes';
        if(is_dir($dir)){
            $this->destroy_dir($dir);
        }
        
    }
    
    private function destroy_dir($dir) {
        
        if (!file_exists($dir)) return true; 
        if (!is_dir($dir) || is_link($dir)) return unlink($dir); 
        foreach (scandir($dir) as $item) { 
            if ($item == '.' || $item == '..') continue; 
            if (!$this->destroy_dir($dir . "/" . $item)) { 
                chmod($dir . "/" . $item, 0777); 
                if (!$this->destroy_dir($dir . "/" . $item)) return false; 
            }; 
        } 
        return rmdir($dir);
        
    
    } 
    
}