<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 5.2 - 13, January 2014
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class AuthentificationModel extends doorgetsModel{
    
    
    public function __construct($action,$controller,$lg = 'fr',$form = array()){
        
        parent::__construct($action,$controller,$lg);
        
    }
    
    public function doAction(){
        
        $out = '';
        
        switch($this->Action){
            
            case 'index':
                
                if(!empty($this->Controller->form->i)){
                    
                    $_SESSION = array();
                    
                    // vérification champ vide
                    foreach($this->Controller->form->i as $k=>$v){
                        if(empty($v)){
                            
                            $this->Controller->form->e['authentification_login'] = 'ok';
                            $this->Controller->form->e['authentification_password'] = 'ok';
                            
                        }
                    }
                    
                    // verification de la taille du password
                    if( strlen($this->Controller->form->i['password']) < 4 ){
                        
                        $this->Controller->form->e['authentification_login'] = 'ok';
                        $this->Controller->form->e['authentification_password'] = 'ok';
                        
                    }
                    
                    if( empty($this->Controller->form->e) ){
                        
                        if(ACTIVE_DEMO){
                            
                            $_SESSION['doorgets']['id'] = 0;
                            $_SESSION['doorgets']['groupe'] = 0;
                            $_SESSION['doorgets']['login'] = USR_LOGIN;
                            $_SESSION['doorgets']['password'] = USR_PWD;
                            
                            header('Location:'.$_SERVER['REQUEST_URI'].'');
                            // Utilisateur identifié
                            // transmision des données 
                            exit();
                            
                        }
                        
                        if( $this->Controller->form->i['login'] === USR_LOGIN && $this->Controller->form->i['password'] === USR_PWD ){
                            
                            $_SESSION['doorgets']['id'] = 0;
                            $_SESSION['doorgets']['groupe'] = 0;
                            $_SESSION['doorgets']['login'] = USR_LOGIN;
                            $_SESSION['doorgets']['password'] = USR_PWD;
                            
                            header('Location:'.$_SERVER['REQUEST_URI'].'');
                            // Utilisateur identifié
                            // transmision des données 
                            exit();
                            
                        }else{
                            
                            $this->Controller->form->e['authentification_login'] = 'ok';
                            $this->Controller->form->e['authentification_password'] = 'ok';
                            
                        }
                        
                    }
                }
                
                
                break;
            
            case 'logout':
                
                $_SESSION = array();
                header('Location:./');
                break;
            
        }
        
        return $out;
        
    }
    
}