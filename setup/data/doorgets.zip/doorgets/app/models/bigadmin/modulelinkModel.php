<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 07, February 2014
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class ModuleLinkModel extends doorgetsModuleModel{
    
    public function __construct($action,$controller,$lg="fr"){
        
        parent::__construct($action,$controller,$lg);
        $this->table = '_dg_links';
        
    }
    
    public function doAction(){
        
        $out = '';
        $this->table = '_dg_links';
        // Init langue 
        $lgActuel       = $this->getLangueTradution();
        $moduleInfos    = $this->moduleInfos($this->uri,$lgActuel);
        // Init url redirection 
        $redirectUrl = './?controller=module'.$moduleInfos['type'].'&uri='.$this->uri.'&lg='.$lgActuel;
        
        // get Content for edit 
        $params = $this->Controller->Params();
        if(array_key_exists('uri',$params['GET'])){
            
            $uri = $params['GET']['uri'];
            $isContent = $this->dbQS($uri,$this->table,'uri_module');
            
            
            
        }
        
        $champsObligatoire = array('label','link');
        
        if(!empty($this->Controller->form->i)){
            
            $this->Controller->checkMode();
            
            // gestion des champs vide
            foreach($this->Controller->form->i as $k=>$v){
                
                if( empty($v))
                {
                    $this->Controller->form->e[$this->Controller->controllerName.'_edit_'.$k] = 'ok';   
                }
            }
            
            if(empty($this->Controller->form->e)){
                
                $data = $this->Controller->form->i;
                $this->dbQU($this->uri,$data,$this->table,'uri_module',"AND langue = '".$lgActuel."' LIMIT 1 ");
                $this->clearDBCache();
                
                
                FlashInfo::set($this->l("Vos informations ont bien été mises à jour"));
                header('Location:'.$redirectUrl);
                exit();
                
            }
            
            FlashInfo::set($this->l("Veuillez remplir correctement le formulaire"),"error");
        }
        
    }
}