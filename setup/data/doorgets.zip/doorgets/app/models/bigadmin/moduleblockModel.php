<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 07, February 2014
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class ModuleBlockModel extends doorgetsModuleModel{
    
    public function __construct($action,$controller,$lg="fr"){
        
        parent::__construct($action,$controller,$lg);
        $this->table = '_dg_block';
        
    }
    
    public function doAction(){
        
        $out = '';
        $this->table = '_dg_block';
        // Init langue 
        $lgActuel       = $this->getLangueTradution();
        $moduleInfos    = $this->moduleInfos($this->uri,$lgActuel);
        // Init url redirection 
        $redirectUrl = './?controller=module'.$moduleInfos['type'].'&uri='.$this->uri.'&lg='.$lgActuel;
        
        // get Content for edit / delete
        $params = $this->Controller->Params();
        if(array_key_exists('uri',$params['GET'])){
            
            $uri = $params['GET']['uri'];
            $isContent = $this->dbQS($uri,$this->table,'uri');
            
            if(!empty($isContent)){
                
                if($lgGroupe = @unserialize($isContent['groupe_traduction'])){
                    
                    $idLgGroupe = $lgGroupe[$lgActuel];
                    
                    $isContentTraduction = $this->dbQS($idLgGroupe,$this->table.'_traduction');
                    if(!empty($isContentTraduction)){
                        unset($isContent['id']);
                        $isContent = $isContent + $isContentTraduction;
                        
                    }
                    
                }
                
            }
            
        }
        
        $champsObligatoire = array('titre','article_tinymce');
        
        if(!empty($this->Controller->form->i)){
            
            $this->Controller->checkMode();
            
            if(empty($this->Controller->form->e)){
                
                $data = $this->Controller->form->i;
                
                $data['date_modification'] = time();
                $dataContenu['date_modification'] = time();
                
                $this->dbQU($isContent['id_block'],$dataContenu,$this->table);
                $this->dbQU($isContent['id'],$data,$this->table.'_traduction',"id"," AND langue='$lgActuel' LIMIT 1 ");
                $this->clearDBCache();
                
                
                FlashInfo::set($this->l("Vos informations ont bien été mises à jour"));
                header('Location:'.$redirectUrl);
                exit();
                
            }
            
            FlashInfo::set($this->l("Veuillez remplir correctement le formulaire"),"error");
        }
        
    }
}