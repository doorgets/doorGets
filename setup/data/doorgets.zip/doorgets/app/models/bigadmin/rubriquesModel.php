<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 5.2 - 05, January 2014
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class RubriquesModel extends doorgetsModel{
    
    
    public function __construct($action,$controller,$lg="fr"){
        
        parent::__construct($action,$controller,$lg);
        
    }
    
    public function doAction(){
        
        $out = '';
        
        $params = $this->Controller->Params();
        if(array_key_exists('id',$params['GET'])){
            
            $id = $params['GET']['id'];
            $isContent = $this->dbQS($id,'_rubrique');
            if(empty($isContent)){
                header('Location:./?controller=rubriques'); exit();
            }
        }
        
        switch($this->Action){
            
            case 'add':
                
                $cResultsInt = $this->getCountTable('_rubrique');
                
                if(!empty($this->Controller->form->i)){
                    
                    $this->Controller->checkMode();
                    
                    foreach($this->Controller->form->i as $k=>$v){
                        if(empty($v)  && $k !== 'idModule'  ){
                            
                            $this->Controller->form->e['rubriques_add_'.$k] = 'ok';
                            
                        }
                    }
                    
                    if(empty($this->Controller->form->e)){
                        
                        $data['name'] = $this->Controller->form->i['name'];
                        $data['ordre'] = $cResultsInt + 1;
                        $data['idModule'] = $this->Controller->form->i['idModule'];
                        $data['showinmenu'] = $this->Controller->form->i['showinmenu'];
                        $data['date_creation'] = time();
                        
                        $idContent = $this->dbQI($data,'_rubrique');
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header('Location:./?controller=rubriques'); exit();
                        
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }
                
                break;
            
            case 'edit':
                
                if(!empty($this->Controller->form->i)){
                    
                    $this->Controller->checkMode();
                    
                    foreach($this->Controller->form->i as $k=>$v){
                        if(empty($v)  && $k !== 'idModule'  ){
                            
                            $this->Controller->form->e['rubriques_edit_'.$k] = 'ok';
                            
                        }
                    }
                    if(empty($this->Controller->form->e)){
                        
                        $data = $this->Controller->form->i;
                        
                        $this->dbQU($isContent['id'],$data,'_rubrique');
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        $this->clearDBCache();
                        header('Location:./?controller=rubriques');
                        exit();
                    }
                }
                
                break;
            
            case 'delete':
                
                if( !empty($this->Controller->form->i) && empty($this->Controller->form->e)){
                    
                    $this->Controller->checkMode();
                    
                    $this->dbQD($isContent['id'],'_rubrique','id');
                    $this->dbQL("UPDATE _rubrique SET ordre = ordre - 1 WHERE ordre > ".$isContent['ordre']." ");
                    
                    FlashInfo::set("Vos informations sont bien supprimées.");
                    header('Location:./?controller=rubriques');
                    exit();
                    
                }
                
                break;
            
        }
        
    }
    
    
    
    
    
}