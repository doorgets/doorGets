<?php

/*******************************************************************************
/*******************************************************************************
    doorgets 5.0 #!#!#
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class MediaModel extends doorgetsModel{
    
    private $sizeMax = 8192000;
    
    private $typeFile = array();
    private $typeExtension = array();
    private $typeImage = array();
    
    public function __construct($action,$controller,$lg="fr"){
        
        parent::__construct($action,$controller,$lg);
        
    }
    
    public function doAction(){
        
        $typeFile["image/png"] = "data/upload/png/";
        $typeFile["image/jpeg"] = "data/upload/jpg/";
        $typeFile["image/gif"] = "data/upload/gif/";
        
        $typeFile["application/zip"] = "data/upload/zip/";
        $typeFile["application/x-zip-compressed"] = "data/upload/xzip/";
        $typeFile["application/pdf"] = "data/upload/pdf/";
        $typeFile["application/x-shockwave-flash"] = "data/upload/swf/";
        
        $typeExtension["image/png"] = "png";
        $typeExtension["image/jpeg"] = "jpg";
        $typeExtension["image/gif"] = "gif";
        
        $typeExtension["application/zip"] = "zip";
        $typeExtension["application/x-zip-compressed"] = "zip";
        
        $typeExtension["application/pdf"] = "pdf";
        $typeExtension["application/x-shockwave-flash"] = "swf";
        
        $typeImage["image/png"] = '<img src="'.BASE_IMG.'png.png" class="ico_fichier" >';
        $typeImage["image/jpeg"] = '<img src="'.BASE_IMG.'jpg.png" class="ico_fichier" >';
        $typeImage["image/gif"] = '<img src="'.BASE_IMG.'gif.png" class="ico_fichier" >';
        $typeImage["application/zip"] = '<img src="'.BASE_IMG.'zip.png" class="ico_fichier" >';
        $typeImage["application/x-zip-compressed"] = '<img src="'.BASE_IMG.'zip.png" class="ico_fichier" >';
        $typeImage["application/pdf"] = '<img src="'.BASE_IMG.'pdf.png" class="ico_fichier" >';
        $typeImage["application/x-shockwave-flash"] = '<img src="'.BASE_IMG.'swf.png" class="ico_fichier" >';
        
        $this->typeFile = $typeFile;
        $this->typeExtension = $typeExtension;
        $this->typeImage = $typeImage;
        
        $out = '';
        $tableName = '_dg_files';
        $controllerName = 'media';
        
        // get Content for edit / delete
        $params = $this->Controller->Params();
        if(array_key_exists('id',$params['GET'])){
            
            $id = $params['GET']['id'];
            $isContent = $this->dbQS($id,$tableName);
            if(empty($isContent)){
                header('Location:./?controller='.$controllerName); exit();
            }
        }
        
        switch($this->Action){
            
            case 'add':
                
                if( !empty($this->Controller->form->i) && empty($this->Controller->form->e) ){
                    
                    $this->Controller->checkMode();
                    
                    if( empty($this->Controller->form->i['nom']) ){
                        
                        FlashInfo::set($this->l("Veuillez saisir le nom du fichier."),"error");
                        $this->Controller->form->e['media_add_nom'] = 'ok';
                        
                    }
                    if(  isset($_FILES['media_add_fichier']) &&  $_FILES['media_add_fichier']['error'] != 0  ){
                        
                        FlashInfo::set($this->l("Veuillez importer un fichier valide."),"error");
                        $this->Controller->form->e['media_add_fichier'] = 'ok';
                        
                    }
                    
                    if ( isset($_FILES['media_add_fichier']) && empty($this->Controller->form->e) ){
                        
                        if( !array_key_exists($_FILES['media_add_fichier']["type"],$this->typeFile)  ){
                            
                            FlashInfo::set($this->l("Veuillez importer un fichier valide."),"error");
                            
                            $this->Controller->form->e['media_add_fichier'] = 'ok';
                        
                        }
                        if( $_FILES['media_add_fichier']["size"] > $this->sizeMax ){
                            
                            FlashInfo::set($this->l("Votre fichier est trop lourd."),"error");
                            
                            $this->Controller->form->e['media_add_fichier'] = 'ok';
                        
                        }
                    }
                    
                    if(empty($this->Controller->form->e)){
                        
                        $ttff = $_FILES['media_add_fichier']["type"];
                        
                        $sSize = $_FILES['media_add_fichier']['size'];
                        $ttf = $this->typeExtension[$ttff];
                        $uni = time().'-'.uniqid($ttf);
                        
                        $nameFileImage = $uni.'-doorgets.'.$ttf;
                        
                        $uploaddir = $this->typeFile[$ttff];
                        $uploadfile = BASE.$uploaddir.$nameFileImage;
                        
                        if(
                            move_uploaded_file($_FILES['media_add_fichier']['tmp_name'], $uploadfile)
                        ){
                            $this->Controller->form->i['fichier'] = $nameFileImage;
                        }
                        
                        $data['id_user']        = $this->user['id'];
                        $data['id_groupe']      = $this->user['groupe'];
                        $data['type']           = $ttff;
                        $data['nom']            = $this->Controller->form->i['nom'];
                        $data['fichier']        = $nameFileImage;
                        $data['poid']           = $sSize;
                        $data['date_creation']  = time();
                        
                        $idContent = $this->dbQI($data,$tableName);
                        
                        FlashInfo::set($this->l("Le fichier a bien été télécharger."));
                        header('Location:'.$_SERVER['REQUEST_URI']); exit();
                        
                    }
                    
                }
                
                break;
            
            case 'edit':
                
                $error = false;
                
                if(!empty($this->Controller->form->i)){
                    
                    $this->Controller->checkMode();
                    
                    if( empty($this->Controller->form->i['nom']) ){
                        
                        FlashInfo::set($this->l("Veuillez saisir le nom du fichier."),"error");
                        $this->Controller->form->e['media_edit_nom'] = 'ok';
                        $error = true;
                        
                    }
                    
                    if($_FILES['media_edit_fichier']['error'] === 0){
                        
                        if ( isset($_FILES['media_edit_fichier'])    && empty($this->Controller->form->e) ){
                            
                            if( $_FILES['media_edit_fichier']["type"] !== $isContent['type']){
                                
                                FlashInfo::set($this->l("Veuillez importer un fichier du même type."),"error");
                                $this->Controller->form->e['media_edit_fichier'] = 'ok';
                                $error = true;
                            
                            }
                            if( $_FILES['media_edit_fichier']["size"] > $this->sizeMax ){
                                
                                FlashInfo::set($this->l("Votre fichier est trop lourd."),"error");
                                $this->Controller->form->e['media_edit_fichier'] = 'ok';
                                $error = true;
                            
                            }
                        }
                        
                    }

                    
                    if(empty($this->Controller->form->e)){
                        
                        $sSize = $isContent['poid'];
                        
                        if($_FILES['media_edit_fichier']['error'] === 0){
                            
                            $uploaddir = $this->typeFile[$isContent['type']];
                            $uploadfile = BASE.$uploaddir.$isContent['fichier'];
                            
                            @move_uploaded_file($_FILES['media_edit_fichier']['tmp_name'], $uploadfile);
                            $sSize = $_FILES['media_edit_fichier']['size'];
                            
                        }
                        
                        $data['nom']            = $this->Controller->form->i['nom'];
                        $data['poid']           = $sSize;
                        $data['fichier']        = $isContent['fichier'];
                        $data['date_creation']  = time();
                        
                        $this->dbQU($isContent['id'],$data,$tableName);
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header('Location:./?controller=media&action=select&id='.$isContent['id']);
                        exit();
                    }
                    
                    if(!$error){
                        FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    }
                    
                }
                
                break;
            
            case 'delete':
                
                $urlFile = $isContent['fichier'];
                $uploaddir = $this->typeFile[$isContent['type']];
                $uploadfile = BASE.$uploaddir.$urlFile;
                
                if(!empty($this->Controller->form->i)){
                    
                    $this->Controller->checkMode();
                    
                    if(empty($this->Controller->form->e)){
                        
                        $this->dbQD($isContent['id'],$tableName);
                        if(is_file($uploadfile)){
                            @unlink($uploadfile);
                        }
                        
                        FlashInfo::set("Le fichier à été corréctement supprimer.");
                        header('Location:./?controller=media');
                        exit();
                        
                    }
                }
                
                break;
            
            case 'massdelete':
                
                if(
                    
                    !empty($this->Controller->form['massdelete_index']->i)
                    && isset($this->Controller->form['massdelete_index']->i['groupe_delete_index'])
                   
                ){
                    $this->Controller->checkMode();
                    
                    if(empty($this->Controller->form['massdelete_index']->e))
                    {
                        
                        $ListeForDeleted = $this->_toArray($this->Controller->form['massdelete_index']->i['groupe_delete_index']);
                
                        foreach($ListeForDeleted as $id){
                            
                            $isCont = $this->dbQS($id,$tableName);
                            if(!empty($isCont)){
                                
                                $urlFile = $isCont['fichier'];
                                $uploaddir = $this->typeFile[$isCont['type']];
                                $uploadfile = BASE.$uploaddir.$urlFile;
                                
                                if(is_file($uploadfile)){ @unlink($uploadfile); }
                                
                            }
                            
                            $this->dbQD($id,$tableName);
                            
                        }
                        
                        FlashInfo::set("Les données sont supprimées.");
                        header('Location:./?controller='.$controllerName); exit();
                        
                    }
                    
                }
                
                break;
        }
    }
}

