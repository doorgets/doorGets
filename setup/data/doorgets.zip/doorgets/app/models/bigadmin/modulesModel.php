<?php

/*******************************************************************************
/*******************************************************************************
    doorgets 5.0 #!#!#
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class ModulesModel extends doorgetsModel{
    
    
    public function __construct($action,$controller,$lg="fr"){
        
        parent::__construct($action,$controller,$lg);
        
    }
    
    public function doAction(){
        
        $out = '';
        
        $lgActuel = $this->getLangueTradution();
        
        
        // get Content for edit / delete
        $params = $this->Controller->Params();
        if(array_key_exists('id',$params['GET'])){
            
            $id = $params['GET']['id'];
            $isContent = $this->dbQS($id,'_modules');
            if(empty($isContent)){
                header('Location:./?controller=modules'); exit();
            }
            if(!empty($isContent)){
                
                $lgGroupe = @unserialize($isContent['groupe_traduction']);
                $idLgGroupe = $lgGroupe[$lgActuel];
                
                $isContentTraduction = $this->dbQS($idLgGroupe,'_modules_traduction');
                if(!empty($isContentTraduction)){
                    unset($isContentTraduction['id']);
                    $isContent = array_merge($isContent,$isContentTraduction);
                }
                
            }
            
        }
        
        
        
        $nonObligatoire = array('description','top_tinymce','bottom_tinymce','image','meta_titre','meta_description','meta_keys');
        
        switch($this->Action){
            
            case 'addblock':
                
                $Form = $this->Controller->form->i;
                
                if(!empty($Form)){
                    
                    $this->Controller->checkMode();
                    
                    foreach($Form as $k=>$v){
                        if( empty($v) && !in_array($k,$nonObligatoire) ){
                            $this->Controller->form->e['modules_addblock_'.$k] = 'ok';
                        }
                    }
                    
                    // gestion de l'ui
                    $lenUri = strlen($Form['uri']);
                    $isUriValide = ctype_alnum($Form['uri']);
                    if( empty($isUriValide) || $lenUri > 250 ){
                        
                        $this->Controller->form->e['modules_addblock_uri'] = 'ok';
                        
                    }else{
                         
                        $isUriExist = $this->dbQS($Form['uri'],'_modules','uri');
                        if( !empty($isUriExist) ){
                            
                            $this->Controller->form->e['modules_addblock_uri'] = 'ok';
                        }
                        
                    }
                    
                    if(strtolower($Form['uri']) === 'doorgets'){
                        $this->Controller->form->e['modules_addblock_uri'] = 'ok';
                    }
                    
                    if(empty($this->Controller->form->e)){
                        
                        if( !array_key_exists('active',$Form) ){
                            $Form['active'] = 0;
                        }
                        
                        $data['uri'] = $Form['uri'];
                        $data['type'] = 'block';
                        $data['active'] = $Form['active'];
                        $data['date_creation'] = time();
                        
                        $idModule = $this->dbQI($data,'_modules');
                        
                        $dataNext = $Form;
                        
                        unset($dataNext['active']);
                        unset($dataNext['type']);
                        unset($dataNext['uri']);
                        
                        foreach($this->getAllLanguages() as $k=>$v){
                            
                            $dataNext['id_module'] = $idModule;
                            $dataNext['langue'] = $k;
                            $dataNext['date_modification'] = time();
                            $idTraduction[$k] = $this->dbQI($dataNext,'_modules_traduction');
                            
                        }
                        
                        $dataModification['groupe_traduction'] = serialize($idTraduction);
                        $this->dbQU($idModule,$dataModification,'_modules');
                        
                        $this->createBlockInstance($data['uri'],$Form['titre'],$Form['description']);
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header('Location:./?controller=modules');
                        exit();
                        
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }

            case 'addpage':
                
                $Form = $this->Controller->form->i;
                
                if(!empty($Form)){
                    
                    $this->Controller->checkMode();
                    
                    foreach($Form as $k=>$v){
                        if( empty($v) && !in_array($k,$nonObligatoire) ){
                            $this->Controller->form->e['modules_addpage_'.$k] = 'ok';
                        }
                    }
                    
                    // gestion de l'uri
                    $lenUri = strlen($Form['uri']);
                    $isUriValide = ctype_alnum($Form['uri']);
                    if( empty($isUriValide) || $lenUri > 250 ){
                        
                        $this->Controller->form->e['modules_addpage_uri'] = 'ok';
                        
                    }else{
                         
                        $isUriExist = $this->dbQS($Form['uri'],'_modules','uri');
                        if( !empty($isUriExist) ){
                            
                            $this->Controller->form->e['modules_addpage_uri'] = 'ok';
                        }
                        
                    }
                    
                    if(strtolower($Form['uri']) === 'doorgets'){
                        $this->Controller->form->e['modules_addpage_uri'] = 'ok';
                    }
                    
                    if(empty($this->Controller->form->e)){
                        
                        if( !array_key_exists('active',$Form) ){
                            $Form['active'] = 0;
                        }
                        if( !array_key_exists('notification_mail',$Form) ){
                            $Form['notification_mail'] = 0;
                        }
                        if( !array_key_exists('is_first',$Form) ){
                            $Form['is_first'] = 0;
                        }
                        
                        if($Form['type'] == 'block'){
                            $Form['is_first'] = 0;
                        }
                        
                        $data['uri'] = $Form['uri'];
                        $data['type'] = 'page';
                        $data['active'] = $Form['active'];
                        $data['is_first'] = $Form['is_first'];
                        $data['notification_mail'] = $Form['notification_mail'];
                        $data['date_creation'] = time();
                        
                        if($data['is_first'] == 1){
                            
                            $this->dbQL("UPDATE _modules SET is_first = 0 WHERE id >= 1");
                        }
                        
                        $idModule = $this->dbQI($data,'_modules');
                        
                        if($data['is_first'] == 1){
                            
                            $dataModuleWebsite['module_homepage'] = $data['uri'];
                            $this->dbQU(1,$dataModuleWebsite,'_website');
                            
                        }
                        
                        $dataNext = $Form;
                        
                        unset($dataNext['active']);
                        unset($dataNext['type']);
                        unset($dataNext['uri']);
                        unset($dataNext['is_first']);
                        unset($dataNext['notification_mail']);
                        
                        foreach($this->getAllLanguages() as $k=>$v){
                            
                            $dataNext['id_module'] = $idModule;
                            $dataNext['langue'] = $k;
                            $dataNext['date_modification'] = time();
                            $idTraduction[$k] = $this->dbQI($dataNext,'_modules_traduction');
                            
                        }
                        
                        $dataModification['groupe_traduction'] = serialize($idTraduction);
                        $this->dbQU($idModule,$dataModification,'_modules');
                        
                        $this->createPageInstance($data['uri'],$Form);
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header('Location:./?controller=modules');
                        exit();
                        
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }
            
            case 'addmultipage':
                
                $Form = $this->Controller->form->i;
                
                if(!empty($Form)){
                    
                    $this->Controller->checkMode();
                    
                    foreach($Form as $k=>$v){
                        if( empty($v) && !in_array($k,$nonObligatoire) ){
                            $this->Controller->form->e['modules_addmultipage_'.$k] = 'ok';
                        }
                    }
                    
                    // gestion de l'uri
                    $lenUri = strlen($Form['uri']);
                    $isUriValide = ctype_alnum($Form['uri']);
                    if( empty($isUriValide) || $lenUri > 250 ){
                        
                        $this->Controller->form->e['modules_addmultipage_uri'] = 'ok';
                        
                    }else{
                         
                        $isUriExist = $this->dbQS($Form['uri'],'_modules','uri');
                        if( !empty($isUriExist) ){
                            
                            $this->Controller->form->e['modules_addmultipage_uri'] = 'ok';
                        }
                        
                    }
                    
                    if(strtolower($Form['uri']) === 'doorgets'){
                        $this->Controller->form->e['modules_addmultipage_uri'] = 'ok';
                    }
                    
                    if(empty($this->Controller->form->e)){
                        
                        if( !array_key_exists('active',$Form) ){
                            $Form['active'] = 0;
                        }
                        if( !array_key_exists('notification_mail',$Form) ){
                            $Form['notification_mail'] = 0;
                        }
                        if( !array_key_exists('is_first',$Form) ){
                            $Form['is_first'] = 0;
                        }
                        
                        if($Form['type'] == 'block'){
                            $Form['is_first'] = 0;
                        }
                        
                        $data['uri'] = $Form['uri'];
                        $data['type'] = 'multipage';
                        $data['active'] = $Form['active'];
                        $data['is_first'] = $Form['is_first'];
                        $data['notification_mail'] = $Form['notification_mail'];
                        $data['date_creation'] = time();
                        
                        if($data['is_first'] == 1){
                            
                            $this->dbQL("UPDATE _modules SET is_first = 0 WHERE id >= 1");
                        }
                        
                        $idModule = $this->dbQI($data,'_modules');
                        
                        if($data['is_first'] == 1){
                            
                            $dataModuleWebsite['module_homepage'] = $data['uri'];
                            $this->dbQU(1,$dataModuleWebsite,'_website');
                            
                        }
                        
                        $dataNext = $Form;
                        
                        unset($dataNext['active']);
                        unset($dataNext['type']);
                        unset($dataNext['uri']);
                        unset($dataNext['is_first']);
                        unset($dataNext['notification_mail']);
                        
                        foreach($this->getAllLanguages() as $k=>$v){
                            
                            $dataNext['id_module'] = $idModule;
                            $dataNext['langue'] = $k;
                            $dataNext['date_modification'] = time();
                            $idTraduction[$k] = $this->dbQI($dataNext,'_modules_traduction');
                            
                        }
                        
                        $dataModification['groupe_traduction'] = serialize($idTraduction);
                        $this->dbQU($idModule,$dataModification,'_modules');
                        
                        $this->dbQL($this->createSqlMultipage($data['uri']));
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header('Location:./?controller=modules');
                        exit();
                        
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }
            
            case 'addnews':
                
                $Form = $this->Controller->form->i;
                
                if(!empty($Form)){
                    
                    $this->Controller->checkMode();
                    
                    foreach($Form as $k=>$v){
                        if( empty($v) && !in_array($k,$nonObligatoire) ){
                            $this->Controller->form->e['modules_addnews_'.$k] = 'ok';
                        }
                    }
                    
                    // gestion de l'uri
                    $lenUri = strlen($Form['uri']);
                    $isUriValide = ctype_alnum($Form['uri']);
                    if( empty($isUriValide) || $lenUri > 250 ){
                        
                        $this->Controller->form->e['modules_addnews_uri'] = 'ok';
                        
                    }else{
                         
                        $isUriExist = $this->dbQS($Form['uri'],'_modules','uri');
                        if( !empty($isUriExist) ){
                            
                            $this->Controller->form->e['modules_addnews_uri'] = 'ok';
                        }
                        
                    }
                    
                    if(strtolower($Form['uri']) === 'doorgets'){
                        $this->Controller->form->e['modules_addnews_uri'] = 'ok';
                    }
                    
                    if(empty($this->Controller->form->e)){
                        
                        if( !array_key_exists('active',$Form) ){
                            $Form['active'] = 0;
                        }
                        if( !array_key_exists('notification_mail',$Form) ){
                            $Form['notification_mail'] = 0;
                        }
                        if( !array_key_exists('is_first',$Form) ){
                            $Form['is_first'] = 0;
                        }
                        
                        if($Form['type'] == 'block'){
                            $Form['is_first'] = 0;
                        }
                        
                        $data['uri'] = $Form['uri'];
                        $data['type'] = 'news';
                        $data['active'] = $Form['active'];
                        $data['is_first'] = $Form['is_first'];
                        $data['bynum'] = $Form['bynum'];
                        $data['avoiraussi'] = $Form['avoiraussi'];
                        $data['notification_mail'] = $Form['notification_mail'];
                        $data['date_creation'] = time();
                        
                        if($data['is_first'] == 1){
                            
                            $this->dbQL("UPDATE _modules SET is_first = 0 WHERE id >= 1");
                        }
                        
                        $idModule = $this->dbQI($data,'_modules');
                        
                        if($data['is_first'] == 1){
                            
                            $dataModuleWebsite['module_homepage'] = $data['uri'];
                            $this->dbQU(1,$dataModuleWebsite,'_website');
                            
                        }
                        
                        $dataNext = $Form;
                        
                        unset($dataNext['active']);
                        unset($dataNext['type']);
                        unset($dataNext['uri']);
                        unset($dataNext['is_first']);
                        unset($dataNext['bynum']);
                        unset($dataNext['avoiraussi']);
                        unset($dataNext['notification_mail']);
                        
                        foreach($this->getAllLanguages() as $k=>$v){
                            
                            $dataNext['id_module'] = $idModule;
                            $dataNext['langue'] = $k;
                            $dataNext['date_modification'] = time();
                            $idTraduction[$k] = $this->dbQI($dataNext,'_modules_traduction');
                            
                        }
                        
                        $dataModification['groupe_traduction'] = serialize($idTraduction);
                        $this->dbQU($idModule,$dataModification,'_modules');
                        
                        $this->dbQL($this->createSqlNews($data['uri']));
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header('Location:./?controller=modules');
                        exit();
                        
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }
            
            case 'addvideo':
                
                $Form = $this->Controller->form->i;
                
                if(!empty($Form)){
                    
                    $this->Controller->checkMode();
                    
                    foreach($Form as $k=>$v){
                        if( empty($v) && !in_array($k,$nonObligatoire) ){
                            $this->Controller->form->e['modules_addvideo_'.$k] = 'ok';
                        }
                    }
                    
                    // gestion de l'uri
                    $lenUri = strlen($Form['uri']);
                    $isUriValide = ctype_alnum($Form['uri']);
                    if( empty($isUriValide) || $lenUri > 250 ){
                        
                        $this->Controller->form->e['modules_addvideo_uri'] = 'ok';
                        
                    }else{
                         
                        $isUriExist = $this->dbQS($Form['uri'],'_modules','uri');
                        if( !empty($isUriExist) ){
                            
                            $this->Controller->form->e['modules_addvideo_uri'] = 'ok';
                        }
                        
                    }
                    
                    if(strtolower($Form['uri']) === 'doorgets'){
                        $this->Controller->form->e['modules_addvideo_uri'] = 'ok';
                    }
                    
                    if(empty($this->Controller->form->e)){
                        
                        if( !array_key_exists('active',$Form) ){
                            $Form['active'] = 0;
                        }
                        if( !array_key_exists('notification_mail',$Form) ){
                            $Form['notification_mail'] = 0;
                        }
                        if( !array_key_exists('is_first',$Form) ){
                            $Form['is_first'] = 0;
                        }
                        
                        if($Form['type'] == 'block'){
                            $Form['is_first'] = 0;
                        }
                        
                        $data['uri'] = $Form['uri'];
                        $data['type'] = 'video';
                        $data['active'] = $Form['active'];
                        $data['is_first'] = $Form['is_first'];
                        $data['bynum'] = $Form['bynum'];
                        $data['avoiraussi'] = $Form['avoiraussi'];
                        $data['notification_mail'] = $Form['notification_mail'];
                        $data['date_creation'] = time();
                        
                        if($data['is_first'] == 1){
                            
                            $this->dbQL("UPDATE _modules SET is_first = 0 WHERE id >= 1");
                        }
                        
                        $idModule = $this->dbQI($data,'_modules');
                        
                        if($data['is_first'] == 1){
                            
                            $dataModuleWebsite['module_homepage'] = $data['uri'];
                            $this->dbQU(1,$dataModuleWebsite,'_website');
                            
                        }
                        
                        $dataNext = $Form;
                        
                        unset($dataNext['active']);
                        unset($dataNext['type']);
                        unset($dataNext['uri']);
                        unset($dataNext['is_first']);
                        unset($dataNext['bynum']);
                        unset($dataNext['avoiraussi']);
                        unset($dataNext['notification_mail']);
                        
                        foreach($this->getAllLanguages() as $k=>$v){
                            
                            $dataNext['id_module'] = $idModule;
                            $dataNext['langue'] = $k;
                            $dataNext['date_modification'] = time();
                            $idTraduction[$k] = $this->dbQI($dataNext,'_modules_traduction');
                            
                        }
                        
                        $dataModification['groupe_traduction'] = serialize($idTraduction);
                        $this->dbQU($idModule,$dataModification,'_modules');
                        
                        $this->dbQL($this->createSqlVideo($data['uri']));
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header('Location:./?controller=modules');
                        exit();
                        
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }
            
            case 'addimage':
                
                $Form = $this->Controller->form->i;
                
                if(!empty($Form)){
                    
                    $this->Controller->checkMode();
                    
                    foreach($Form as $k=>$v){
                        if( empty($v) && !in_array($k,$nonObligatoire) ){
                            $this->Controller->form->e['modules_addimage_'.$k] = 'ok';
                        }
                    }
                    
                    // gestion de l'uri
                    $lenUri = strlen($Form['uri']);
                    $isUriValide = ctype_alnum($Form['uri']);
                    if( empty($isUriValide) || $lenUri > 250 ){
                        
                        $this->Controller->form->e['modules_addimage_uri'] = 'ok';
                        
                    }else{
                         
                        $isUriExist = $this->dbQS($Form['uri'],'_modules','uri');
                        if( !empty($isUriExist) ){
                            
                            $this->Controller->form->e['modules_addimage_uri'] = 'ok';
                        }
                        
                    }
                    
                    if(strtolower($Form['uri']) === 'doorgets'){
                        $this->Controller->form->e['modules_addimage_uri'] = 'ok';
                    }
                    
                    if(empty($this->Controller->form->e)){
                        
                        if( !array_key_exists('active',$Form) ){
                            $Form['active'] = 0;
                        }
                        if( !array_key_exists('notification_mail',$Form) ){
                            $Form['notification_mail'] = 0;
                        }
                        if( !array_key_exists('is_first',$Form) ){
                            $Form['is_first'] = 0;
                        }
                        
                        if($Form['type'] == 'block'){
                            $Form['is_first'] = 0;
                        }
                        
                        $data['uri'] = $Form['uri'];
                        $data['type'] = 'image';
                        $data['active'] = $Form['active'];
                        $data['is_first'] = $Form['is_first'];
                        $data['bynum'] = $Form['bynum'];
                        $data['avoiraussi'] = $Form['avoiraussi'];
                        $data['notification_mail'] = $Form['notification_mail'];
                        $data['date_creation'] = time();
                        
                        if($data['is_first'] == 1){
                            
                            $this->dbQL("UPDATE _modules SET is_first = 0 WHERE id >= 1");
                        }
                        
                        $idModule = $this->dbQI($data,'_modules');
                        
                        if($data['is_first'] == 1){
                            
                            $dataModuleWebsite['module_homepage'] = $data['uri'];
                            $this->dbQU(1,$dataModuleWebsite,'_website');
                            
                        }
                        
                        $dataNext = $Form;
                        
                        unset($dataNext['active']);
                        unset($dataNext['type']);
                        unset($dataNext['uri']);
                        unset($dataNext['is_first']);
                        unset($dataNext['bynum']);
                        unset($dataNext['avoiraussi']);
                        unset($dataNext['notification_mail']);
                        
                        foreach($this->getAllLanguages() as $k=>$v){
                            
                            $dataNext['id_module'] = $idModule;
                            $dataNext['langue'] = $k;
                            $dataNext['date_modification'] = time();
                            $idTraduction[$k] = $this->dbQI($dataNext,'_modules_traduction');
                            
                        }
                        
                        $dataModification['groupe_traduction'] = serialize($idTraduction);
                        $this->dbQU($idModule,$dataModification,'_modules');
                        
                        $this->dbQL($this->createSqlImage($data['uri']));
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header('Location:./?controller=modules');
                        exit();
                        
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }
            
            case 'addinbox':
                
                $Form = $this->Controller->form->i;
                
                if(!empty($Form)){
                    
                    $this->Controller->checkMode();
                    
                    foreach($Form as $k=>$v){
                        if( empty($v) && !in_array($k,$nonObligatoire) ){
                            $this->Controller->form->e['modules_addinbox_'.$k] = 'ok';
                        }
                    }
                    
                    // gestion de l'uri
                    $lenUri = strlen($Form['uri']);
                    $isUriValide = ctype_alnum($Form['uri']);
                    if( empty($isUriValide) || $lenUri > 250 ){
                        
                        $this->Controller->form->e['modules_addinbox_uri'] = 'ok';
                        
                    }else{
                         
                        $isUriExist = $this->dbQS($Form['uri'],'_modules','uri');
                        if( !empty($isUriExist) ){
                            
                            $this->Controller->form->e['modules_addinbox_uri'] = 'ok';
                        }
                        
                    }
                    
                    if(strtolower($Form['uri']) === 'doorgets'){
                        $this->Controller->form->e['modules_addinbox_uri'] = 'ok';
                    }
                    
                    if(empty($this->Controller->form->e)){
                        
                        if( !array_key_exists('active',$Form) ){
                            $Form['active'] = 0;
                        }
                        if( !array_key_exists('notification_mail',$Form) ){
                            $Form['notification_mail'] = 0;
                        }
                        if( !array_key_exists('is_first',$Form) ){
                            $Form['is_first'] = 0;
                        }
                        
                        if($Form['type'] == 'block'){
                            $Form['is_first'] = 0;
                        }
                        
                        $data['uri'] = $Form['uri'];
                        $data['type'] = 'inbox';
                        $data['active'] = $Form['active'];
                        $data['is_first'] = $Form['is_first'];
                        $data['notification_mail'] = $Form['notification_mail'];
                        $data['date_creation'] = time();
                        
                        if($data['is_first'] == 1){
                            
                            $this->dbQL("UPDATE _modules SET is_first = 0 WHERE id >= 1");
                        }
                        
                        $idModule = $this->dbQI($data,'_modules');
                        
                        if($data['is_first'] == 1){
                            
                            $dataModuleWebsite['module_homepage'] = $data['uri'];
                            $this->dbQU(1,$dataModuleWebsite,'_website');
                            
                        }
                        
                        $dataNext = $Form;
                        
                        unset($dataNext['active']);
                        unset($dataNext['type']);
                        unset($dataNext['uri']);
                        unset($dataNext['is_first']);
                        unset($dataNext['notification_mail']);
                        
                        foreach($this->getAllLanguages() as $k=>$v){
                            
                            $dataNext['id_module'] = $idModule;
                            $dataNext['langue'] = $k;
                            $dataNext['date_modification'] = time();
                            $idTraduction[$k] = $this->dbQI($dataNext,'_modules_traduction');
                            
                        }
                        
                        $dataModification['groupe_traduction'] = serialize($idTraduction);
                        $this->dbQU($idModule,$dataModification,'_modules');
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header('Location:./?controller=modules');
                        exit();
                        
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }
            
            
            case 'addfaq':
                
                $Form = $this->Controller->form->i;
                
                if(!empty($Form)){
                    
                    $this->Controller->checkMode();
                    
                    foreach($Form as $k=>$v){
                        if( empty($v) && !in_array($k,$nonObligatoire) ){
                            $this->Controller->form->e['modules_addfaq_'.$k] = 'ok';
                        }
                    }
                    
                    // gestion de l'uri
                    $lenUri = strlen($Form['uri']);
                    $isUriValide = ctype_alnum($Form['uri']);
                    if( empty($isUriValide) || $lenUri > 250 ){
                        
                        $this->Controller->form->e['modules_addfaq_uri'] = 'ok';
                        
                    }else{
                         
                        $isUriExist = $this->dbQS($Form['uri'],'_modules','uri');
                        if( !empty($isUriExist) ){
                            
                            $this->Controller->form->e['modules_addfaq_uri'] = 'ok';
                        }
                        
                    }
                    
                    if(strtolower($Form['uri']) === 'doorgets'){
                        $this->Controller->form->e['modules_addfaq_uri'] = 'ok';
                    }
                    
                    if(empty($this->Controller->form->e)){
                        
                        if( !array_key_exists('active',$Form) ){
                            $Form['active'] = 0;
                        }
                        if( !array_key_exists('notification_mail',$Form) ){
                            $Form['notification_mail'] = 0;
                        }
                        if( !array_key_exists('is_first',$Form) ){
                            $Form['is_first'] = 0;
                        }
                        
                        if($Form['type'] == 'block'){
                            $Form['is_first'] = 0;
                        }
                        
                        $data['uri'] = $Form['uri'];
                        $data['type'] = 'faq';
                        $data['active'] = $Form['active'];
                        $data['is_first'] = $Form['is_first'];
                        $data['notification_mail'] = $Form['notification_mail'];
                        $data['date_creation'] = time();
                        
                        if($data['is_first'] == 1){
                            
                            $this->dbQL("UPDATE _modules SET is_first = 0 WHERE id >= 1");
                        }
                        
                        $idModule = $this->dbQI($data,'_modules');
                        
                        if($data['is_first'] == 1){
                            
                            $dataModuleWebsite['module_homepage'] = $data['uri'];
                            $this->dbQU(1,$dataModuleWebsite,'_website');
                            
                        }
                        
                        $dataNext = $Form;
                        
                        unset($dataNext['active']);
                        unset($dataNext['type']);
                        unset($dataNext['uri']);
                        unset($dataNext['is_first']);
                        unset($dataNext['notification_mail']);
                        
                        foreach($this->getAllLanguages() as $k=>$v){
                            
                            $dataNext['id_module'] = $idModule;
                            $dataNext['langue'] = $k;
                            $dataNext['date_modification'] = time();
                            $idTraduction[$k] = $this->dbQI($dataNext,'_modules_traduction');
                            
                        }
                        
                        $dataModification['groupe_traduction'] = serialize($idTraduction);
                        $this->dbQU($idModule,$dataModification,'_modules');
                        
                        $this->dbQL($this->createSqlFaq($data['uri']));
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header('Location:./?controller=modules');
                        exit();
                        
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }
            
            
            case 'addpartner':
                
                $Form = $this->Controller->form->i;
                
                if(!empty($Form)){
                    
                    $this->Controller->checkMode();
                    
                    foreach($Form as $k=>$v){
                        if( empty($v) && !in_array($k,$nonObligatoire) ){
                            $this->Controller->form->e['modules_addpartner_'.$k] = 'ok';
                        }
                    }
                    
                    // gestion de l'uri
                    $lenUri = strlen($Form['uri']);
                    $isUriValide = ctype_alnum($Form['uri']);
                    if( empty($isUriValide) || $lenUri > 250 ){
                        
                        $this->Controller->form->e['modules_addpartner_uri'] = 'ok';
                        
                    }else{
                         
                        $isUriExist = $this->dbQS($Form['uri'],'_modules','uri');
                        if( !empty($isUriExist) ){
                            
                            $this->Controller->form->e['modules_addpartner_uri'] = 'ok';
                        }
                        
                    }
                    
                    if(strtolower($Form['uri']) === 'doorgets'){
                        $this->Controller->form->e['modules_addpartner_uri'] = 'ok';
                    }
                    
                    if(empty($this->Controller->form->e)){
                        
                        if( !array_key_exists('active',$Form) ){
                            $Form['active'] = 0;
                        }
                        if( !array_key_exists('notification_mail',$Form) ){
                            $Form['notification_mail'] = 0;
                        }
                        if( !array_key_exists('is_first',$Form) ){
                            $Form['is_first'] = 0;
                        }
                        
                        if($Form['type'] == 'block'){
                            $Form['is_first'] = 0;
                        }
                        
                        $data['uri'] = $Form['uri'];
                        $data['type'] = 'partner';
                        $data['active'] = $Form['active'];
                        $data['is_first'] = $Form['is_first'];
                        $data['notification_mail'] = $Form['notification_mail'];
                        $data['date_creation'] = time();
                        
                        if($data['is_first'] == 1){
                            
                            $this->dbQL("UPDATE _modules SET is_first = 0 WHERE id >= 1");
                        }
                        
                        $idModule = $this->dbQI($data,'_modules');
                        
                        if($data['is_first'] == 1){
                            
                            $dataModuleWebsite['module_homepage'] = $data['uri'];
                            $this->dbQU(1,$dataModuleWebsite,'_website');
                            
                        }
                        
                        $dataNext = $Form;
                        
                        unset($dataNext['active']);
                        unset($dataNext['type']);
                        unset($dataNext['uri']);
                        unset($dataNext['is_first']);
                        unset($dataNext['notification_mail']);
                        
                        foreach($this->getAllLanguages() as $k=>$v){
                            
                            $dataNext['id_module'] = $idModule;
                            $dataNext['langue'] = $k;
                            $dataNext['date_modification'] = time();
                            $idTraduction[$k] = $this->dbQI($dataNext,'_modules_traduction');
                            
                        }
                        
                        $dataModification['groupe_traduction'] = serialize($idTraduction);
                        $this->dbQU($idModule,$dataModification,'_modules');
                        
                        $this->dbQL($this->createSqlPartner($data['uri']));
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header('Location:./?controller=modules');
                        exit();
                        
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }
            
            case 'addlink':
                
                $Form = $this->Controller->form->i;
                
                if(!empty($Form)){
                    
                    $this->Controller->checkMode();
                    
                    foreach($Form as $k=>$v){
                        if( empty($v) && !in_array($k,$nonObligatoire) ){
                            $this->Controller->form->e['modules_addlink_'.$k] = 'ok';
                        }
                    }
                    
                    // gestion de l'uri
                    $lenUri = strlen($Form['uri']);
                    $isUriValide = ctype_alnum($Form['uri']);
                    if( empty($isUriValide) || $lenUri > 250 ){
                        
                        $this->Controller->form->e['modules_addlink_uri'] = 'ok';
                        
                    }else{
                         
                        $isUriExist = $this->dbQS($Form['uri'],'_modules','uri');
                        if( !empty($isUriExist) ){
                            
                            $this->Controller->form->e['modules_addlink_uri'] = 'ok';
                        }
                        
                    }
                    
                    if(strtolower($Form['uri']) === 'doorgets'){
                        $this->Controller->form->e['modules_addlink_uri'] = 'ok';
                    }
                    
                    if(empty($this->Controller->form->e)){
                        
                        if( !array_key_exists('active',$Form) ){
                            $Form['active'] = 0;
                        }
                        
                        $data['uri'] = $Form['uri'];
                        $data['type'] = 'link';
                        $data['active'] = $Form['active'];
                        $data['is_first'] = 0;
                        $data['notification_mail'] = 0;
                        $data['date_creation'] = time();
                        
                        $idModule = $this->dbQI($data,'_modules');
                        
                        $dataNext = $Form;
                        
                        unset($dataNext['active']);
                        unset($dataNext['type']);
                        unset($dataNext['uri']);
                        
                        foreach($this->getAllLanguages() as $k=>$v){
                            
                            $dataNext['id_module'] = $idModule;
                            $dataNext['langue'] = $k;
                            $dataNext['date_modification'] = time();
                            $idTraduction[$k] = $this->dbQI($dataNext,'_modules_traduction');
                            
                        }
                        
                        $dataModification['groupe_traduction'] = serialize($idTraduction);
                        $this->dbQU($idModule,$dataModification,'_modules');
                        
                        $this->createLinkInstance($data['uri']);
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header('Location:./?controller=modules');
                        exit();
                        
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }
            
            case 'addapplicationjob':
                
                $Form = $this->Controller->form->i;
                
                if(!empty($Form)){
                    
                    $this->Controller->checkMode();
                    
                    foreach($Form as $k=>$v){
                        if( empty($v) && !in_array($k,$nonObligatoire) ){
                            $this->Controller->form->e['modules_addapplicationjob_'.$k] = 'ok';
                        }
                    }
                    
                    // gestion de l'uri
                    $lenUri = strlen($Form['uri']);
                    $isUriValide = ctype_alnum($Form['uri']);
                    if( empty($isUriValide) || $lenUri > 250 ){
                        
                        $this->Controller->form->e['modules_addapplicationjob_uri'] = 'ok';
                        
                    }else{
                         
                        $isUriExist = $this->dbQS($Form['uri'],'_modules','uri');
                        if( !empty($isUriExist) ){
                            
                            $this->Controller->form->e['modules_addapplicationjob_uri'] = 'ok';
                        }
                        
                    }
                    
                    if(strtolower($Form['uri']) === 'doorgets'){
                        $this->Controller->form->e['modules_addapplicationjob_uri'] = 'ok';
                    }
                    
                    if(empty($this->Controller->form->e)){
                        
                        if( !array_key_exists('active',$Form) ){
                            $Form['active'] = 0;
                        }
                        if( !array_key_exists('notification_mail',$Form) ){
                            $Form['notification_mail'] = 0;
                        }
                        if( !array_key_exists('is_first',$Form) ){
                            $Form['is_first'] = 0;
                        }
                        
                        if($Form['type'] == 'block'){
                            $Form['is_first'] = 0;
                        }
                        
                        $data['uri'] = $Form['uri'];
                        $data['type'] = 'applicationjob';
                        $data['active'] = $Form['active'];
                        $data['is_first'] = $Form['is_first'];
                        $data['notification_mail'] = $Form['notification_mail'];
                        $data['date_creation'] = time();
                        
                        if($data['is_first'] == 1){
                            
                            $this->dbQL("UPDATE _modules SET is_first = 0 WHERE id >= 1");
                        }
                        
                        $idModule = $this->dbQI($data,'_modules');
                        
                        if($data['is_first'] == 1){
                            
                            $dataModuleWebsite['module_homepage'] = $data['uri'];
                            $this->dbQU(1,$dataModuleWebsite,'_website');
                            
                        }
                        
                        $dataNext = $Form;
                        
                        unset($dataNext['active']);
                        unset($dataNext['type']);
                        unset($dataNext['uri']);
                        unset($dataNext['is_first']);
                        unset($dataNext['notification_mail']);
                        
                        foreach($this->getAllLanguages() as $k=>$v){
                            
                            $dataNext['id_module'] = $idModule;
                            $dataNext['langue'] = $k;
                            $dataNext['date_modification'] = time();
                            $idTraduction[$k] = $this->dbQI($dataNext,'_modules_traduction');
                            
                        }
                        
                        $dataModification['groupe_traduction'] = serialize($idTraduction);
                        $this->dbQU($idModule,$dataModification,'_modules');
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header('Location:./?controller=modules');
                        exit();
                        
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }
                
            
            case 'editapplicationjob':
            case 'editblock':
            case 'editpage':
            case 'editmultipage':
            case 'editnews':
            case 'editinbox':
            case 'editlink':
            case 'editvideo':
            case 'editimage':
            case 'editfaq':
            case 'editpartner':
                
                $Form = $this->Controller->form->i;
                
                if(!empty($Form)){
                    
                    $this->Controller->checkMode();
                    
                    foreach($Form as $k=>$v){
                        if( empty($v)  && !in_array($k,$nonObligatoire) )
                        {
                            $this->Controller->form->e['modules_edit_'.$k] = 'ok';
                        }
                    }
                    
                    if(empty($this->Controller->form->e)){
                        
                        if( !array_key_exists('active',$Form) ){
                            $Form['active'] = 0;
                        }

                        if( !array_key_exists('notification_mail',$Form) ){
                            $Form['notification_mail'] = 0;
                        }
                        if( !array_key_exists('is_first',$Form) ){
                            $Form['is_first'] = 0;
                        }
                        
                        $dataContenu['active'] = $Form['active'];
                        $dataContenu['bynum'] = $Form['bynum'];
                        $dataContenu['avoiraussi'] = $Form['avoiraussi'];
                        $dataContenu['notification_mail'] = $Form['notification_mail'];
                        $dataContenu['is_first'] = $Form['is_first'];
                        
                        
                        if($dataContenu['is_first'] == 1){
                       
                            $this->dbQL("UPDATE _modules SET is_first = 0 WHERE id >= 1");
                            
                            $dataModuleWebsite['module_homepage'] = $isContent['uri'];
                            $this->dbQU(1,$dataModuleWebsite,'_website');
                            
                        }
                        
                        $data = $Form;
                        unset($data['active']);
                        unset($data['bynum']);
                        unset($data['avoiraussi']);
                        unset($data['notification_mail']);
                        unset($data['is_first']);
                        
                        $this->dbQU($isContent['id'],$dataContenu,'_modules','id');
                        $this->dbQU($isContent['id'],$data,'_modules_traduction','id_module'," AND langue = '$lgActuel' LIMIT 1 ");
                        
                        $this->clearDBCache();
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header('Location:'.$_SERVER['REQUEST_URI']); exit();
                        exit();
                        
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }
                
                break;
            
            case 'delete':
                
                $Form = $this->Controller->form->i;
                
                if(!empty($Form)){
                    
                    $this->Controller->checkMode();
                    
                    $lgGroupe = unserialize($isContent['groupe_traduction']);
                    foreach($lgGroupe as $v){
                        @$this->dbQD($v,'_modules_traduction');
                    }
                    
                    $this->dbQD($isContent['id'],'_modules');
                    $this->dbQL("DELETE FROM _modules_traduction WHERE id_module = '".$isContent['id']."'; ");
                    $this->dbQL("DELETE FROM _dg_comments WHERE uri_module = '".$isContent['uri']."'; ");
                    $this->dbQL("DELETE FROM _categories WHERE uri_module = '".$isContent['uri']."' ; ");
                    $this->dbQL("DELETE FROM _categories_traduction WHERE id_cat Not In (SELECT id_cat FROM _categories) ; ");
                    $this->dbQL("DELETE FROM _dg_links WHERE uri_module = '".$isContent['uri']."'; ");
                    $this->dbQL("DELETE FROM _dg_inbox WHERE uri_module = '".$isContent['uri']."'; ");
                    $this->dbQL("DELETE FROM _dg_page WHERE uri = '".$isContent['uri']."'; ");
                    $this->dbQL("DELETE FROM _dg_page_traduction WHERE uri_module = '".$isContent['uri']."'; ");
                    $this->dbQL("DELETE FROM _dg_block WHERE uri = '".$isContent['uri']."'; ");
                    $this->dbQL("DELETE FROM _dg_block_traduction WHERE uri_module = '".$isContent['uri']."'; ");
                    $this->dbQL("DROP TABLE IF EXISTS _m_".$isContent['uri']."  ");
                    $this->dbQL("DROP TABLE IF EXISTS _m_".$isContent['uri']."_traduction  ");
                    
                    $this->clearDBCache();
                    
                    FlashInfo::set($this->l("Le module est maintenant supprimer."));
                    header('Location:./?controller=modules&lg='.$lgActuel);
                    exit();
                    
                }
            
            break;
            
        }
        
        return $out;
        
    }
    
    private function createPageInstance($name,$datas){
        
        $data['uri']                = $name;
        $data['id_user']            = 0;
        $data['id_groupe']          = 0;
        $data['date_creation']      = time();
        
        $iCrud = new Langue();
        $id = $iCrud->dbQI($data,'_dg_page');
        
        $groupe_traduction = array();
        
        foreach($this->getAllLanguages() as $k=>$v){
            
            $dataTraduction['titre']                = $datas['titre'];
            $dataTraduction['description']          = $datas['description'];
            $dataTraduction['uri_module']           = $name;
            $dataTraduction['id_content']           = $id;
            $dataTraduction['langue']               = $k;
            
            $dataTraduction['meta_titre']           = $datas['meta_titre'];
            $dataTraduction['meta_description']     = $datas['meta_description'];
            $dataTraduction['meta_keys']            = $datas['meta_keys'];
            
            $dataTraduction['date_modification']    = time();
            
            $groupe_traduction[$k] = $iCrud->dbQI($dataTraduction,'_dg_page_traduction');
            
        }
        
        $data['groupe_traduction'] = @serialize($groupe_traduction);
        
        $iCrud->dbQU($id,$data,'_dg_page');
        
        
    }
    
    private function createBlockInstance($name,$title,$description){
        
        $data['uri']                = $name;
        $data['id_user']            = 0;
        $data['id_groupe']          = 0;
        $data['date_creation']      = time();
        
        $iCrud = new Langue();
        $id = $iCrud->dbQI($data,'_dg_block');
        
        $groupe_traduction = array();
        
        foreach($this->getAllLanguages() as $k=>$v){
            
            $dataTraduction['titre']                = $title;
            $dataTraduction['description']          = $description;
            $dataTraduction['uri_module']           = $name;
            $dataTraduction['id_block']             = $id;
            $dataTraduction['langue']               = $k;
            $dataTraduction['date_modification']    = time();
            
            $groupe_traduction[$k] = $iCrud->dbQI($dataTraduction,'_dg_block_traduction');
            
        }
        
        $data['groupe_traduction'] = @serialize($groupe_traduction);
        
        $iCrud->dbQU($id,$data,'_dg_block');
        
        
    }
    
    private function createLinkInstance($name){
        
        $data['uri_module']         = $name;
        $data['date_creation']      = time();
        $data['date_modification']  = time();
        
        $iCrud = new Langue();
        foreach($this->getAllLanguages() as $k=>$v){
            $data['label']   = 'doorGets '.$k;
            $data['link']    = 'http://www.doorgets.com/t/'.$k;
            $data['langue']  = $k;
            $iCrud->dbQI($data,'_dg_links');
            
        }
        
    }
    
    
    
    private function createSqlMultipage($name){
        
        $namePage = '_m_'.$name;
        $namePageTrad = '_m_'.$name.'_traduction';
        
        $out = "
        CREATE TABLE IF NOT EXISTS $namePage (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `pseudo` varchar(255) DEFAULT NULL,
            `id_user` int(11) DEFAULT '0',
            `id_groupe` int(11) DEFAULT '0',
            `categorie` varchar(255) DEFAULT NULL,
            `active` int(11) NOT NULL DEFAULT '0',
            `comments` int(11) NOT NULL DEFAULT '0',
            `partage` int(11) NOT NULL DEFAULT '1',
            `facebook` int(11) DEFAULT '0',
            `id_facebook` varchar(255) DEFAULT NULL,
            `disqus` int(11) DEFAULT '0',
            `id_disqus` varchar(255) DEFAULT NULL,
            `mailsender` int(11) DEFAULT '0',
            `sendto` varchar(255) DEFAULT NULL,
            `in_rss` int(11) NOT NULL DEFAULT '0',
            `ordre` int(11) NOT NULL DEFAULT '0',
            `groupe_traduction` text,
            `date_creation` int(11) DEFAULT NULL,
            `id_modo` int(111) DEFAULT NULL,
            `val_modo` int(11) DEFAULT '0',
            `date_modo` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=777 ;
          
          
        CREATE TABLE IF NOT EXISTS $namePageTrad (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `id_content` int(11) NOT NULL DEFAULT '0',
            `langue` varchar(255) DEFAULT NULL,
            `categorie` varchar(255) DEFAULT NULL,
            `titre` varchar(255) DEFAULT NULL,
            `description` text,
            `article_tinymce` text,
            `uri` varchar(255) DEFAULT NULL,
            `meta_titre` varchar(255) DEFAULT NULL,
            `meta_description` varchar(255) DEFAULT NULL,
            `meta_keys` varchar(255) DEFAULT NULL,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=777 ;";
        
        return $out;
    
    }

    private function createSqlNews($name){
        
        $nameNews = '_m_'.$name;
        $nameNewsTrad = '_m_'.$name.'_traduction';
        
        $out = "
        CREATE TABLE IF NOT EXISTS $nameNews (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `pseudo` varchar(255) DEFAULT NULL,
            `id_user` int(11) DEFAULT '0',
            `id_groupe` int(11) DEFAULT '0',
            `categorie` varchar(255) DEFAULT NULL,
            `active` int(11) NOT NULL DEFAULT '0',
            `comments` int(11) NOT NULL DEFAULT '0',
            `partage` int(11) NOT NULL DEFAULT '1',
            `facebook` int(11) DEFAULT '0',
            `id_facebook` varchar(255) DEFAULT NULL,
            `disqus` int(11) DEFAULT '0',
            `id_disqus` varchar(255) DEFAULT NULL,
            `mailsender` int(11) DEFAULT '0',
            `sendto` varchar(255) DEFAULT NULL,
            `in_rss` int(11) NOT NULL DEFAULT '0',
            `ordre` int(11) NOT NULL DEFAULT '0',
            `groupe_traduction` text,
            `date_creation` int(11) DEFAULT NULL,
            `id_modo` int(111) DEFAULT NULL,
            `val_modo` int(11) DEFAULT '0',
            `date_modo` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=777 ;
          
          
        CREATE TABLE IF NOT EXISTS $nameNewsTrad (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `id_content` int(11) NOT NULL DEFAULT '0',
            `langue` varchar(255) DEFAULT NULL,
            `categorie` varchar(255) DEFAULT NULL,
            `titre` varchar(255) DEFAULT NULL,
            `description` text,
            `article_tinymce` text,
            `uri` varchar(255) DEFAULT NULL,
            `meta_titre` varchar(255) DEFAULT NULL,
            `meta_description` varchar(255) DEFAULT NULL,
            `meta_keys` varchar(255) DEFAULT NULL,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=777 ;";
        
        return $out;
        
    }
    
    private function createSqlVideo($name){
        
        $nameNews = '_m_'.$name;
        $nameNewsTrad = '_m_'.$name.'_traduction';
        
        $out = "
        CREATE TABLE IF NOT EXISTS $nameNews (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `pseudo` varchar(255) DEFAULT NULL,
            `id_user` int(11) DEFAULT '0',
            `id_groupe` int(11) DEFAULT '0',
            `categorie` varchar(255) DEFAULT NULL,
            `active` int(11) NOT NULL DEFAULT '0',
            `comments` int(11) NOT NULL DEFAULT '0',
            `partage` int(11) NOT NULL DEFAULT '1',
            `facebook` int(11) DEFAULT '0',
            `id_facebook` varchar(255) DEFAULT NULL,
            `disqus` int(11) DEFAULT '0',
            `id_disqus` varchar(255) DEFAULT NULL,
            `mailsender` int(11) DEFAULT '0',
            `sendto` varchar(255) DEFAULT NULL,
            `in_rss` int(11) NOT NULL DEFAULT '0',
            `ordre` int(11) NOT NULL DEFAULT '0',
            `groupe_traduction` text,
            `date_creation` int(11) DEFAULT NULL,
            `id_modo` int(111) DEFAULT NULL,
            `val_modo` int(11) DEFAULT '0',
            `date_modo` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=777 ;
          
          
        CREATE TABLE IF NOT EXISTS $nameNewsTrad (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `id_content` int(11) NOT NULL DEFAULT '0',
            `langue` varchar(255) DEFAULT NULL,
            `categorie` varchar(255) DEFAULT NULL,
            `youtube` varchar(255) DEFAULT NULL,
            `temps` int(11) NOT NULL DEFAULT '1',
            `titre` varchar(255) DEFAULT NULL,
            `description` text,
            `article_tinymce` text,
            `uri` varchar(255) DEFAULT NULL,
            `meta_titre` varchar(255) DEFAULT NULL,
            `meta_description` varchar(255) DEFAULT NULL,
            `meta_keys` varchar(255) DEFAULT NULL,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=777 ;";
        
        return $out;
        
    }
    
    private function createSqlImage($name){
        
        $nameNews = '_m_'.$name;
        $nameNewsTrad = '_m_'.$name.'_traduction';
        
        $out = "
        CREATE TABLE IF NOT EXISTS $nameNews (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `pseudo` varchar(255) DEFAULT NULL,
            `id_user` int(11) DEFAULT '0',
            `id_groupe` int(11) DEFAULT '0',
            `categorie` varchar(255) DEFAULT NULL,
            `active` int(11) NOT NULL DEFAULT '0',
            `comments` int(11) NOT NULL DEFAULT '0',
            `partage` int(11) NOT NULL DEFAULT '1',
            `facebook` int(11) DEFAULT '0',
            `id_facebook` varchar(255) DEFAULT NULL,
            `disqus` int(11) DEFAULT '0',
            `id_disqus` varchar(255) DEFAULT NULL,
            `mailsender` int(11) DEFAULT '0',
            `sendto` varchar(255) DEFAULT NULL,
            `in_rss` int(11) NOT NULL DEFAULT '0',
            `ordre` int(11) NOT NULL DEFAULT '0',
            `groupe_traduction` text,
            `date_creation` int(11) DEFAULT NULL,
            `id_modo` int(111) DEFAULT NULL,
            `val_modo` int(11) DEFAULT '0',
            `date_modo` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=777 ;
          
          
        CREATE TABLE IF NOT EXISTS $nameNewsTrad (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `id_content` int(11) NOT NULL DEFAULT '0',
            `langue` varchar(255) DEFAULT NULL,
            `categorie` varchar(255) DEFAULT NULL,
            `image` varchar(255) DEFAULT NULL,
            `titre` varchar(255) DEFAULT NULL,
            `description` text,
            `article_tinymce` text,
            `uri` varchar(255) DEFAULT NULL,
            `meta_titre` varchar(255) DEFAULT NULL,
            `meta_description` varchar(255) DEFAULT NULL,
            `meta_keys` varchar(255) DEFAULT NULL,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=777 ;";
        
        return $out;
        
    }
    
    private function createSqlFaq($name){
        
        $nameFaq = '_m_'.$name;
        $nameFaqTrad = '_m_'.$name.'_traduction';
        
        $out = "
        CREATE TABLE IF NOT EXISTS $nameFaq (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `pseudo` varchar(255) DEFAULT NULL,
            `id_user` int(11) DEFAULT '0',
            `id_groupe` int(11) DEFAULT '0',
            `active` int(11) NOT NULL DEFAULT '0',
            `ordre` int(11) DEFAULT NULL,
            `groupe_traduction` text,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
        
        CREATE TABLE IF NOT EXISTS $nameFaqTrad (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `id_content` int(11) DEFAULT NULL,
            `langue` varchar(255) DEFAULT NULL,
            `uri` varchar(255) DEFAULT NULL,
            `question` text,
            `reponse_tinymce` text,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";
        
        return $out;
        
    }
    
    private function createSqlPartner($name){
        
        $nameLiens = '_m_'.$name;
        $nameLiensTrad = '_m_'.$name.'_traduction';
        
        $out = "
        CREATE TABLE IF NOT EXISTS $nameLiens (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `pseudo` varchar(255) DEFAULT NULL,
            `id_user` int(11) DEFAULT '0',
            `id_groupe` int(11) DEFAULT '0',
            `active` int(11) NOT NULL DEFAULT '0',
            `ordre` int(11) DEFAULT NULL,
            `groupe_traduction` text,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
        
        CREATE TABLE IF NOT EXISTS $nameLiensTrad (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `id_content` int(11) DEFAULT NULL,
            `langue` varchar(255) DEFAULT NULL,
            `image` varchar(255) DEFAULT NULL,
            `titre` varchar(255) DEFAULT NULL,
            `url` varchar(255) DEFAULT NULL,
            `description` text,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";
        
        return $out;
        
    }
    
}