<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 07, February 2014
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class ModuleImageModel extends doorgetsModuleModel{
    
    public function __construct($action,$controller,$lg="fr"){
        
        parent::__construct($action,$controller,$lg);
        
    }
    
    public function doAction(){
        
        $out = '';
        $cName = $this->Controller->controllerName;
        
        // Init langue 
        $lgActuel       = $this->getLangueTradution();
        $moduleInfos    = $this->moduleInfos($this->uri,$lgActuel);
        // Init url redirection 
        $redirectUrl = './?controller=module'.$moduleInfos['type'].'&uri='.$this->uri.'&lg='.$lgActuel;
        
        // get Content for edit / delete
        $params = $this->Controller->Params();
        if(array_key_exists('id',$params['GET'])){
            
            $id = $params['GET']['id'];
            $isContent = $this->dbQS($id,$this->table);
            
            if(!empty($isContent)){
                
                if($lgGroupe = @unserialize($isContent['groupe_traduction'])){
                    
                    $idLgGroupe = $lgGroupe[$lgActuel];
                    
                    $isContentTraduction = $this->dbQS($idLgGroupe,$this->table.'_traduction');
                    if(!empty($isContentTraduction)){
                        
                        $isContent = array_merge($isContent,$isContentTraduction);
                        
                    }
                    
                }
                
            }
            
        }
        
        $champsNonObligatoire = array('article_tinymce','meta_titre','meta_description','meta_keys','sendto','id_disqus',);
        
        switch($this->Action){
            
            case 'add':
                
                if(!empty($this->Controller->form->i)){
                    
                    $this->Controller->checkMode();
                    
                    $cResultsInt = $this->getCountTable($this->table);
                    
                    $listToCategories = '';
                    // gestion des champs vide
                    foreach($this->Controller->form->i as $k=>$v){
                        
                        if(
                           !in_array($k,$champsNonObligatoire) &&  empty($v)
                        ){
                            
                            $this->Controller->form->e[$cName.'_add_'.$k] = 'ok';
                            
                        }
                        
                        $iCat = explode('_',$k);
                        if( !empty($iCat) && $iCat[0] === 'categories' && is_numeric($iCat[1]) ){
                            
                            $listToCategories .= $iCat[1].',';
                            unset($this->Controller->form->i[$k]);
                            
                        }
                        
                    }
                    
                    $extension = '.png';
                    
                    if (    isset($_FILES[$cName.'_add_image']) &&
                            (
                                $_FILES[$cName.'_add_image']["type"] == "image/jpeg"
                                || $_FILES[$cName.'_add_image']["type"] == "image/png"
                                
                            ) && ($_FILES[$cName.'_add_image']["error"] === 0 )
                    ){
                        
                        if($_FILES[$cName.'_add_image']["type"] == "image/jpeg"){
                            $extension = '.jpg';
                        }
                        
                    }else{
                        
                        $this->Controller->form->e[$cName.'_add_image'] = 'ok';
                    }
                    
                    if(empty($this->Controller->form->e)){
                
                        $uni = time().'-'.uniqid('doorgets').'';
                        
                        $nameFileImage = $uni.'-'.$this->uri;
                        
                        $this->Controller->form->i['image'] = $nameFileImage;
                        $send_img = UploadImage::send($this->uri,$_FILES[$cName.'_add_image']['tmp_name'],$_FILES[$cName.'_add_image']['name'],$nameFileImage,257);
                        if($send_img !== null){
                            $this->Controller->form->i['image'] = strtolower($send_img);   
                        }
                        
                    }
                    
                    // validation si aucune erreur
                    if(empty($this->Controller->form->e)){
                        
                        if( !array_key_exists('active',$this->Controller->form->i) ){
                            $this->Controller->form->i['active'] = 0;
                        }
                        if( !array_key_exists('comments',$this->Controller->form->i) ){
                            $this->Controller->form->i['comments'] = 0;
                        }
                        if( !array_key_exists('partage',$this->Controller->form->i) ){
                            $this->Controller->form->i['partage'] = 0;
                        }
                        if( !array_key_exists('facebook',$this->Controller->form->i) ){
                            $this->Controller->form->i['facebook'] = 0;
                        }
                        if( !array_key_exists('disqus',$this->Controller->form->i) ){
                            $this->Controller->form->i['disqus'] = 0;
                        }
                        if( !array_key_exists('in_rss',$this->Controller->form->i) ){
                            $this->Controller->form->i['in_rss'] = 0;
                        }
                        //
                        
                        $data['pseudo']         = 'bigadmin';
                        $data['id_user']        = $this->user['id'];
                        $data['id_groupe']      = $this->user['groupe'];
                        $data['categorie']      = $listToCategories;
                        $data['ordre']          = $cResultsInt + 1 ;
                        $data['active']         = $this->Controller->form->i['active'];
                        $data['comments']       = $this->Controller->form->i['comments'];
                        $data['partage']        = $this->Controller->form->i['partage'];
                        $data['facebook']       = $this->Controller->form->i['facebook'];
                        $data['disqus']         = $this->Controller->form->i['disqus'];
                        $data['in_rss']         = $this->Controller->form->i['in_rss'];
                        $data['date_creation']  = time();
                        
                        $idContent = $this->dbQI($data,$this->table);
                        
                        //
                        
                        foreach($this->getAllLanguages() as $k=>$v){
                            
                            $dataNext = array();
                            $dataNext = $this->Controller->form->i;
                            
                            unset($dataNext['active']);
                            unset($dataNext['comments']);
                            unset($dataNext['partage']);
                            unset($dataNext['facebook']);
                            unset($dataNext['disqus']);
                            unset($dataNext['in_rss']);
                            
                            $dataNext['categorie']       = $listToCategories;
                            $dataNext['date_creation']  = $data['date_creation'];
                            $dataNext['id_content']     = $idContent;
                            $dataNext['langue']         = $k;
                            $dataNext['uri']            = $this->Controller->form->i['uri'].'-'.$k;
                            
                            $idTraduction[$k]           = $this->dbQI($dataNext,$this->table.'_traduction');
                            
                        }
                        
                        $dataModification['groupe_traduction'] = serialize($idTraduction);
                        $this->dbQU($idContent,$dataModification,$this->table);
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour"));
                        header('Location:'.$redirectUrl);
                        exit();
                        
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire"),"error");
                    
                }
                
                break;
            
            case 'edit':
                
                if(!empty($this->Controller->form->i)){
                    
                    $this->Controller->checkMode();
                    
                    $listToCategories = '';
                    // gestion des champs vide
                    foreach($this->Controller->form->i as $k=>$v){
                        
                        if(
                           !in_array($k,$champsNonObligatoire) &&  empty($v)
                        ){
                            
                            $this->Controller->form->e[$cName.'_edit_'.$k] = 'ok';
                            
                        }
                        
                        $iCat = explode('_',$k);
                        if( !empty($iCat) && $iCat[0] === 'categories' && is_numeric($iCat[1]) ){
                            
                            $listToCategories .= $iCat[1].',';
                            unset($this->Controller->form->i[$k]);
                            
                        }
                        
                    }
                    
                    $extension = '.png';
                    
                    if (    isset($_FILES[$cName.'_edit_image']) &&
                            (
                                $_FILES[$cName.'_edit_image']["type"] == "image/jpeg"
                                || $_FILES[$cName.'_edit_image']["type"] == "image/png"
                            )
                            && ($_FILES[$cName.'_edit_image']["error"] === 0 )
                    ){
                        
                        if($_FILES[$cName.'_edit_image']["type"] == "image/jpeg"){ $extension = '.jpg'; }
                        
                    }
                    
                    if(empty($this->Controller->form->e)){
                
                        $uni = time().'-'.uniqid('doorgets').'';
                        
                        $nameFileImage = $uni.'-'.$this->uri;
                        
                        $send_img = UploadImage::send($this->uri,$_FILES[$cName.'_edit_image']['tmp_name'],$_FILES[$cName.'_edit_image']['name'],$nameFileImage,257);
                        if($send_img !== null){
                            $this->Controller->form->i['image'] = strtolower($send_img);   
                        }
                        
                    }
                    
                    if(empty($this->Controller->form->e)){
                        
                        if( !array_key_exists('active',$this->Controller->form->i) ){
                            $this->Controller->form->i['active'] = 0;
                        }
                        if( !array_key_exists('comments',$this->Controller->form->i) ){
                            $this->Controller->form->i['comments'] = 0;
                        }
                        if( !array_key_exists('partage',$this->Controller->form->i) ){
                            $this->Controller->form->i['partage'] = 0;
                        }
                        if( !array_key_exists('facebook',$this->Controller->form->i) ){
                            $this->Controller->form->i['facebook'] = 0;
                        }
                        if( !array_key_exists('disqus',$this->Controller->form->i) ){
                            $this->Controller->form->i['disqus'] = 0;
                        }
                        if( !array_key_exists('in_rss',$this->Controller->form->i) ){
                            $this->Controller->form->i['in_rss'] = 0;
                        }
                        
                        $dataContenu['categorie']       = $listToCategories;
                        $dataContenu['active']          = $this->Controller->form->i['active'];
                        $dataContenu['comments']        = $this->Controller->form->i['comments'];
                        $dataContenu['partage']         = $this->Controller->form->i['partage'];
                        $dataContenu['facebook']        = $this->Controller->form->i['facebook'];
                        $dataContenu['disqus']          = $this->Controller->form->i['disqus'];
                        $dataContenu['in_rss']          = $this->Controller->form->i['in_rss'];
                        
                        $data = $this->Controller->form->i;
                        $data['categorie']       = $listToCategories;
                        unset($data['active']);
                        unset($data['comments']);
                        unset($data['partage']);
                        unset($data['facebook']);
                        unset($data['disqus']);
                        unset($data['sendto']);
                        unset($data['in_rss']);
                        
                        $this->dbQU($isContent['id_content'],$dataContenu,$this->table,'id');
                        $this->dbQU($isContent['id_content'],$data,$this->table.'_traduction',"id_content"," AND langue='$lgActuel' LIMIT 1 ");
                        $this->clearDBCache();
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour"));
                        header('Location:'.$_SERVER['REQUEST_URI']);
                        exit();
                        
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire"),"error");
                }
                
                break;
            
            case 'delete':
                
                if(!empty($this->Controller->form->i)){
                    
                    $this->Controller->checkMode();
                    
                    if(empty($this->Controller->form->e)){
                        
                        $lgGroupe = unserialize($isContent['groupe_traduction']);
                        foreach($lgGroupe as $v){
                            @$this->dbQD($v,$this->table.'_traduction');
                        }
                        
                        @unlink(BASE.'data/'.$this->uri.'/'.$isContent['image']);
                        
                        $this->dbQD($isContent['id_content'],$this->table);
                        $this->dbQL("DELETE FROM _dg_comments WHERE uri_module = '".$this->uri."' AND uri_content = '".$isContent['id_content']."' ");
                        $this->dbQL("UPDATE ".$this->table." SET ordre = ordre - 1 WHERE ordre > ".$isContent['ordre']." ");
                        $this->clearDBCache();
                        
                        FlashInfo::set("Les données sont supprimées.");
                        header('Location:'.$redirectUrl);
                        exit();
                    }
                    
                }
                
                break;
            
            case 'massdelete':
                
                if(
                    
                    !empty($this->Controller->form['massdelete_index']->i)
                    && isset($this->Controller->form['massdelete_index']->i['groupe_delete_index'])
                   
                ){
                    
                    $this->Controller->checkMode();
                    
                    if(empty($this->Controller->form['massdelete_index']->e))
                    {
                        
                        $ListeForDeleted = $this->_toArray($this->Controller->form['massdelete_index']->i['groupe_delete_index']);
                
                        foreach($ListeForDeleted as $id){
                            
                            $isContent = $this->dbQS($id,$this->table);
                            
                            
                            $this->dbQD($id,$this->table);
                            $this->dbQL("DELETE FROM ".$this->table."_traduction WHERE id_content = '$id' ");
                            $this->dbQL("DELETE FROM _dg_comments WHERE uri_module = '".$this->uri."' AND uri_content = '".$id."' ");
                            $this->dbQL("UPDATE ".$this->table." SET ordre = ordre - 1 WHERE ordre > ".$isContent['ordre']." ");
                            
                            
                        }
                        
                        FlashInfo::set("Les données sont supprimées.");
                        header('Location:'.$redirectUrl);
                        exit();
                    }
                    
                }
                
                break;
        }
        
    }
    
}