<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 5.2 - 05, January 2014
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class ModuleCategoryModel extends doorgetsModel{
    
    public function __construct($action,$controller,$lg="fr"){
        
        parent::__construct($action,$controller,$lg);
        
    }
    
    public function doAction(){
        
        $out = '';
        
        $lgActuel = $this->getLangueTradution();
        
        // get Content for edit / delete
        $params = $this->Controller->Params();
        if(array_key_exists('id',$params['GET'])){
            
            $id = $params['GET']['id'];
            $isContent = $this->dbQS($id,'_categories');
            
            if(!empty($isContent)){
                
                $lgGroupe = @unserialize($isContent['groupe_traduction']);
                $idLgGroupe = $lgGroupe[$lgActuel];
                
                $isContentTraduction = $this->dbQS($idLgGroupe,'_categories_traduction');
                if(!empty($isContentTraduction)){
                    
                    $isContent = array_merge($isContent,$isContentTraduction);
                }
                
            }
            
            
        }
        
        switch($this->Action){
            
            case 'add':
                
                $cResultsInt = $this->getCountTable('_categories',array(array('key'=>'uri_module','type'=>'=','value'=>$this->uri)));
                
                if(!empty($this->Controller->form->i)){
                    
                    $this->Controller->checkMode();
                    
                    foreach($this->Controller->form->i as $k=>$v){
                        if(empty($v) && $k !== 'description' && $k !== 'image' && $k !== 'meta_titre' && $k !== 'meta_description' && $k !== 'meta_keys'  ){
                            
                            $this->Controller->form->e['modulecategory_add_'.$k] = 'ok';
                            
                        }
                    }
                    
                    // gestion de l'ui
                    
                    $lenUri = strlen($this->Controller->form->i['uri']);
                    $var = str_replace('-','',$this->Controller->form->i['uri']);
                    
                    $isUriValide = ctype_alnum($var);
                    if( empty($isUriValide) || $lenUri > 250 ){
                        
                        $this->Controller->form->e['modulecategory_add_uri'] = 'ok';
                        
                    }else{
                        
                        $isUriExist = $this->dbQS($this->Controller->form->i['uri'],'_categories_traduction','uri');
                        if( !empty($isUriExist) ){
                            
                            $this->Controller->form->e['modulecategory_add_uri'] = 'ok';
                        }
                        
                    }
        
                    
                    if(empty($this->Controller->form->e)){
                        
                        $data['uri_module'] = $this->uri;
                        $data['ordre'] = $cResultsInt + 1;
                        $data['date_creation'] = time();
                        
                        $idCat= $this->dbQI($data,'_categories');
                        
                        $dataNext = $this->Controller->form->i;
                        $dataNext['date_creation'] = time();
                        
                        foreach($this->getAllLanguages() as $k=>$v){
                            
                            $dataNext['id_cat'] = $idCat;
                            $dataNext['langue'] = $k;
                            $dataNext['uri'] = $this->Controller->form->i['uri'].'-'.$this->uri.'-'.$k;
                            $idTraduction[$k] = $this->dbQI($dataNext,'_categories_traduction');
                            
                        }
                        
                        $dataModification['groupe_traduction'] = serialize($idTraduction);
                        $this->dbQU($idCat,$dataModification,'_categories');
                        
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header('Location:./?controller=modulecategory&uri='.$this->uri);
                        exit();
                        
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }
                
                break;
            
            case 'edit':
                
                if(!empty($this->Controller->form->i)){
                    
                    $this->Controller->checkMode();
                    
                    foreach($this->Controller->form->i as $k=>$v){
                        if(empty($v)  && $k !== 'description' && $k !== 'image' && $k !== 'meta_titre' && $k !== 'meta_description' && $k !== 'meta_keys'  ){
                            
                            $this->Controller->form->e['modulecategory_edit_'.$k] = 'ok';
                            
                        }
                    }
                    
                    // gestion de l'uri
                
                    $lenUri = strlen($this->Controller->form->i['uri']);
                    $var = str_replace('-','',$this->Controller->form->i['uri']);
                    
                    $isUriValide = ctype_alnum($var);
                    if( empty($isUriValide) || $lenUri > 250 ){
                        
                        $this->Controller->form->e['modulecategory_edit_uri'] = 'ok';
                        
                    }else{
                        
                        $isUriExist = $this->dbQS($this->Controller->form->i['uri'],'_categories_traduction','uri');
                        if( !empty($isUriExist) && $isUriExist['id'] != $isContent['id']){
                            
                            $this->Controller->form->e['modulecategory_edit_uri'] = 'ok';
                        }
                        
                    }
                    
                    if(empty($this->Controller->form->e)){
                        
                        $data = $this->Controller->form->i;
                        
                        $this->dbQU($isContent['id'],$data,'_categories_traduction');
                        FlashInfo::set($this->l("Vos informations ont bien été mises à jour."));
                        header('Location:'.$_SERVER['REQUEST_URI']);
                        exit();
                        
                    }
                    
                    FlashInfo::set($this->l("Veuillez remplir correctement le formulaire."),"error");
                    
                }
                
                break;
            
            case 'delete':
                
                if(!empty($this->Controller->form->i)){
                    
                    $this->Controller->checkMode();
                    
                    $lgGroupe = unserialize($isContent['groupe_traduction']);
                    foreach($lgGroupe as $v){
                        @$this->dbQD($v,'_categories_traduction');
                    }
                    
                    $this->dbQD($isContent['id_cat'],'_categories');
                    $this->dbQL("UPDATE _categories SET ordre = ordre - 1 WHERE ordre > ".$isContent['ordre']." AND uri_module = '".$this->uri."'");
                    FlashInfo::set($this->l("Suppression effectuée avec succès."));
                    header('Location:./?controller=modulecategory&uri='.$this->uri.'&lg='.$lgActuel);
                    exit();
                }
            
            break;
            
        }
        
        return $out;
        
    }
    
}