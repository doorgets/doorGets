<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 21, December 2013
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class moduleApplicationjobModel extends doorgetsWebsiteModel{
    
    public $isSend;
    
    public function __construct($WebsiteObject){
        
        $WebsiteObject->form['contact_applicationjob'] = new Formulaire('contact_applicationjob');
        parent::__construct($WebsiteObject);
        $this->doAction();
    }
    
    public function doAction(){
        
        $fileType['application/msword'] = 'doc';
        $fileType['application/vnd.openxmlformats-officedocument.wordprocessingml.document'] = 'docx';
        $fileType["application/pdf"] = "pdf";
        
        $out = '';
        
        $idForm = uniqid();

        if(!array_key_exists('idForm',$_SESSION)){
            
            $_SESSION['idForm'] = $idForm;
            
        }
        
        if(
           !empty($this->Website->form['contact_applicationjob']->i)
           && $_SESSION['idForm'] !== $this->Website->form['contact_applicationjob']->i['secureFormulaire']
        ){
            
            header("Location:".$_SERVER['REQUEST_URI']);
            
        }
        
        if(
           !empty($this->Website->form['contact_applicationjob']->i)
           && $_SESSION['idForm'] === $this->Website->form['contact_applicationjob']->i['secureFormulaire']
        ){
            
            $this->Website->checkMode();
            
            $var = $this->Website->form['contact_applicationjob']->i['email'];
            $isEmail = filter_var($var, FILTER_VALIDATE_EMAIL);
            if( empty($isEmail) ){
                
                $this->Website->form['contact_applicationjob']->e['contact_applicationjob_email'] = 'ok';
                
            }
            if(empty($this->Website->form['contact_applicationjob']->i['last_name'])){
                $this->Website->form['contact_applicationjob']->e['contact_applicationjob_last_name'] = "ok";
            }
            if(empty($this->Website->form['contact_applicationjob']->i['sujet'])){
                $this->Website->form['contact_applicationjob']->e['contact_applicationjob_sujet'] = "ok";
            }
            if(empty($this->Website->form['contact_applicationjob']->i['first_name'])){
                $this->Website->form['contact_applicationjob']->e['contact_applicationjob_first_name'] = "ok";
            }
            
            if(  isset($_FILES['contact_applicationjob_f_cv']) &&  $_FILES['contact_applicationjob_f_cv']['error'] != 0  ){
                $this->Website->form['contact_applicationjob']->e['contact_applicationjob_f_cv'] = "ok";
            }
            
            if ( isset($_FILES['contact_applicationjob_f_cv']) && empty($this->Website->form['contact_applicationjob']->e) ){
                if( !array_key_exists($_FILES['contact_applicationjob_f_cv']["type"],$fileType)  ){
                    $this->Website->form['contact_applicationjob']->e['contact_applicationjob_f_cv'] = 'ok';
                }
            }
            
            if ( isset($_FILES['contact_applicationjob_f_motivation']) && empty($this->Website->form['contact_applicationjob']->e) ){
                if( !array_key_exists($_FILES['contact_applicationjob_f_motivation']["type"],$fileType)  ){
                    $this->Website->form['contact_applicationjob']->e['contact_applicationjob_f_motivation'] = 'ok';
                }
            }
            
            if(empty($this->Website->form['contact_applicationjob']->e)){
                
                $ttff = $_FILES['contact_applicationjob_f_cv']["type"];
                $sSize = $_FILES['contact_applicationjob_f_cv']['size'];
                
                $ttf = $fileType[$ttff];
                $uni = time().'-'.uniqid($ttf);
                $nameFile = $uni.'-doorgets.'.$ttf;
                
                $uploaddir = $fileType[$ttff];
                $uploadfile = BASE_DATA.$this->Website->getModule().'/'.$nameFile;
                @mkdir(BASE_DATA.$this->Website->getModule());
                
                if(move_uploaded_file($_FILES['contact_applicationjob_f_cv']['tmp_name'], $uploadfile)){
                    
                    $this->Website->form['contact_applicationjob']->i['file_cv']        = $this->Website->getModule().'/'.$nameFile;
                    $this->Website->form['contact_applicationjob']->i['file_cv_type']   = $ttf;
                    $this->Website->form['contact_applicationjob']->i['file_cv_size']   = $sSize;
                    
                }
                
                $_SESSION['idForm']     = $idForm;
                $data['uri_module']     = $this->Website->getModule();
                $data['lu']             = 2;
                $data['sujet']          = $this->Website->form['contact_applicationjob']->i['sujet'];
                $data['last_name']      = $this->Website->form['contact_applicationjob']->i['last_name'];
                $data['email']          = $this->Website->form['contact_applicationjob']->i['email'];
                $data['first_name']     = $this->Website->form['contact_applicationjob']->i['first_name'];
                $data['file_cv']        = $this->Website->form['contact_applicationjob']->i['file_cv'];
                $data['file_cv_type']   = $this->Website->form['contact_applicationjob']->i['file_cv_type'];
                $data['file_cv_size']   = $this->Website->form['contact_applicationjob']->i['file_cv_size'];
                $data['date_creation']  = time();
                
                $idContactez = $this->Website->dbQI($data,'_dg_applicationjob');
                $this->Website->form['contact_applicationjob']->isSended = true;
                
                // Mail Sender Notification
                $moduleInfo = $this->Website->dbQS($this->Website->getModule(),'_modules','uri');
                if( !empty($moduleInfo) && !empty($moduleInfo['notification_mail'])){

                    $_email = $this->Website->configWeb['email'];
                    $_lg    = $this->Website->configWeb['langue'];
                    $_sujet = $this->Website->l("Candidature").' / '.ucfirst($this->Website->getModule()).'['.$idContactez.']';
                    
                    new SendMailAlert($_email,$_sujet,$_lg);
                    
                }
                
            }
            
        }
        
        
        
    }
    
}