<?php

/*******************************************************************************
/*******************************************************************************
    doorgets 5.0 #!#!#
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class moduleVideoView extends doorgetsWebsiteView{
    
    public function __construct($WebsiteObject){
        
        parent::__construct($WebsiteObject);
        
    }
    
    public function getContent(){
        
        $out = $q = $qN = '';
        $Website = $this->Website;
        $nameTable = '_m_'.$Website->getModule();
        
        $categories = $Website->loadCategories($Website->getModule());
        $categoriesIds = $Website->categoriesIds;
        
        $_imgTime = URL.'themes/'.$Website->getTheme().'/img/icone_time.png';
        $_imgTag = URL.'themes/'.$Website->getTheme().'/img/icone_tag.png';
        $_imgCalendar = URL.'themes/'.$Website->getTheme().'/img/icone_calendar.png';
        $_imgComment = URL.'themes/'.$Website->getTheme().'/img/icone_comment.png';
        
        if($Website->getPosition() === 'root' || $Website->getPosition() === 'category'){
            
            $Params = $Website->getParams();
            $ModuleInfos = $Website->moduleInfos($Website->getModule());
            
            $par = $ModuleInfos['groupe_by'];
            
            if( array_key_exists('q',$Params['GET']) && !empty($Params['GET']['q']) )
            {
                $q = mb_strtolower($Params['GET']['q'],'UTF-8');
            }
            
            if( !empty($q) )
            {
                $qN = '&amp;q='.$q;
            }
            
            $outFilterAND = $sqlGroupe = $getCategory = '';
            $outGroupe = 'all';
            $valFilter = 'date';
            $outFilterORDER = ' '.$nameTable.'.date_creation DESC ';
            
            $outSqlGroupe = " WHERE ".$nameTable.".active = 2
            AND ".$nameTable."_traduction.id_content = ".$nameTable.".id
            AND ".$nameTable."_traduction.langue = '".$Website->myLanguage()."'
            ORDER BY ".$nameTable.".date_creation DESC ";
            
            $outRub = $Website->getModule();
            $categoryLabel = '';
            if( array_key_exists('doorgets',$Params['GET']) ){
               
                $getCategory = $Params['GET']['doorgets'];
                $isCategorie = $Website->dbQS($getCategory,'_categories_traduction','uri');
                if(!empty($isCategorie)){
                    
                    $outGroupe = $getCategory;
                    
                    $outSqlGroupe = " WHERE ".$nameTable."_traduction.id_content = ".$nameTable.".id
                    AND ".$nameTable.".categorie LIKE '%".$isCategorie['id_cat'].",%'
                    AND  ".$nameTable.".active = 2 AND ".$nameTable."_traduction.langue = '".$Website->myLanguage()."'
                    ORDER BY ".$nameTable.".date_creation DESC ";
                    
                    $outRub = 'doorgets='.$getCategory;
                    if( array_key_exists($getCategory,$categories) ){
                        $categoryLabel = $categories[$getCategory];
                    }
                    
                }
                
            }
            
            if( !empty($q) ){
                $outSqlGroupe = " WHERE  ".$nameTable.".active = 2
                AND ".$nameTable."_traduction.id_content = ".$nameTable.".id
                AND ".$nameTable."_traduction.langue = '".$Website->myLanguage()."'  ";
            }
            
            $champsliste[] = $nameTable.'_traduction.titre';
            $champsliste[] = $nameTable.'_traduction.description';
            $champsliste[] = $nameTable.'_traduction.uri';
            $champsliste[] = $nameTable.'_traduction.article_tinymce';
            $champsliste[] = $nameTable.'_traduction.meta_titre';
            $champsliste[] = $nameTable.'_traduction.meta_description';
            $champsliste[] = $nameTable.'_traduction.meta_keys';
            
            if( !empty($q) && !empty($champsliste) ){
                $sqlGroupe .= " AND (";
                foreach($champsliste as $v){
                    $sqlGroupe .= " ".$v." LIKE '%".$q."%' OR";
                }
                $sqlGroupe = substr($sqlGroupe,0,-2);
                $sqlGroupe .= ") ";
            }
            
            $outSqlGroupe = $outSqlGroupe.$sqlGroupe;
            
            $isContents = $Website->dbQ('SELECT COUNT(*) as counter FROM '.$nameTable.', '.$nameTable.'_traduction '.$outSqlGroupe);
            $totalContents = (int)$isContents[0]['counter'];
            $urlPage = BASE_URL."?$outRub$qN&amp;p=";
            
            $p = 1;
            $ini = 0;
            $per = $par;
            
            if(
                array_key_exists('p',$Params['GET']) 
                && is_numeric($Params['GET']['p'])
                && $Params['GET']['p'] <= (ceil($totalContents / $per))
            ){
                $p      = $Params['GET']['p'];
                $ini    = $p * $per - $per;
            }
            
            $sqlLimit = " $outSqlGroupe   LIMIT ".$ini.",".$per;
            
            $getPagination = '';
            if($totalContents > $per){ $getPagination = Pagination::page($totalContents,$p,$per,$urlPage); }
            
            $all = $Website->dbQ('SELECT * FROM '.$nameTable.', '.$nameTable.'_traduction '.$sqlLimit);
            $cAll = count($all);
            
            $finalPer = $ini+$per;
            if( $finalPer >  $totalContents){ $finalPer = $totalContents; }
            
            $out = '';
            $contents = array();
            $iMaxDescription = 500;
            
            if(!empty($all)){
            
                foreach($all as $k=>$data){
                    $contents[$k]['uri'] = $data['uri'];
                    $contents[$k]['title'] = $data['titre'];
                    $contents[$k]['temps'] = $data['temps'];
                    $contents[$k]['title'] = $data['titre'];
                    $contents[$k]['description'] = $data['description'];
                    $contents[$k]['youtube'] = $data['youtube'];
                    $contents[$k]['article'] = html_entity_decode($data['article_tinymce']);
                    $lenArticle = strlen($contents[$k]['article']);
                    
                    if( $lenArticle > $iMaxDescription - 1 ){
                        $contents[$k]['article'] = substr(strip_tags($contents[$k]['article']),0,$iMaxDescription).'...';
                    }
                    
                    $contents[$k]['order'] = $data['ordre'];
                    $contents[$k]['categories'] = $data['categorie'];
                    $contents[$k]['date'] = GetDate::in($data['date_creation'],2,$Website->myLanguage);
                }
            }
            
            $groupeBy = $par;
            if(!empty($contents)){$ini = $ini+1;}
            $tplModuleNewsListing = Template::getWebsiteView('modules/video/video_listing',$Website->getTheme());
            ob_start(); if(is_file($tplModuleNewsListing)){ include $tplModuleNewsListing; }  $out .= ob_get_clean();
            
        }else{
            
            $linksToCategories = '';
            
            $isContent = $Website->dbQS($Website->getUri(),$nameTable.'_traduction','uri');
            if(!empty($isContent)){
                
                $isContentActive = $Website->dbQS($isContent['id_content'],$nameTable);
                if(!empty($isContentActive)){
                    
                    $isContent['article'] = htmlspecialchars_decode(html_entity_decode($isContent['article_tinymce']));
                    $isContent['article'] = $Website->_convertMethod($isContent['article']);
                    $isContent['title'] = $isContent['titre'];
                    
                    unset($isContent['titre']);
                    unset($isContent['article_tinymce']);
                    unset($isContent['id']);
                    unset($isContent['meta_titre']);
                    unset($isContent['meta_description']);
                    unset($isContent['meta_keys']);
                    unset($isContent['langue']);
                    
                    $isContent['comments']      = $isContentActive['comments'];
                    $isContent['sharethis']     = $isContentActive['partage'];
                    $isContent['facebook']      = $isContentActive['facebook'];
                    $isContent['disqus']        = $isContentActive['disqus'];
                    
                    $isContent['date_creation'] = GetDate::in($isContent['date_creation'],2,$Website->myLanguage);
                    
                    $aCategories = $Website->_toArray($isContentActive['categorie']);
                    if(!empty($aCategories)){
                        foreach($aCategories as $id_category){
                            if(array_key_exists($id_category,$categoriesIds)){
                                $linksToCategories .= '<a href="'.BASE_URL.'?doorgets='.$categoriesIds[$id_category].'">'.$Website->categorieSimple[$id_category].'</a>';
                            }
                            
                        }
                    }
                }
                
                
            }
            
            extract($isContent);
            
            $tplModuleNewsContent = Template::getWebsiteView('modules/video/video_content',$Website->getTheme());
            ob_start(); if(is_file($tplModuleNewsContent)){ include $tplModuleNewsContent; }  $out .= ob_get_clean();
            
        }
        
        return $out;
        
    }
    
}