<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 07, February 2014
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class moduleMultipageView extends doorgetsWebsiteView{
    
    public function __construct($WebsiteObject){
        
        parent::__construct($WebsiteObject);
        
    }
    
    public function getContent(){
        
        $out = '';
        $Website = $this->Website;
        $Module = $Website->getModule();
        $moduleInfo = $Website->getActiveModules();
        
        $templateDefault = 'modules/multipage/multipage_listing';
        if(array_key_exists($Module,$moduleInfo)){
            
            
            if(!empty($moduleInfo[$Module]['all']['template_index'])){
                $templateDefault = $moduleInfo[$Module]['all']['template_index'];
                $templateDefault = str_replace('.tpl.php','',$templateDefault);
            }
            
        }
        $nameTable = '_m_'.$Module;
        $uri = $Website->getUri();
        $isContent  = array();
        
        if(empty($uri)){
            
            $isContentFirst = $Website->dbQS(1,$nameTable,'ordre');
            if(!empty($isContentFirst)){
                
                $groupeTraduction = @unserialize($isContentFirst['groupe_traduction']);
                $idGroupeTraduction = $groupeTraduction[$Website->myLanguage];
                
                $isContent = $Website->dbQS($idGroupeTraduction,$nameTable.'_traduction');
                
            }
            
        }else{
            
            $isContent = $Website->dbQS($uri,$nameTable.'_traduction','uri');
        }
        
        if(!empty($isContent)){
            
            $isContentActive = $Website->dbQS($isContent['id_content'],$nameTable);
            $isContent['article'] = html_entity_decode($isContent['article_tinymce']);
            $isContent['article'] = $Website->_convertMethod($isContent['article']);
            unset($isContent['article_tinymce']);
            unset($isContent['id']);
            unset($isContent['meta_titre']);
            unset($isContent['meta_description']);
            unset($isContent['meta_keys']);
            unset($isContent['langue']);
            
            $isContent['comments']      = $isContentActive['comments'];
            $isContent['sharethis']     = $isContentActive['partage'];
            $isContent['facebook']      = $isContentActive['facebook'];
            $isContent['disqus']        = $isContentActive['disqus'];
            $isContent['date_creation'] = GetDate::in($isContentActive['date_creation'],1,$Website->myLanguage);
        }
        
        extract($isContent);
        
        $tplModuleMultipageListing = Template::getWebsiteView($templateDefault,$Website->getTheme());
        ob_start(); if(is_file($tplModuleMultipageListing)){ include $tplModuleMultipageListing; }   $out .= ob_get_clean();
        
        return $out;
        
    }
}