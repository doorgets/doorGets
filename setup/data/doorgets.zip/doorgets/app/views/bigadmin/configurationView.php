<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 07, February 2014
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class ConfigurationView extends doorgetsView{
    
    public function __construct($action,$controller,$lg='fr'){
        
        parent::__construct($action,$controller,$lg);
    }
    
    public function getContent(){
        
        $out = '';
        
        $Rubriques = array(
            
            'siteweb'         => $this->l('Site Web'),
            'langue'        => $this->l('Langue').' / '.$this->l('Heure'),
            'media'         => $this->l('Logo').' & '.$this->l('Icône'),
            'modules'       => $this->l('Modules interne'),
            'adresse'       => $this->l('Addresse').' & '.$this->l('Contact'),
            'network'       => $this->l('Réseaux sociaux'),
            'analytics'     => $this->l('Google analytics'),
            'sitemap'       => $this->l('Plan du site'),
            'backups'       => $this->l('Sauvegardes'),
            'updater'       => $this->l('Mise à jour'),
            'cache'         => $this->l('Cache'),
            'pwd'           => $this->l('Mot de passe'),
            'params'        => $this->l('Paramètres'),
            
        );
        $RubriquesImage = array(
            
            'siteweb'         => '<b class="glyphicon glyphicon-home"></b>',
            'langue'        => '<b class="glyphicon glyphicon-globe"></b>',
            'media'         => '<b class="glyphicon glyphicon-picture"></b>',
            'modules'       => '<b class="glyphicon glyphicon-asterisk"></b>',
            'adresse'       => '<b class="glyphicon glyphicon-envelope"></b>',
            'network'       => '<b class="glyphicon glyphicon-link"></b>',
            'analytics'     => '<b class="glyphicon glyphicon-stats"></b>',
            'sitemap'       => '<b class="glyphicon glyphicon-tree-deciduous"></b>',
            'backups'       => '<b class="glyphicon glyphicon-floppy-disk"></b>',
            'updater'       => '<b class="glyphicon glyphicon-open"></b>',
            'cache'         => '<b class="glyphicon glyphicon-refresh"></b>',
            'pwd'           => '<b class="glyphicon glyphicon-edit"></b>',
            'params'        => '<b class="glyphicon glyphicon-cog"></b>'
            
        );
        $params = $this->Controller->thisController->Params();
        
        //$tpl = Template::getView('bigadmin/configuration/bigadmin_configuration_rubrique');
        //ob_start(); if(is_file($tpl)){ include $tpl; } $out .= ob_get_clean();
        
        if( array_key_exists($this->Action,$Rubriques) || $this->Action === 'index')
        {
            switch($this->Action){
                
                case 'siteweb':
                    
                    $yDateNow = date("Y"); $dateCreation = array();
                    for($i = $yDateNow;$i> ( $yDateNow - 100);$i--){ $dateCreation[(string)$i] = (int)$i; }
                    
                    $statutImage = '<img src="'.BASE_IMG.'puce-verte.png" title="'.$this->l('Activer').'" class="ico-image"  />';
                    if($this->configWeb['statut'] == '2'){
                        $statutImage = '<img src="'.BASE_IMG.'puce-rouge.png" title="'.$this->l('Désactiver').'" class="ico-image" />';
                    }
                    $aValidation = $this->getArrayForms('website_activation');
                    
                    break;
                
                
                
                case 'langue':
                    
                    $arrLangue = $this->getAllLanguages();
                    
                    break;
                
                case 'backups':
                    
                    $urlTop = '<a href="?controller=configuration&action=backups&do=create"><img src="'.BASE_IMG.'add.png" alt="'.$this->l("Créer une sauvegarde").'" class="ico-image" />  '.$this->l('Créer une sauvegarde').'</a>';
                    
                    if(array_key_exists('do',$params['GET'])){
                        
                        $urlTop = '<a class="doorGets-comebackform" href="?controller=configuration&action=backups"><img src="'.BASE_IMG.'retour.png" class="retour-img"> '.$this->l('Retour').'</a>';
                        
                    }
                    
                    
                    $backups = new doorgetsBackups($this);
                    
                    
                    break;
                
                case 'modules':
                    
                    $imgOk = '<img src="'.BASE_IMG.'activer.png" > ';
                    $imgNo = '<img src="'.BASE_IMG.'pause.png" > ';
                    $isActive = '';
                    $isChecked = '';
                    
                    break;
                
                case 'updater':
                    
                    $checkNow = $this->Controller->thisController->_ckeckVersion();
                    
                    extract($checkNow);
                    
                    break;
                
                case 'sitemap':
                    
                    $fileSitemap = BASE.'sitemap.xml';
                    $urlSitemap = URL.'sitemap.xml';
                    
                    $dateEdit = $this->l("Jamais");
                    if(is_file($fileSitemap)){
                        $dateEdit = GetDate::in($fileSitemap,1,$this->myLanguage());
                    }
                    
                    break;
                
                case 'params':
                    
                    $ouinon = array(1=>$this->l('Oui'),2=>$this->l('Non'));
                    $valCache = 2;if(ACTIVE_CACHE){$valCache = 1;}
                    $valDemo = 2;if(ACTIVE_DEMO){$valDemo = 1;}
                    
                    break;
            }
            
            $ActionFile = 'bigadmin/configuration/bigadmin_configuration_'.$this->Action;
            
            $tpl = Template::getView($ActionFile);
            ob_start(); if(is_file($tpl)){ include $tpl; } $out .= ob_get_clean();
            
        }
        
        return $out;
        
    }
    
}