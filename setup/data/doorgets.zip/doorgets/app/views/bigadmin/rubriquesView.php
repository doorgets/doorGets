<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 21, December 2013
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/



class RubriquesView extends doorgetsView{
    
    public function __construct($action,$controller,$lg='fr'){
        
        parent::__construct($action,$controller,$lg);
        
    }
    
    public function getContent(){
        
        $out = '';
        
        $Rubriques = array(
            
            'index'         => $this->l('Gestion des rubriques'),
            'select'        => $this->l('Voir une rubrique'),
            'add'           => $this->l('Ajouter une rubrique'),
            'edit'          => $this->l('Modifier une rubrique'),
            'delete'        => $this->l('Supprimer une rubrique'),
            
        );
        
        $listeModules = $this->loadModulesRubrique();
        
        $params = $this->Controller->Params();
        if(array_key_exists('id',$params['GET'])){
            
            $id = $params['GET']['id'];
            $isContent = $this->dbQS($id,'_rubrique');
            if(empty($isContent)){ return null; }
            $listeModules = $this->loadModulesRubrique($isContent['idModule']);
            
        }
        
        $cListeModules = count($listeModules);
        
        $listeModulesForm = array('--');
        $listeModules = $listeModulesForm + $listeModules;
        
        $ouinon = $this->getArrayForms();
        
        if( array_key_exists($this->Action,$Rubriques) )
        {
            switch($this->Action){
                
                case 'index':
                    
                    $nbStringCount = '';
                    $per = 300;
                    $ini = 0;
                    $cResultsInt = $this->getCountTable('_rubrique');
                    
                    $sqlLimit = " ORDER BY ordre  LIMIT ".$ini.",".$per;
                    
                    $all = $this->dbQA('_rubrique',$sqlLimit);
                    $cAll = count($all);
                    
                    if($cAll > 4){
                        $nbStringCount = $cResultsInt.' '.$this->l('Rubriques');
                    }
                    
                    $block = new BlockTable();
                    $block->setClassCss('doorgets-listing');
                    
                    if($cAll != 0){
                        
                        $block->addTitle($nbStringCount,'titre','first-title td-title');
                        $block->addTitle('','statut','td-title');
                        $block->addTitle('','topup','td-title');
                        $block->addTitle('','topbottom','td-title');
                        $block->addTitle('','edit','td-title');
                        $block->addTitle('','delete','td-title');
                        
                        for($i=0;$i<$cAll;$i++){
                            
                            $urlStatut = BASE_IMG.'puce-verte.png';
                            
                            $bCss = 'backddd';$nModule = '';$tModule = '';$tiModule = '';
                            $isModule = $this->dbQS($all[$i]['idModule'],'_modules');
                            $isModuleTrad = $this->dbQS($all[$i]['idModule'],'_modules_traduction','id_module'," AND langue = '".$this->myLanguage()."' LIMIT 1 ");
                            if( !empty($isModule) && !empty($isModuleTrad) ){
                                
                                $nModule=$isModule['uri'];
                                $tModule='['.$isModule['type'].']';
                                $tiModule = '<span class="right"><small>'.$all[$i]['name'].' #</small></span> '.$isModuleTrad['nom'].' - '.$isModuleTrad['titre'];
                                $bCss = ' hover';
                                if($all[$i]['showinmenu'] === '2'){
                                    
                                    $urlStatut = BASE_IMG.'puce-orange.png';
                                    
                                }
                            }else{
                                
                                $tiModule = $all[$i]['name'];
                                if($all[$i]['showinmenu'] === '2'){
                                    
                                    $urlStatut = BASE_IMG.'puce-rouge.png';
                                    
                                }else{
                                    
                                    $urlStatut = BASE_IMG.'puce-orange.png';
                                    
                                }
                                
                                
                            }
                            
                            $urlStatut = '<img src="'.$urlStatut.'" >';
                            
                            $urlVoirTitle = '<a title="'.$this->l('Modifier').'" href="./?controller=rubriques&action=edit&id='.$all[$i]['id'].'"><img src="'.BASE_IMG.'list-rubrique.png'.'" style="width: 20px;height: 20px;vertical-align: middle;margin-right: 5px;"> '.$tiModule.' '.$tModule.'</a>';
                            $urlVoir = '<a title="'.$this->l('Modifier').'" href="./?controller=rubriques&action=edit&id='.$all[$i]['id'].'"><img src="'.BASE_IMG.'voir.png'.'" class="img-info " ></a>';
                            $urlDelete = '<a title="'.$this->l('Supprimer').'" href="./?controller=rubriques&action=delete&id='.$all[$i]['id'].'"><img src="'.BASE_IMG.'supprimer.png'.'" class="img-info " ></a>';
                            $urlEdit = '<a title="'.$this->l('Modifier').'" href="./?controller=rubriques&action=edit&id='.$all[$i]['id'].'"><img src="'.BASE_IMG.'modifier.png'.'" class="img-info " ></a>';
                            
                            $urlMovedown = '';
                            if( $all[$i]['ordre'] != $cResultsInt ){
                                $urlMovedown = $this->movePosition('down','_rubrique',$all[$i]['id'],$all[$i]['ordre'],$cResultsInt);
                            }
                            $urlMoveup = '';
                            if( $all[$i]['ordre'] != 1 ){
                                $urlMoveup = $this->movePosition('up','_rubrique',$all[$i]['id'],$all[$i]['ordre'],$cResultsInt);
                            }
                            $dateCreation = GetDate::in($all[$i]['date_creation'],1,$this->myLanguage());
                            
                            
                            
                            $block->addContent('titre',$urlVoirTitle );
                            $block->addContent('statut',$urlStatut,'center');
                            $block->addContent('topbottom',$urlMovedown,'center');
                            $block->addContent('topup',$urlMoveup,'center');
                            $block->addContent('edit',$urlEdit,'center');
                            $block->addContent('delete',$urlDelete,'center');
                        }
                    
                    }
                    
                    break;
                
            }
            
            $ActionFile = 'bigadmin/rubriques/bigadmin_rubriques_'.$this->Action;
            
            $tpl = Template::getView($ActionFile);
            ob_start();
            if(is_file($tpl)){ include $tpl; }
            
            $out .= ob_get_clean();
            
        }
        
        return $out;
        
    }
    
    
    
    
    
}