<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 5.2 - 05, January 2014
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class themeView extends doorgetsView{
    
    public function __construct($action,$controller,$lg='fr'){
        
        parent::__construct($action,$controller,$lg);
        
    }
    
    public function getContent(){
        
        $out = '';
        $nameController = $this->Controller->controllerName;
        $params = $this->Controller->Params();
        $Rubriques = array(
            
            'index'         => $this->l('Index de la page'),
            'add'           => $this->l('Ajouter'),
            'edit'          => $this->l('Modifier'),
            'delete'        => $this->l('Supprimer'),
            
        );
        
        $isAllTheme = $this->getAllThemesName();
        $nameTheme  = $this->configWeb['theme'];
        $countTheme = count($isAllTheme);
        
        if( array_key_exists($this->Action,$Rubriques) )
        {
            switch($this->Action){
                
                case 'index':
                    
                    
                    
                    break;
                
                case 'add':
                    
                    
                    $allTheme = array();
                    if(!empty($isAllTheme)){
                        foreach($isAllTheme as $v){
                            $allTheme[$v] = $v;
                        }                        
                    }
                    
                    break;
                
                case 'edit':
                    
                    $theme = $params['GET']['name'];
                    $fileSelected = 'doorgets.css';
                    $urlFile = '';
                    
                    if(array_key_exists('file',$params['GET'])){
                        
                        $fileSelected = $params['GET']['file'];
                        
                    }
                    $themeListe = $this->listThemeFiles($theme);
                    //sort($themeListe['tpl']);
                    $fileContent = '';
                    
                    if( in_array($fileSelected,$themeListe['js']) ){
                        
                        $urlFile = array_search($fileSelected,$themeListe['js']);
                        $fileContent = file_get_contents(THEME.$urlFile);
                    }
                    
                    if( in_array($fileSelected,$themeListe['css']) ){
                        
                        $urlFile = array_search($fileSelected,$themeListe['css']);
                        $fileContent = file_get_contents(THEME.$urlFile);
                    }
                    
                    if( in_array($fileSelected,$themeListe['tpl']) ){
                        
                        $urlFile = array_search($fileSelected,$themeListe['tpl']);
                        $fileContent = file_get_contents(THEME.$urlFile);
                    }
                    
                    break;
                
                case 'delete':
                    
                    $theme = $params['GET']['name'];
                    break;
            }

            $ActionFile = 'bigadmin/'.$nameController.'/bigadmin_'.$nameController.'_'.$this->Action;
            
            $tpl = Template::getView($ActionFile);
            ob_start(); if(is_file($tpl)){ include $tpl; } $out .= ob_get_clean();
            
        }
        
        return $out;
        
    }
    
}