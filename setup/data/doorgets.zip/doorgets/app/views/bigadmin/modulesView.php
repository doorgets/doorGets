<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 21, December 2013
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class ModulesView extends doorgetsView{
    
    public function __construct($action,$controller,$lg='fr'){
        
        parent::__construct($action,$controller,$lg);
        
    }
    
    public function getContent(){
        
        $out = '';
        
        $lgActuel = $this->getLangueTradution();
        
        // Init action
        $Rubriques = array(
            
            'index'                 => $this->l('Index'),
            'addblock'              => $this->l('Ajouter'),
            'addpage'               => $this->l('Ajouter'),
            'addmultipage'          => $this->l('Ajouter'),
            'addinbox'              => $this->l('Ajouter'),
            'addlink'               => $this->l('Ajouter'),
            'addnews'               => $this->l('Ajouter'),
            'addimage'              => $this->l('Ajouter'),
            'addvideo'              => $this->l('Ajouter'),
            'addfaq'                => $this->l('Ajouter'),
            'addpartner'            => $this->l('Ajouter'),
            'addapplicationjob'     => $this->l('Ajouter'),
            'editblock'             => $this->l('Modifier'),
            'editpage'              => $this->l('Modifier'),
            'editmultipage'         => $this->l('Modifier'),
            'editinbox'             => $this->l('Modifier'),
            'editlink'              => $this->l('Modifier'),
            'editnews'              => $this->l('Modifier'),
            'editimage'             => $this->l('Modifier'),
            'editvideo'             => $this->l('Modifier'),
            'editfaq'               => $this->l('Modifier'),
            'editpartner'           => $this->l('Modifier'),
            'editapplicationjob'    => $this->l('Modifier'),
            'delete'                => $this->l('Supprimer'),
            'type'                  => $this->l('Chox du module'),
            'massdelete'            => $this->l('Supprimer par groupe'),
            
        );
        
        // get Content for edit / delete
        $params = $this->Controller->Params();
        if(array_key_exists('id',$params['GET'])){
            
            $id = $params['GET']['id'];
            $isContent = $this->dbQS($id,'_modules');
            
            if(!empty($isContent)){
                
                $lgGroupe = @unserialize($isContent['groupe_traduction']);
                $idLgGroupe = $lgGroupe[$lgActuel];
                
                $isContentTraduction = $this->dbQS($idLgGroupe,'_modules_traduction');
                if(!empty($isContentTraduction)){
                    unset($isContentTraduction['id']);
                    $isContent = array_merge($isContent,$isContentTraduction);
                }
                
                $imageIcone = BASE_DATA.'/_gestion/'.$isContent['image'];
            
                if(!is_file($imageIcone)){
                    $imageIcone = BASE_IMG.'/ico_module.png';
                }
                
                $isActiveModule = '';
                if(!empty($isContent['active'])){ $isActiveModule = 'checked'; }
                
                $isActiveNotification = '';
                if(!empty($isContent['notification_mail'])){ $isActiveNotification = 'checked'; }
                
                $isHomePage = '';
                if(!empty($isContent['is_first'])){ $isHomePage = 'checked'; }
                    
            }
            
            
        }
        
        // Init variables form
        $numGroupe = array();
        for($i=1;$i<100;$i++){
            $numGroupe[$i] = $i;
        }
        
        $liste['block']             = $this->l('Bloc Statique');
        $liste['page']              = $this->l('Page Statique');
        $liste['multipage']         = $this->l('Multi-Pages Statiques');
        $liste['news']              = $this->l("Fil d'actualités");
        $liste['video']             = $this->l('Galerie vidéos');
        $liste['image']             = $this->l("Galerie d'images");
        $liste['faq']               = $this->l('FAQ');
        $liste['partner']           = $this->l('Partenaires');
        $liste['link']              = $this->l('Lien de redirection');
        $liste['inbox']             = $this->l('Formulaire de contact');
        $liste['applicationjob']    = $this->l('Formulaire candidature spontanée');
        
        $listeInfos = array(
            'block' => array(
                'description' => $this->l('Créer des blocs statiques.'),
                'image' => BASE_IMG.'mod_block.png',
            ),
            'page' => array(
                'description' => $this->l('Créer une page simple.'),
                'image' => BASE_IMG.'mod_page.png',
            ),
            'multipage' => array(
                'description' => $this->l('Créer plusieurs pages simple.'),
                'image' => BASE_IMG.'mod_multipage.png',
            ),
            'news' => array(
                'description' => $this->l("Créer un fil d'actualités."),
                'image' => BASE_IMG.'mod_news.png',
            ),
            'inbox' => array(
                'description' => $this->l('Un formulaire pour prendre contact avec vous'),
                'image' => BASE_IMG.'mod_inbox.png',
            ),
            'link' => array(
                'description' => $this->l('Lien de redirection à ajouter au menu'),
                'image' => BASE_IMG.'mod_link.png',
            ),
            'video' => array(
                'description' => $this->l('Créer une galerie vidéos youtube'),
                'image' => BASE_IMG.'mod_video.png',
            ),
            'image' => array(
                'description' => $this->l("Créer votre galerie d'images"),
                'image' => BASE_IMG.'mod_image.png',
            ),
            'faq' => array(
                'description' => $this->l('Liste de questions fréquentes'),
                'image' => BASE_IMG.'mod_faq.png',
            ),
            'partner' => array(
                'description' => $this->l('Afficher la liste de vos partenaires'),
                'image' => BASE_IMG.'mod_partner.png',
            ),
            'applicationjob' => array(
                'description' => $this->l('Proposer un formulaire de candidature'),
                'image' => BASE_IMG.'mod_applicationjob.png',
            ),
        );
        
        if( array_key_exists($this->Action,$Rubriques) )
        {
            switch($this->Action){
                
                case 'index':
                    
                    $out = '';
                    
                    $nbStringCount = '';
                    $per = 300;
                    $ini = 0;
                    $cResultsInt = $this->getCountTable('_modules');
                    
                    $sqlLimit = " ORDER BY type  LIMIT ".$ini.",".$per;
                    
                    $all = $this->dbQA('_modules',$sqlLimit);
                    $cAll = count($all);
                    
                    if($cAll > 4){
                        $nbStringCount = $cResultsInt.' '.$this->l('Modules');
                    }
                    
                    $block = new BlockTable();
                    
                    $block->setClassCss('doorgets-listing');
                    
                    $block->addTitle('','statut','td-title');
                    $block->addTitle('','image','td-title');
                    $block->addTitle('','titre','first-title td-title left');
                    //$block->addTitle('','rubrique','td-title');
                    $block->addTitle('','gerer','td-title');
                    $block->addTitle('','editer','td-title');
                    $block->addTitle('','supprimer','td-title');
                    
                    $isHomePageIn = '';
                    
                    for($i=0;$i<$cAll;$i++){
                        
                        $lgGroupe = unserialize($all[$i]['groupe_traduction']);
                        $idTraduction = $lgGroupe[$lgActuel];
                        
                        $isContentTraduction = $this->dbQS($idTraduction,'_modules_traduction');
                        
                        $cResultsComInt = '';
                        $cResultsContentsInt = '';
                        $cResultsCatInt = '';
                        $cResultsRub = '-';
                        $idRub = 0;
                        
                        if( 
                            $all[$i]['type'] !== 'page'  
                            && $all[$i]['type'] !== 'inbox'
                            && $all[$i]['type'] !== 'block'  
                            && $all[$i]['type'] !== 'link' 
                            && $all[$i]['type'] !== 'applicationjob' 
                        ){
                            
                            $iComments = $this->dbQ("SELECT COUNT(*) as counter FROM _dg_comments WHERE uri_module = '".$all[$i]['uri']."' ");
                            $cResultsComInt = (int)$iComments[0]['counter'];
                            
                            $iContents = $this->dbQ("SELECT COUNT(*) as counters FROM _m_".$all[$i]['uri']."  ");
                            $cResultsContentsInt = (int)$iContents[0]['counters'];
                            
                            $iCat = $this->dbQ("SELECT COUNT(*) as counters FROM _categories WHERE uri_module = '".$all[$i]['uri']."' ");
                            $cResultsCatInt = (int)$iCat[0]['counters'];
                            
                            $aRubrique = $this->dbQS($all[$i]['id'],'_rubrique','idModule');
                            if(!empty($aRubrique)){
                                $cResultsRub = $aRubrique['name'];
                                $idRub = $aRubrique['id'];
                            }
                            
                        }
                        
                        if( $all[$i]['type'] === 'page' || $all[$i]['type'] === 'link' || $all[$i]['type'] === 'block' || $all[$i]['type'] === 'applicationjob' ){
                            
                            $aRubrique = $this->dbQS($all[$i]['id'],'_rubrique','idModule');
                            if(!empty($aRubrique)){
                                $cResultsRub = $aRubrique['name'];
                                $idRub = $aRubrique['id'];
                            }
                            
                        }
                        
                        
                        if( $all[$i]['type'] === 'inbox' ){
                            
                            $iContents = $this->dbQ("SELECT COUNT(*) as counters FROM _dg_inbox WHERE uri_module = '".$all[$i]['uri']."'  ");
                            $cResultsContentsInt = (int)$iContents[0]['counters'];
                            
                            $aRubrique = $this->dbQS($all[$i]['id'],'_rubrique','idModule');
                            if(!empty($aRubrique)){
                                $cResultsRub = $aRubrique['name'];
                                $idRub = $aRubrique['id'];
                            }
                            
                        }
                        
                        if( $all[$i]['type'] === 'applicationjob' ){
                            
                            $iContents = $this->dbQ("SELECT COUNT(*) as counters FROM _dg_applicationjob WHERE uri_module = '".$all[$i]['uri']."'  ");
                            $cResultsContentsInt = (int)$iContents[0]['counters'];
                            
                            $aRubrique = $this->dbQS($all[$i]['id'],'_rubrique','idModule');
                            if(!empty($aRubrique)){
                                $cResultsRub = $aRubrique['name'];
                                $idRub = $aRubrique['id'];
                            }
                            
                        }
                        
                        $isFirstr = $imgFirst = '';
                        if($all[$i]['is_first']){
                            
                            $imgFirst = '<img src="'.BASE_IMG.'home.png" class="ico-home" />';
                            $isHomePageIn = 1;
                            
                        }
                        
                        $imgRubrique = '<img src="'.BASE_IMG.'list-rubrique.png" class="px20 doorgets-img-ico" />';
                        
                        $ImageStatut = BASE_IMG.'puce-orange.png';
                        if($all[$i]['active'] == '1' AND $cResultsRub !== '-')
                        {
                            
                            $ImageStatut = BASE_IMG.'puce-verte.png';
                            
                        }elseif($all[$i]['active'] == '0'){
                            
                            $ImageStatut = BASE_IMG.'puce-rouge.png';
                            
                        }
                        
                        
                        $imageIcone = BASE_IMG.'ico_module.png';
                        if(array_key_exists($all[$i]['type'],$listeInfos)){$imageIcone = $listeInfos[$all[$i]['type']]['image'];}
                        
                        if($all[$i]['type'] === 'block'){ $ImageStatut = BASE_IMG.'puce-verte.png'; }
                        
                        if(!empty($isContentTraduction)){
                            
                            $tGerer = $this->l("Gérer le contenu du module").' '.$all[$i]['uri'];
                            $tEditer = $this->l("Paramètres du module").' '.$all[$i]['uri'];
                            $tDel = $this->l("Supprimer le module").' '.$all[$i]['uri'];
                            
                            $urlGerer = '<a title="'.$tGerer.'" href="./?controller=module'.$all[$i]['type'].'&uri='.$all[$i]['uri'].'&lg='.$lgActuel.'"><img src="'.BASE_IMG.'edit.png'.'" style="height: 36px;width:36px;" >';
                            $urlEditer = '<a title="'.$tEditer.'" href="./?controller=modules&action=edit'.$all[$i]['type'].'&id='.$all[$i]['id'].'&lg='.$lgActuel.'"><img src="'.BASE_IMG.'config.png'.'" style="height: 36px;width:36px;" >';
                            $urlSupprimer = '<a title="'.$tDel.'" href="./?controller=modules&action=delete&id='.$all[$i]['id'].'&lg='.$lgActuel.'"><img src="'.BASE_IMG.'icone-delete.png'.'" style="height: 36px;width:36px;" ></a>';
                            
                            $urlImage = '<a title="'.$tGerer.'"  href="./?controller=module'.$all[$i]['type'].'&uri='.$all[$i]['uri'].'&lg='.$lgActuel.'" title="'.ucfirst($isContentTraduction['nom']).'" ><img src="'.$imageIcone.'" style="height: 36px;width:36px;" alt="'.ucfirst($isContentTraduction['nom']).'" ></a>';
                            $urlTitre = '<a title="'.$tGerer.'"  href="./?controller=module'.$all[$i]['type'].'&uri='.$all[$i]['uri'].'&lg='.$lgActuel.'" style="font-size:12pt;padding:8px;"  >'.$imgFirst.'<b> '.ucfirst($isContentTraduction['titre']).'</b>';
                            if($all[$i]['type'] === 'inbox'){
                                $urlImage = '<a title="'.$tGerer.'"  href="./?controller='.$all[$i]['type'].'&doorGets_search_filter_q_uri_module='.$all[$i]['uri'].'" title="'.ucfirst($isContentTraduction['nom']).'" ><img src="'.$imageIcone.'" style="height: 36px;width:36px;" ></a>';
                                $urlTitre = '<a title="'.$tGerer.'"  href="./?controller='.$all[$i]['type'].'&doorGets_search_filter_q_uri_module='.$all[$i]['uri'].'" style="font-size:12pt;padding:8px;"  >'.$imgFirst.' <b>'.ucfirst($isContentTraduction['titre']).'</b>';
                                $urlGerer = '<a title="'.$tGerer.'"  href="./?controller='.$all[$i]['type'].'&doorGets_search_filter_q_uri_module='.$all[$i]['uri'].'"><img src="'.BASE_IMG.'edit.png'.'" style="height: 36px;width:36px;" >';
                            
                            }
                            $urlStatut = '<img src="'.$ImageStatut.'" style="vertical-align: middle;" >';
                            $urlType = '<em>'.$all[$i]['type'].'</em>';
                            $urlName = '<small><em>'.$all[$i]['uri'].'</em></small>';
                            
                            $urlRubrique = '<a href="./?controller=rubriques&action=edit&id='.$idRub.'">'.$imgRubrique.' '.$cResultsRub.'</a>';
                            if($cResultsRub === '-'){ $urlRubrique = ''; }
                            
                            if(!empty($cResultsContentsInt)){
                                $urlTitre = $urlTitre.' '.'<span class="count-modules">'.$cResultsContentsInt.'</span>';
                            }
                            
                            $block->addContent('statut',$urlStatut,'tb-30');
                            $block->addContent('image',$urlImage,'tb-30');
                            $block->addContent('titre',$urlTitre);
                            //$block->addContent('rubrique',$urlRubrique,'nb-link ');
                            $block->addContent('gerer',$urlGerer,'tb-30');
                            $block->addContent('editer',$urlEditer,'tb-30');
                            $block->addContent('supprimer',$urlSupprimer,'tb-30');
                            
                        }
                        
                    }
                    
                    break;
                
            }
            
            $ActionFile = 'bigadmin/modules/bigadmin_modules_'.$this->Action;
            
            $tpl = Template::getView($ActionFile);
            ob_start();if(is_file($tpl)){ include $tpl; } $out .= ob_get_clean();
            
        }
        
        return $out;
        
    }
    
    
}