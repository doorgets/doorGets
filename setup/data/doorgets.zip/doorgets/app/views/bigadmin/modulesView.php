<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 20, February 2014
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class ModulesView extends doorgetsView{
    
    public function __construct($action,$controller,$lg='fr'){
        
        parent::__construct($action,$controller,$lg);
        
    }
    
    public function getContent(){
        
        $out = '';
        
        $lgActuel = $this->getLangueTradution();
        
        // Init action
        $Rubriques = array(
            
            'index'                 => $this->l('Index'),
            'addblock'              => $this->l('Ajouter'),
            'addblog'              => $this->l('Ajouter'),
            'addpage'               => $this->l('Ajouter'),
            'addgendata'            => $this->l('Ajouter'),
            'addgenform'            => $this->l('Ajouter'),
            'addmultipage'          => $this->l('Ajouter'),
            'addinbox'              => $this->l('Ajouter'),
            'addlink'               => $this->l('Ajouter'),
            'addnews'               => $this->l('Ajouter'),
            'addimage'              => $this->l('Ajouter'),
            'addvideo'              => $this->l('Ajouter'),
            'addfaq'                => $this->l('Ajouter'),
            'addpartner'            => $this->l('Ajouter'),
            'editblock'             => $this->l('Modifier'),
            'editblog'             => $this->l('Modifier'),
            'editpage'              => $this->l('Modifier'),
            'editmultipage'         => $this->l('Modifier'),
            'editinbox'             => $this->l('Modifier'),
            'editgenform'           => $this->l('Modifier'),
            'editlink'              => $this->l('Modifier'),
            'editnews'              => $this->l('Modifier'),
            'editimage'             => $this->l('Modifier'),
            'editvideo'             => $this->l('Modifier'),
            'editfaq'               => $this->l('Modifier'),
            'editpartner'           => $this->l('Modifier'),
            'delete'                => $this->l('Supprimer'),
            'type'                  => $this->l('Chox du module'),
            'massdelete'            => $this->l('Supprimer par groupe'),
            
        );
        
        // get Content for edit / delete
        $params = $this->Controller->Params();
        if(array_key_exists('id',$params['GET']) && !array_key_exists('uri',$params['GET'])){
            
            $id = $params['GET']['id'];
            $isContent = $this->dbQS($id,'_modules');
            
            if(!empty($isContent)){
                
                $lgGroupe = @unserialize($isContent['groupe_traduction']);
                $idLgGroupe = $lgGroupe[$lgActuel];
                
                $isContentTraduction = $this->dbQS($idLgGroupe,'_modules_traduction');
                if(!empty($isContentTraduction)){
                    unset($isContentTraduction['id']);
                    $isContent = array_merge($isContent,$isContentTraduction);
                }
                
                $imageIcone = BASE_DATA.'/_gestion/'.$isContent['image'];
            
                if(!is_file($imageIcone)){
                    $imageIcone = BASE_IMG.'/ico_module.png';
                }
                
                $isActiveModule = '';
                if(!empty($isContent['active'])){ $isActiveModule = 'checked'; }
                
                $isActiveNotification = '';
                if(!empty($isContent['notification_mail'])){ $isActiveNotification = 'checked'; }
                
                $isHomePage = '';
                if(!empty($isContent['is_first'])){ $isHomePage = 'checked'; }
                    
            }
            
            
        }
        
        // Init variables form
        $numGroupe = array();
        for($i=1;$i<100;$i++){
            $numGroupe[$i] = $i;
        }
        
        
        $liste['page']              = $this->l('Page Statique');
        $liste['multipage']         = $this->l('Multi-Pages Statiques');
        $liste['blog']              = $this->l("Blog");
        $liste['news']              = $this->l("Fil d'actualités");
        $liste['video']             = $this->l('Galerie vidéos');
        $liste['image']             = $this->l("Galerie d'images");
        $liste['faq']               = $this->l('FAQ');
        $liste['partner']           = $this->l('Partenaires');
        $liste['inbox']             = $this->l('Formulaire de contact');
        
        $liste['block']             = $this->l('Bloc Statique');
        $liste['link']              = $this->l('Lien de redirection');
        $liste['genform']           = $this->l('Formulaire');
        
        
        $listeInfos = array(
            'block' => array(
                'description' => $this->l('Créer des blocs statiques'),
                'image' => BASE_IMG.'mod_block.png',
            ),
            'page' => array(
                'description' => $this->l('Créer une page simple'),
                'image' => BASE_IMG.'mod_page.png',
            ),
            'multipage' => array(
                'description' => $this->l('Créer plusieurs pages simple'),
                'image' => BASE_IMG.'mod_multipage.png',
            ),
            'blog' => array(
                'description' => $this->l("Créer un blog"),
                'image' => BASE_IMG.'mod_blog.png',
            ),
            'news' => array(
                'description' => $this->l("Créer un fil d'actualités"),
                'image' => BASE_IMG.'mod_news.png',
            ),
            'inbox' => array(
                'description' => $this->l('Un formulaire pour prendre contact avec vous'),
                'image' => BASE_IMG.'mod_inbox.png',
            ),
            'link' => array(
                'description' => $this->l('Lien de redirection à ajouter au menu'),
                'image' => BASE_IMG.'mod_link.png',
            ),
            'video' => array(
                'description' => $this->l('Créer une galerie vidéos youtube'),
                'image' => BASE_IMG.'mod_video.png',
            ),
            'image' => array(
                'description' => $this->l("Créer votre galerie d'images"),
                'image' => BASE_IMG.'mod_image.png',
            ),
            'faq' => array(
                'description' => $this->l('Liste de questions fréquentes'),
                'image' => BASE_IMG.'mod_faq.png',
            ),
            'partner' => array(
                'description' => $this->l('Afficher la liste de vos partenaires'),
                'image' => BASE_IMG.'mod_partner.png',
            ),
            
            'genform' => array(
                'description' => $this->l('Formulaire'),
                'image' => BASE_IMG.'mod_genform.png',
            ),
        );
        
        $ouinon = $this->getArrayForms();
        
        $modules = $allModules = $this->loadModules(true);
        $modulesBlocks = $this->loadModulesBlocks();
        $canAddType = array('blog','news','multipage','video','faq','image','partner','genform');
        $iCountContents = 0;
        
        foreach($modules as $k => $v){
            
            $allModules[$k]['url_edit'] = "?controller=modules&action=edit".$v['type']."&id=".$v['id'];
            
            if(!in_array($v['type'],$canAddType)){
                
                unset($modules[$k]);
                $allModules[$k]['count']    = '';
                $allModules[$k]['url']      = "?controller=module".$v['type']."&uri=".$v['uri'];
                
                
            }else{
                
                $allModules[$k]['count']    = $this->getCountTable('_m_'.$v['uri']);
                $allModules[$k]['url']      = "?controller=module".$v['type']."&uri=".$v['uri'];
                
            }
            
            if($v['type'] === 'inbox'){
                
                $allModules[$k]['count']    = $this->getCountTable('_dg_inbox',array(array('key'=>'uri_module','type'=>'=','value'=>$v['uri'])));
                $allModules[$k]['url']      = "?controller=inbox&doorGets_search_filter_q_uri_module=".$v['uri'];
            }
            
            if($v['type'] === 'genform'){
                
                $allModules[$k]['count']    = $this->getCountTable('_m_'.$v['uri']);
                $allModules[$k]['url']      = "?controller=module".$v['type']."&uri=".$v['uri'];
            }
            
            if($v['type'] === 'applicationjob'){
                
                $allModules[$k]['count'] = $this->getCountTable('_dg_applicationjob',array(array('key'=>'uri_module','type'=>'=','value'=>$v['uri'])));
                
            }
            
            $iCountContents += $allModules[$k]['count'];
        }
        if( array_key_exists($this->Action,$Rubriques) )
        {
            switch($this->Action){
                
                case 'addgenform':
                    
                    $Form = $this->Controller->form->i;
                    $label = 'input-label';
                    $cLabel = strlen($label);
                    $iLabel = 0;
                    if(!empty($Form)){
                        foreach($Form as $k=>$v){
                            $restLabel = substr($k,0,$cLabel);
                            if($restLabel === $label){
                                $iLabel++;
                            }
                        }
                        
                    }
                    
                    break;
                
                case 'editgenform':
                    
                    
                    $isContent['extras'] = unserialize($isContent['extras']);
                    
                    $this->genArraysForm($isContent['extras']);
                    
                    $isSendEmailTo = '';
                    if($isContent['notification_mail'] === '1'){ $isSendEmailTo = 'checked'; }
                    $isSendEmailUser = '';
                    if($isContent['send_mail_user'] === '1'){ $isSendEmailUser = 'checked'; }
                    $isActiveRecaptcha = '';
                    if($isContent['recaptcha'] === '1'){ $isActiveRecaptcha = 'checked'; }
                    
                    $Form = $this->Controller->form->i;
                    $label = 'input-label';
                    $cLabel = strlen($label);
                    $iLabel = 0;
                    
                    if(!empty($Form)){
                        foreach($Form as $k=>$v){
                            $restLabel = substr($k,0,$cLabel);
                            if($restLabel === $label){
                                $iLabel++;
                            }
                        }
                        
                    }
                    
                    break;
                
                case 'index':
                    
                    $out = '';
                    
                    // Modules without blocks and genforms
                    
                    $nbStringCount = '';
                    $per = 300;
                    $ini = 0;
                    
                    $cResultsInt = $this->getCountTable('_modules',array()," WHERE type != 'block' AND type != 'genform' ");
                    
                    $sqlLimit = " WHERE type != 'block' AND type != 'genform' ORDER BY type  LIMIT ".$ini.",".$per;
                    
                    $all = $this->dbQA('_modules',$sqlLimit);
                    $cAll = count($all);
                    
                    if($cAll > 4){
                        $nbStringCount = $cResultsInt.' '.$this->l('Modules');
                    }
                    
                    $block = new BlockTable();
                    
                    $block->setClassCss('doorgets-listing');
                    
                    $block->addTitle('','statut','td-title');
                    $block->addTitle('','image','td-title');
                    $block->addTitle('','titre','first-title td-title left');
                    $block->addTitle('','rubrique','td-title');
                    $block->addTitle('','gerer','td-title');
                    $block->addTitle('','editer','td-title');
                    $block->addTitle('','supprimer','td-title');
                    
                    $isHomePageIn = '';
                    
                    for($i=0;$i<$cAll;$i++){
                        
                        $lgGroupe = unserialize($all[$i]['groupe_traduction']);
                        $idTraduction = $lgGroupe[$lgActuel];
                        
                        $isContentTraduction = $this->dbQS($idTraduction,'_modules_traduction');
                        
                        $cResultsComInt = '';
                        $cResultsContentsInt = '';
                        $cResultsCatInt = '';
                        $cResultsRub = '-';
                        $idRub = 0;
                        
                        if( 
                            $all[$i]['type'] !== 'page'  
                            && $all[$i]['type'] !== 'inbox'
                            && $all[$i]['type'] !== 'block'
                            && $all[$i]['type'] !== 'link' 
                        ){
                            
                            $iComments = $this->dbQ("SELECT COUNT(*) as counter FROM _dg_comments WHERE uri_module = '".$all[$i]['uri']."' ");
                            $cResultsComInt = (int)$iComments[0]['counter'];
                            
                            $iContents = $this->dbQ("SELECT COUNT(*) as counters FROM _m_".$all[$i]['uri']."  ");
                            $cResultsContentsInt = (int)$iContents[0]['counters'];
                            
                            $iCat = $this->dbQ("SELECT COUNT(*) as counters FROM _categories WHERE uri_module = '".$all[$i]['uri']."' ");
                            $cResultsCatInt = (int)$iCat[0]['counters'];
                            
                            $aRubrique = $this->dbQS($all[$i]['id'],'_rubrique','idModule');
                            if(!empty($aRubrique)){
                                $cResultsRub = $aRubrique['name'];
                                $idRub = $aRubrique['id'];
                            }
                            
                        }
                        
                        if( $all[$i]['type'] === 'page' || $all[$i]['type'] === 'link' || $all[$i]['type'] === 'block' || $all[$i]['type'] === 'genform' || $all[$i]['type'] === 'applicationjob' ){
                            
                            $aRubrique = $this->dbQS($all[$i]['id'],'_rubrique','idModule');
                            if(!empty($aRubrique)){
                                $cResultsRub = $aRubrique['name'];
                                $idRub = $aRubrique['id'];
                            }
                            
                        }
                        
                        
                        if( $all[$i]['type'] === 'inbox' ){
                            
                            $iContents = $this->dbQ("SELECT COUNT(*) as counters FROM _dg_inbox WHERE uri_module = '".$all[$i]['uri']."'  ");
                            $cResultsContentsInt = (int)$iContents[0]['counters'];
                            
                            $aRubrique = $this->dbQS($all[$i]['id'],'_rubrique','idModule');
                            if(!empty($aRubrique)){
                                $cResultsRub = $aRubrique['name'];
                                $idRub = $aRubrique['id'];
                            }
                            
                        }
                        
                        if( $all[$i]['type'] === 'applicationjob' ){
                            
                            $iContents = $this->dbQ("SELECT COUNT(*) as counters FROM _dg_applicationjob WHERE uri_module = '".$all[$i]['uri']."'  ");
                            $cResultsContentsInt = (int)$iContents[0]['counters'];
                            
                            $aRubrique = $this->dbQS($all[$i]['id'],'_rubrique','idModule');
                            if(!empty($aRubrique)){
                                $cResultsRub = $aRubrique['name'];
                                $idRub = $aRubrique['id'];
                            }
                            
                        }
                        
                        $isFirstr = $imgFirst = '';
                        if($all[$i]['is_first']){
                            
                            $imgFirst = '<img src="'.BASE_IMG.'home.png" class="ico-home" />';
                            $isHomePageIn = 1;
                            
                        }
                        
                        $imgRubrique = '<img src="'.BASE_IMG.'list-rubrique.png" class="px20 doorgets-img-ico" />';
                        
                        $ImageStatut = BASE_IMG.'puce-orange.png';
                        if($all[$i]['active'] == '1' AND $cResultsRub !== '-')
                        {
                            
                            $ImageStatut = BASE_IMG.'puce-verte.png';
                            
                        }elseif($all[$i]['active'] == '0'){
                            
                            $ImageStatut = BASE_IMG.'puce-rouge.png';
                            
                        }
                        
                        
                        $imageIcone = BASE_IMG.'ico_module.png';
                        if(array_key_exists($all[$i]['type'],$listeInfos)){$imageIcone = $listeInfos[$all[$i]['type']]['image'];}
                        
                        if($all[$i]['type'] === 'block' || $all[$i]['type'] === 'genform' ){ $ImageStatut = BASE_IMG.'puce-verte.png'; }
                        
                        if(!empty($isContentTraduction)){
                            
                            $tGerer = $this->l("Gérer le contenu du module").' '.$all[$i]['uri'];
                            $tEditer = $this->l("Paramètres du module").' '.$all[$i]['uri'];
                            $tDel = $this->l("Supprimer le module").' '.$all[$i]['uri'];
                            
                            $urlGerer = '<a title="'.$tGerer.'" href="./?controller=module'.$all[$i]['type'].'&uri='.$all[$i]['uri'].'&lg='.$lgActuel.'"><b class="glyphicon glyphicon-pencil"></b>';
                            $urlEditer = '<a title="'.$tEditer.'" href="./?controller=modules&action=edit'.$all[$i]['type'].'&id='.$all[$i]['id'].'&lg='.$lgActuel.'"><b class="glyphicon glyphicon-cog"></b>';
                            $urlSupprimer = '<a title="'.$tDel.'" href="./?controller=modules&action=delete&id='.$all[$i]['id'].'&lg='.$lgActuel.'"><b class="glyphicon glyphicon-remove"></b></a>';
                            
                            $urlImage = '<a title="'.$tGerer.'"  href="./?controller=module'.$all[$i]['type'].'&uri='.$all[$i]['uri'].'&lg='.$lgActuel.'" title="'.ucfirst($isContentTraduction['nom']).'" ><img src="'.$imageIcone.'" class="px36" alt="'.ucfirst($isContentTraduction['nom']).'" ></a>';
                            $urlTitre = '<a title="'.$tGerer.'"  href="./?controller=module'.$all[$i]['type'].'&uri='.$all[$i]['uri'].'&lg='.$lgActuel.'" style="font-size:12pt;padding:8px;"  >'.$imgFirst.'<b> '.ucfirst($isContentTraduction['titre']).'</b>';
                            if($all[$i]['type'] === 'inbox'){
                                $urlImage = '<a title="'.$tGerer.'"  href="./?controller='.$all[$i]['type'].'&doorGets_search_filter_q_uri_module='.$all[$i]['uri'].'" title="'.ucfirst($isContentTraduction['nom']).'" ><img src="'.$imageIcone.'" class="px36" ></a>';
                                $urlTitre = '<a title="'.$tGerer.'"  href="./?controller='.$all[$i]['type'].'&doorGets_search_filter_q_uri_module='.$all[$i]['uri'].'" style="font-size:12pt;padding:8px;"  >'.$imgFirst.' <b>'.ucfirst($isContentTraduction['titre']).'</b>';
                                $urlGerer = '<a title="'.$tGerer.'"  href="./?controller='.$all[$i]['type'].'&doorGets_search_filter_q_uri_module='.$all[$i]['uri'].'"><b class="glyphicon glyphicon-pencil"></b>';
                            
                            }
                            $urlStatut = '<img src="'.$ImageStatut.'" style="vertical-align: middle;" >';
                            $urlType = '<em>'.$all[$i]['type'].'</em>';
                            $urlName = '<small><em>'.$all[$i]['uri'].'</em></small>';
                            
                            $urlRubrique = '<a class="size12" href="./?controller=rubriques&action=edit&id='.$idRub.'">'.$imgRubrique.' '.$cResultsRub.'</a>';
                            if($cResultsRub === '-'){ $urlRubrique = ''; }
                            
                            if(!empty($cResultsContentsInt)){
                                $urlTitre = $urlTitre.' '.'<span class="badge right">'.$cResultsContentsInt.'</span>';
                            }
                            
                            $block->addContent('statut',$urlStatut,'tb-30');
                            $block->addContent('image',$urlImage,'tb-30');
                            $block->addContent('titre',$urlTitre);
                            $block->addContent('rubrique',$urlRubrique,'tb-150 ');
                            $block->addContent('gerer',$urlGerer,'tb-30');
                            $block->addContent('editer',$urlEditer,'tb-30');
                            $block->addContent('supprimer',$urlSupprimer,'tb-30');
                            
                            
                            
                        }
                        
                    }
                    
                    // Modules  blocks and genforms
                    
                    $nbStringCount = '';
                    $per = 300;
                    $ini = 0;
                    
                    $cResultsInt = $this->getCountTable('_modules',array()," WHERE type = 'block' OR type = 'genform' ");
                    
                    $sqlLimit = " WHERE type = 'block' OR type = 'genform' ORDER BY type  LIMIT ".$ini.",".$per;
                    
                    $allBlocksGenforms = $this->dbQA('_modules',$sqlLimit);
                    $cAllBlocksGenforms = count($allBlocksGenforms);
                    
                    if($cAllBlocksGenforms > 4){
                        $nbStringCount = $cResultsInt.' '.$this->l('Modules');
                    }
                    
                    $blockBlocksForms = new BlockTable();
                    
                    $blockBlocksForms->setClassCss('doorgets-listing');
                    
                    $blockBlocksForms->addTitle('','statut','td-title');
                    $blockBlocksForms->addTitle('','image','td-title');
                    $blockBlocksForms->addTitle('','titre','first-title td-title left');
                    //$blockBlocksForms->addTitle('','rubrique','td-title');
                    $blockBlocksForms->addTitle('','gerer','td-title');
                    $blockBlocksForms->addTitle('','editer','td-title');
                    $blockBlocksForms->addTitle('','supprimer','td-title');
                    
                    $isHomePageIn = '';
                    
                    for($i=0;$i<$cAllBlocksGenforms;$i++){
                        
                        $lgGroupe = unserialize($allBlocksGenforms[$i]['groupe_traduction']);
                        $idTraduction = $lgGroupe[$lgActuel];
                        
                        $isContentTraduction = $this->dbQS($idTraduction,'_modules_traduction');
                        
                        $cResultsComInt = '';
                        $cResultsContentsInt = '';
                        $cResultsCatInt = '';
                        $cResultsRub = '-';
                        $idRub = 0;
                        
                        if( 
                            $allBlocksGenforms[$i]['type'] !== 'block'
                        ){
                            
                            $iComments = $this->dbQ("SELECT COUNT(*) as counter FROM _dg_comments WHERE uri_module = '".$allBlocksGenforms[$i]['uri']."' ");
                            $cResultsComInt = (int)$iComments[0]['counter'];
                            
                            $iContents = $this->dbQ("SELECT COUNT(*) as counters FROM _m_".$allBlocksGenforms[$i]['uri']."  ");
                            $cResultsContentsInt = (int)$iContents[0]['counters'];
                            
                            $iCat = $this->dbQ("SELECT COUNT(*) as counters FROM _categories WHERE uri_module = '".$allBlocksGenforms[$i]['uri']."' ");
                            $cResultsCatInt = (int)$iCat[0]['counters'];
                            
                            $aRubrique = $this->dbQS($allBlocksGenforms[$i]['id'],'_rubrique','idModule');
                            if(!empty($aRubrique)){
                                $cResultsRub = $aRubrique['name'];
                                $idRub = $aRubrique['id'];
                            }
                            
                        }
                        
                        $aRubrique = $this->dbQS($allBlocksGenforms[$i]['id'],'_rubrique','idModule');
                        if(!empty($aRubrique)){
                            $cResultsRub = $aRubrique['name'];
                            $idRub = $aRubrique['id'];
                        }
                        
                        $isFirstr = $imgFirst = '';
                        
                        $imgRubrique = '<img src="'.BASE_IMG.'list-rubrique.png" class="px20 doorgets-img-ico" />';
                        
                        $ImageStatut = BASE_IMG.'puce-orange.png';
                        if($allBlocksGenforms[$i]['active'] == '1' AND $cResultsRub !== '-')
                        {
                            
                            $ImageStatut = BASE_IMG.'puce-verte.png';
                            
                        }elseif($allBlocksGenforms[$i]['active'] == '0'){
                            
                            $ImageStatut = BASE_IMG.'puce-rouge.png';
                            
                        }
                        
                        
                        $imageIcone = BASE_IMG.'ico_module.png';
                        if(array_key_exists($allBlocksGenforms[$i]['type'],$listeInfos)){$imageIcone = $listeInfos[$allBlocksGenforms[$i]['type']]['image'];}
                        
                        if($allBlocksGenforms[$i]['type'] === 'block' || $allBlocksGenforms[$i]['type'] === 'genform' ){ $ImageStatut = BASE_IMG.'puce-verte.png'; }
                        
                        if(!empty($isContentTraduction)){
                            
                            $tGerer = $this->l("Gérer le contenu du module").' '.$allBlocksGenforms[$i]['uri'];
                            $tEditer = $this->l("Paramètres du module").' '.$allBlocksGenforms[$i]['uri'];
                            $tDel = $this->l("Supprimer le module").' '.$allBlocksGenforms[$i]['uri'];
                            
                            $urlGerer = '<a title="'.$tGerer.'" href="./?controller=module'.$allBlocksGenforms[$i]['type'].'&uri='.$allBlocksGenforms[$i]['uri'].'&lg='.$lgActuel.'"><b class="glyphicon glyphicon-pencil"></b>';
                            $urlEditer = '<a title="'.$tEditer.'" href="./?controller=modules&action=edit'.$allBlocksGenforms[$i]['type'].'&id='.$allBlocksGenforms[$i]['id'].'&lg='.$lgActuel.'"><b class="glyphicon glyphicon-cog"></b>';
                            $urlSupprimer = '<a title="'.$tDel.'" href="./?controller=modules&action=delete&id='.$allBlocksGenforms[$i]['id'].'&lg='.$lgActuel.'"><b class="glyphicon glyphicon-remove"></b></a>';
                            
                            $urlImage = '<a title="'.$tGerer.'"  href="./?controller=module'.$allBlocksGenforms[$i]['type'].'&uri='.$allBlocksGenforms[$i]['uri'].'&lg='.$lgActuel.'" title="'.ucfirst($isContentTraduction['nom']).'" ><img src="'.$imageIcone.'" class="px36" alt="'.ucfirst($isContentTraduction['nom']).'" ></a>';
                            $urlTitre = '<a title="'.$tGerer.'"  href="./?controller=module'.$allBlocksGenforms[$i]['type'].'&uri='.$allBlocksGenforms[$i]['uri'].'&lg='.$lgActuel.'" style="font-size:12pt;padding:8px;"  >'.$imgFirst.'<b> '.ucfirst($isContentTraduction['titre']).'</b>';
                            
                            $urlStatut = '<img src="'.$ImageStatut.'" style="vertical-align: middle;" >';
                            $urlType = '<em>'.$allBlocksGenforms[$i]['type'].'</em>';
                            $urlName = '<small><em>'.$allBlocksGenforms[$i]['uri'].'</em></small>';
                            
                            $urlRubrique = '<a href="./?controller=rubriques&action=edit&id='.$idRub.'">'.$imgRubrique.' '.$cResultsRub.'</a>';
                            if($cResultsRub === '-'){ $urlRubrique = ''; }
                            
                            if(!empty($cResultsContentsInt)){
                                $urlTitre = $urlTitre.' '.'<span class="badge right">'.$cResultsContentsInt.'</span>';
                            }
                            
                            $blockBlocksForms->addContent('statut',$urlStatut,'tb-30');
                            $blockBlocksForms->addContent('image',$urlImage,'tb-30');
                            $blockBlocksForms->addContent('titre',$urlTitre);
                            //$blockBlocksForms->addContent('rubrique',$urlRubrique,'nb-link ');
                            $blockBlocksForms->addContent('gerer',$urlGerer,'tb-30');
                            $blockBlocksForms->addContent('editer',$urlEditer,'tb-30');
                            $blockBlocksForms->addContent('supprimer',$urlSupprimer,'tb-30');
                            
                            
                            
                        }
                        
                    }
                    
                    break;
                
            }
            
            $ActionFile = 'bigadmin/modules/bigadmin_modules_'.$this->Action;
            $tpl = Template::getView($ActionFile);  ob_start();if(is_file($tpl)){ include $tpl; } $out = $tpl; $out = ob_get_clean();
            
        }
        
        return $out;
        
    }
    
    public function getBoxTitle($displayDelete=false,$displayBox=false,$i=0,$lLabel = '',$lActive = '', $lFilter = '' ,$lCss = '' ){
        
        $boxTag = 'bigadmin/modules/bigadmin_modules_box_tag_title';
        $tpl = Template::getView($boxTag);  ob_start();if(is_file($tpl)){ include $tpl; } $out = $tpl; $out = ob_get_clean();
            
        return $out;
        
    }
    
    public function getBoxQuotte($displayDelete=false,$displayBox=false,$i=0,$lLabel = '',$lActive = '', $lFilter = '' ,$lCss = '' ){
        
        $boxTag = 'bigadmin/modules/bigadmin_modules_box_tag_quotte';
        $tpl = Template::getView($boxTag);  ob_start();if(is_file($tpl)){ include $tpl; } $out = $tpl; $out = ob_get_clean();
            
        return $out;
        
    }
    
    public function getBoxSeparateur($displayDelete=false,$displayBox=false,$i=0,$lLabel = '',$lActive = '', $lFilter = '' ,$lCss = '' ){
        
        $boxTag = 'bigadmin/modules/bigadmin_modules_box_tag_separateur';
        $tpl = Template::getView($boxTag);  ob_start();if(is_file($tpl)){ include $tpl; } $out = $tpl; $out = ob_get_clean();
            
        return $out;
        
    }
    
    public function getBoxText($type="text",$displayDelete=false,$displayBox=false,$i=0,$lLabel = '',$lValue = '',$lActive = '',$lObli = '', $lFilter = '' , $lInfo = '' , $lCss = '' ){
        
        $boxFile = 'bigadmin/modules/bigadmin_modules_box_text';
        $tpl = Template::getView($boxFile);  ob_start();if(is_file($tpl)){ include $tpl; } $out = $tpl; $out = ob_get_clean();
        
        return $out;
        
    }
    
    public function getBoxSelect($type="radio",$displayDelete=false,$displayBox=false,$i=0,$lLabel = '',$lValue = '',$lActive = '',$lObli = '',  $lInfo = '' , $lCss = '' , $lListe = ''){
        
        $boxFile = 'bigadmin/modules/bigadmin_modules_box_select';
        $tpl = Template::getView($boxFile);  ob_start();if(is_file($tpl)){ include $tpl; } $out = $tpl; $out = ob_get_clean();
        
        return $out;
        
    }
    
    public function getBoxFile($displayDelete=false,$displayBox=false,$i=0,$lLabel = '',$lValue = '',$lActive = '',$lObli = '',  $lInfo = '' , $lCss = '' , $tZip = '',$tPng = '', $tJpg = '', $tGif = '', $tPdf = '', $tSwf = '', $tDoc = ''){
        
        $boxFile = 'bigadmin/modules/bigadmin_modules_box_file';
        $tpl = Template::getView($boxFile);  ob_start();if(is_file($tpl)){ include $tpl; } $out = $tpl; $out = ob_get_clean();
        
        return $out;
        
    }
    
    public function genArraysForm($data){
        
        
        if(!empty($data)){
            
            $iLabel = count($data);
            for($i=1;$i<$iLabel+1;$i++){
                
                $this->Controller->form->i['input-type-'.$i]    = 'text';
                $this->Controller->form->i['input-label-'.$i]       = $data[$i]['label'];
                $this->Controller->form->i['input-css-'.$i]         = $data[$i]['css'];
                
            
                switch ($data[$i]['type']){
                    
                    case 'tag-title':
                        
                        $this->Controller->form->i['input-active-'.$i]  = $data[$i]['active'];
                        
                        $this->Controller->form->i['input-obligatoire-'.$i] = 'no';
                        $this->Controller->form->i['input-info-'.$i]        = '';
                        
                        $this->Controller->form->i['input-type-'.$i]    = 'tag-title';
                        $this->Controller->form->i['input-filter-'.$i]  = $data[$i]['filtre'];
                        break;
                    
                    case 'tag-quotte':
                        
                        $this->Controller->form->i['input-active-'.$i]  = $data[$i]['active'];
                        
                        $this->Controller->form->i['input-obligatoire-'.$i] = 'no';
                        $this->Controller->form->i['input-info-'.$i]        = '';
                        
                        $this->Controller->form->i['input-type-'.$i]    = 'tag-quotte';
                        $this->Controller->form->i['input-filter-'.$i]  = $data[$i]['filtre'];
                        break;
                    
                    case 'tag-separateur':
                        
                        $this->Controller->form->i['input-active-'.$i]      = $data[$i]['active'];
                        
                        $this->Controller->form->i['input-obligatoire-'.$i] = 'no';
                        $this->Controller->form->i['input-info-'.$i]        = '';
                        
                        $this->Controller->form->i['input-type-'.$i]        = 'tag-separateur';
                        $this->Controller->form->i['input-filter-'.$i]      = $data[$i]['filtre'];
                        break;
                    
                    case 'text':
                        
                        $this->Controller->form->i['input-active-'.$i]      = $data[$i]['active'];
                        $this->Controller->form->i['input-obligatoire-'.$i] = $data[$i]['obligatoire'];
                        $this->Controller->form->i['input-info-'.$i]        = $data[$i]['info'];
                        
                        $this->Controller->form->i['input-type-'.$i]    = 'text';
                        $this->Controller->form->i['input-filter-'.$i]  = $data[$i]['filtre'];
                        $this->Controller->form->i['input-value-'.$i]       = $data[$i]['value'];
                        break;
                    
                    case 'textarea':
                        
                        $this->Controller->form->i['input-active-'.$i]      = $data[$i]['active'];
                        $this->Controller->form->i['input-obligatoire-'.$i] = $data[$i]['obligatoire'];
                        $this->Controller->form->i['input-info-'.$i]        = $data[$i]['info'];
                        
                        $this->Controller->form->i['input-type-'.$i]    = 'textarea';
                        $this->Controller->form->i['input-filter-'.$i]  = '';
                        $this->Controller->form->i['input-value-'.$i]       = $data[$i]['value'];
                        break;
                    
                    case 'select':
                        
                        $this->Controller->form->i['input-active-'.$i]      = $data[$i]['active'];
                        $this->Controller->form->i['input-obligatoire-'.$i] = $data[$i]['obligatoire'];
                        $this->Controller->form->i['input-info-'.$i]        = $data[$i]['info'];
                        
                        $this->Controller->form->i['input-type-'.$i]    = 'select';
                        $this->Controller->form->i['input-liste-'.$i]   = $data[$i]['liste'];
                        $this->Controller->form->i['input-value-'.$i]       = $data[$i]['value'];
                        break;
                    
                    case 'checkbox':
                        
                        $this->Controller->form->i['input-active-'.$i]      = $data[$i]['active'];
                        $this->Controller->form->i['input-obligatoire-'.$i] = $data[$i]['obligatoire'];
                        $this->Controller->form->i['input-info-'.$i]        = $data[$i]['info'];
                        
                        $this->Controller->form->i['input-type-'.$i]    = 'checkbox';
                        $this->Controller->form->i['input-liste-'.$i]   = $data[$i]['liste'];
                        $this->Controller->form->i['input-value-'.$i]       = $data[$i]['value'];
                        break;
                    
                    case 'radio':
                        
                        $this->Controller->form->i['input-active-'.$i]      = $data[$i]['active'];
                        $this->Controller->form->i['input-obligatoire-'.$i] = $data[$i]['obligatoire'];
                        $this->Controller->form->i['input-info-'.$i]        = $data[$i]['info'];
                        
                        $this->Controller->form->i['input-type-'.$i]    = 'radio';
                        $this->Controller->form->i['input-liste-'.$i]   = $data[$i]['liste'];
                        $this->Controller->form->i['input-value-'.$i]   = $data[$i]['value'];
                        break;
                    
                    case 'file':
                        
                        $this->Controller->form->i['input-active-'.$i]      = $data[$i]['active'];
                        $this->Controller->form->i['input-obligatoire-'.$i] = $data[$i]['obligatoire'];
                        $this->Controller->form->i['input-info-'.$i]        = $data[$i]['info'];
                        
                        $this->Controller->form->i['input-type-'.$i]    = 'file';
                        $this->Controller->form->i['input-value-'.$i]   = $data[$i]['value'];
                        
                        $this->Controller->form->i['input-zip-'.$i] = $data[$i]['file-type']['zip'];
                        $this->Controller->form->i['input-png-'.$i] = $data[$i]['file-type']['png'];
                        $this->Controller->form->i['input-jpg-'.$i] = $data[$i]['file-type']['jpg'];
                        $this->Controller->form->i['input-gif-'.$i] = $data[$i]['file-type']['gif'];
                        $this->Controller->form->i['input-pdf-'.$i] = $data[$i]['file-type']['pdf'];
                        $this->Controller->form->i['input-swf-'.$i] = $data[$i]['file-type']['swf'];
                        $this->Controller->form->i['input-doc-'.$i] = $data[$i]['file-type']['doc'];
                        
                        break;
                }
            }
            
        }
        
    
    }
    
}