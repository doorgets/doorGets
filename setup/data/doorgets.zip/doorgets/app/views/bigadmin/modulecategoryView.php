<?php

/*******************************************************************************
/*******************************************************************************
    doorgets 5.0 #!#!#
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class ModuleCategoryView extends doorgetsView{
    
    protected $table;
    protected $uri;
    
    public function __construct($action,$controller,$lg='fr'){
        
        parent::__construct($action,$controller,$lg);
        
    }
    
    public function getContent(){
        
        $out = '';
        
        $lgActuel       = $this->getLangueTradution();
        $moduleInfos    = $this->moduleInfos($this->uri,$lgActuel);
        
        $Rubriques = array(
            
            'index'         => $this->l('Index des catégories'),
            'add'           => $this->l('Ajouter une catégorie'),
            'edit'          => $this->l('Modifier une catégorie'),
            'delete'        => $this->l('Supprimer une catégorie'),
            
        );
        
        // get Content for edit / delete
        $params = $this->Controller->Params();
        if(array_key_exists('id',$params['GET'])){
            
            $id = $params['GET']['id'];
            $isContent = $this->dbQS($id,'_categories');
            
            if(!empty($isContent)){
                
                if($lgGroupe = @unserialize($isContent['groupe_traduction'])){
                    
                    $idLgGroupe = $lgGroupe[$lgActuel];
                    
                    $isContentTraduction = $this->dbQS($idLgGroupe,'_categories_traduction');
                    if(!empty($isContentTraduction)){
                        
                        $isContent = array_merge($isContent,$isContentTraduction);
                        
                    }
                    
                }
                
            }
            
        }
        
        if( array_key_exists($this->Action,$Rubriques) )
        {
            switch($this->Action){
                
                case 'index':
                    
                    $ini = 0;
                    $per = 300;
                    $nbStringCount = '';
                    
                    $lgActuel = $this->getLangueTradution();
                    
                    $arrForCountSearchQuery = array();
                    $arrForCountSearchQuery[] = array('key'=>"_categories.uri_module",'type'=>'=','value'=>$this->uri);
                    
                    $cResultsInt = $this->getCountTable('_categories',$arrForCountSearchQuery);
                    
                    $outSqlJoin = " WHERE _categories_traduction.id_cat = _categories.id
                    AND _categories.uri_module = '".$this->uri."' AND _categories_traduction.langue = '".$lgActuel."'";
                    
                    $sqlLimit = " $outSqlJoin ORDER BY ordre  LIMIT ".$ini.",".$per;
                    $all = $this->dbQA('_categories, _categories_traduction',$sqlLimit);
                    $cAll = count($all);
                    
                    if($cAll > 4){
                        $nbStringCount = '<b>'.$cResultsInt.' '.$this->l('Catégories').'<b>';
                    }
                    
                    $block = new BlockTable();
                    $block->setClassCss('doorgets-listing');
                    
                    if($cAll != 0){
                        
                        $block->addTitle($nbStringCount,'titre','first-title td-title left' );
                        $block->addTitle('','topup','td-title');
                        $block->addTitle('','topbottom','td-title');
                        $block->addTitle('','edit','td-title');
                        $block->addTitle('','delete','td-title');
                        
                        for($i=0;$i<$cAll;$i++){
                            
                            $urlStatut = BASE_IMG.'puce-verte.png';
                            $urlAction = './?controller=modulecategory&uri='.$this->uri.'&id='.$all[$i]['id_cat'].'&lg='.$lgActuel;
                            
                            $urlStatut = '<img src="'.$urlStatut.'" >';
                            
                            $urlVoirTitle = '<a title="'.$this->l('Modifier').'" href="'.$urlAction.'&action=edit">';
                            $urlVoirTitle .= '<img src="'.BASE_IMG.'list-rubrique.png'.'" style="width: 25px;height: 25px;vertical-align: middle;margin-right: 5px;float:left;">';
                            $urlVoirTitle .= $all[$i]['nom'];
                            $urlVoirTitle .= ' ';
                            $urlVoirTitle .= '<span class="doorGets-sub-title-categorie">'.$all[$i]['titre'].'</span></a>';
                            
                            $urlDelete = '<a title="'.$this->l('Supprimer').'" href="'.$urlAction.'&action=delete"><img src="'.BASE_IMG.'supprimer.png'.'" class="img-info " ></a>';
                            $urlEdit = '<a title="'.$this->l('Modifier').'" href="'.$urlAction.'&action=edit"><img src="'.BASE_IMG.'modifier.png'.'" class="img-info " ></a>';
                            
                            $urlMovedown = '';
                            if( $all[$i]['ordre'] != $cResultsInt ){
                                $urlMovedown = $this->movePosition('down','_categories',$all[$i]['id_cat'],$all[$i]['ordre'],$cResultsInt);
                            }
                            $urlMoveup = '';
                            if( $all[$i]['ordre'] != 1 ){
                                $urlMoveup = $this->movePosition('up','_categories',$all[$i]['id_cat'],$all[$i]['ordre'],$cResultsInt);
                            }
                            $dateCreation = GetDate::in($all[$i]['date_creation'],1,$this->myLanguage());
                            
                            
                            
                            $block->addContent('titre',$urlVoirTitle,'' );
                            $block->addContent('topbottom',$urlMovedown,'center');
                            $block->addContent('topup',$urlMoveup,'center');
                            $block->addContent('edit',$urlEdit,'center');
                            $block->addContent('delete',$urlDelete,'center');
                        }
                    
                    }
                    
                    break;
                
                case 'delete':
                    
                    $isArcticleIn = $this->dbQ("SELECT * FROM ".$this->table." WHERE categorie = '".$isContent['id_cat']."' LIMIT 1 ");
                    
                    break;
            }
            
            $ActionFile = 'modules/bigadmin/category/bigadmin_category_'.$this->Action;
            
            $tpl = Template::getView($ActionFile);
            ob_start(); if(is_file($tpl)){ include $tpl; } $out .= ob_get_clean();
            
        }
        
        return $out;
        
    }
    
}