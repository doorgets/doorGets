<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 20, February 2014
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class DashboardView extends doorgetsView{
    
    public function __construct($action,$controller,$lg='fr'){
        
        parent::__construct($action,$controller,$lg);
        
    }
    
    public function getContent(){
        
        $out = '';
        $modules = $allModules = $this->loadModules(true);
        $modulesBlocks = $this->loadModulesBlocks();
        $modulesGenforms = $this->loadModulesGenforms();
        $canAddType = array('blog','news','multipage','video','faq','image','partner','genform');
        $iCountContents = 0;
        
        foreach($modulesGenforms as $k => $v){
            $modulesGenforms[$k]['count']    = $this->getCountTable('_m_'.$v['uri']);
        }
        
        foreach($modules as $k => $v){
            
            $allModules[$k]['url_edit'] = "?controller=modules&action=edit".$v['type']."&id=".$v['id'];
            
            if(!in_array($v['type'],$canAddType)){
                
                unset($modules[$k]);
                $allModules[$k]['count']    = '';
                $allModules[$k]['url']      = "?controller=module".$v['type']."&uri=".$v['uri'];
                
                
            }else{
                
                $allModules[$k]['count']    = $this->getCountTable('_m_'.$v['uri']);
                $allModules[$k]['url']      = "?controller=module".$v['type']."&uri=".$v['uri'];
                
            }
            
            if($v['type'] === 'inbox'){
                
                $allModules[$k]['count']    = $this->getCountTable('_dg_inbox',array(array('key'=>'uri_module','type'=>'=','value'=>$v['uri'])));
                $allModules[$k]['url']      = "?controller=inbox&doorGets_search_filter_q_uri_module=".$v['uri'];
            }
            
            if($v['type'] === 'applicationjob'){
                
                $allModules[$k]['count'] = $this->getCountTable('_dg_applicationjob',array(array('key'=>'uri_module','type'=>'=','value'=>$v['uri'])));
                
            }
            
            $iCountContents += $allModules[$k]['count'];
        }
        
        $Rubriques = array(
            
            'index'         => $this->l('Index de la page'),
            
        );
        
        $liste['page']              = $this->l('Page Statique');
        $liste['multipage']         = $this->l('Multi-Pages Statiques');
        $liste['blog']              = $this->l("Blog");
        $liste['news']              = $this->l("Fil d'actualités");
        $liste['video']             = $this->l('Galerie vidéos');
        $liste['image']             = $this->l("Galerie d'images");
        $liste['faq']               = $this->l('FAQ');
        $liste['partner']           = $this->l('Partenaires');
        $liste['link']              = $this->l('Lien de redirection');
        $liste['inbox']             = $this->l('Formulaire de contact');
        $liste['block']             = $this->l('Bloc Statique');
        $liste['genform']           = $this->l('Formulaire');
        
        $listeInfos = array(
            'block' => array(
                'description' => $this->l('Créer des blocs statiques'),
                'image' => BASE_IMG.'mod_block.png',
            ),
            'page' => array(
                'description' => $this->l('Créer une page simple'),
                'image' => BASE_IMG.'mod_page.png',
            ),
            'multipage' => array(
                'description' => $this->l('Créer plusieurs pages simple'),
                'image' => BASE_IMG.'mod_multipage.png',
            ),
            'news' => array(
                'description' => $this->l("Créer un fil d'actualités"),
                'image' => BASE_IMG.'mod_news.png',
            ),
            'blog' => array(
                'description' => $this->l("Créer un blog"),
                'image' => BASE_IMG.'mod_blog.png',
            ),
            'inbox' => array(
                'description' => $this->l('Un formulaire pour prendre contact avec vous'),
                'image' => BASE_IMG.'mod_inbox.png',
            ),
            'link' => array(
                'description' => $this->l('Lien de redirection à ajouter au menu'),
                'image' => BASE_IMG.'mod_link.png',
            ),
            'video' => array(
                'description' => $this->l('Créer une galerie vidéos youtube'),
                'image' => BASE_IMG.'mod_video.png',
            ),
            'image' => array(
                'description' => $this->l("Créer votre galerie d'images"),
                'image' => BASE_IMG.'mod_image.png',
            ),
            'faq' => array(
                'description' => $this->l('Liste de questions fréquentes'),
                'image' => BASE_IMG.'mod_faq.png',
            ),
            'partner' => array(
                'description' => $this->l('Afficher la liste de vos partenaires'),
                'image' => BASE_IMG.'mod_partner.png',
            ),
            'genform' => array(
                'description' => $this->l('Formulaire'),
                'image' => BASE_IMG.'mod_genform.png',
            ),
        );
        
        if( array_key_exists($this->Action,$Rubriques) )
        {
            switch($this->Action){
                
                case 'index':
                    
                    $filterModules = array(
                        array('key'=>'type','type'=>'!=','value'=>'block'),
                    );
                    $filterValidation = array(
                        array('key'=>'validation','type'=>'=','value'=>'3'),
                    );
                    $filterActive = array(
                        array('key'=>'active','type'=>'=','value'=>'2'),
                    );
                    
                    $iComments = $this->getCountTable('_dg_comments');
                    $iInbox = $this->getCountTable('_dg_inbox');
                    $iModules = count($allModules);
                    $iModulesBlocks = count($modulesBlocks);
                    $iModulesGenforms = count($modulesGenforms);
                    
                    $lastComments = $this->dbQ("SELECT * FROM _dg_comments ORDER BY date_creation DESC LIMIT 10");
                    $lastInbox = $this->dbQ("SELECT * FROM _dg_inbox ORDER BY date_creation DESC LIMIT 10");
                    
                    break;
            }
            
            $ActionFile = 'bigadmin/dashboard/bigadmin_dashboard_'.$this->Action;
            
            $tpl = Template::getView($ActionFile);
            ob_start();
            if(is_file($tpl)){ include $tpl; }
            
            $out .= ob_get_clean();
            
        }
        
        return $out;
        
    }
    
}