<?php

/*******************************************************************************
/*******************************************************************************
    doorgets 5.0 #!#!#
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class Formulaire{
    
    public $name;
    public $i = array();
    public $e = array();
    public $info = array();
    public $isSended;
    public function __construct($name){
        $this->isSended = false;
        $this->name = $name;
        $this->view($name);
    }
    
    public function open($method="post",$action="",$enctype = 'enctype="multipart/form-data"',$class=''){
        
        $name = $this->name;
        if(empty($action)){ $action = $_SERVER['REQUEST_URI']; }
        return '<form '.$enctype.' id="'.$name.'" name="'.$name.'" method="'.$method.'" class="'.$class.'" action="'.$action.'">';
    }
    
    public function close(){
        
        return '</form>';
    
    }
    
    public function recaptcha(){
        
        require_once(LIB.'recaptchalib.php');
        return recaptcha_get_html(RECAPTCHA_PUBLIC_KEY);
        
    }
    
    public function submit($value,$style="",$class=""){
        
        $name = $this->name.'_submit';
        return '<input type="submit" id="'.$name.'" name="'.$name.'" value="'.$value.'" style="'.$style.'" class="'.$class.'" >';
    }
    
    public function input($label,$name,$type="text",$value="",$class=""){
        
        $input = '';
        $valueTemp = $value;
        $name = $this->name.'_'.$name;
        $style = '';
        $styleLabel = '';
        
        if(isset($_POST[$name])){
            $value = $_POST[$name];
            if(!empty($this->e[$name])){
                
                $styleLabel = 'style="color:#ff0000;"';
                $style = 'style="border:solid 2px #ff0000;"';
                $value = $valueTemp;
            }
        }

        if($type !== 'hidden' && !empty($label) ){
            $input .= "\r\n\t\t<label $styleLabel >$label</label>";
        }
        $value = Convertag::in($value);
        $input .= '<input maxlength="220" type="'.$type.'" id="'.$name.'" name="'.$name.'" value="'.$value.'" class="'.$class.'" '.$style.' >';
        return $input;
        
    }
    
    public function inputt($label,$name,$type="text",$value="",$class=""){
        
        $input = '';
        $valueTemp = $value;
        if(!empty($this->name)){
            $name = $this->name.'_'.$name;
        }
        $style = '';
        $styleLabel = '';
        if(isset($_POST[$name])){
            $value = $_POST[$name];
            if(!empty($this->e[$name])){
                $styleLabel = 'style="color:#ff0000;"';
                $style = 'style="border:solid 2px #ff0000;"';
                $value = $valueTemp;
            }
        }
        
        $value = Convertag::in($value);
        $input .= '<input maxlength="220" type="'.$type.'" id="'.$name.'" name="'.$name.'" placeholder="'.$label.'" required="required" value="'.$value.'" class="'.$class.'" '.$style.' >';
        return $input;
        
    }
    public function inputtr($label,$name,$type="text",$value="",$class=""){
        
        $input = '';
        $valueTemp = $value;
        $name = $this->name.'_'.$name;
        $style = '';
        $styleLabel = '';
        if(isset($_POST[$name])){
            $value = $_POST[$name];
            if(!empty($this->e[$name])){
                $styleLabel = 'style="color:#ff0000;"';
                $style = 'style="border:solid 2px #ff0000;"';
                $value = $valueTemp;
            }
        }
        
        $value = Convertag::in($value);
        $input .= '<input maxlength="220" type="'.$type.'" id="'.$name.'" name="'.$name.'" placeholder="'.$label.'" required value="'.$value.'" class="'.$class.'" '.$style.' >';
        return $input;
        
    }
    
    public function file($label,$name,$class=""){
        
        $name = $this->name.'_'.$name;
        $style = '';
        $styleLabel = '';
        
        if(!empty($this->e[$name])){
            
            $styleLabel = ' style="color:#ff0000;" ';
            $style= ' style="border: solid 2px #ff0000;" ';
            
        }
        
        $input = "<label $styleLabel >$label</label>";
        $input .= '<input type="file" id="'.$name.'" name="'.$name.'"  '.$style.' class="'.$class.'" >';
        
        return $input;
        
    }
    
    public function textarea($label,$name,$value="",$class="",$style=''){
        
        $rest = substr($name, -8);
        $restHtml = substr($name, -5); 
        if( ( $rest === '_tinymce' || $restHtml === '_html' ) && !empty($this->i)){
            
            $value = $value ;
            
        }
        if($rest !== '_tinymce' && $restHtml !== '_html'){
            $value = Convertag::in($value);
        }

        $valueTemp = $value;
        $name = $this->name.'_'.$name;
        $style = '';
        $styleLabel = '';
        
        if(isset($_POST[$name])){
            $value = $_POST[$name];
            if(!empty($this->e[$name])){
                $styleLabel = 'style="color:#ff0000;"';
                $style = 'style=" border:solid 2px #ff0000; "';
                $value = $valueTemp;
            }
        }
        
        
        $textarea = '';
        if(!empty($label)){
            $textarea = '<label '.$styleLabel.' >'.$label.'</label>';
        }
        $textarea .= '<textarea id="'.$name.'" name="'.$name.'" class="'.$class.'" '.$style.' >'.$value.'</textarea>';
        
        
        return $textarea;
    }
    
    public function select($label,$name,$option = array(),$value=""){
        
        
        $valueTemp = $value;
        $name = $this->name.'_'.$name;
        $style = '';
        $styleLabel = '';
        $obli = '';
        
        $formName = $this->name;
        
        if(isset($_POST[$name])){
            $value = trim(htmlentities($_POST[$name],ENT_NOQUOTES));
            if(!empty($this->e[$name])){
                $styleLabel = 'style="color:#ff0000;"';
                $style = 'style="border:solid 2px #ff0000;"';
                $value = $valueTemp;
            }
        }
        
        
        $select = "<label $styleLabel >$label</label>";
        
        $select .= "\n\r";
        $select .= '<select name="'.$name.'" id="'.$name.'" '.$style.' >';
        $select .= "\n\r";
        
        if(is_array($option) && !empty($option))
        {
            foreach($option as $k=>$v){
                
                
                $select .="\t".'<option ';
                
                if(!empty($value)){
                    
                    if(strtolower($value) === strtolower($k)){ 
                        $select .=" selected=\"selected\" "; 
                    }
                }
                $select .=" value=\"$k\" >$v</option>";
               
            }
        }
        $select .='</select>';
        
        
        return $select;
        
    }
    
    public function date($label='',$name='',$date = 0,$lg='fr'){
        
        $out = '';
        
        if( empty($date) || !is_numeric($date) ){ $date = time(); }
        
        $jour   = date("j",$date);
        $mois   = date("n",$date);
        $annee  = date("Y",$date);
        $heure  = date("H",$date);
        $minute  = date("i",$date);
        
        $iJour = array();
        for($i=1;$i<=31;$i++){
            
            $z = '';
            if($i<10){ $z='0'; }
            $iJour[$i] = $z.$i;
            
        }
        
        $iMois = array();
        for($i=1;$i<=12;$i++){ 
            
            $z = '';
            if($i<10){ $z='0'; }
            $iMois[$i] = $z.$i;
            
        }
        $years = date("Y",time());
        $yearsTo = $years + 10;
        $iAnnee = array();
        for($i=$years;$i<=$yearsTo;$i++){
            
            $iAnnee[$i] = $i;
            
        }
        
        $iHeure = array();
        for($i=0;$i<=23;$i++){ 
            
            $z = '';
            if($i<10){ $z='0'; }
            $iHeure[$i] = $z.$i;
            
        }
        
        $iMinute = array();
        for($i=0;$i<=59;$i++){ 
            
            $z = '';
            if($i<10){ $z='0'; }
            $iMinute[$i] = $z.$i;
            
        }
        
        $out .= '<label>'.$label.'</label>';
        if($lg == 'fr'){
            
            $out .= $this->select('Jour :'.'',$name.'_jour',$iJour,$jour);
            $out .= $this->select('Mois :'.'',$name.'_mois',$iMois,$mois);
            $out .= $this->select('Année :'.'',$name.'_annee',$iAnnee,$annee);
            $out .= $this->select('<br />Heure :'.'',$name.'_heure',$iHeure,$heure);
            $out .= $this->select('Minute :'.'',$name.'_minute',$iMinute,$minute);
            
        }else{
            
            $out .= $this->select('DD :'.'',$name.'_mois',$iMois,$mois);
            $out .= $this->select('MM :'.'',$name.'_jour',$iJour,$jour);
            $out .= $this->select('YYYY :'.'',$name.'_annee',$iAnnee,$annee);
            $out .= $this->select('<br />HH :'.'',$name.'_heure',$iHeure,$heure);
            $out .= $this->select('MM :'.'',$name.'_minute',$iMinute,$minute);
            
        }
        
        
        return $out;
        
    }   
    
    public function checkbox($label,$name,$value,$checked=""){
        
        $name = $this->name.'_'.$name;
        
        if(
           !empty($checked) || isset($_POST[$name])
        ){ $checked = ' checked="checked" ';}
        
        $style = '';
        $styleLabel = '';
        $obli = '';
        $formName = $this->name;
        
        
        if(!empty($this->e[$name])){
            $styleLabel = 'style="color:#ff0000;"';
            $style = 'style="border:solid 1px #ff0000;padding:2px;text-align:left;"';
        }
        
        $checkbox = '<label '.$styleLabel.' for="'.$name.'" >';
        $checkbox .= '<input type="checkbox" name="'.$name.'" id="'.$name.'" value="'.$value.'" '.$checked.' ><span class="in-check"></span>';
        $checkbox .= ''.$label.'</label>';
        return $checkbox;
        
    }
    
    public function radio($label,$name,$value,$checked=""){
        
        $name = $this->name.'_'.$name;
        
        if(
           (isset($_POST[$name]) && $_POST[$name] === $value)
           || (!empty($checked) && $checked === $value)
        ){
            $checked = ' checked="checked" ';
        }
        
        $style = '';
        $styleLabel = '';
        $obli = '';
        $formName = $this->name;
        
        
        if(!empty($this->e[$name])){
            $styleLabel = 'style="color:#ff0000;"';
            $style = 'style="border:solid 1px #ff0000;padding:2px;text-align:left;"';
        }
        
        $radioBox = '<label '.$styleLabel.' for="'.$name.'_'.$value.'" >';
        $radioBox .= '<input type="radio" name="'.$name.'" id="'.$name.'_'.$value.'" value="'.$value.'" '.$checked.' >';
        $radioBox .= ' '.$label.'</label>';
        return $radioBox;
        
    }
    
    public function view($nameForm){
        
        $name = $nameForm;
        $isView = null;
        if(!empty($_POST)){
            
            // recaptcha verification
            require_once(LIB.'recaptchalib.php');
            if (
                array_key_exists('recaptcha_challenge_field',$_POST)
                && array_key_exists('recaptcha_response_field',$_POST)
            ){
                $resp = recaptcha_check_answer (RECAPTCHA_PRIVATE_KEY,
                    $_SERVER["REMOTE_ADDR"],
                    $_POST["recaptcha_challenge_field"],
                    $_POST["recaptcha_response_field"]
                );
                
                if (!$resp->is_valid) { $this->e['recaptcha_error'] = 'ok'; }
                
            }
            
            // $_POST checking
            foreach($_POST as $k=>$v){
                
                $rest = substr($k, -8);
                $restHtml = substr($k, -5);
                if($rest !== '_tinymce' && $restHtml !== '_html'){
                    
                    $_POST[$k] = filter_input(INPUT_POST, $k, FILTER_SANITIZE_STRING) ;
                    
                }
            }
            
            // onclic submit form
            if(isset($_POST[$nameForm.'_submit'])){
                
                unset($_POST[$nameForm.'_submit']);
                
                foreach($_POST as $k=>$v){
                    
                    $rest = substr($k, -8);
                    $restHtml = substr($k, -5);
                    if($rest === '_tinymce' || $restHtml === '_html'){
                        
                        if( !empty($this->i) && empty($this->e) ){
                            
                            $k = str_replace($nameForm.'_','',$k);
                            //$_POST[$k] = stripcslashes($_POST[$k]);
                            $this->i[$k] = htmlentities($v,ENT_QUOTES);
                        }
                        
                    }else{
                        
                        $k = str_replace($nameForm.'_','',$k);
                        $this->i[$k] = Convertag::get($v);
                        
                    }
                    
                }
            }
            
            // reset recaptcha
            if( array_key_exists('recaptcha_response_field',$this->i) )
            { unset($this->i["recaptcha_response_field"]); }
            
            if( array_key_exists('recaptcha_challenge_field',$this->i) )
            { unset($this->i["recaptcha_challenge_field"]); }
            
        }
    }
    

}
