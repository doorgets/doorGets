<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 07, February 2014
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class doorgetsModuleView extends doorgetsView{
    
    public function __construct($action,$controller,$lg='fr'){
        
        parent::__construct($action,$controller,$lg);
        $this->categorie = $this->loadCategories($this->uri);
        
        
    }
    
    public function getContent(){
        
        $out = '';
        
        $lgActuel       = $this->getLangueTradution();
        $moduleInfos    = $this->moduleInfos($this->uri,$lgActuel);
        $listeCategories = $this->categorieSimple;
        unset($listeCategories[0]);
        $aActivation = $this->getArrayForms('activation');
        
        $Rubriques = array(
            
            'index'         => $this->l('Index'),
            'add'           => $this->l('Ajouter'),
            'edit'          => $this->l('Modifier'),
            'delete'        => $this->l('Supprimer'),
            'massdelete'    => $this->l('Supprimer par groupe'),
            
        );
        
        // get Content for edit / delete
        $params = $this->Controller->Params();
        if(array_key_exists('id',$params['GET'])){
            
            $id = $params['GET']['id'];
            $isContent = $this->dbQS($id,$this->table);
            
            if(!empty($isContent)){
                
                if($lgGroupe = @unserialize($isContent['groupe_traduction'])){
                    
                    $idLgGroupe = $lgGroupe[$lgActuel];
                    
                    $isContentTraduction = $this->dbQS($idLgGroupe,$this->table.'_traduction');
                    if(!empty($isContentTraduction)){
                        
                        $isContent = array_merge($isContent,$isContentTraduction);
                        
                    }
                    
                }
                
                $idNextContent      = $this->getIdContentPosition($isContent['id_content']);
                $idPreviousContent  = $this->getIdContentPosition($isContent['id_content'],'prev');
                
                $urlPrevious = '';
                if(!empty($idPreviousContent)){
                    $urlPrevious = '?controller='.$this->Controller->controllerName.'&uri='.$this->uri.'&action=edit&id='.$idPreviousContent.'&lg='.$lgActuel;
                }
                $urlNext = '';
                if(!empty($idNextContent)){
                    $urlNext = '?controller='.$this->Controller->controllerName.'&uri='.$this->uri.'&action=edit&id='.$idNextContent.'&lg='.$lgActuel;
                }
            }
            
        }
        
        
        if( array_key_exists($this->Action,$Rubriques) )
        {
            switch($this->Action){
                
                case 'index':
                    
                    if(!empty($this->uri) && !empty($this->table)){
                        
                        $q = '';
                        $urlSearchQuery = '';
                        
                        $p = 1;
                        $ini = 0;
                        $per = 10;
                        
                        $params = $this->Controller->Params();
                        $lgActuel = $this->getLangueTradution();
                        
                        $isFieldArray       = array(
                            
                            "titre"=>$this->l('Titre'),
                            "active"=>$this->l('Statut'),
                            "date_creation"=>$this->l('Date'),
                            "ordre"=>$this->l('Position')
                        );
                        
                        $isFieldArraySort   = array('ordre','active','titre','date_creation',);
                        $isInClassicTable   = array('ordre','active');
                        $isFieldArraySearch = array('titre','active','date_creation_start','date_creation_end',);
                        $isFieldArrayDate   = array('date_creation');
                        
                        $urlOrderby         = '&orderby='.$isFieldArraySort[0];
                        $urlSearchQuery     = '';
                        $urlSort            = '&desc';
                        $urlLg              = '&lg='.$lgActuel;
                        $urlCategorie       = '';
                        $urlGroupBy         = '&gby='.$per;
                        
                        // Init table query
                        $tAll = $this->table." , ".$this->table."_traduction "; 
                        
                        // Create query search for mysql
                        $sqlLabelSearch = '';
                        $arrForCountSearchQuery = array();
                        $arrForCountSearchQuery[] = array('key'=>$this->table."_traduction.id_content",'type'=>'!=!','value'=>$this->table.".id");
                        $arrForCountSearchQuery[] = array('key'=>$this->table."_traduction.langue",'type'=>'=','value'=>$lgActuel);
                        
                        // Init Query Search
                        $aGroupeFilter = array();
                        if(!empty($isFieldArraySearch)){
                            
                            // Récupére les paramêtres du get et post pour la recherche par filtre
                            foreach($isFieldArraySearch as $v)
                            {
                                
                                $valueQP = '';
                                if(
                                    array_key_exists('doorGets_search_filter_q_'.$v,$params['GET'])
                                    && !empty($params['GET']['doorGets_search_filter_q_'.$v])
                                ){
                                    
                                    $valueQP = trim($params['GET']['doorGets_search_filter_q_'.$v]);
                                    $aGroupeFilter['doorGets_search_filter_q_'.$v] = $valueQP;
                                    
                                }
                                
                                if(
                                    array_key_exists('doorGets_search_filter_q_'.$v,$params['POST'])
                                    && !array_key_exists('doorGets_search_filter_q_'.$v,$params['GET'])
                                    && !empty($params['POST']['doorGets_search_filter_q_'.$v])
                                ){
                                    
                                    $valueQP = trim($params['POST']['doorGets_search_filter_q_'.$v]);
                                    $aGroupeFilter['doorGets_search_filter_q_'.$v] = $valueQP;
                                    
                                }
                                
                                if(
                                    ( array_key_exists('doorGets_search_filter_q_'.$v,$params['GET'])
                                        && !empty($params['GET']['doorGets_search_filter_q_'.$v])
                                    )
                                    ||
                                    ( array_key_exists('doorGets_search_filter_q_'.$v,$params['POST'])
                                        && !array_key_exists('doorGets_search_filter_q_'.$v,$params['GET'])
                                        && !empty($params['POST']['doorGets_search_filter_q_'.$v])
                                    )
                                ){
                                    
                                    
                                    if(!empty($valueQP)){
                                        
                                        $valEnd = str_replace('_start','',$v);
                                        $valEnd = str_replace('_end','',$v);
                                        
                                        if(in_array($valEnd,$isFieldArrayDate)){
                                            if(
                                                array_key_exists('doorGets_search_filter_q_'.$v,$params['GET'])
                                                && !empty($params['GET']['doorGets_search_filter_q_'.$v])
                                            ){
                                                $fromFormat = trim($params['GET']['doorGets_search_filter_q_'.$valEnd.'_start']);
                                                $toFormat = trim($params['GET']['doorGets_search_filter_q_'.$valEnd.'_end']);
                                                
                                            }else{
                                                $fromFormat = trim($params['POST']['doorGets_search_filter_q_'.$valEnd.'_start']);
                                                $toFormat = trim($params['POST']['doorGets_search_filter_q_'.$valEnd.'_end']);
                                            }
                                            
                                            
                                            if(!empty($fromFormat))
                                            { $from = strtotime($fromFormat);  }
                                            
                                            if(!empty($toFormat))
                                            {  $to = strtotime($toFormat); $to = $to + ( 60 * 60 * 24 ); }
                                            
                                            if(strlen(str_replace('_end','',$v)) !== strlen($v)){
                                                
                                                $nameTable = $this->table.".".$valEnd;
                                                
                                                $sqlLabelSearch .= $nameTable." >= $from AND ";
                                                $sqlLabelSearch .= $nameTable." <= $to AND ";
                                                
                                                $arrForCountSearchQuery[] = array('key'=>$nameTable,'type'=>'>','value'=>$from);
                                                $arrForCountSearchQuery[] = array('key'=>$nameTable,'type'=>'<','value'=>$to);
                                                
                                                $urlSearchQuery .= '&doorGets_search_filter_q_'.$valEnd.'_end='.$toFormat;
                                            }
                                            
                                        }else{
                                            
                                            if(in_array($v,$isInClassicTable))
                                            {
                                                
                                                $sqlLabelSearch .= $this->table.".".$v." LIKE '%".$valueQP."%' AND ";
                                                $arrForCountSearchQuery[] = array('key'=>$this->table.".".$v,'type'=>'like','value'=>$valueQP);
                                                
                                            }elseif(in_array($v,$isFieldArraySort)){
                                                
                                                $sqlLabelSearch .= $this->table."_traduction.".$v." LIKE '%".$valueQP."%' AND ";
                                                $arrForCountSearchQuery[] = array('key'=>$this->table."_traduction.".$v,'type'=>'like','value'=>$valueQP);
                                            }
                                            
                                            $urlSearchQuery .= '&doorGets_search_filter_q_'.$valEnd.'='.$valueQP;
                                        }
                                    }
                                }
                                
                            }
                            
                            // préparation de la requête mysql
                            if(!empty($sqlLabelSearch)){
                                
                                $sqlLabelSearch = substr($sqlLabelSearch,0,-4);
                                $sqlLabelSearch = " AND ( $sqlLabelSearch ) ";
                                
                            }
                            
                        }
                        
                        // Init Group By
                        if(
                            array_key_exists('gby',$params['GET'])
                            && is_numeric($params['GET']['gby'])
                            && $params['GET']['gby'] < 300
                        ){
                            
                            $per        = $params['GET']['gby'];
                            $urlGroupBy = '&gby='.$per;
                            
                        }
                        
                        // Init count total fields
                        $cResultsInt = $this->getCountTable($tAll,$arrForCountSearchQuery);
                        
                        // Init categorie
                        $sqlCategorie = '';
                        
                        if(
                            array_key_exists('categorie',$params['GET'])
                            && !empty($params['GET']['categorie'])
                            && array_key_exists($params['GET']['categorie'],$this->categorieSimple)
                        ){
                            
                            
                            $getCategorie = $params['GET']['categorie'];
                            
                            $arrForCountSearchQuery[] = array('key'=>$this->table.'.categorie','type'=>'like','value'=>$getCategorie.',');
                            
                            $cResultsInt = $this->getCountTable($tAll,$arrForCountSearchQuery);
                            
                            $sqlCategorie = " AND ".$this->table.".categorie LIKE '%".$getCategorie.",%'";
                            $urlCategorie = '&categorie='.$getCategorie;
                            
                        }
                        
                        // Init sort 
                        $getDesc = 'DESC';
                        $getSort = '&asc';
                        if(isset($_GET['asc']))
                        {
                            $getDesc = 'ASC';
                            $getSort = '&desc';
                            $urlSort = '&asc';
                        }
                        
                        // Init filter for order by 
                        $outFilterORDER = $this->table.'_traduction.date_creation  '.$getDesc;
                        
                        $getFilter = '';
                        if(
                            array_key_exists('orderby',$params['GET'])
                            && !empty($params['GET']['orderby'])
                            && in_array($params['GET']['orderby'],$isFieldArraySort)
                        ){
                            
                            $getFilter      = $params['GET']['orderby'];
                            
                            $outFilterORDER = $this->table.'_traduction.'.$getFilter.'  '.$getDesc;
                            
                            // Execption for field that not in traduction table
                            if( in_array($getFilter,$isInClassicTable) )
                            {
                                $outFilterORDER = $this->table.'.'.$getFilter.'  '.$getDesc;
                            }
                            
                            $urlOrderby     = '&orderby='.$getFilter;
                            
                        }
                        
                        // Init page position
                        if(
                            array_key_exists('page',$params['GET'])
                            && is_numeric($params['GET']['page'])
                            && $params['GET']['page'] <= (ceil($cResultsInt / $per))
                        ){
                            
                            $p = $params['GET']['page'];
                            $ini = $p * $per - $per;
                        }
                        
                        $finalPer = $ini+$per;
                        if( $finalPer >  $cResultsInt){
                            $finalPer = $cResultsInt;
                        }
                        
                        // Create sql query for transaction
                        $outSqlGroupe = " WHERE ".$this->table."_traduction.id_content = ".$this->table.".id
                        AND ".$this->table."_traduction.langue = '".$lgActuel."' ".$sqlCategorie." ".$sqlLabelSearch;
                        $sqlLimit = " $outSqlGroupe ORDER BY $outFilterORDER  LIMIT ".$ini.",".$per;
                        
                        // Create url to go for pagination
                        $urlPage = "./?controller=module".$moduleInfos['type']."&uri=".$this->uri.$urlCategorie.$urlOrderby.$urlSearchQuery.$urlSort.$urlGroupBy.$urlLg.'&page=';
                        $urlPagePosition = "./?controller=module".$moduleInfos['type']."&uri=".$this->uri.$urlCategorie.$urlOrderby.$urlSearchQuery.$urlSort.$urlLg.'&page='.$p;
                        // Generate the pagination system
                        $valPage = '';
                        if($cResultsInt > $per){
                            
                            $valPage = Pagination::page($cResultsInt,$p,$per,$urlPage);
                            
                        }
                        
                        // Select all contents / Query SQL
                        $all = $this->dbQA($tAll,$sqlLimit);
                        $cAll = count($all);
                        
                        /**********
                         *
                         *  Start block creation for listing fields
                         * 
                         **********/
                        
                        $block = new BlockTable();
                        
                        $imgTop = '<div class="d-top"></div>';
                        $imgBottom= '<div class="d-bottom"></div>';
                        $block->setClassCss('doorgets-listing');
                        
                        $iPos = 0;
                        $dgSelMass = '';
                        $urlPage = "./?controller=module".$moduleInfos['type']."&uri=".$this->uri.$urlCategorie."&lg=$lgActuel&page=";
                        $urlPageGo = './?controller=module'.$moduleInfos['type'].'&uri='.$this->uri.$urlCategorie.'&lg='.$lgActuel;
                        
                        $block->addTitle($dgSelMass,'sel_mass','td-title');
                        foreach($isFieldArray as $fieldName=>$fieldNameLabel){
                            
                            $_css   = '_css_'.$fieldName;
                            $_img   = '_img_'.$fieldName;
                            $_desc  = '_desc_'.$fieldName;
                            
                            $$_css = $$_img = $$_desc = $leftFirst = '';
                            
                            if(
                                $getFilter === $fieldName
                                || ( empty($getFilter) && $fieldName === $isFieldArraySort[0] )
                            ){
                                $$_css = ' class="green" ';
                                $$_img = $imgTop;
                                $$_desc = $getSort;
                                if($getDesc === 'ASC'){
                                    $$_img = $imgBottom;
                                    $$_desc = '';
                                }
                            }
                            
                            if($iPos === 0){
                                $leftFirst = 'first-title left';
                            }
                            
                            $dgLabel = $fieldNameLabel;
                            if(in_array($fieldName,$isFieldArraySort))
                            {
                                $dgLabel = '<a href="'.$urlPageGo.'&orderby='.$fieldName.$urlSearchQuery.'&gby='.$per.$$_desc.'" '.$$_css.'  >'.$$_img.$fieldNameLabel.'</a>';
                            }
                            
                            $block->addTitle($dgLabel,$fieldName,"$leftFirst td-title center");
                            $iPos++;
                            
                        }
                        
                        if($getFilter === 'ordre' && empty($urlCategorie) )
                        {
                            $block->addTitle('','topup','td-title');
                            $block->addTitle('','topbottom','td-title');                            
                        }

                        $block->addTitle('','edit','td-title');
                        $block->addTitle('','delete','td-title');
                        
                        $arFilterActivation = $this->getArrayForms('activation');
                        
                        $valFilterTitre = '';
                        if(array_key_exists('doorGets_search_filter_q_titre',$aGroupeFilter)){
                            $valFilterTitre = $aGroupeFilter['doorGets_search_filter_q_titre'];
                        }
                        
                        $valFilterActive = 0;
                        if(array_key_exists('doorGets_search_filter_q_active',$aGroupeFilter)){
                            $valFilterActive = $aGroupeFilter['doorGets_search_filter_q_active'];
                        }
                        
                        $valFilterDateStart = '';
                        if(array_key_exists('doorGets_search_filter_q_date_creation_start',$aGroupeFilter)){
                            $valFilterDateStart = $aGroupeFilter['doorGets_search_filter_q_date_creation_start'];
                        }
                        
                        $valFilterDateEnd = '';
                        if(array_key_exists('doorGets_search_filter_q_date_creation_end',$aGroupeFilter)){
                            $valFilterDateEnd = $aGroupeFilter['doorGets_search_filter_q_date_creation_end'];
                        }
                        
                        $sFilterActive  = $this->Controller->form['_search_filter']->select('','q_active',$arFilterActivation,$valFilterActive);
                        $sFilterTitre   = $this->Controller->form['_search_filter']->input('','q_titre','text',$valFilterTitre);
                        $sFilterDate    = $this->Controller->form['_search_filter']->input('','q_date_creation_start','text',$valFilterDateStart,'doorGets-date-input datepicker-from');
                        $sFilterDate    .= $this->Controller->form['_search_filter']->input('','q_date_creation_end','text',$valFilterDateEnd,'doorGets-date-input datepicker-to');
                        
                        // Search
                        $urlMassdelete = '<input type="checkbox" class="check-me-mass-all" />';
                        $urlMassdelete = '';
                        
                        $block->addContent('sel_mass',$urlMassdelete );
                        $block->addContent('titre',$sFilterTitre );
                        $block->addContent('active',$sFilterActive ,'center');
                        $block->addContent('date_creation',$sFilterDate,'center');
                        $block->addContent('ordre','--','center');
                        if($getFilter === 'ordre' && empty($urlCategorie) )
                        {
                            $block->addContent('topbottom','--','center');
                            $block->addContent('topup','--','center');
                        }
                        $block->addContent('edit','--','center');
                        $block->addContent('delete','--','center');
                        
                        // end Seach
                        
                        if(empty($cAll)){
                            
                            $block->addContent('sel_mass','' );
                            $block->addContent('titre','' );
                            $block->addContent('active','' ,'center');
                            $block->addContent('date_creation','','center');
                            $block->addContent('ordre','','center');
                            if($getFilter === 'ordre' && empty($urlCategorie) )
                            {
                                $block->addContent('topbottom','--','center');
                                $block->addContent('topup','--','center');
                            }
                            $block->addContent('edit','','center');
                            $block->addContent('delete','','center');
                            
                        }
                        
                        for($i=0;$i<$cAll;$i++){
                            
                            $ImageStatut = BASE_IMG.'puce-rouge.png';
                            if($all[$i]['active'] == '2')
                            {
                                
                                $ImageStatut = BASE_IMG.'puce-verte.png';
                                
                            }elseif($all[$i]['active'] == '3'){
                                
                                $ImageStatut = BASE_IMG.'puce-orange.png';
                                
                            }elseif($all[$i]['active'] == '4'){
                                
                                $ImageStatut = BASE_IMG.'icone_redaction.png';
                                
                            }
                            $urlStatut = '<img src="'.$ImageStatut.'" style="vertical-align: middle;" >';
                            
                            $urlMassdelete = '<input id="'.$all[$i]["id_content"].'" type="checkbox" class="check-me-mass" >';
                            $urlTitle = '<a title="'.$this->l('Modifier').'" href="./?controller=module'.$moduleInfos['type'].'&uri='.$this->uri.'&action=edit&id='.$all[$i]['id_content'].'&lg='.$lgActuel.'">'.$all[$i]["titre"].'</a>';
                            $urlDelete = '<a title="'.$this->l('Supprimer').'" href="./?controller=module'.$moduleInfos['type'].'&uri='.$this->uri.'&action=delete&id='.$all[$i]['id_content'].'&lg='.$lgActuel.'"><b class="glyphicon glyphicon-remove"></b></a>';
                            $urlEdit = '<a title="'.$this->l('Modifier').'" href="./?controller=module'.$moduleInfos['type'].'&uri='.$this->uri.'&action=edit&id='.$all[$i]['id_content'].'&lg='.$lgActuel.'"><b class="glyphicon glyphicon-pencil"></b></a>';
                            $urlMovedown = '';
                            if( $all[$i]['ordre'] != $cResultsInt ){
                                $urlMovedown = $this->movePosition('down',$this->table,$all[$i]['id_content'],$all[$i]['ordre'],$cResultsInt);
                            }
                            $urlMoveup = '';
                            if( $all[$i]['ordre'] != 1 ){
                                $urlMoveup = $this->movePosition('up',$this->table,$all[$i]['id_content'],$all[$i]['ordre'],$cResultsInt);
                            }
                            $dateCreation = GetDate::in($all[$i]['date_creation'],1,$this->myLanguage());
                            
                            $block->addContent('sel_mass',$urlMassdelete );
                            $block->addContent('titre',$urlTitle );
                            $block->addContent('active',$urlStatut ,' center');
                            $block->addContent('date_creation',$dateCreation,'center');
                            $block->addContent('ordre',$all[$i]["ordre"],'tb-30 center');
                            if($getFilter === 'ordre' && empty($urlCategorie) )
                            {
                                $block->addContent('topbottom',$urlMovedown,'tb-30 center');
                                $block->addContent('topup',$urlMoveup,'tb-30 center');
                            }
                            $block->addContent('edit',$urlEdit,'tb-30 center');
                            $block->addContent('delete',$urlDelete,'tb-30 center');
                            
                        }
                        
                        $formMassDelete = '';
                        $fileFormMassDelete = 'modules/'.$this->Controller->thisController->zoneArea().'/'.$this->Controller->thisController->zoneArea().'_form_massdelete';
                        $tplFormMassDelete = Template::getView($fileFormMassDelete);
                        ob_start(); if(is_file($tplFormMassDelete)){ include $tplFormMassDelete;} $formMassDelete = ob_get_clean();
                        
                        /**********
                         *
                         *  End block creation for listing fields
                         * 
                         */
                        
                    }
                    
                    break;
                
                case 'add':
                    
                    unset($aActivation[3]);
                    
                    $formAddTop = $formAddBottom = '';
                    $fileFormAddTop = 'modules/'.$this->Controller->thisController->zoneArea().'/'.$this->Controller->thisController->zoneArea().'_form_add_top';
                    $tplFormAddTop = Template::getView($fileFormAddTop);
                    ob_start(); if(is_file($tplFormAddTop)){ include $tplFormAddTop; } $formAddTop = ob_get_clean();
                    
                    $fileFormAddBottom = 'modules/'.$this->Controller->thisController->zoneArea().'/'.$this->Controller->thisController->zoneArea().'_form_add_bottom';
                    $tplFormAddBottom = Template::getView($fileFormAddBottom);
                    ob_start(); if(is_file($tplFormAddBottom)){ include $tplFormAddBottom;} $formAddBottom = ob_get_clean();
                    
                    break;
                
                case 'edit':
                    
                    $isActiveContent =  $isActiveComments =  $isActiveEmail = '';
                    $isActivePartage =  $isActiveFacebook =   $isActiveDisqus =  $isActiveRss = '';
                    
                    if(!empty($isContent['active'])){ $isActiveContent = 'checked'; }
                    if(!empty($isContent['comments'])){ $isActiveComments = 'checked'; }
                    if(!empty($isContent['partage'])){ $isActivePartage = 'checked'; }
                    if(!empty($isContent['mailsender'])){ $isActiveEmail = 'checked'; }
                    if(!empty($isContent['facebook'])){ $isActiveFacebook = 'checked'; }
                    if(!empty($isContent['in_rss'])){ $isActiveRss = 'checked'; }
                    if(!empty($isContent['disqus'])){ $isActiveDisqus = 'checked'; }
                    
                    $formEditTop = $formEditBottom = '';
                    $fileFormEditTop = 'modules/'.$this->Controller->thisController->zoneArea().'/'.$this->Controller->thisController->zoneArea().'_form_edit_top';
                    $tplFormEditTop = Template::getView($fileFormEditTop);
                    ob_start(); if(is_file($tplFormEditTop)){ include $tplFormEditTop; } $formEditTop = ob_get_clean();
                    
                    $fileFormEditBottom = 'modules/'.$this->Controller->thisController->zoneArea().'/'.$this->Controller->thisController->zoneArea().'_form_edit_bottom';
                    $tplFormEditBottom = Template::getView($fileFormEditBottom);
                    ob_start(); if(is_file($tplFormEditBottom)){ include $tplFormEditBottom;} $formEditBottom = ob_get_clean();
                    
                    break;
                
                case 'delete':
                    
                    $formDelete = '';
                    $fileFormDelete = 'modules/'.$this->Controller->thisController->zoneArea().'/'.$this->Controller->thisController->zoneArea().'_form_delete';
                    $tplFormDelete = Template::getView($fileFormDelete);
                    ob_start(); if(is_file($tplFormDelete)){ include $tplFormDelete;} $formDelete = ob_get_clean();
                    
                    break;
                
                case 'massdelete': 
                    
                    $varListeFile = '';
                    $cListe = 0;
                    
                    if(
                        array_key_exists('module'.$moduleInfos['type'].'_massdelete_groupe_delete',$_POST)
                    ){
                        
                        $varListeFile = filter_input(INPUT_POST,'module'.$moduleInfos['type'].'_massdelete_groupe_delete',FILTER_SANITIZE_STRING);
                        $ListeForDeleted = $this->_toArray($_POST['module'.$moduleInfos['type'].'_massdelete_groupe_delete']);
                        $cListe = count($ListeForDeleted);
                        
                    }
                    
                    $formMassDeleteIndex = '';
                    $fileFormMassDeleteIndex = 'modules/'.$this->Controller->thisController->zoneArea().'/'.$this->Controller->thisController->zoneArea().'_form_massdelete_index';
                    $tplFormMassDeleteIndex = Template::getView($fileFormMassDeleteIndex);
                    ob_start(); if(is_file($tplFormMassDeleteIndex)){ include $tplFormMassDeleteIndex;} $formMassDeleteIndex = ob_get_clean();
                    
                    break;
                
            }
            
            $ActionFile = 'modules/'.$this->Controller->thisController->zoneArea().'/'.$this->Controller->controllerName.'/'.$this->Controller->thisController->zoneArea().'_'.$this->Controller->controllerName.'_'.$this->Action;
            $tpl = Template::getView($ActionFile);
            ob_start(); if(is_file($tpl)){ include $tpl; } $out .= ob_get_clean();
            
        }
        
        return $out;
        
    }
    
}