<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 04 December, 2013
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class doorgetsBackups extends Langue{
    
    private $files;
    
    private $fileName;
    
    public $doorgetsController;
    
    public $html;
    
    public function __construct($obj){
        
	if(!is_object($obj)){ return null; }
        $this->doorgetsController = $obj->Controller;
	
	
        $dir = BASE."io/";
	$this->files = $obj->files($dir);
	
	$isOut = true;
	
	$params = $obj->Controller->thisController->Params();
	if(array_key_exists('do',$params['GET'])){
	    
	    $actionBackups = $params['GET']['do'];
	    if(array_key_exists('file',$params['GET']) && in_array($params['GET']['file'],$this->files)){
		$this->fileName = $params['GET']['file'];
		
		
	    }
	    if(!empty($params['GET']['file']) && !in_array($params['GET']['file'],$this->files)){
		header('Location:./?controller=configuration&action=backups'); exit();
	    }
	    
	    $translate = $this->doorgetsController->thisController;
	    
	    switch($actionBackups){
		
		case 'create':
		    
		    $isOut = false;
		    $obj->controller->thisController->form['backups_create'] = new Formulaire('backups_create');
		    $this->html = $this->getHtmlCreateBackup();
		    break;
		
		case 'install':
		    
		    if(!empty($this->fileName)){
			$isOut = false;
			$obj->controller->thisController->form['backups_install'] = new Formulaire('backups_install');
			$this->html = $this->getHtmlInstallBackup();			
		    }

		    break;
		
		case 'delete':
		    
		    if(!empty($this->fileName)){
			
			$isOut = false;
			$obj->form['backups_delete'] = new Formulaire('backups_delete');
			$this->html = $this->getHtmlDeleteBackup();
		    }
		    break;
	    }
	    
	}
	   
	if($isOut){
	    $this->html = $this->getHtmlIndex();
	    
	}
	
	
	
    }
    
    public function getHtml(){
	return $this->html;
    }
    
    public function getFiles(){
	return $this->files;
    }
    
    public function getFileName(){
	
	if(!empty($this->fileName)){
	    $fileName = (int)trim(str_replace('.zip','',$this->fileName));
	    $this->fileName = GetDate::in($fileName).' / '.$this->fileName;
	}
	
	return $this->fileName;
    }
    
    private function getHtmlIndex(){
	
	$translate = $this->doorgetsController->thisController;
	
	$allFiles = $this->getFiles();
	/**********
	 *
	 *  Start block creation for listing fields
	 * 
	 **********/
	if(!empty($allFiles)){
	    
	    $block = new BlockTable();
	    $block->setClassCss('doorgets-listing');
	    
	    $block->addTitle('','title','first-title td-title');
	    $block->addTitle('','size','td-title');
	    $block->addTitle('','download','td-title');
	    $block->addTitle('','install','td-title');
	    $block->addTitle('','delete','td-title');
	    
	    $allFiles = array_reverse($allFiles);
	    
	    foreach($allFiles as $k=>$v){
		
		    $dt = (int)trim(str_replace('.zip','',$v));
		    $date = GetDate::in($dt).' / '.$v;
		    $sizeFile = 0;
		    if(is_file(BASE.'io/'.$v)){  $sizeFile = filesize(BASE.'io/'.$v); }
		    
		    $linkDownload 	= '<a href="'.URL.'io/'.$v.'" >'.$translate->l('Telecharger').'</a>';
		    $linkInstall 	= '<a href="?controller=configuration&action=backups&do=install&file='.$v.'" >'.$translate->l('Installer').'</a>';
		    $linkDelete 	= '<a href="?controller=configuration&action=backups&do=delete&file='.$v.'" >'.$translate->l('Supprimer').'</a>';
		    
		    $block->addContent('title','<img src="'.BASE_IMG.'icone_save.png" class="ico-image" > '.$date,'first-title td-title');
		    $block->addContent('size','<div>'.number_format(((int)$sizeFile/1000000),2,',',' ').'..Mo </div>','td-title');
		    $block->addContent('download',$linkDownload,'td-title');
		    $block->addContent('install',$linkInstall,'td-title');
		    $block->addContent('delete',$linkDelete,'td-title');
		    
	    } 
	}
	
	$fTpl = Template::getView('bigadmin/configuration/backups/bigadmin_configuration_backups_index');
    	ob_start(); include $fTpl; $out = ob_get_clean();
	
	return $out;
	
    }
    
    public function getHtmlCreateBackup(){
	
	$form = $this->doorgetsController->form['backups_create'];
	$translate = $this->doorgetsController->thisController;
	$fTpl = Template::getView('bigadmin/configuration/backups/bigadmin_configuration_backups_create');
    	ob_start(); include $fTpl; $out = ob_get_clean();
	
	return $out;
	
    }
    
    public function getHtmlInstallBackup(){
	
	$form = $this->doorgetsController->form['backups_install'];
	$translate = $this->doorgetsController->thisController;
	$fTpl = Template::getView('bigadmin/configuration/backups/bigadmin_configuration_backups_install');
    	ob_start(); include $fTpl; $out = ob_get_clean();
	
	return $out;
	
    }
    
    public function getHtmlDeleteBackup(){
	
	$form = $this->doorgetsController->form['backups_delete'];
	$translate = $this->doorgetsController->thisController;
	$fTpl = Template::getView('bigadmin/configuration/backups/bigadmin_configuration_backups_delete');
    	ob_start(); include $fTpl; $out = ob_get_clean();
	
	return $out;
	
    }
    
    
    
}