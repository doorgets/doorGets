<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 5.2 - 13, January 2014
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class doorgetsWebsite extends Langue{
    
    private   $theme;
    
    private   $uri;
    
    private   $Params        = array();
    
    private   $activeModules = array();
    
    private   $module;
    
    private   $category;
    
    private   $contentView;
    
    private   $content;
    
    private   $position;
    
    private   $label;
    
    private   $type;
    
    private   $rubriques    = array();
    
    private   $meta         = array();
    
    public    $form         = array();
    
    public    $Controller;
    
    protected $htmlContent;
    
    public function __construct($lg = ''){
        
        $lgTemp = $lg;
        if(empty($lg)){            
            $db = new CRUD();
            $isWebsite = $db->dbQS(1,'_website');
            if(!empty($isWebsite) ){
                
                $lgTemp = $isWebsite['langue_front'];
                $isWebsite['langue_groupe'] = unserialize($isWebsite['langue_groupe']);
                $isWebsite['langue_groupe'][$lgTemp] = $lgTemp;
                $urlToRedirect = URL.'t/'.$lgTemp;
                $cLangues = count($isWebsite['langue_groupe']);
                if($cLangues === 1){
                    $urlToRedirect = URL;
                }
                if($cLangues > 1){
                    header('HTTP/1.1 301 Moved Permanently', false, 301);
                    header('Location: '.$urlToRedirect); exit();    
                }
                
            }    
        }
        
        parent::__construct($lgTemp);
        
        if(!empty($lg) && array_key_exists($lgTemp,$this->allLanguages))
        {
            $this->configWeb['langue_front'] = $lgTemp;
        }
        
        if(!empty($lg) && count($this->allLanguagesWebsite) === 1)
        {
            header('HTTP/1.1 301 Moved Permanently', false, 301);
            header('Location: '.URL); exit();
        }
        
        
        if(
            !array_key_exists($this->configWeb['langue_front'],$this->configWeb['langue_groupe'])
            && empty($this->allLanguagesWebsite)
        ){
            header('Location:'.URL.'#'); exit();
        }
        
        $this->myLanguage           = $this->configWeb['langue_front'];
        $this->module               = $this->configWeb['module_homepage'];
        $this->theme                = $this->configWeb['theme'];
        $this->rubriques            = $this->getRubriques('_rubrique');
        $this->activeModules        = $this->getAllActiveModules();
        
        // Widget Newsletter init
        $this->initNewsletterWidget();
        
        $themeExists = $this->checkTheme();
        if(empty($themeExists)){ die('The dir <b>'.THEME.'/'.$this->theme.'</b> not found.'); }
        
        $this->htmlContent = $this->getHtmlWaitingPage();
        $isIpUserStatut = $this->isIpUserStatut();
        
        if($this->configWeb['statut'] === '1' || $isIpUserStatut){
            
            $this->loadParams();
            $this->loadPosition();
            $this->loadMeta();
            
            // Widget Comment init
            $this->initCommentWidget();
            
            $this->genController();
            $this->htmlContent = $this->getHtmlWrapper();
            
        }
        
        
        
    }
    
    public function getWebsiteRubriques(){
        
        return $this->rubriques;
    
    }
    
    public function getTheme(){
        
        return $this->theme;
    
    }
    
    public function getUri(){
        
        return $this->uri;
    
    }
    
    public function getActiveModules(){
        
        return $this->activeModules;
    
    }
    
    public function getModule(){
        
        return $this->module;
    
    }
    
    public function getCategory(){
        
        return $this->category;
    
    }
    
    public function getContent(){
        
        return $this->content;
    
    }
    
    public function setContent($value){
        
        $this->content = $value;
    
    }
    
    public function getContentView(){
        
        return $this->contentView;
    
    }
    
    public function setContentView($value){
        
        $this->contentView = $value;
    
    }
    
    public function getPosition(){
        
        return $this->position;
    
    }
    
    public function getType(){
        
        return $this->type;
    
    }
    
    public function getLabel(){
        
        return $this->type;
    
    }
    
    public function getParams(){
        
        return $this->Params;
    
    }
    
    public function getHtmlContent(){
        
        return $this->htmlContent;
        
    }
    
    public function loadParams(){
        
        $GET = $POST = array();
        
        if(!empty($_GET)){
            foreach($_GET as $k=>$v){
                $GET[$k] = filter_input(INPUT_GET,$k,FILTER_SANITIZE_STRING);
            }
        }
        
        $this->Params['GET'] = $GET;
        
        if(!empty($_POST)){
            foreach($_POST as $k=>$v){
                $POST[$k] = filter_input(INPUT_POST,$k,FILTER_SANITIZE_STRING);
            }
        }
        
        $this->Params['POST'] = $POST;
        
    }
    
    public function loadPosition(){
        
        $this->position = 'root';
        
        // Get module
        if( array_key_exists('doorgets',$this->Params['GET']) )
        {
            
            $uriCategory    = $this->Params['GET']['doorgets'];
            $isCategory     = $this->dbQS($uriCategory,'_categories_traduction','uri'," AND langue = '".$this->myLanguage."' LIMIT 1 ");
            
            if(!empty($isCategory)){
                
                $isParentCategory = $this->dbQS($isCategory['id_cat'],'_categories');
                
                if(!empty($isParentCategory)){
                    
                    if(array_key_exists($isParentCategory['uri_module'],$this->activeModules)){
                        
                        
                        $this->category     =   $isCategory;
                        $this->position     =   'category';
                        $this->module       =   $isParentCategory['uri_module'];
                        
                    }
                }
            }
        }
        
        // Get Content
        $this->checkModuleContent();
        
        if(
            array_key_exists($this->module,$this->rubriques)
        ){
        
            $this->label    = $this->rubriques[$this->module]['label'];
            $this->type     = $this->rubriques[$this->module]['type'];
            
        }
        
        
        
    }
    
    public function loadMeta(){
        
        $meta['label']          = $this->configWeb['slogan'];
        $meta['title']          = $this->configWeb['title'];
        $meta['description']    = $this->configWeb['description'];
        $meta['keywords']       = $this->configWeb['keywords'];
        
        if(
            !empty($this->position)
            && $this->position === 'root'
            && array_key_exists($this->module,$this->rubriques)
        ){
            
            $meta['label']          = $this->rubriques[$this->module]['all']['nom'].' &#8250; '.$this->configWeb['title'];
            $meta['title']          = $this->rubriques[$this->module]['all']['meta_titre'];
            $meta['description']    = $this->rubriques[$this->module]['all']['meta_description'];
            $meta['keywords']       = $this->rubriques[$this->module]['all']['meta_keys'];
            
            
        }
        
        if(!empty($this->position) && $this->position === 'category'){
            
            $meta['label']          = $this->category['nom'] . ' &#8250; ' .$this->rubriques[$this->module]['all']['nom'].' &#8250; '.$this->configWeb['title'];
            $meta['title']          = $this->category['meta_titre'];
            $meta['description']    = $this->category['meta_description'];
            $meta['keywords']       = $this->category['meta_keys'];
            
            
            
        }
        
        if(!empty($this->position) && $this->position === 'content'){
            
            $meta['label']          = $this->content['titre'] . ' &#8250; ' .$this->rubriques[$this->module]['all']['nom'].' &#8250; '.$this->configWeb['title'];
            $meta['title']          = $this->content['meta_titre'];
            $meta['description']    = $this->content['meta_description'];
            $meta['keywords']       = $this->content['meta_keys'];
            
            
            
        }
        
        $this->meta = $meta;
        
    }
    
    public function checkModuleContent(){
        
        foreach($this->activeModules as $nameModule=>$v){
            
            if(array_key_exists($nameModule,$this->Params['GET'])){
                
                $this->type     = $v['type'];
                $this->module   = $nameModule;
                
                if(
                    $this->type !== 'page'
                    && $this->type !== 'inbox'
                    && $this->type !== 'link'
                    && $this->type !== 'applicationjob'
                ){
                    
                    $uriContent = $this->Params['GET'][$nameModule];
                    
                    $table = '_m_'.$nameModule;
                    $tableTraduction = '_m_'.$nameModule.'_traduction';
                    if($this->type !== 'faq' && $this->type !== 'partner' ){
                        $isContent = $this->dbQS($uriContent,$tableTraduction,'uri'," AND langue = '".$this->myLanguage."' LIMIT 1 ");
                    }
                    
                    if(!empty($isContent)){
                        
                        $isContentActive    = $this->dbQS($isContent['id_content'],$table,'id'," AND active = 2 LIMIT 1 ");
                        if(!empty($isContentActive)){
                            
                            $isContent['ordre'] = $isContentActive['ordre'];
                            
                            $this->content  = $isContent;
                            $this->position = 'content';
                            $this->uri      = $isContent['uri'];                            
                        }

                    }
                    
                }
                
            }
        }
        
    }
    
    public function checkTheme(){
        
        $dirTheme = THEME.$this->theme;
        if(is_dir($dirTheme))
        {
            return true;
        }
        
        return false;
    }
    
    public function getHtmlSitemap(){
        
        $Sitemap = new GenSitemapHtml($this->myLanguage());
        return $Sitemap->getHtml();
        
    }
    
    public function getHtmlBlock($uri_module=''){
        
        if(empty($uri_module)){return null;}
        $isBlock = $this->dbQS($uri_module,'_dg_block','uri');
        if(empty($isBlock)){return null;}
        
        $groupe_traduction = @unserialize($isBlock['groupe_traduction']);
        $idLangueTraduction = $groupe_traduction[$this->myLanguage];
        
        $isContentTraduction = $this->dbQS($idLangueTraduction,'_dg_block_traduction');
        if(empty($isContentTraduction)){return null;}
        
        return '<div class="block-static-'.$uri_module.'">'.htmlspecialchars_decode(html_entity_decode($isContentTraduction['article_tinymce'])).'</div>';
        
    }
    
    public function getHtmlWrapper(){
        
        $title          = $this->configWeb['title'];
        $copyright      = $this->configWeb['copyright'];
        $dateCreated    = $this->configWeb['year'];
        $yearNow        = date('Y',time());
        
        $dateWesbsite = $dateCreated.'-'.$yearNow;
        if($dateCreated == $yearNow){ $dateWesbsite = $yearNow; }
        
        $tplWrapper = Template::getWebsiteView('wrapper',$this->getTheme());
        ob_start(); if(is_file($tplWrapper)){ include $tplWrapper; } $out = ob_get_clean();
        return $out;
        
    }
    
    public function getHtmlHeader(){
        
        extract($this->meta);
        
        $lgFacebook = 'fr_FR';
        switch($this->myLanguage){
            
            case 'en': $lgFacebook = 'en_US'; break;
            case 'de': $lgFacebook = 'de_DE'; break;
            case 'it': $lgFacebook = 'it_IT'; break;
            case 'ru': $lgFacebook = 'ru_RU'; break;
            case 'pl': $lgFacebook = 'pl_PL'; break;
            case 'tu': $lgFacebook = 'tr_TR'; break;
            case 'su': $lgFacebook = 'sv_SE'; break;
            case 'es': $lgFacebook = 'es_LA'; break;
            case 'po': $lgFacebook = 'pt_BR'; break;
        }
        
        $rss = new GenRss(1);
	$rssLinks = $rss->getAllToRssLink();
        
        $url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
        
        $tplHeader = Template::getWebsiteView('header',$this->getTheme());
        ob_start(); if(is_file($tplHeader)){ include $tplHeader; } $out = ob_get_clean();
        
        return $out;
    }
    
    public function getHtmlFooter(){
        
        $tplFooter = Template::getWebsiteView('footer',$this->getTheme());
        ob_start(); if(is_file($tplFooter)){ include $tplFooter; } $out = ob_get_clean();
        
        return $out;
    }
    
    public function getHtmlNavigation(){
        
        $navigation = $this->rubriques;
        
        $tplNavigation= Template::getWebsiteView('widgets/navigation',$this->getTheme());
        ob_start(); if(is_file($tplNavigation)){ include $tplNavigation; }  $out = ob_get_clean();
        
        return $out;
    }
    
    public function getHtmlLanguages(){
        
        $base_url = URL.'t/';
        $languages = $this->allLanguagesWebsite;
        
        $languagesMenu = array();
        if(count($languages) > 1){
            foreach($languages as $uri_language => $label){
                
                if($this->type !== 'page'){
                    
                    $languagesMenu[$uri_language]['url']    = $base_url.$uri_language.'/?'.$this->module;
                    $languagesMenu[$uri_language]['label']  = $label;
                    
                    if($this->position === 'content'){
                        
                        $isContent = $this->dbQS($this->content['id_content'],'_m_'.$this->module.'_traduction','id_content'," AND langue = '".$uri_language."' LIMIT 1");
                        if(!empty($isContent)){
                            
                            $languagesMenu[$uri_language]['url']    = $base_url.$uri_language.'/?'.$this->module.'='.$isContent['uri'];
                            $languagesMenu[$uri_language]['label']  = $label;
                        }
                        
                    }
                    
                    if($this->position === 'category'){
                        
                        $isCategory = $this->dbQS($this->category['id_cat'],'_categories_traduction','id_cat'," AND langue = '".$uri_language."' LIMIT 1");
                        if(!empty($isCategory)){
                            
                            $languagesMenu[$uri_language]['url']    = $base_url.$uri_language.'/?doorgets='.$isCategory['uri'];
                            $languagesMenu[$uri_language]['label']  = $label;
                        }
                        
                    }
                    
                }else{
                    
                    $languagesMenu[$uri_language]['url']    = $base_url.$uri_language.'/?'.$this->module;
                    $languagesMenu[$uri_language]['label']  = $label;
                    
                }
                
            }
        }
        
        
        
        $tplTanguages= Template::getWebsiteView('widgets/languages',$this->getTheme());
        ob_start(); if(is_file($tplTanguages)){ include $tplTanguages; }  $out = ob_get_clean();
        
        return $out;
    }
    
    public function getHtmlComment(){
        
        if(empty($this->configWeb['m_comment'])) return null;
        
        $form = $this->form['comment'];
        
        $tplComment = Template::getWebsiteView('widgets/comment',$this->getTheme());
        ob_start(); if(is_file($tplComment)){ include $tplComment; } $out = ob_get_clean();
        
        return $out;
        
    }
    
    public function getHtmlCommentDisqus(){
        
        if(empty($this->configWeb['m_comment_disqus'])) return null;
        
        $idDisqus = $this->configWeb['id_disqus'];
        
        $tplDisqus = Template::getWebsiteView('widgets/comment_disqus',$this->getTheme());
        ob_start(); if(is_file($tplDisqus)){ include $tplDisqus; } $out = ob_get_clean();
        
        return $out;
        
    }
    
    public function getHtmlCommentFacebook(){
        
        if(empty($this->configWeb['m_comment_facebook'])) return null;
        
        $idFacebook = $this->configWeb['id_facebook'];
        
        $tplFacebook = Template::getWebsiteView('widgets/comment_facebook',$this->getTheme());
        ob_start(); if(is_file($tplFacebook)){ include $tplFacebook; } $out = ob_get_clean();
        
        return $out;
        
    }
    
    public function getHtmlSharethis(){
        
        if(empty($this->configWeb['m_sharethis'])) return null;
        
        $tplSharethis = Template::getWebsiteView('widgets/sharethis',$this->getTheme());
        ob_start(); if(is_file($tplSharethis)){ include $tplSharethis; } $out = ob_get_clean();
        
        return $out;
        
    }
    
    public function getHtmlNewsletter(){
        
        if(empty($this->configWeb['m_newsletter'])) return null;
        
        $form = $this->form['newsletter'];
        
        $tplNewsletter = Template::getWebsiteView('widgets/newsletter',$this->getTheme());
        ob_start(); if(is_file($tplNewsletter)){ include $tplNewsletter; } $out = ob_get_clean();
        
        return $out;
    }
    
    public function getHtmlNetwork(){
        
        // change position in array for change order
        $ntworks = array(
            
            'facebook',
            'twitter',
            'linkedin',
            'pinterest',
            'youtube',
            'google',
            'myspace',
            
        );
        
        $networks = array();
        
        foreach($ntworks as $name){
            
            if(
                array_key_exists($name,$this->configWeb)
                && !empty($this->configWeb[$name])
            ){
                $networks[$this->getUrl($name)] = $this->getImageSkin($name);
            }
            
        }
        
        $tplNetworks = Template::getWebsiteView('widgets/networks',$this->getTheme());
        ob_start(); if(is_file($tplNetworks)){ include $tplNetworks; } $out = ob_get_clean();
        
        return $out;
        
    }
    
    public function getHtmlAnalytics(){
        
        $codeAnalytics = $this->configWeb['analytics'];
        
        $tplAnalytics = Template::getWebsiteView('widgets/analytics',$this->getTheme());
        ob_start(); if(is_file($tplAnalytics)){ include $tplAnalytics; } $out = ob_get_clean();
        
        return $out;
        
    }
    
    public function getHtmlModuleComments(){
        
        $isModuleComments = $this->dbQA('_dg_comments'," WHERE uri_module = '".$this->module."' AND uri_content = '".$this->uri."' AND validation = '2' ORDER BY date_creation DESC  ");
        $countComments = count($isModuleComments);
        
        $tplModuleComments = Template::getWebsiteView('widgets/comment_listing',$this->getTheme());
        ob_start(); if(is_file($tplModuleComments)){ include $tplModuleComments; } $out = ob_get_clean();
        
        return $out;
        
    }
    
    public function getHtmlModuleSearch($q = ''){
        
        $form = new Formulaire('');
        
        $tplModuleSearch = Template::getWebsiteView('widgets/module_search',$this->getTheme());
        ob_start(); if(is_file($tplModuleSearch)){ include $tplModuleSearch; } $out = ob_get_clean();
        
        return $out;
        
    }
    
    
    public function getHtmlFixed($position = 'top'){
        
        $out = '';
        
        if(
            $this->position == 'root'
            && array_key_exists($this->module,$this->activeModules)
        ){
            switch($position){
                
                case 'top':
                    
                    $fixed_top = $this->activeModules[$this->module]['all']['top_tinymce'];
                    if(!empty($fixed_top)){
                        $out = '<div class="doorGets-fixed-top">';
                        $out .= htmlspecialchars_decode(html_entity_decode($fixed_top));
                        $out .= '</div>';
                        
                    }
                    
                    break;
                
                case 'bottom':
                    
                    
                    $fixed_bottom = $this->activeModules[$this->module]['all']['bottom_tinymce'];
                    if(!empty($fixed_bottom)){
                        $out = '<div class="doorGets-fixed-bottom">';
                        $out .= htmlspecialchars_decode(html_entity_decode($fixed_bottom));
                        $out .= '</div>';
                    }
                    
                    break;
                
            }
        }
        
        return $out;
    }
    
    public function getHtmlModuleCategories(){
        
        $category_now = $this->getCategory();
        $togo = 'doorgets';
        if($this->type === 'multipage'){
            
            $categories = $this->loadMultipageCategories($this->module);
            $togo = $this->module;
            
        }else{
            $categories = $this->loadCategories($this->module);
        }
        
        $tplModuleCategories = Template::getWebsiteView('widgets/module_categories',$this->getTheme());
        ob_start(); if(is_file($tplModuleCategories)){ include $tplModuleCategories; } $out = ob_get_clean();
        
        return $out;
        
    }
    
    public function initNewsletterWidget(){
        
        if(empty($this->configWeb['m_newsletter'])) return null;
        
        // Start Widget Newsletter
        
        // Init form
        $this->form['newsletter']   = new Formulaire('doorgets_newsletter');
        
        // Check validation for form submit
        if( !empty($this->form['newsletter']->i) )
        {
            
            $this->checkMode();
            
            $email          = $this->form['newsletter']->i['email'];
            $isEmail        = filter_var($email, FILTER_VALIDATE_EMAIL);
            $isEmailExist   = $this->dbQS($email,'_dg_newsletter','email');
            $isIpExist      = $this->dbQS($_SERVER['REMOTE_ADDR'],'_dg_newsletter','client_ip'," ORDER BY date_creation DESC LIMIT 1 ");
            
            if( empty($this->form['newsletter']->i['nom']) )
            {
               $this->form['newsletter']->e['doorgets_newsletter_nom'] = 'ok'; 
            }
            if( !$isEmail || !empty($isEmailExist) )
            {
               $this->form['newsletter']->e['doorgets_newsletter_email'] = 'ok'; 
            }
            if(!empty($isIpExist)){
                
                $time_hack = 60;
                $time_ip   = (int)$isIpExist['date_creation'];
                
                $time_left = time() - $time_ip;
                
                if($time_left < $time_hack){
                    $this->form['newsletter']->e['doorgets_hack'] = 'ok'; 
                }
            }
            
            if( empty($this->form['newsletter']->e) )
            {
                
                if( array_key_exists('recaptcha_response_field',$this->form['newsletter']->i) )
                { unset($this->form['newsletter']->i["recaptcha_response_field"]); }
                
                if( array_key_exists('recaptcha_challenge_field',$this->form['newsletter']->i) )
                { unset($this->form['newsletter']->i["recaptcha_challenge_field"]); }
                
                $data = $this->form['newsletter']->i;
                $data['client_ip']      = $_SERVER['REMOTE_ADDR'];
                $data['date_creation']  = time();
                $this->dbQI($data,'_dg_newsletter');
                
            }
            
        }
        
        // End Widget Newsletter
    }
    
    public function initCommentWidget(){
        
        if(empty($this->configWeb['m_comment'])) return null;
        
        // Start Widget Comment
        
        $idForm = uniqid();

        if(!array_key_exists('idForm',$_SESSION)){
            
            $_SESSION['idForm'] = $idForm;
            
        }
        
        // Init form
        $this->form['comment']   = new Formulaire('doorgets_comment');
        
        
        if(
           !empty($this->form['comment']->i)
           && $_SESSION['idForm'] !== $this->form['comment']->i['secureFormulaire']
        ){  
            
            header("Location:".$_SERVER['REQUEST_URI']);
            
        }
        
        // Check validation for form submit
        if(
           !empty($this->form['comment']->i)
           && $_SESSION['idForm'] === $this->form['comment']->i['secureFormulaire']
        ){
            
            $this->checkMode();
            
            $name   = $this->form['comment']->i['name'];
            if( empty($name) ){ $this->form['comment']->e['doorgets_comment_nom'] = 'ok'; }
            
            $email  = $this->form['comment']->i['email'];
            $isEmail = filter_var($email, FILTER_VALIDATE_EMAIL);
            if( empty($isEmail) ){ $this->form['comment']->e['doorgets_comment_email'] = 'ok'; }
            
            $comment = $this->form['comment']->i['comment'];
            if( empty($comment) ){ $this->form['comment']->e['doorgets_comment_nom'] = 'ok'; }
            
            if(empty($this->form['comment']->e)){
                
                
                $statut = 3;
                // reset sercure form
                $_SESSION['idForm'] = $idForm;
                
                // add comment to database
                $data = array(
                    
                    'uri_module'    => $this->module,
                    'uri_content'   => $this->uri,
                    'nom'           => $name,
                    'email'         => $email,
                    'comment'       => $comment,
                    'url'           => $_SERVER["REQUEST_URI"],
                    'date_creation' => time(),
                    'validation'    => $statut,
                    'adress_ip'     => $_SERVER["REMOTE_ADDR"],
                    'langue'        => $this->myLanguage
                    
                );
                
                $idComment = $this->dbQI($data,'_dg_comments');
                
                // Mail Sender Notification
                $moduleInfo = $this->dbQS($this->getModule(),'_modules','uri');
                if( !empty($moduleInfo) && !empty($moduleInfo['notification_mail'])){

                    $_email = $this->configWeb['email'];
                    $_lg    = $this->configWeb['langue'];
                    $_sujet = $this->l("Commentaire").' / '.ucfirst($this->getModule()).'['.$idComment.']';
                    
                    new SendMailAlert($_email,$_sujet,$_lg);
                    
                }
                
            }
            
        }
        
        // End Widget Comment
    }
    
    public function genController(){
        
        $nameController = 'module'.ucfirst($this->type).'Controller';
        $fileNameController = CONTROLLERS.'website/'.$nameController.'.php';
        
        if(!is_file($fileNameController))
        { $this->htmlContent = $this->getHtmlWaitingPage(); return true; }
        require_once $fileNameController;
        
        if(!class_exists ($nameController))
        { echo 'Class  not found : ' . $nameController.' : '; exit(); }
        
        $this->Controller = new $nameController($this);
        
    }
    
    
    public function getUrlPreviousContent(){
        
        $out = array();
        $order = 1;
        if( !empty($this->content) ){
            if(array_key_exists('ordre',$this->content)){
                $order = $this->content['ordre'];
            }
        }
        
        $nameTable = '_m_'.$this->module;
        $nameTableTraduction = $nameTable.'_traduction';
        
        $isContent = $this->dbQ("SELECT id,ordre,groupe_traduction FROM $nameTable WHERE ordre > $order AND active = 2 ORDER BY ordre LIMIT 1");
        if(!empty($isContent)){
            
            $groupe_traduction = @unserialize($isContent[0]['groupe_traduction']);
            $idContentTraduction = $groupe_traduction[$this->myLanguage];
            
            $isContentTraduction = $this->dbQS($idContentTraduction,$nameTableTraduction);
            if(!empty($isContentTraduction)){
                
                $out['label']   = $isContentTraduction['titre'];
                $out['url']     = BASE_URL.'?'.$this->module.'='.$isContentTraduction['uri'];
            }
            
        }
        
        return $out;
    
    }
    
    public function getUrlNextContent(){
        
        $out = array();
        $order = 1;
        if( !empty($this->content) ){
            if(array_key_exists('ordre',$this->content)){
                $order = $this->content['ordre'];
            }
        }
        
        if($order !== 1){
            
            $nameTable = '_m_'.$this->module;
            $nameTableTraduction = $nameTable.'_traduction';
            
            $isContent = $this->dbQ("SELECT id,ordre,groupe_traduction FROM $nameTable WHERE ordre < $order AND active = 2 ORDER BY ordre DESC LIMIT 1");
            if(!empty($isContent)){
                
                $groupe_traduction = @unserialize($isContent[0]['groupe_traduction']);
                $idContentTraduction = $groupe_traduction[$this->myLanguage];
                
                $isContentTraduction = $this->dbQS($idContentTraduction,$nameTableTraduction);
                if(!empty($isContentTraduction)){
                    
                    $out['label']   = $isContentTraduction['titre'];
                    $out['url']     = BASE_URL.'?'.$this->module.'='.$isContentTraduction['uri'];
                }
                
            }
        }
        
        
        return $out;
    
    }
    
    public function getHtmlWaitingPage(){
        
        $label      = $this->configWeb['title'];
        $content    = $this->configWeb['statut_tinymce'];
        
        $tplWantingPage = Template::getWebsiteView('waitingpage',$this->getTheme());
        ob_start(); if(is_file($tplWantingPage)){ include $tplWantingPage; } $out = ob_get_clean();
        
        return $out;
        
    }
    
    
    public function getLastComments($count = 5){
        
        
        $allComments = $this->dbQ("SELECT * FROM _dg_comments WHERE validation = 2 ORDER BY id LIMIT $count");
        
        $i = 0;
        $Comments = array();
        foreach($allComments as $Comment){
            
            $Comments[$i]['author']  = $Comment['nom'];
            $Comments[$i]['url']     = URL.'t/'.$Comment['langue'].'/?'.$Comment['uri_module'].'='.$Comment['uri_content'];
            $Comments[$i]['comment'] = $this->_truncate($Comment['comment'],50);
            
            $i++;
        
        }
        
        $tplComments = Template::getWebsiteView('widgets/comment_last',$this->getTheme());
        ob_start(); if(is_file($tplComments)){ include $tplComments; } $out = ob_get_clean();
        
        return $out;
        
    }
    
    public function getLastModuleContents($module , $count = 3){
        
        $out = '';
        $iMaxDescription = 500;
        
        $nameTable      = '_m_'.$module;
        $nameTableTrad  = $nameTable.'_traduction';
        //echo $module;
        $isModule = $this->dbQS($module,'_modules','uri');
        $valActive = array("blog","news","video","image");
        
        if(
           empty($isModule)
        ){ return '# Error Class doorgetsWebiste  line '.__LINE__; }
        
        if(
           !in_array($isModule['type'],$valActive)
        ){ return '# Error Class doorgetsWebiste ['.$isModule['type'].'] line '.__LINE__; }
        
        
        if(!empty($isModule)){
            
            $Contents = $this->dbQ("SELECT * FROM $nameTable WHERE active = 2 ORDER BY id DESC LIMIT $count");
            
            if(!empty($Contents)){
                
                switch($isModule['type']){
                    
                    case 'news':
                        
                        foreach($Contents as $k=>$content){
                        
                            $lgTrad = unserialize($content['groupe_traduction']);
                            $Contents[$k]['groupe_traduction'] = $lgTrad;
                            $idLg = $Contents[$k]['groupe_traduction'][$this->myLanguage()];
                            
                            $isContent = $this->dbQS($idLg,$nameTableTrad);
                            $Contents[$k]['content_traduction'] = $isContent;
                            
                            $Contents[$k]['date'] = GetDate::in($Contents[$k]['date_creation'],2,$this->myLanguage);
                            
                            $Contents[$k]['article'] = html_entity_decode($Contents[$k]['content_traduction']['article_tinymce']);
                            $lenArticle = strlen($Contents[$k]['article']);
                            
                            if( $lenArticle > $iMaxDescription - 1 ){
                                $Contents[$k]['article'] = substr(strip_tags($Contents[$k]['article']),0,$iMaxDescription).'...';
                            }
                        }
                        
                        $tplNews = Template::getWebsiteView('modules/news/news_last_contents',$this->getTheme());
                        ob_start(); if(is_file($tplNews)){ include $tplNews; } $out = ob_get_clean();
                        break;
                    
                    case 'blog':
                        
                        foreach($Contents as $k=>$content){
                        
                            $lgTrad = unserialize($content['groupe_traduction']);
                            $Contents[$k]['groupe_traduction'] = $lgTrad;
                            $idLg = $Contents[$k]['groupe_traduction'][$this->myLanguage()];
                            
                            $isContent = $this->dbQS($idLg,$nameTableTrad);
                            $Contents[$k]['content_traduction'] = $isContent;
                            $Contents[$k]['image'] = $isContent['image'];
                            
                            $Contents[$k]['date'] = GetDate::in($Contents[$k]['date_creation'],2,$this->myLanguage);
                            
                            $Contents[$k]['article'] = html_entity_decode($Contents[$k]['content_traduction']['article_tinymce']);
                            $lenArticle = strlen($Contents[$k]['article']);
                            
                            if( $lenArticle > $iMaxDescription - 1 ){
                                $Contents[$k]['article'] = substr(strip_tags($Contents[$k]['article']),0,$iMaxDescription).'...';
                            }
                        }
                        
                        $tplNews = Template::getWebsiteView('modules/blog/blog_last_contents',$this->getTheme());
                        ob_start(); if(is_file($tplNews)){ include $tplNews; } $out = ob_get_clean();
                        break;
                    
                    case 'video':
                        
                        foreach($Contents as $k=>$content){
                        
                            $lgTrad = unserialize($content['groupe_traduction']);
                            $Contents[$k]['groupe_traduction'] = $lgTrad;
                            $idLg = $Contents[$k]['groupe_traduction'][$this->myLanguage()];
                            
                            $isContent = $this->dbQS($idLg,$nameTableTrad);
                            $Contents[$k]['content_traduction'] = $isContent;
                            
                            $Contents[$k]['date'] = GetDate::in($Contents[$k]['date_creation'],2,$this->myLanguage);
                            
                        }
                        
                        $tplVideo = Template::getWebsiteView('modules/video/video_last_contents',$this->getTheme());
                        ob_start(); if(is_file($tplVideo)){ include $tplVideo; } $out = ob_get_clean();
                        break;
                    
                    case 'image':
                        
                        foreach($Contents as $k=>$content){
                        
                            $lgTrad = unserialize($content['groupe_traduction']);
                            $Contents[$k]['groupe_traduction'] = $lgTrad;
                            $idLg = $Contents[$k]['groupe_traduction'][$this->myLanguage()];
                            
                            $isContent = $this->dbQS($idLg,$nameTableTrad);
                            $Contents[$k]['content_traduction'] = $isContent;
                            
                            $Contents[$k]['date'] = GetDate::in($Contents[$k]['date_creation'],2,$this->myLanguage);
                            
                        }
                        
                        $tplImage = Template::getWebsiteView('modules/image/image_last_contents',$this->getTheme());
                        ob_start(); if(is_file($tplImage)){ include $tplImage; } $out = ob_get_clean();
                        break;
                }
                
            }
            
        }
        
        return $out;
    
    }
    
    
    public function _convertTag($string){
        
        $out = '';
        $convertArray = array(
            "\[url=([^\]]*)\](.*)\[\/url\]" => '<a href="$1" >$2</a>',
            "\[img=([^\]]*)\](.*)\[\/img\]" => '<img src="$1" alt="$2" />',
            "\[b\](.*?)\[\/b\]" => '<strong>$1</strong>',
            "\[li\](.*?)\[\/li\]" => '<li>$1</li>',
            "\[ul\](.*?)\[\/ul\]" => '<ul>$1</ul>',
            "\[h1\](.*?)\[\/h1\]" => '<h1>$1</h1>',
            "\[h2\](.*?)\[\/h2\]" => '<h2>$1</h2>',
            "\[h3\](.*?)\[\/h3\]" => '<h3>$1</h3>',
            "\[h4\](.*?)\[\/h4\]" => '<h4>$1</h4>',
            "\[br\/\]" => '<br />'
            
            
        );
        
        
        foreach($convertArray as $k=>$v){
            
            $val = '/'.$k.'/i';
            $string = preg_replace($val,$v,$string);
            
        }
        
        return $string;
    }
    
    public function _convertMethod($string){
        
        $stringToOut = $string;
        
        $strStart = "{{!"; $strEnd = "!}}";
        $cExplode = explode("{{!",$string);
        unset($cExplode[0]);
        
        $count    = $cExplode;
        
        if(!empty($cExplode)){
            foreach($cExplode as $Content){
                
                $posStrEnd = strpos($Content,$strEnd);
                if($posStrEnd !== false){
                    
                    $nameMethod = substr($Content,0,$posStrEnd);
                    
                    $eMethod = explode('/',$nameMethod);
                    
                    $cMethod = count($eMethod);
                    if($cMethod === 1){
                        if(method_exists($this,$eMethod[0])){
                            $mehodContent = $this->$eMethod[0]();
                            $nameMethodSub = '{{!'.$eMethod[0].'!}}';
                            //echo $nameMethodSub;
                            $stringToOut = str_ireplace($nameMethodSub,$mehodContent,$stringToOut);
                        }
                    }
                    if($cMethod === 2){
                        
                        if(method_exists($this,$eMethod[0])){
                            $mehodContent = $this->$eMethod[0]($eMethod[1]);
                            $nameMethodSub = '{{!'.$eMethod[0].'/'.$eMethod[1].'!}}';
                            //echo $nameMethodSub;
                            $stringToOut = str_ireplace($nameMethodSub,$mehodContent,$stringToOut);
                        }
                    }
                    if($cMethod === 3){
                        
                        if(method_exists($this,$eMethod[0])){
                            $mehodContent = $this->$eMethod[0]($eMethod[1],$eMethod[2]);
                            $nameMethodSub = '{{!'.$eMethod[0].'/'.$eMethod[1].'/'.$eMethod[2].'!}}';
                            //echo $nameMethodSub;
                            $stringToOut = str_ireplace($nameMethodSub,$mehodContent,$stringToOut);
                        }
                    }
                }
            }
        }
        
        return $stringToOut;
    }
    
    
    public function __destruct(){
        
        parent::__destruct();
        
    }
    
}