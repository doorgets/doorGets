<?php


class GoogleTranslate{
    
    static function rest($words,$langueFrom,$langueTo){
        
        $words = urlencode($words);
        
        $url = "https://www.googleapis.com/language/translate/v2?key=AIzaSyADQ_JkqWno2rZ7cx1BjhAtI5Qe1cFjHEs&q=$words&source=$langueFrom&target=$langueTo";
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
        $recived_content = curl_exec($ch); 
        $data = json_decode($recived_content);
        
        return $data->data->translations[0]->translatedText;
    }
    
    
}