<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 21, December 2013
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class GetDate{
    
    static function in($time = 0,$format = 1,$langue= 'fr'){
        
        if(!is_numeric($time) || empty($time)){ $time = time(); }
        switch($format){
            case 1:
                
                if($langue === 'fr'){
                    
                    $out = date('d/m/Y - H:i',$time); // Temps 31/12/1984
                    
                }else{
                    
                    $out = date('m/d/Y - h:i a',$time); // Temps 12/31/1984
                    
                }
                break;
            
            case 2:
                
                if($langue === 'fr'){
                    
                    $out = date('d/m/Y',$time); // Temps 31/12/1984
                    
                }else{
                    
                    $out = date('m/d/Y',$time); // Temps 12/31/1984
                    
                }
                break;
            
            case 3:
                
                $out = ucfirst(strftime("%A %d %B %Y",$time));  // Temps Mercredi 20 mars 2013 
                break;
            
            case 4:
                
                $out = ucfirst(strftime("%A %d %B %Y %H:%M",$time));     // Temps Mercredi 20 mars 2013 18:41
                break;
            
            default:
                if($langue === 'fr'){
                    
                    $out = date('d/m/Y',$time); // Temps 31/12/1984
                    
                }else{
                    
                    $out = date('m/d/Y',$time); // Temps 12/31/1984
                    
                }
                break;
        }
        
        return $out;
        
    }
    
}