<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 5.2 - 05, January 2014
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/



class AuthUser extends Langue{
    
    private $isConnected = array();
    
    public function __construct(){
        
        parent::__construct('fr');

        if( 
            isset($_SESSION['doorgets_user']) 
            and isset($_SESSION['doorgets_user']['login'])
            and isset($_SESSION['doorgets_user']['password']) 
        ){
            
            extract($_SESSION['doorgets_user']);
            $LogineExist = $this->dbQS($login,'_users','login');
            
            if(!empty($LogineExist) && $this->_decrypt($password) === $this->_decrypt($LogineExist['password'])){
                
                $LogineExistInfo = $this->dbQS($LogineExist['id'],'_users_info','id_user');
                if(!empty($LogineExistInfo)){
                    
                    $LogineExistInfoGroupe = $this->dbQS($LogineExistInfo['network'],'_users_groupes');
                    if(!empty($LogineExistInfoGroupe)){
                        
                        $this->isConnected['id']                            =  $LogineExist['id'];
                        $this->isConnected['groupe']                        =  $LogineExistInfo['network'];
                        $this->isConnected['login']                         =  $LogineExist['login'];
                        $this->isConnected['password']                      =  $LogineExist['password']; 
                        
                        $this->isConnected['timezone']                      =  $LogineExistInfo['horaire'];
                        
                        $this->isConnected['pseudo']                        =  $LogineExistInfo['pseudo'];
                        $this->isConnected['langue']                        =  $LogineExistInfo['langue'];
                        $this->isConnected['last_name']                     =  $LogineExistInfo['last_name'];
                        $this->isConnected['first_name']                    =  $LogineExistInfo['first_name'];
                        $this->isConnected['description']                   =  $LogineExistInfo['description'];
                        
                        $this->isConnected['liste_module']                  =  $this->_toArray($LogineExistInfoGroupe['liste_module']);
                        $this->isConnected['liste_module_interne']          =  $this->_toArray($LogineExistInfoGroupe['liste_module_interne']);
                        $this->isConnected['liste_enfant']                  =  $this->_toArray($LogineExistInfoGroupe['liste_enfant']);
                        
                        $this->isConnected['liste_module_limit']            =  $this->_toArrayKeys($LogineExistInfoGroupe['liste_module_limit']);
                        
                        $this->isConnected['liste_module_modo']             =  $this->_toArray($LogineExistInfoGroupe['liste_module_modo']);
                        $this->isConnected['liste_module_interne_modo']     =  $this->_toArray($LogineExistInfoGroupe['liste_module_interne_modo']);
                        $this->isConnected['liste_enfant_modo']             =  $this->_toArray($LogineExistInfoGroupe['liste_enfant_modo']);
                        
                        $this->isConnected['liste_enfant']                  =  $this->_toArray($LogineExistInfoGroupe['liste_enfant']);
                        
                        $this->isConnected['rubriques']                     = $this->getRubriquesUsers('_rubrique_users',$this->isConnected['liste_module']);
                        
                        
                        $this->_trackMe($LogineExist['id']);
                        
                        //var_dump($this);
                        
                    }
                }
            }
        }
        
        
        return null;
        
    }
    
    public function isConnected(){
        
        return $this->isConnected;
    
    }
}