<?php

/*******************************************************************************
/*******************************************************************************
    doorgets 5.0 #!#!#
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class SendMailAuth extends Langue{
    
    public $header;

    public $email;

    public $sujet;

    public $messageHtml;

    public $messageTxt;

    public function __construct($email,$type,$url,$lg= 'fr'){
        
        parent::__construct($lg);
        
    	$this->email = $email;
    	$this->sujet = $this->getSubject($type);
        
    	$this->messageHtml = "<html><head></head><body>";
    	$this->messageHtml .= $this->getContentHtml($type,$url);
    	$this->messageHtml .= "</body></html>";
        
    	$this->messageTxt = $this->getContentTxt($type,$url);
    	
    	$this->sendMail();
        
    }
    
    private function getSubject($type){
        
        $out = 'Info';
        
        switch($type){
            
            case 'subscribe':
                $out = $this->l("Activer votre compte")." / ".$this->l("Code d'activation");
                break;
            
            case 'forget':
                $out = $this->l("Mot de passe oubli�")." / ".$this->l("Code d'activation");
                break;
            
        }
        
        return $out;
    }
    
    private function getContentHtml($type,$url){
        
        $out = 'Info';
        
        $msgHtmlSubscribe    = $this->l("Salut").',<br /><br />';
        $msgHtmlSubscribe   .= $this->l("Veuillez cliquer sur le lien suivant pour confirmer votre inscription")." : <br /><br />";
        $msgHtmlSubscribe   .= $url;
        
        
        $msgHtmlForget       = $this->l("Salut").',<br /><br />';
        $msgHtmlForget      .= $this->l("Veuillez cliquer sur le lien suivant pour red�finir votre mot de passe")." : <br /><br />";
        $msgHtmlForget      .= $url;
        
        switch($type){
            
            case 'subscribe':
                $out = $msgHtmlSubscribe;
                break;
            
            case 'forget':
                $out = $msgHtmlForget;
                break;
            
        }
        
        return $out;
    }
    
    private function getContentTxt($type,$url){
        
        $out = 'Info';
        
        $msgTxtSubscribe    = $this->l("Salut").','."\r\n";
        $msgTxtSubscribe   .= $this->l("Veuillez cliquer sur le lien suivant pour confirmer votre inscription")." : "."\r\n\r\n";
        $msgTxtSubscribe   .= $url."\r\n";
        
        
        $msgTxtForget       = $this->l("Salut").','."\r\n";
        $msgTxtForget      .= $this->l("Veuillez cliquer sur le lien suivant pour red�finir votre mot de passe")." : "."\r\n\r\n";
        $msgTxtForget      .= $url."\r\n";
        
        switch($type){
            
            case 'subscribe':
                $out = $msgTxtSubscribe;
                break;
            
            case 'forget':
                $out = $msgTxtForget;
                break;
            
        }
        
        return $out;
    }
    
    private function sendMail(){

    	$serverName = $_SERVER['SERVER_NAME'];
    	$serverName = str_replace('www.', '', $serverName);
    	$mailSender = 'no-reply@'.$serverName;

    	$boundary = "-----=".md5(rand());

    	if (!preg_match("#^[a-z0-9._-]+@(hotmail|live|msn).[a-z]{2,4}$#", $this->email)) 
		{ $pl= "\r\n"; }else{ $pl = "\n"; }

		$this->header = "From: \"$serverName\"<$mailSender>".$pl;
		$this->header.= "Reply-to: \"$serverName\" <$mailSender>".$pl;
		$this->header.= "MIME-Version: 1.0".$pl;
		$this->header.= "Content-Type: multipart/alternative;".$pl." boundary=\"$boundary\"".$pl;

		$message = $pl."--".$boundary.$pl;
		//=====Ajout du message au format texte.
		$message.= "Content-Type: text/plain; charset=\"ISO-8859-1\"".$pl;
		$message.= "Content-Transfer-Encoding: 8bit".$pl;
		$message.= $pl.$this->messageTxt.$pl;
		//==========
		$message.= $pl."--".$boundary.$pl;
		//=====Ajout du message au format HTML
		$message.= "Content-Type: text/html; charset=\"ISO-8859-1\"".$pl;
		$message.= "Content-Transfer-Encoding: 8bit".$pl;
		$message.= $pl.$this->messageHtml.$pl;
		//==========
		$message.= $pl."--".$boundary."--".$pl;
		$message.= $pl."--".$boundary."--".$pl;

		mail($this->email,$this->sujet,$message,$this->header);

    }
    
}