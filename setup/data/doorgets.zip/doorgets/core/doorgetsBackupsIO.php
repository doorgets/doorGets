<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 21, December 2013
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/



class doorgetsBackupsIO extends Langue{
    
    public function __construct($lg="fr"){
        
        parent::__construct($lg);
        
    }
    
    public function genExport(){
        return $this->genExportMatrice();
    }
    
    public function doImport($file){
        
        // Création d'une sauvegarde de récupération
        //$this->genExport();
        
        return $this->genImportMatrice($file);
    
    }
    
    private function genImportMatrice($file){
        
        $ff=$file;
        $file = BASE.'io/'.$file;
        
        if(!is_file($file)) return false;
        $fileName = str_replace('.zip','',$ff);
        $contents = '';
        $configData = '';
            
            
        
        // Récupération du fichier de configuration doorgets.php
        $zip = new ZipArchive;
        if($res = $zip->open($file)){
            
            $configFile = $zip->getStream('doorgets.php');
            while (!feof($configFile)) {
                $contents .= fread($configFile, 2);
            }
            
            $configData  = unserialize($contents);
            
            if(!empty($configData) && is_array($configData)){
                
                $sql_query_install = '';
                $dirDatabase = 'database/';
                
                // Récupération des donnés de la database
                $entriesDatabase = array();
                $entriesData = array();
                $entriesDataDoorgets = array();
                $entriesDataSkin = array();
                for ($idx = 0; $idx < $zip->numFiles; $idx++) {
                    
                    $nameIndex = $zip->getNameIndex($idx);
                    $firstNameIndexDatabase = substr($nameIndex,0,8);
                    $firstNameIndexData = substr($nameIndex,0,4);
                    $firstNameIndexDoorgets = substr($nameIndex,0,8);
                    $firstNameIndexSkin = substr($nameIndex,0,4);
                    
                    if( $firstNameIndexDatabase === 'database' ) {
                        $entriesDatabase[] = $zip->getNameIndex($idx);
                    }elseif( $firstNameIndexDoorgets === 'doorgets' ) {
                        $entriesDataDoorgets[] = $zip->getNameIndex($idx);
                    }elseif( $firstNameIndexData === 'data' ) {
                        $entriesData[] = $zip->getNameIndex($idx);
                    }elseif( $firstNameIndexSkin === 'skin' ) {
                        $entriesDataSkin[] = $zip->getNameIndex($idx);
                    }
                    
                }
                
                // Extraction des données de la databse vers un dossier Temp
                $nameDirTemp = BASE.'data/_temp/';
                if(!is_dir($nameDirTemp)){mkdir($nameDirTemp);}
                if(!is_dir($nameDirTemp.$fileName.'/')){mkdir($nameDirTemp.$fileName.'/');}
                $dirTempDatabase = $nameDirTemp.$fileName.'/';
                $dirToCopyAllDatas = BASE.'';
                
                $zip->extractTo($dirToCopyAllDatas,$entriesData);
                $zip->extractTo($dirToCopyAllDatas,$entriesDataDoorgets);
                $zip->extractTo($dirToCopyAllDatas,$entriesDataSkin);
                $zip->extractTo($dirTempDatabase,$entriesDatabase);
                
                $db = new CRUD();
                // Installation de la base de données
                foreach($configData as $k=>$v){
                    
                    if(!empty($v['sql_create_table'])){
                        
                        $query = str_replace("\n",' ',$v['sql_create_table']);
                        $query = str_replace("\t",'',$query);
                        $query = str_replace("\r",'',$query);
                        
                        $query = trim($query);
                        $db->dbQuery($query);
                        
                    }
                    
                    
                }
                
                $db2 = new CRUD();
                
                foreach($configData as $k=>$v){
                    
                    $dirDatabaseName = $dirTempDatabase.'database/'.$k.'/';
                    $allFiles = $this->files($dirDatabaseName);
                    foreach($allFiles as $nameFile){
                        
                        if(is_file($dirDatabaseName.$nameFile)){
                             
                            $dataTableFile = file_get_contents($dirDatabaseName.$nameFile);
                            if($dataTableContent = unserialize($dataTableFile)){
                                
                                $qqq = $this->dbVQI($dataTableContent,$k);
                                $db2->dbQuery($qqq);
                                
                            }
                            
                        }
                        
                    }
                    
                }
                // Suppression des données temporaire
                if(is_file($dirToCopyAllDatas.'doorgets.php')){ @unlink($dirToCopyAllDatas.'doorgets.php'); }
                if(is_dir($nameDirTemp)){ $this->destroy_dir($nameDirTemp); }
                
            }
        }
        
        $zip->close();
        
        FlashInfo::set($this->l("Votre sauvegarde est installée."));
        header("Location:./?controller=configuration&action=backups"); exit();
        
    }
    
    private function genExportMatrice(){
        
        $arrayCatInc = array('news','multipage','video','image','faq','partner');
        
        $table = array();
        
        $table['_dg_applicationjob']['count'] = 0;
        $table['_dg_applicationjob']['type'] = '_mod';
        $table['_dg_applicationjob']['sql_create_table'] = " DROP TABLE IF EXISTS `_dg_applicationjob`;
            CREATE TABLE IF NOT EXISTS `_dg_applicationjob` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `last_name` varchar(255) DEFAULT NULL,
                `first_name` varchar(255) DEFAULT NULL,
                `email` varchar(255) DEFAULT NULL,
                `file_cv` varchar(255) DEFAULT NULL,
                `file_cv_type` varchar(255) DEFAULT NULL,
                `file_cv_size` varchar(255) DEFAULT NULL,
                `lu` int(11) DEFAULT '0',
                `date_creation` int(11) DEFAULT NULL,
                `date_lu` int(11) DEFAULT NULL,
                `uri_module` varchar(255) DEFAULT NULL,
                `sujet` varchar(255) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;";
        
        $table['_dg_inbox']['count'] = 0;
        $table['_dg_inbox']['type'] = '_mod';
        $table['_dg_inbox']['sql_create_table'] = " DROP TABLE IF EXISTS `_dg_inbox`;
            CREATE TABLE IF NOT EXISTS `_dg_inbox` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `uri_module` varchar(255) DEFAULT NULL,
                `sujet` varchar(255) NOT NULL,
                `nom` varchar(255) DEFAULT NULL,
                `email` varchar(255) DEFAULT NULL,
                `message` text,
                `telephone` varchar(255) DEFAULT NULL,
                `lu` int(11) NOT NULL DEFAULT '0',
                `archive` int(11) NOT NULL DEFAULT '0',
                `date_creation` int(11) NOT NULL DEFAULT '0',
                `date_archive` int(11) NOT NULL DEFAULT '0',
                `date_lu` int(11) NOT NULL DEFAULT '0',
                PRIMARY KEY (`id`)
              ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;";
        
        
        $table['_dg_links']['count'] = 0;
        $table['_dg_links']['type'] = '_mod';
        $table['_dg_links']['sql_create_table'] = " DROP TABLE IF EXISTS `_dg_links`;
            CREATE TABLE IF NOT EXISTS `_dg_links` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `langue` varchar(255) DEFAULT NULL,
                `uri_module` varchar(255) DEFAULT NULL,
                `label` varchar(255) DEFAULT NULL,
                `link` varchar(255) DEFAULT NULL,
                `date_creation` int(11) DEFAULT NULL,
                `date_modification` int(11) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ; ";
        
        $table['_dg_newsletter_emailling_campagne']['count'] = 0;
        $table['_dg_newsletter_emailling_campagne']['type'] = '_mod';
        $table['_dg_newsletter_emailling_campagne']['sql_create_table'] = " DROP TABLE IF EXISTS `_dg_newsletter_emailling_campagne`;
            CREATE TABLE IF NOT EXISTS `_dg_newsletter_emailling_campagne` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `id_groupe` int(11) NOT NULL,
                `id_models` int(11) NOT NULL,
                `statut` varchar(255) NOT NULL,
                `titre` text NOT NULL,
                `description` text NOT NULL,
                `message` text,
                `date_creation` int(11) NOT NULL,
                `date_modification` int(11) DEFAULT NULL,
                `date_envoi` int(11) NOT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ; ";
            
        $table['_dg_newsletter_emailling_groupe']['count'] = 0;
        $table['_dg_newsletter_emailling_groupe']['type'] = '_mod';
        $table['_dg_newsletter_emailling_groupe']['sql_create_table'] = " DROP TABLE IF EXISTS `_dg_newsletter_emailling_groupe`;
            CREATE TABLE IF NOT EXISTS `_dg_newsletter_emailling_groupe` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `titre` varchar(255) DEFAULT NULL,
                `description` text NOT NULL,
                `date_creation` int(11) NOT NULL,
                `date_modification` int(11) NOT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ; ";
            
        $table['_dg_newsletter_emailling_models']['count'] = 0;
        $table['_dg_newsletter_emailling_models']['type'] = '_mod';
        $table['_dg_newsletter_emailling_models']['sql_create_table'] = " DROP TABLE IF EXISTS `_dg_newsletter_emailling_models`;
            CREATE TABLE IF NOT EXISTS `_dg_newsletter_emailling_models` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `titre` varchar(255) DEFAULT NULL,
                `description` text,
                `langue` varchar(255) DEFAULT NULL,
                `format` varchar(255) DEFAULT NULL,
                `sujet` varchar(255) DEFAULT NULL,
                `article_tinymce` text,
                `date_creation` int(11) DEFAULT NULL,
                `date_modification` int(11) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ; ";
            
        $table['_dg_newsletter']['count'] = 0;
        $table['_dg_newsletter']['type'] = '_mod';
        $table['_dg_newsletter']['sql_create_table'] = " DROP TABLE IF EXISTS `_dg_newsletter`;
            CREATE TABLE IF NOT EXISTS `_dg_newsletter` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `id_user` int(11) NOT NULL DEFAULT '0',
                `id_groupe` int(11) NOT NULL DEFAULT '0',
                `nom` varchar(255) DEFAULT NULL,
                `email` varchar(255) DEFAULT NULL,
                `description` text,
                `newsletter` int(11) DEFAULT '1',
                `client_ip` varchar(255) DEFAULT NULL,
                `date_creation` int(11) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ; ";
        
        $table['_dg_page']['count'] = 0;
        $table['_dg_page']['type'] = '_mod';
        $table['_dg_page']['sql_create_table'] = " DROP TABLE IF EXISTS `_dg_page`;
            CREATE TABLE IF NOT EXISTS `_dg_page` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `id_user` int(11) DEFAULT '0',
                `id_groupe` int(11) DEFAULT '0',
                `uri` varchar(255) DEFAULT NULL,
                `active` int(11) NOT NULL DEFAULT '0',
                `comments` int(11) NOT NULL DEFAULT '0',
                `partage` int(11) NOT NULL DEFAULT '1',
                `facebook` int(11) DEFAULT '0',
                `id_facebook` varchar(255) DEFAULT NULL,
                `disqus` int(11) DEFAULT '0',
                `id_disqus` varchar(255) DEFAULT NULL,
                `mailsender` int(11) DEFAULT '0',
                `sendto` varchar(255) DEFAULT NULL,
                `in_rss` int(11) NOT NULL DEFAULT '0',
                `ordre` int(11) NOT NULL DEFAULT '0',
                `groupe_traduction` text,
                `date_creation` int(11) DEFAULT NULL,
                `id_modo` int(111) DEFAULT NULL,
                `val_modo` int(11) DEFAULT '0',
                `date_modo` int(11) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ; ";
            
        $table['_dg_page_traduction']['count'] = 0;
        $table['_dg_page_traduction']['type'] = '_mod';
        $table['_dg_page_traduction']['sql_create_table'] = " DROP TABLE IF EXISTS `_dg_page_traduction`;
            CREATE TABLE IF NOT EXISTS `_dg_page_traduction` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `id_content` int(11) NOT NULL DEFAULT '0',
                `langue` varchar(255) DEFAULT NULL,
                `titre` varchar(255) DEFAULT NULL,
                `description` text,
                `article_tinymce` text,
                `uri` varchar(255) DEFAULT NULL,
                `uri_module` varchar(255) DEFAULT NULL,
                `meta_titre` varchar(255) DEFAULT NULL,
                `meta_description` varchar(255) DEFAULT NULL,
                `meta_keys` varchar(255) DEFAULT NULL,
                `date_modification` int(11) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ; ";
        
        $table['_dg_files']['count'] = 0;
        $table['_dg_files']['type'] = '_mod';
        $table['_dg_files']['sql_create_table'] = " DROP TABLE IF EXISTS `_dg_files`;
            CREATE TABLE IF NOT EXISTS `_dg_files` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `id_user` int(11) DEFAULT '0',
                `id_groupe` int(11) DEFAULT '0',
                `type` varchar(255) NOT NULL,
                `nom` varchar(255) DEFAULT NULL,
                `description` text,
                `fichier` varchar(255) DEFAULT NULL,
                `poid` varchar(255) DEFAULT NULL,
                `date_creation` int(11) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ; ";
        
        $table['_categories']['count'] = 0;
        $table['_categories']['type'] = '_mod';
        $table['_categories']['sql_create_table'] = " DROP TABLE IF EXISTS `_categories`;
            CREATE TABLE IF NOT EXISTS `_categories` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `uri_module` varchar(255) DEFAULT NULL,
                `groupe_traduction` text,
                `ordre` int(11) DEFAULT NULL,
                `date_creation` int(11) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ; ";
        
        $table['_categories_traduction']['count'] = 0;
        $table['_categories_traduction']['type'] = '_mod';
        $table['_categories_traduction']['sql_create_table'] = " DROP TABLE IF EXISTS `_categories_traduction`;
            CREATE TABLE IF NOT EXISTS `_categories_traduction` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `id_cat` int(11) NOT NULL DEFAULT '0',
                `langue` varchar(10) NOT NULL DEFAULT 'fr',
                `nom` varchar(255) DEFAULT NULL,
                `titre` varchar(255) DEFAULT NULL,
                `description` text,
                `uri` varchar(255) DEFAULT NULL,
                `meta_titre` varchar(255) DEFAULT NULL,
                `meta_description` varchar(255) DEFAULT NULL,
                `meta_keys` varchar(255) DEFAULT NULL,
                `date_creation` int(11) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ; ";
        
        $table['_dg_comments']['count'] = 0;
        $table['_dg_comments']['type'] = '_mod';
        $table['_dg_comments']['sql_create_table'] = " DROP TABLE IF EXISTS `_dg_comments`;   
            CREATE TABLE IF NOT EXISTS `_dg_comments` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `id_user` int(11) DEFAULT '0',
                `id_groupe` int(11) DEFAULT '0',
                `uri_module` varchar(255) DEFAULT NULL,
                `uri_content` varchar(255) DEFAULT NULL,
                `nom` varchar(255) DEFAULT NULL,
                `email` varchar(255) DEFAULT NULL,
                `url` varchar(255) DEFAULT NULL,
                `comment` text,
                `lu` int(11) NOT NULL DEFAULT '0',
                `archive` int(11) NOT NULL DEFAULT '0',
                `date_creation` int(11) DEFAULT NULL,
                `validation` int(11) DEFAULT '0',
                `date_validation` int(11) DEFAULT '0',
                `date_archive` int(11) NOT NULL DEFAULT '0',
                `adress_ip` varchar(255) DEFAULT NULL,
                `langue` varchar(255) DEFAULT 'en',
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ; ";
        
        $table['_modules']['count'] = 0;
        $table['_modules']['type'] = '_mod';
        $table['_modules']['sql_create_table'] = " DROP TABLE IF EXISTS `_modules`; 
            CREATE TABLE IF NOT EXISTS `_modules` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `type` varchar(255) DEFAULT NULL,
                `uri` varchar(255) DEFAULT NULL,
                `active` int(11) DEFAULT '1',
                `is_first` int(11) DEFAULT '0',
                `plugins` text,
                `groupe_traduction` text,
                `bynum` int(11) DEFAULT '10',
                `avoiraussi` int(11) NOT NULL DEFAULT '3',
                `image` varchar(255) DEFAULT NULL,
                `notification_mail` int(11) NOT NULL DEFAULT '1',
                `date_creation` int(11) NOT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ; ";
        
        $table['_modules_traduction']['count'] = 0;
        $table['_modules_traduction']['type'] = '_mod';
        $table['_modules_traduction']['sql_create_table'] = " DROP TABLE IF EXISTS `_modules_traduction`;
            CREATE TABLE IF NOT EXISTS `_modules_traduction` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `id_module` int(11) DEFAULT NULL,
                `langue` varchar(255) DEFAULT NULL,
                `nom` varchar(255) DEFAULT NULL,
                `titre` varchar(255) DEFAULT NULL,
                `description` text,
                `top_tinymce` text,
                `bottom_tinymce` text,
                `meta_titre` varchar(255) DEFAULT NULL,
                `meta_description` varchar(255) DEFAULT NULL,
                `meta_keys` varchar(255) DEFAULT NULL,
                `date_modification` int(11) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ; ";
        
        $table['_rubrique']['count'] = 0;
        $table['_rubrique']['type'] = '_mod';
        $table['_rubrique']['sql_create_table'] = " DROP TABLE IF EXISTS `_rubrique`;
            CREATE TABLE IF NOT EXISTS `_rubrique` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `name` varchar(220) DEFAULT NULL,
                `ordre` int(11) DEFAULT NULL,
                `idModule` int(11) NOT NULL DEFAULT '0',
                `idParent` int(11) DEFAULT '0',
                `showinmenu` int(11) DEFAULT '1',
                `date_creation` int(11) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ; ";
            
        $table['_users']['count'] = 0;
        $table['_users']['type'] = '_mod';
        $table['_users']['sql_create_table'] = " DROP TABLE IF EXISTS `_users`;
            CREATE TABLE IF NOT EXISTS `_users` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `login` varchar(255) DEFAULT NULL,
                `password` varchar(255) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ; ";
        
        $table['_users_groupes']['count'] = 0;
        $table['_users_groupes']['type'] = '_mod';
        $table['_users_groupes']['sql_create_table'] = " DROP TABLE IF EXISTS `_users_groupes`;
            CREATE TABLE IF NOT EXISTS `_users_groupes` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `title` varchar(255) DEFAULT NULL,
                `description` text,
                `liste_module` text,
                `liste_module_limit` text,
                `liste_module_modo` text,
                `liste_module_interne` text,
                `liste_module_interne_modo` text,
                `liste_enfant` text,
                `liste_enfant_modo` text,
                `liste_parent` text,
                `can_subscribe` int(11) DEFAULT '1',
                `date_creation` int(255) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ; ";
        
        $table['_users_info']['count'] = 0;
        $table['_users_info']['type'] = '_mod';
        $table['_users_info']['sql_create_table'] = " DROP TABLE IF EXISTS `_users_info`;
            CREATE TABLE IF NOT EXISTS `_users_info` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `active` int(11) DEFAULT '0',
                `id_user` int(11) DEFAULT NULL,
                `langue` varchar(255) DEFAULT NULL,
                `network` int(11) DEFAULT NULL,
                `email` varchar(255) DEFAULT NULL,
                `pseudo` varchar(255) DEFAULT NULL,
                `last_name` varchar(255) DEFAULT NULL,
                `first_name` varchar(255) DEFAULT NULL,
                `description` text,
                `horaire` varchar(255) DEFAULT NULL,
                `date_creation` int(11) DEFAULT NULL,
                `date_modification` int(11) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ; ";
        
        $table['_users_notification']['count'] = 0;
        $table['_users_notification']['type'] = '_mod';
        $table['_users_notification']['sql_create_table'] = " DROP TABLE IF EXISTS `_users_notification`;
            CREATE TABLE IF NOT EXISTS `_users_notification` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `id_user` int(11) DEFAULT NULL,
                `id_session` varchar(255) DEFAULT NULL,
                `ip_session` varchar(255) DEFAULT NULL,
                `url_page` varchar(255) DEFAULT NULL,
                `url_referer` varchar(255) DEFAULT NULL,
                `date` int(11) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ; ";
        
        $table['_users_track']['count'] = 0;
        $table['_users_track']['type'] = '_mod';
        $table['_users_track']['sql_create_table'] = " DROP TABLE IF EXISTS `_users_track`;
            CREATE TABLE IF NOT EXISTS `_users_track` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `id_session` varchar(255) DEFAULT NULL,
                `id_user` int(11) NOT NULL,
                `uri_module` varchar(255) NOT NULL,
                `id_content` text NOT NULL,
                `action` varchar(255) NOT NULL,
                `ip_user` varchar(255) NOT NULL,
                `url_page` varchar(255) DEFAULT NULL,
                `url_referer` varchar(255) DEFAULT NULL,
                `date` int(11) NOT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ; ";
        
        $table['_website']['count'] = 0;
        $table['_website']['type'] = '_mod';
        $table['_website']['sql_create_table'] = "  DROP TABLE IF EXISTS `_website`;
            CREATE TABLE IF NOT EXISTS `_website` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `statut` int(11) DEFAULT '1',
                `statut_version` int(11) DEFAULT '0',
                `statut_ip` varchar(255) DEFAULT NULL,
                `version_doorgets` varchar(255) DEFAULT NULL,
                `title` varchar(220) NOT NULL,
                `slogan` varchar(180) DEFAULT NULL,
                `copyright` varchar(100) NOT NULL,
                `year` varchar(10) NOT NULL,
                `description` varchar(220) NOT NULL,
                `keywords` varchar(220) NOT NULL,
                `email` varchar(80) DEFAULT NULL,
                `pays` varchar(180) DEFAULT NULL,
                `ville` varchar(180) DEFAULT NULL,
                `adresse` varchar(220) DEFAULT NULL,
                `codepostal` varchar(25) DEFAULT NULL,
                `tel_fix` varchar(30) DEFAULT NULL,
                `tel_mobil` varchar(30) DEFAULT NULL,
                `tel_fax` varchar(30) DEFAULT NULL,
                `facebook` varchar(120) DEFAULT NULL,
                `twitter` varchar(120) DEFAULT NULL,
                `pinterest` varchar(255) DEFAULT NULL,
                `myspace` varchar(255) DEFAULT NULL,
                `linkedin` varchar(255) DEFAULT NULL,
                `youtube` varchar(120) DEFAULT NULL,
                `google` varchar(250) DEFAULT NULL,
                `analytics` varchar(50) DEFAULT NULL,
                `langue` varchar(255) DEFAULT 'fr',
                `langue_front` varchar(255) DEFAULT 'fr',
                `langue_groupe` text,
                `horaire` varchar(255) DEFAULT '315',
                `mentions` int(11) DEFAULT '1',
                `cgu` int(11) DEFAULT '1',
                `m_newsletter` int(1) DEFAULT '1',
                `m_comment` int(11) DEFAULT '1',
                `m_comment_facebook` int(11) DEFAULT '0',
                `m_comment_disqus` int(11) DEFAULT '0',
                `m_sharethis` int(11) DEFAULT '1',
                `m_sitemap` int(11) DEFAULT '1',
                `m_rss` int(11) DEFAULT '1',
                `id_facebook` varchar(255) DEFAULT NULL,
                `id_disqus` varchar(255) DEFAULT NULL,
                `theme` varchar(255) NOT NULL DEFAULT 'doorgets-home',
                `module_homepage` varchar(255) DEFAULT NULL,
                `date_creation` int(11) DEFAULT NULL,
                `date_modification` int(11) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ; ";
        
        $table['_website_traduction']['count'] = 0;
        $table['_website_traduction']['type'] = '_mod';
        $table['_website_traduction']['sql_create_table'] = " DROP TABLE IF EXISTS `_website_traduction`;
            CREATE TABLE IF NOT EXISTS `_website_traduction` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `langue` varchar(255) DEFAULT NULL,
                `statut_tinymce` text,
                `title` varchar(255) DEFAULT NULL,
                `slogan` varchar(255) DEFAULT NULL,
                `description` varchar(255) DEFAULT NULL,
                `copyright` varchar(255) DEFAULT NULL,
                `year` varchar(255) DEFAULT NULL,
                `keywords` varchar(255) DEFAULT NULL,
                `date_modification` int(11) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ; ";
        
        
        $isAllModule = $this->dbQ("SELECT id,uri,type FROM _modules ORDER BY id DESC LIMIT 200");
        $cAllModule = count($isAllModule);
        if(!empty($isAllModule)){
            for($i=0;$i<$cAllModule;$i++){
                if(in_array($isAllModule[$i]['type'],$arrayCatInc)){
                    
                    $table['_m_'.$isAllModule[$i]['uri']]['count'] = 0;
                    $table['_m_'.$isAllModule[$i]['uri']]['type'] = $isAllModule[$i]['type'];
                    
                    switch($isAllModule[$i]['type']){
                    
                        case 'faq':
                            $table['_m_'.$isAllModule[$i]['uri']]['sql_create_table'] = $this->getSqlFaq($isAllModule[$i]['uri']);
                            break;
                        case 'partner':
                            $table['_m_'.$isAllModule[$i]['uri']]['sql_create_table'] = $this->getSqlPartner($isAllModule[$i]['uri']);
                            break;
                        case 'image':
                            $table['_m_'.$isAllModule[$i]['uri']]['sql_create_table'] = $this->getSqlImage($isAllModule[$i]['uri']);
                            break;
                        case 'video':
                            $table['_m_'.$isAllModule[$i]['uri']]['sql_create_table'] = $this->getSqlVideo($isAllModule[$i]['uri']);
                            break;
                        case 'multipage':
                            $table['_m_'.$isAllModule[$i]['uri']]['sql_create_table'] = $this->getSqlMultipage($isAllModule[$i]['uri']);
                            break;
                        case 'news':
                            $table['_m_'.$isAllModule[$i]['uri']]['sql_create_table'] = $this->getSqlNews($isAllModule[$i]['uri']);
                            break;
                        
                    }
                    
                    $table['_m_'.$isAllModule[$i]['uri'].'_traduction']['count'] = 0;
                    $table['_m_'.$isAllModule[$i]['uri'].'_traduction']['type'] = $isAllModule[$i]['type'].'_traduction';
                    $table['_m_'.$isAllModule[$i]['uri'].'_traduction']['sql_create_table'] = '';
                    
                }
                
            }
        }
        
        $timer = time();
        // Création de l'archive zipper
        $zip_file = BASE."io/$timer.zip";
        
        $zipArchive = new ZipDir;

        $res = $zipArchive->open($zip_file, ZipArchive::CREATE);
        
        if($res === TRUE) {
            
            // Copie des fichiers doorgets
            
            $zipArchive->addDir(BASE.'data', 'data');
            $zipArchive->addDir(BASE.'doorgets', 'doorgets');
            $zipArchive->addDir(BASE.'skin', 'skin');
            
            // Création de la copie de la database
            $zipArchive->addEmptyDir('database/');
            
            // Création des fichiers d'éxportation de la base
            foreach($table as $name_table=>$v){
               
                $iTable = $this->dbQ('SELECT COUNT(*) as counter FROM '.$name_table);
                $table[$name_table]['count'] = (int)$iTable[0]['counter'];
                
                $dirIoFile = 'database/'.$name_table.'/';
                $zipArchive->addEmptyDir($dirIoFile);
                
                for($i=0;$i<$table[$name_table]['count'];$i++){
                    
                    $valContent = $this->dbQA($name_table," LIMIT $i,1 ");
                    if(!empty($valContent)){
                        
                        $fileNameSaved = $dirIoFile.$name_table.'-'.$valContent[0]['id'].'.php';
                        $infoSerialized = serialize($valContent[0]);
                        
                        $zipArchive->addFromString( $fileNameSaved,$infoSerialized );
                        
                    }
                    
                }
                
            }
            
            $tableInfo = serialize($table);
            $zipArchive->addFromString( 'doorgets.php',$tableInfo );
            
            $zipArchive->close();
            
        }
        
        return true;
        
    }
    
    private function getSqlMultipage($name){
        
        $nameMultipage = '_m_'.$name;
        $nameMultipageTrad = '_m_'.$name.'_traduction';
        
        $out = "
        
        DROP TABLE IF EXISTS `$nameMultipage`;
        DROP TABLE IF EXISTS `$nameMultipageTrad`;
        
        CREATE TABLE IF NOT EXISTS $nameMultipage (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `pseudo` varchar(255) DEFAULT NULL,
            `id_user` int(11) DEFAULT '0',
            `id_groupe` int(11) DEFAULT '0',
            `categorie` varchar(255) DEFAULT NULL,
            `active` int(11) NOT NULL DEFAULT '0',
            `comments` int(11) NOT NULL DEFAULT '0',
            `partage` int(11) NOT NULL DEFAULT '1',
            `facebook` int(11) DEFAULT '0',
            `id_facebook` varchar(255) DEFAULT NULL,
            `disqus` int(11) DEFAULT '0',
            `id_disqus` varchar(255) DEFAULT NULL,
            `mailsender` int(11) DEFAULT '0',
            `sendto` varchar(255) DEFAULT NULL,
            `in_rss` int(11) NOT NULL DEFAULT '0',
            `ordre` int(11) NOT NULL DEFAULT '0',
            `groupe_traduction` text,
            `date_creation` int(11) DEFAULT NULL,
            `id_modo` int(111) DEFAULT NULL,
            `val_modo` int(11) DEFAULT '0',
            `date_modo` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;
        
        CREATE TABLE IF NOT EXISTS $nameMultipageTrad (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `id_content` int(11) NOT NULL DEFAULT '0',
            `langue` varchar(255) DEFAULT NULL,
            `categorie` varchar(255) DEFAULT NULL,
            `titre` varchar(255) DEFAULT NULL,
            `description` text,
            `article_tinymce` text,
            `uri` varchar(255) DEFAULT NULL,
            `meta_titre` varchar(255) DEFAULT NULL,
            `meta_description` varchar(255) DEFAULT NULL,
            `meta_keys` varchar(255) DEFAULT NULL,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;";

        return $out;
    
    }
    
    //------------------------
    
    private function getSqlFaq($name){
        
        $nameFaq = '_m_'.$name;
        $nameFaqTrad = '_m_'.$name.'_traduction';
        
        $out = "
            DROP TABLE IF EXISTS `$nameFaq`;
            DROP TABLE IF EXISTS `$nameFaqTrad`;
            
            CREATE TABLE IF NOT EXISTS `$nameFaq` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `pseudo` varchar(255) DEFAULT NULL,
                `id_user` int(11) DEFAULT '0',
                `id_groupe` int(11) DEFAULT '0',
                `active` int(11) NOT NULL DEFAULT '0',
                `ordre` int(11) DEFAULT NULL,
                `groupe_traduction` text,
                `date_creation` int(11) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;
              
              
            CREATE TABLE IF NOT EXISTS `$nameFaqTrad` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `id_content` int(11) DEFAULT NULL,
                `langue` varchar(255) DEFAULT NULL,
                `question` text,
                `reponse_tinymce` text,
                `date_creation` int(11) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;";

        return $out;
    
    }
    
    private function getSqlImage($name){
        
        $nameImage = '_m_'.$name;
        $nameImageTrad = '_m_'.$name.'_traduction';
        
        $out = "
            DROP TABLE IF EXISTS `$nameImage`;
            DROP TABLE IF EXISTS `$nameImageTrad`;
            
            CREATE TABLE IF NOT EXISTS `$nameImage` (
              `id` int(11) NOT NULL AUTO_INCREMENT,
              `pseudo` varchar(255) DEFAULT NULL,
              `id_user` int(11) DEFAULT '0',
              `id_groupe` int(11) DEFAULT '0',
              `categorie` varchar(255) DEFAULT NULL,
              `active` int(11) NOT NULL DEFAULT '0',
              `comments` int(11) NOT NULL DEFAULT '0',
              `partage` int(11) NOT NULL DEFAULT '1',
              `facebook` int(11) DEFAULT '0',
              `id_facebook` varchar(255) DEFAULT NULL,
              `disqus` int(11) DEFAULT '0',
              `id_disqus` varchar(255) DEFAULT NULL,
              `mailsender` int(11) DEFAULT '0',
              `sendto` varchar(255) DEFAULT NULL,
              `in_rss` int(11) NOT NULL DEFAULT '0',
              `ordre` int(11) NOT NULL DEFAULT '0',
              `groupe_traduction` text,
              `date_creation` int(11) DEFAULT NULL,
              `id_modo` int(111) DEFAULT NULL,
              `val_modo` int(11) DEFAULT '0',
              `date_modo` int(11) DEFAULT NULL,
              PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;
            
            
            CREATE TABLE IF NOT EXISTS `$nameImageTrad` (
              `id` int(11) NOT NULL AUTO_INCREMENT,
              `id_content` int(11) NOT NULL DEFAULT '0',
              `langue` varchar(255) DEFAULT NULL,
              `categorie` varchar(255) DEFAULT NULL,
              `image` varchar(255) DEFAULT NULL,
              `titre` varchar(255) DEFAULT NULL,
              `description` text,
              `article_tinymce` text,
              `uri` varchar(255) DEFAULT NULL,
              `meta_titre` varchar(255) DEFAULT NULL,
              `meta_description` varchar(255) DEFAULT NULL,
              `meta_keys` varchar(255) DEFAULT NULL,
              `date_creation` int(11) DEFAULT NULL,
              PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;
        ";

        return $out;
    
    }
    

    private function getSqlPartner($name){
        
        $namePartner = '_m_'.$name;
        $namePartnerTrad = '_m_'.$name.'_traduction';
        
        $out = "       
            DROP TABLE IF EXISTS `$namePartner`;
            DROP TABLE IF EXISTS `$namePartnerTrad`;
            
            CREATE TABLE IF NOT EXISTS `$namePartner` (
              `id` int(11) NOT NULL AUTO_INCREMENT,
              `pseudo` varchar(255) DEFAULT NULL,
              `id_user` int(11) DEFAULT '0',
              `id_groupe` int(11) DEFAULT '0',
              `active` int(11) NOT NULL DEFAULT '0',
              `ordre` int(11) DEFAULT NULL,
              `groupe_traduction` text,
              `date_creation` int(11) DEFAULT NULL,
              PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;
            
            
            
            CREATE TABLE IF NOT EXISTS `$namePartnerTrad` (
              `id` int(11) NOT NULL AUTO_INCREMENT,
              `id_content` int(11) DEFAULT NULL,
              `langue` varchar(255) DEFAULT NULL,
              `image` varchar(255) DEFAULT NULL,
              `titre` varchar(255) DEFAULT NULL,
              `url` varchar(255) DEFAULT NULL,
              `description` text,
              `date_creation` int(11) DEFAULT NULL,
              PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;
        ";

        return $out;
    
    }

    private function getSqlVideo($name){
        
        $nameVideo = '_m_'.$name;
        $nameVideoTrad = '_m_'.$name.'_traduction';
        
        $out = "
            DROP TABLE IF EXISTS `$nameVideo`;
            DROP TABLE IF EXISTS `$nameVideoTrad`;
            
            CREATE TABLE IF NOT EXISTS `$nameVideo` (
              `id` int(11) NOT NULL AUTO_INCREMENT,
              `pseudo` varchar(255) DEFAULT NULL,
              `id_user` int(11) DEFAULT '0',
              `id_groupe` int(11) DEFAULT '0',
              `categorie` varchar(255) DEFAULT NULL,
              `active` int(11) NOT NULL DEFAULT '0',
              `comments` int(11) NOT NULL DEFAULT '0',
              `partage` int(11) NOT NULL DEFAULT '1',
              `facebook` int(11) DEFAULT '0',
              `id_facebook` varchar(255) DEFAULT NULL,
              `disqus` int(11) DEFAULT '0',
              `id_disqus` varchar(255) DEFAULT NULL,
              `mailsender` int(11) DEFAULT '0',
              `sendto` varchar(255) DEFAULT NULL,
              `in_rss` int(11) NOT NULL DEFAULT '0',
              `ordre` int(11) NOT NULL DEFAULT '0',
              `groupe_traduction` text,
              `date_creation` int(11) DEFAULT NULL,
              `id_modo` int(111) DEFAULT NULL,
              `val_modo` int(11) DEFAULT '0',
              `date_modo` int(11) DEFAULT NULL,
              PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;
            
            
            
            CREATE TABLE IF NOT EXISTS `$nameVideoTrad` (
              `id` int(11) NOT NULL AUTO_INCREMENT,
              `id_content` int(11) NOT NULL DEFAULT '0',
              `langue` varchar(255) DEFAULT NULL,
              `categorie` varchar(255) DEFAULT NULL,
              `youtube` varchar(255) DEFAULT NULL,
              `temps` int(11) NOT NULL DEFAULT '1',
              `titre` varchar(255) DEFAULT NULL,
              `description` text,
              `article_tinymce` text,
              `uri` varchar(255) DEFAULT NULL,
              `meta_titre` varchar(255) DEFAULT NULL,
              `meta_description` varchar(255) DEFAULT NULL,
              `meta_keys` varchar(255) DEFAULT NULL,
              `date_creation` int(11) DEFAULT NULL,
              PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;
        ";

        return $out;
    
    }
    
    
    //------------------------
    
    

    private function getSqlNews($name){
        
        $nameNews = '_m_'.$name;
        $nameNewsTrad = '_m_'.$name.'_traduction';
        
        $out = "
        
        DROP TABLE IF EXISTS `$nameNews`;
        
        CREATE TABLE IF NOT EXISTS $nameNews (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `pseudo` varchar(255) DEFAULT NULL,
            `id_user` int(11) DEFAULT '0',
            `id_groupe` int(11) DEFAULT '0',
            `categorie` varchar(255) DEFAULT NULL,
            `active` int(11) NOT NULL DEFAULT '0',
            `comments` int(11) NOT NULL DEFAULT '0',
            `partage` int(11) NOT NULL DEFAULT '1',
            `facebook` int(11) DEFAULT '0',
            `id_facebook` varchar(255) DEFAULT NULL,
            `disqus` int(11) DEFAULT '0',
            `id_disqus` varchar(255) DEFAULT NULL,
            `mailsender` int(11) DEFAULT '0',
            `sendto` varchar(255) DEFAULT NULL,
            `in_rss` int(11) NOT NULL DEFAULT '0',
            `ordre` int(11) NOT NULL DEFAULT '0',
            `groupe_traduction` text,
            `date_creation` int(11) DEFAULT NULL,
            `id_modo` int(111) DEFAULT NULL,
            `val_modo` int(11) DEFAULT '0',
            `date_modo` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;
        
        DROP TABLE IF EXISTS `$nameNewsTrad`;
        
        CREATE TABLE IF NOT EXISTS $nameNewsTrad (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `id_content` int(11) NOT NULL DEFAULT '0',
            `langue` varchar(255) DEFAULT NULL,
            `categorie` varchar(255) DEFAULT NULL,
            `titre` varchar(255) DEFAULT NULL,
            `description` text,
            `article_tinymce` text,
            `uri` varchar(255) DEFAULT NULL,
            `meta_titre` varchar(255) DEFAULT NULL,
            `meta_description` varchar(255) DEFAULT NULL,
            `meta_keys` varchar(255) DEFAULT NULL,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;";
        
        return $out;
        
    }
    
    
    public function full_copy( $source, $target ) {
        
        if ( is_dir( $source ) ) {
            @mkdir( $target );
            $d = dir( $source );
            while ( FALSE !== ( $entry = $d->read() ) ) {
                if ( $entry == '.' || $entry == '..' ) {
                    continue;
                }
                $Entry = $source . '/' . $entry; 
                if ( is_dir( $Entry ) ) {
                    $this->full_copy( $Entry, $target . '/' . $entry );
                    continue;
                }
                copy( $Entry, $target . '/' . $entry );
            }
    
            $d->close();
        }else {
            copy( $source, $target );
        }
        
    }
    
    private function destroy_dir($dir) {
        
        if (!file_exists($dir)) return true; 
        if (!is_dir($dir) || is_link($dir)) return unlink($dir); 
        foreach (scandir($dir) as $item) { 
            if ($item == '.' || $item == '..') continue; 
            if (!$this->destroy_dir($dir . "/" . $item)) { 
                chmod($dir . "/" . $item, 0777); 
                if (!$this->destroy_dir($dir . "/" . $item)) return false; 
            }; 
        } 
        return rmdir($dir);
        
    
    }
    
}