<?php

/*******************************************************************************
/*******************************************************************************
    doorgets 5.0 #!#!#
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class doorgetsController extends Langue{
    
    public      $controllerName;
    
    private     $Action = 'index';
    
    private     $Params = array();
    
    protected   $Content;
    
    public      $thisController;
    
    private     $zoneArea;
    
    protected   $uri;
    
    protected   $table;
    
    public function __construct($doorGetsController){
        
        if(!is_object($doorGetsController)){   return null;   }
        
        $this->Params = $doorGetsController->Params();
        $this->Action = $doorGetsController->Action();
        
        $this->thisController = $doorGetsController;
        $this->zoneArea = $doorGetsController->zoneArea();
        
        $this->getActionMethod();
        
        // Test if $uri module is valid
        $isUri = array();
        $params = $doorGetsController->Params();
        if( array_key_exists('uri',$params['GET']) )
        {
            
            $uri = $params['GET']['uri'];
            $isUri = $doorGetsController->dbQS($uri,'_modules','uri');
            if(!empty($isUri)){
                $this->uri = $uri;
                $this->table = '_m_'.$uri;
            }
        }
        
    }
    
    
    // return the action name
    public function Action(){
        
        return $this->Action;
    
    }
    
    // return all params from $_GET et $_POST
    public function Params(){
        
        return $this->Params;
    
    }
    
    
    public function getUri(){
        
        return $this->uri;    
        
    }
    
    // return the model of te current controller
    public function getModel()
    {
        
        $nameModel = $this->controllerName.'Model';
        $fileNameModel = MODELS.$this->zoneArea.'/'.$nameModel.'.php';
        
        if(!is_file($fileNameModel)){ header('Location:./#'.$fileNameModel); exit(); }
        require_once $fileNameModel;
        
        if(!class_exists ($nameModel)){ header('Location:./#'.$nameModel); exit(); };
        return new $nameModel($this->Action(),$this,$this->thisController->myLanguage());
        
        
    }
    
    // return the view of the current controller
    public function getView()
    {
        
        $nameView = $this->controllerName.'View';
        $fileNameView = VIEW.$this->zoneArea.'/'.$nameView.'.php';
        
        if(!is_file($fileNameView)){ header('Location:./#'.$fileNameView); exit(); };
        require_once $fileNameView;
        
        if(!class_exists ($nameView)){ header('Location:./#'.$nameView); exit(); };
        $view = new $nameView($this->Action(),$this,$this->thisController->myLanguage());
        return $view->getContent();
    }
    
    // return the content
    public function getContent(){
        
        return $this->Content;
    
    }
    
    // Call action mehtod name from the action global and
    // load the return method in Content propriety
    protected function getActionMethod(){
        
        $nameAction = $this->Action().'Action';
        if(method_exists($this,$nameAction)){
            
            $this->Content = $this->$nameAction();
            
        }else{
            
            if( array_key_exists('GET',$this->Params) && array_key_exists('action',$this->Params['GET']) && ctype_alnum($this->Params['GET']['action']) )
            {
                $this->Action = $this->Params['GET']['action'] = 'index';
                $this->Content = $this->indexAction();
            }
        }
        
    }
    
    public function indexAction()
    {
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
        
    }
    
    public function setAction($name){
        
        $this->Action = $name;
        
    }
    
    
}