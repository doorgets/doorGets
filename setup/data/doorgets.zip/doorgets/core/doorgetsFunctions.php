<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 20, February 2014
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Websitehttp://www.doorgets.com
    Contacthttp://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class doorgetsFunctions{
    
    
    public function checkMode($isAdminPanel = true) {
        
        // check if is user
        if($isAdminPanel && empty($this->user)){  header('Location:./'); exit(); }

        if(ACTIVE_DEMO){
            
            $l = new Langue();
            if(isset($this->thisController)){
                $l = $this->thisController;    
            }
            
            FlashInfo::set($l->l("Mode démo").', '.$l->l("Aucune modification n'est autorisée").' !','info');
            header('Location:'.$_SERVER['REQUEST_URI']);exit();
        }
        
    }
    
    public function clearDBCache() {
        
        $dir = CACHE_DB;
        
        foreach (scandir($dir) as $file) { 
            if ($file == '.' || $file == '..') continue;
            $f = $dir.$file;
            if(is_file($f)){
                unlink($f);
            }
        }
    }
    
    
    public function goBackUrl(){
        
        $lgActuel = $this->getLangueTradution();
        
        if(!array_key_exists('HTTP_REFERER',$_SERVER)){ return './'; }
        $url_now = 'http://'.$_SERVER["HTTP_HOST"].$_SERVER['REQUEST_URI'];
        $urlReferer = $_SERVER['HTTP_REFERER'];
        
        $action = $this->Controller->thisController->Action();
        if($action === 'edit'){
            return './?controller='.$this->Controller->controllerName.'&uri='.$this->uri.'&lg='.$lgActuel;
        }
        
        $hostRefererArray = parse_url($urlReferer);
        
        $hostReferer = $hostRefererArray['host'];
        $host = $_SERVER['HTTP_HOST'];
        
        return $urlReferer;
    
    }
    
    
    /*
     * $filter = array(
     *              array('key'=>'fooKey','type'=>'like or =','value'=>'fooValue'),
     *              array('key'=>'otherFooKey','type'=>'like or =','value'=>'otherFooValue'),
     *           );
    */
    public function getCountTable($table,$filter = array(),$other = ''){
        
        $cFilter = count($filter);
        $outFilter = '';
        if(!empty($cFilter)){
            
            $outFilter = ' WHERE ';
            for($i=0;$i < $cFilter;$i++){
                
                if(array_key_exists($i,$filter)){
                    
                    // KEY
                    
                    if(array_key_exists('key',$filter[$i])){
                        
                        $outFilter .= ' '.$filter[$i]['key'];
                        
                    }
                    
                    // TYPE
                    
                    $type = ' = '; $startValue = "'"; $endValue = "'";
                    
                    if( $filter[$i]['type'] === '!=!' )
                    {
                        
                        $type = ' = '; $startValue = ''; $endValue = '';
                    
                    }elseif( $filter[$i]['type'] === '>' )
                    {
                        
                        $type = ' >= '; $startValue = ""; $endValue = "";
                        
                    }elseif( $filter[$i]['type'] === '<' )
                    {
                        
                        $type = ' <= '; $startValue = ""; $endValue = "";
                        
                    }elseif(array_key_exists('type',$filter[$i]) && $filter[$i]['type'] === 'like' )
                    {
                        
                        $type = ' LIKE '; $startValue = "'%"; $endValue = "%'";
                    }
                    
                    $outFilter .= $type;
                    
                    // VALUE
                    
                    if( array_key_exists('value',$filter[$i]) )
                    {
                        
                        $outFilter .= $startValue.$filter[$i]['value'].$endValue;
                    }
                    
                }
                
                if( $i != ( $cFilter - 1) )
                {
                    $outFilter .= ' AND ';
                }
            }
        }
        
        $Query = "SELECT COUNT(*) as counter FROM $table $outFilter $other ";
        //echo '----- '.$Query.'------- <br /><br />';
        
        $isContent = $this->dbQ($Query);
        $cResultsInt = (int)$isContent[0]['counter'];
        
        return $cResultsInt;
        
    }
    
    public function getCountComment($uri_module,$uri_content){
        
        $filter = array(
            array('key'=>'uri_module','type'=>'=','value'=>$uri_module),
            array('key'=>'uri_content','type'=>'=','value'=>$uri_content),
            array('key'=>'validation','type'=>'=','value'=>'2'),
        );
        
        return $this->getCountTable('_dg_comments',$filter);
        
    }
    
    public function getCountCommentNotRead(){
        
        $filter = array(
            
            array('key'=>'validation','type'=>'=','value'=>'3'),
        );
        
        return $this->getCountTable('_dg_comments',$filter);
        
    }
    
    public function getCountInboxNotRead(){
        
        $filter = array(
            array('key'=>'lu','type'=>'=','value'=>'2'),
        );
        
        return $this->getCountTable('_dg_inbox',$filter);
        
    }
    
    public function loadCategories($module=''){
        
        $out = array(0=>'Choisir...');
        $outs = array();
        $outIds = array();
        
        $isContent = $this->dbQ("
        SELECT _categories.id as id,
        _categories.uri_module as module,
        _categories_traduction.nom as nom,
        _categories_traduction.uri as uri
        FROM _categories,_categories_traduction
        WHERE  _categories.id = _categories_traduction.id_cat
        AND _categories.uri_module = '$module'
        AND _categories_traduction.langue = '".$this->getLangueTradution()."'
        ORDER BY _categories.ordre ASC ");
        
        $cContent = count($isContent);
        if($cContent > 0){
            for($i=0;$i<$cContent;$i++){
                
                $outIds[$isContent[$i]['id']] = $isContent[$i]['uri'];
                $out[$isContent[$i]['id']] = $isContent[$i]['nom'];
                $outs[$isContent[$i]['uri']] = $isContent[$i]['nom'];
            }
        }
        $this->categorieSimple = $out;
        $this->categoriesIds = $outIds;
        return $outs;
        
    }
    
    public function loadMultipageCategories($module=''){
        
        $nameTable = '_m_'.$module;
        $nameTableTraduction = $nameTable.'_traduction';
        $tablesSql = $nameTable.', '.$nameTableTraduction;
        
        $out = array();
        
        $isContent = $this->dbQA($tablesSql," WHERE $nameTable.active = 2 AND $nameTable.id = $nameTableTraduction.id_content AND  $nameTableTraduction.langue = '".$this->myLanguage."' ORDER BY ordre LIMIT 100");
        $cContent = count($isContent);
        if($cContent > 0){
            for($i=0;$i<$cContent;$i++){
                
                $out[$isContent[$i]['uri']] = $isContent[$i]['titre'];
            }
        }
        
        return $out;
        
    }
    
    public function moduleInfos($uri,$langue="fr"){
        
        $langue = $this->myLanguage;
        
        $moduleInfos                        = array();
        
        $moduleInfos['id']                  = '';
        $moduleInfos['uri']                 = '';
        $moduleInfos['nom']                 = '';
        $moduleInfos['titre']               = '';
        $moduleInfos['description']         = '';
        $moduleInfos['type']                = '';
        $moduleInfos['groupe_by']           = '';
        $moduleInfos['groupe_by_see_to']    = '';
        
        $isModule = $this->dbQS($uri,'_modules','uri');
        
        if(
            !empty($isModule)
            && $isLangueGroupe = @unserialize($isModule['groupe_traduction'])
        ){
            
            $moduleInfos['id']                  = $isModule['id'];
            $moduleInfos['uri']                 = $isModule['uri'];
            $moduleInfos['type']                = $isModule['type'];
            $moduleInfos['groupe_by']           = $isModule['bynum'];
            $moduleInfos['groupe_by_see_to']    = $isModule['avoiraussi'];
            
            $idTraduction = $isLangueGroupe[$langue];
            $isModuleTraduction = $this->dbQS($idTraduction,'_modules_traduction');
            if(!empty($isModuleTraduction)){
                
                $moduleInfos['nom']         = ucfirst($isModuleTraduction['nom']);
                $moduleInfos['titre']       = $isModuleTraduction['titre'];
                $moduleInfos['description'] = $isModuleTraduction['description'];
                $moduleInfos['all']         = $isModuleTraduction;
            }
        }
        
        return $moduleInfos;
        
    }
    
    public function loadModulesRubrique($module = "",$table="_rubrique"){
        
        $out = array('-');
        $outRubrique = array();

        $isAllRubrique = $this->dbQ("SELECT idModule FROM $table LIMIT 200");
        $cAllRubrique = count($isAllRubrique);
        if(!empty($isAllRubrique)){
            for($i=0;$i<$cAllRubrique;$i++){
                $outRubrique[] = $isAllRubrique[$i]['idModule'];
            }
        }

        $isAllModule = $this->dbQ("SELECT id,uri FROM _modules WHERE type != 'block'  LIMIT 200");
        $cAllModule = count($isAllModule);
        if(!empty($isAllModule)){
            for($i=0;$i<$cAllModule;$i++){
                if(
                    $module == $isAllModule[$i]['id'] 
                ){
                    $out[$isAllModule[$i]['id']] = $isAllModule[$i]['uri'];
                    
                }else{
                    if(!in_array($isAllModule[$i]['id'], $outRubrique)){
                        $out[$isAllModule[$i]['id']] = $isAllModule[$i]['uri'];
                    }
                }
                
            }
        }

        
        return $out;
        
    }
    
    public function loadGroupes(){
        
        $out = array();
        
        $isContent = $this->dbQ("SELECT * FROM _users_groupes ");
        
        $cContent = count($isContent);
        if($cContent > 0){
            for($i=0;$i<$cContent;$i++){
                
                $out[$isContent[$i]['id']] = $isContent[$i]['title'];
                
            }
        }
        
        return $out;
        
    }
    
    public function loadGroupesToSelect(){
        
        $out = array('--');
        
        $isContent = $this->dbQ("SELECT * FROM _users_groupes ");
        
        $cContent = count($isContent);
        if($cContent > 0){
            for($i=0;$i<$cContent;$i++){
                
                $out[$isContent[$i]['id']] = $isContent[$i]['title'];
                
            }
        }
        
        return $out;
        
    }
    
    public function loadGroupesOptionToSelect($table = '_dg_inbox',$key ='uri_module'){
        
        $out = array('--');
        
        $isContent = $this->dbQ("SELECT * FROM $table GROUP BY $key ");
        
        $cContent = count($isContent);
        if($cContent > 0){
            for($i=0;$i<$cContent;$i++){
                
                $out[$isContent[$i][$key]] = $isContent[$i][$key];
                
            }
        }
        
        return $out;
        
    }
    
    public function loadModules($with_type = false){
        
        $out = array();
        
        $isContent = $this->dbQ("SELECT * FROM _modules  WHERE type != 'block' AND type != 'genform'  ");
        $cContent = count($isContent);
        if($cContent > 0){
            for($i=0;$i<$cContent;$i++){
                
                if(!$with_type){
                    
                    $out[$isContent[$i]['id']] = $isContent[$i]['uri'];
                    
                }else{
                    
                    $isModuleTrad = $this->dbQS($isContent[$i]['id'],'_modules_traduction','id_module'," AND langue = '".$this->myLanguage()."' LIMIT 1");
                    if(!empty($isModuleTrad)){
                        
                        $out[$isContent[$i]['id']]['id']        = $isContent[$i]['id'];
                        $out[$isContent[$i]['id']]['active']    = $isContent[$i]['active'];  
                        $out[$isContent[$i]['id']]['uri']       = $isContent[$i]['uri'];
                        $out[$isContent[$i]['id']]['type']      = $isContent[$i]['type'];
                        $out[$isContent[$i]['id']]['label']     = $isModuleTrad['titre'];
                        
                    }
                }
            }
        }
        
        return $out;
        
    }
    
    public function loadModulesBlocks(){
        
        $out = array();
        
        $isContent = $this->dbQ("SELECT * FROM _modules  WHERE type = 'block'  ");
        
        $cContent = count($isContent);
        if($cContent > 0){
            for($i=0;$i<$cContent;$i++){
                
                $isModuleTrad = $this->dbQS($isContent[$i]['id'],'_modules_traduction','id_module'," AND langue = '".$this->myLanguage()."' LIMIT 1");
                if(!empty($isModuleTrad)){
                    
                    $out[$isContent[$i]['id']]['id']        = $isContent[$i]['id'];
                    $out[$isContent[$i]['id']]['active']    = $isContent[$i]['active'];  
                    $out[$isContent[$i]['id']]['uri']       = $isContent[$i]['uri'];
                    $out[$isContent[$i]['id']]['type']      = $isContent[$i]['type'];
                    $out[$isContent[$i]['id']]['label']     = $isModuleTrad['titre'];                        
                }
            }
        }
        
        return $out;
        
    }
    
    public function loadModulesGenforms(){
        
        $out = array();
        
        $isContent = $this->dbQ("SELECT * FROM _modules  WHERE type = 'genform'  ");
        
        $cContent = count($isContent);
        if($cContent > 0){
            for($i=0;$i<$cContent;$i++){
                
                $isModuleTrad = $this->dbQS($isContent[$i]['id'],'_modules_traduction','id_module'," AND langue = '".$this->myLanguage()."' LIMIT 1");
                if(!empty($isModuleTrad)){
                    
                    $out[$isContent[$i]['id']]['id']        = $isContent[$i]['id'];
                    $out[$isContent[$i]['id']]['active']    = $isContent[$i]['active'];  
                    $out[$isContent[$i]['id']]['uri']       = $isContent[$i]['uri'];
                    $out[$isContent[$i]['id']]['type']      = $isContent[$i]['type'];
                    $out[$isContent[$i]['id']]['label']     = $isModuleTrad['titre'];                        
                }
            }
        }
        
        return $out;
        
    }
    
    public function getAllActiveModules(){
        
        $out = array();
        
        $isContent = $this->dbQ("SELECT * FROM _modules WHERE active = 1 AND type != 'block' ");
        
        $cContent = count($isContent);
        if($cContent > 0){
            for($i=0;$i<$cContent;$i++){
                
                $isModuleTrad = $this->dbQS($isContent[$i]['id'],'_modules_traduction','id_module'," AND langue = '".$this->myLanguage()."' LIMIT 1");
                if( !empty($isModuleTrad) ){
                    
                    $out[$isContent[$i]['uri']]['id']     = $isContent[$i]['id'];
                    $out[$isContent[$i]['uri']]['type']   = $isContent[$i]['type'];
                    unset($isContent[$i]['extras']);
                    $out[$isContent[$i]['uri']]['all']    = $isContent[$i] + $isModuleTrad;
                    
                } 
            }
        }
        
        return $out;
        
    }
    
    public function movePosition($type,$table,$id,$pos,$max){
        
        $out = '';
       
        if( !empty($this->Controller->form['_position_up']->i) ){
            
            $this->Controller->checkMode();
            
            $id =   $this->Controller->form['_position_up']->i['id'];
            $type = $this->Controller->form['_position_up']->i['type'];
            $pos =   $this->Controller->form['_position_up']->i['position'];
            
            $posPlus = $pos + 1;
            $posMoins = $pos - 1;
            
            if($pos > 1){
                
                $this->dbQL("UPDATE  $table SET ordre = ordre + 1 WHERE ordre = $posMoins LIMIT 1");
                $this->dbQL("UPDATE  $table SET ordre = $posMoins WHERE  id = $id LIMIT 1");
                
                FlashInfo::set($this->l("La position a bien été mise à jour"));
                header('Location:'.$_SERVER['REQUEST_URI']);
                exit();
                
            }
            
            
        }
        
        if( !empty($this->Controller->form['_position_down']->i) ){
            
            $this->Controller->checkMode();
            
            $id =   $this->Controller->form['_position_down']->i['id'];
            $type = $this->Controller->form['_position_down']->i['type'];
            $pos =   $this->Controller->form['_position_down']->i['position'];
            
            $posPlus = $pos + 1;
            $posMoins = $pos - 1;
            
            if($pos < $max){
                
                $this->dbQL("UPDATE  $table SET ordre = ordre - 1 WHERE ordre = $posPlus LIMIT 1");
                $this->dbQL("UPDATE  $table SET ordre = $posPlus WHERE  id = $id LIMIT 1");
                
                FlashInfo::set($this->l("La position a bien été mise à jour"));
                header('Location:'.$_SERVER['REQUEST_URI']);
                exit();
                
            }
            
            
        }
        
        
        $tpl = Template::getView('bigadmin/rubriques/bigadmin_moveposition');
        ob_start();
        if(is_file($tpl)){ include $tpl; }
        $out .= ob_get_clean();
        
        return $out;
    
    }
    
    
    
    public function updateNewListToParent($table,$idContent,$idParent,$action =  'add'){

        $isContent = $this->dbQS($idContent,$table);
        if(!empty($isContent)){
        
            $holdListe  = $isContent['liste_parent'];
            $holdListe  = str_replace($idParent.',', '', $holdListe);
            
            $newListeParent = $holdListe;
            
            if($action === 'add'){
                
                $newListeParent   = $holdListe.$idParent.',';
                
            }
            
            $data['liste_parent'] = $newListeParent;
            
            $this->dbQU($idContent,$data,$table);
        }
    
    }
    
    public function getArrayForms($nameKey = 'yesno'){
        
        $array = array();
        
        $array['yesno'] =  array(
            
           0 => '--',
           1 => $this->l('Oui'),
           2 => $this->l('Non')
            
        );
        
        $array['website_activation'] =  array(
            
           1 => $this->l('Activer'),
           2 => $this->l('Désactiver')
            
        );
        
        $array['activation'] =  array(
            
            0 => '--',
            1 => $this->l('Inactive'),
            2 => $this->l('Active'),
            3 => $this->l('En attente de modération'),
            4 => $this->l('En cours de rédaction')
            
        );
        
        $array['comment_activation'] =  array(
            
            0 => '--',
            1 => $this->l('Bloquer'),
            2 => $this->l('Activer'),
            3 => $this->l('En attente de modération')
            
        );
        
        $array['users_activation'] =  array(
            
            0 => '--',
            1 => $this->l('Inactive'),
            2 => $this->l('Active'),
            3 => $this->l("En attente d'activation"),
            4 => $this->l('Bannir')
            
        );
        
        $array['sub_module'] =  array(
            
            'can_modo'      => $this->l("Modérateur")
            
        );
        
        $array['mail_format'] =  array(
            
            'html'       => $this->l("HTML"),
            'txt'      => $this->l("Texte")
            
        );
        
        $array['times_zone'] = array (
    
            "Pacific/Wake" => "(GMT-12:00) International Date Line West", 
            "Pacific/Apia" => "(GMT-11:00) Midway Island", 
            "Pacific/Apia" => "(GMT-11:00) Samoa", 
            "Pacific/Honolulu" => "(GMT-10:00) Hawaii", 
            "America/Anchorage" => "(GMT-09:00) Alaska", 
            "America/Los_Angeles" => "(GMT-08:00) Pacific Time (US & Canada); Tijuana", 
            "America/Phoenix" => "(GMT-07:00) Arizona", 
            "America/Chihuahua" => "(GMT-07:00) Chihuahua", 
            "America/Chihuahua" => "(GMT-07:00) La Paz", 
            "America/Chihuahua" => "(GMT-07:00) Mazatlan", 
            "America/Denver" => "(GMT-07:00) Mountain Time (US & Canada)", 
            "America/Managua" => "(GMT-06:00) Central America", 
            "America/Chicago" => "(GMT-06:00) Central Time (US & Canada)", 
            "America/Mexico_City" => "(GMT-06:00) Guadalajara", 
            "America/Mexico_City" => "(GMT-06:00) Mexico City", 
            "America/Mexico_City" => "(GMT-06:00) Monterrey", 
            "America/Regina" => "(GMT-06:00) Saskatchewan", 
            "America/Bogota" => "(GMT-05:00) Bogota", 
            "America/New_York" => "(GMT-05:00) Eastern Time (US & Canada)", 
            "America/Indiana/Indianapolis" => "(GMT-05:00) Indiana (East)", 
            "America/Bogota" => "(GMT-05:00) Lima", 
            "America/Bogota" => "(GMT-05:00) Quito", 
            "America/Halifax" => "(GMT-04:00) Atlantic Time (Canada)", 
            "America/Caracas" => "(GMT-04:00) Caracas", 
            "America/Caracas" => "(GMT-04:00) La Paz", 
            "America/Santiago" => "(GMT-04:00) Santiago", 
            "America/St_Johns" => "(GMT-03:30) Newfoundland", 
            "America/Sao_Paulo" => "(GMT-03:00) Brasilia", 
            "America/Argentina/Buenos_Aires" => "(GMT-03:00) Buenos Aires", 
            "America/Argentina/Buenos_Aires" => "(GMT-03:00) Georgetown", 
            "America/Godthab" => "(GMT-03:00) Greenland", 
            "America/Noronha" => "(GMT-02:00) Mid-Atlantic", 
            "Atlantic/Azores" => "(GMT-01:00) Azores", 
            "Atlantic/Cape_Verde" => "(GMT-01:00) Cape Verde Is.", 
            "Africa/Casablanca" => "(GMT) Casablanca", 
            "Europe/London" => "(GMT) Edinburgh", 
            "Europe/London" => "(GMT) Greenwich Mean TimeDublin", 
            "Europe/London" => "(GMT) Lisbon", 
            "Europe/London" => "(GMT) London", 
            "Africa/Casablanca" => "(GMT) Monrovia", 
            "Europe/Berlin" => "(GMT+01:00) Amsterdam", 
            "Europe/Belgrade" => "(GMT+01:00) Belgrade", 
            "Europe/Berlin" => "(GMT+01:00) Berlin", 
            "Europe/Berlin" => "(GMT+01:00) Bern", 
            "Europe/Belgrade" => "(GMT+01:00) Bratislava", 
            "Europe/Paris" => "(GMT+01:00) Brussels", 
            "Europe/Belgrade" => "(GMT+01:00) Budapest", 
            "Europe/Paris" => "(GMT+01:00) Copenhagen", 
            "Europe/Belgrade" => "(GMT+01:00) Ljubljana", 
            "Europe/Paris" => "(GMT+01:00) Madrid", 
            "Europe/Paris" => "(GMT+01:00) Paris", 
            "Europe/Belgrade" => "(GMT+01:00) Prague", 
            "Europe/Berlin" => "(GMT+01:00) Rome", 
            "Europe/Sarajevo" => "(GMT+01:00) Sarajevo", 
            "Europe/Sarajevo" => "(GMT+01:00) Skopje", 
            "Europe/Berlin" => "(GMT+01:00) Stockholm", 
            "Europe/Berlin" => "(GMT+01:00) Vienna", 
            "Europe/Sarajevo" => "(GMT+01:00) Warsaw", 
            "Africa/Lagos" => "(GMT+01:00) West Central Africa", 
            "Europe/Sarajevo" => "(GMT+01:00) Zagreb", 
            "Europe/Istanbul" => "(GMT+02:00) Athens", 
            "Europe/Bucharest" => "(GMT+02:00) Bucharest", 
            "Africa/Cairo" => "(GMT+02:00) Cairo", 
            "Africa/Johannesburg" => "(GMT+02:00) Harare", 
            "Europe/Helsinki" => "(GMT+02:00) Helsinki", 
            "Europe/Istanbul" => "(GMT+02:00) Istanbul", 
            "Asia/Jerusalem" => "(GMT+02:00) Jerusalem", 
            "Europe/Helsinki" => "(GMT+02:00) Kyiv", 
            "Europe/Istanbul" => "(GMT+02:00) Minsk", 
            "Africa/Johannesburg" => "(GMT+02:00) Pretoria", 
            "Europe/Helsinki" => "(GMT+02:00) Riga", 
            "Europe/Helsinki" => "(GMT+02:00) Sofia", 
            "Europe/Helsinki" => "(GMT+02:00) Tallinn", 
            "Europe/Helsinki" => "(GMT+02:00) Vilnius", 
            "Asia/Baghdad" => "(GMT+03:00) Baghdad", 
            "Asia/Riyadh" => "(GMT+03:00) Kuwait", 
            "Europe/Moscow" => "(GMT+03:00) Moscow", 
            "Africa/Nairobi" => "(GMT+03:00) Nairobi", 
            "Asia/Riyadh" => "(GMT+03:00) Riyadh", 
            "Europe/Moscow" => "(GMT+03:00) St. Petersburg", 
            "Europe/Moscow" => "(GMT+03:00) Volgograd", 
            "Asia/Tehran" => "(GMT+03:30) Tehran", 
            "Asia/Muscat" => "(GMT+04:00) Abu Dhabi", 
            "Asia/Tbilisi" => "(GMT+04:00) Baku", 
            "Asia/Muscat" => "(GMT+04:00) Muscat", 
            "Asia/Tbilisi" => "(GMT+04:00) Tbilisi", 
            "Asia/Tbilisi" => "(GMT+04:00) Yerevan", 
            "Asia/Kabul" => "(GMT+04:30) Kabul", 
            "Asia/Yekaterinburg" => "(GMT+05:00) Ekaterinburg", 
            "Asia/Karachi" => "(GMT+05:00) Islamabad", 
            "Asia/Karachi" => "(GMT+05:00) Karachi", 
            "Asia/Karachi" => "(GMT+05:00) Tashkent", 
            "Asia/Calcutta" => "(GMT+05:30) Chennai", 
            "Asia/Calcutta" => "(GMT+05:30) Kolkata", 
            "Asia/Calcutta" => "(GMT+05:30) Mumbai", 
            "Asia/Calcutta" => "(GMT+05:30) New Delhi", 
            "Asia/Katmandu" => "(GMT+05:45) Kathmandu", 
            "Asia/Novosibirsk" => "(GMT+06:00) Almaty", 
            "Asia/Dhaka" => "(GMT+06:00) Astana", 
            "Asia/Dhaka" => "(GMT+06:00) Dhaka", 
            "Asia/Novosibirsk" => "(GMT+06:00) Novosibirsk", 
            "Asia/Colombo" => "(GMT+06:00) Sri Jayawardenepura", 
            "Asia/Rangoon" => "(GMT+06:30) Rangoon", 
            "Asia/Bangkok" => "(GMT+07:00) Bangkok", 
            "Asia/Bangkok" => "(GMT+07:00) Hanoi", 
            "Asia/Bangkok" => "(GMT+07:00) Jakarta", 
            "Asia/Krasnoyarsk" => "(GMT+07:00) Krasnoyarsk", 
            "Asia/Hong_Kong" => "(GMT+08:00) Beijing", 
            "Asia/Hong_Kong" => "(GMT+08:00) Chongqing", 
            "Asia/Hong_Kong" => "(GMT+08:00) Hong Kong", 
            "Asia/Irkutsk" => "(GMT+08:00) Irkutsk", 
            "Asia/Singapore" => "(GMT+08:00) Kuala Lumpur", 
            "Australia/Perth" => "(GMT+08:00) Perth", 
            "Asia/Singapore" => "(GMT+08:00) Singapore", 
            "Asia/Taipei" => "(GMT+08:00) Taipei", 
            "Asia/Irkutsk" => "(GMT+08:00) Ulaan Bataar", 
            "Asia/Hong_Kong" => "(GMT+08:00) Urumqi", 
            "Asia/Tokyo" => "(GMT+09:00) Osaka", 
            "Asia/Tokyo" => "(GMT+09:00) Sapporo", 
            "Asia/Seoul" => "(GMT+09:00) Seoul", 
            "Asia/Tokyo" => "(GMT+09:00) Tokyo", 
            "Asia/Yakutsk" => "(GMT+09:00) Yakutsk", 
            "Australia/Adelaide" => "(GMT+09:30) Adelaide", 
            "Australia/Darwin" => "(GMT+09:30) Darwin", 
            "Australia/Brisbane" => "(GMT+10:00) Brisbane", 
            "Australia/Sydney" => "(GMT+10:00) Canberra", 
            "Pacific/Guam" => "(GMT+10:00) Guam", 
            "Australia/Hobart" => "(GMT+10:00) Hobart", 
            "Australia/Sydney" => "(GMT+10:00) Melbourne", 
            "Pacific/Guam" => "(GMT+10:00) Port Moresby", 
            "Australia/Sydney" => "(GMT+10:00) Sydney", 
            "Asia/Vladivostok" => "(GMT+10:00) Vladivostok", 
            "Asia/Magadan" => "(GMT+11:00) Magadan", 
            "Asia/Magadan" => "(GMT+11:00) New Caledonia", 
            "Asia/Magadan" => "(GMT+11:00) Solomon Is.", 
            "Pacific/Auckland" => "(GMT+12:00) Auckland", 
            "Pacific/Fiji" => "(GMT+12:00) Fiji", 
            "Pacific/Fiji" => "(GMT+12:00) Kamchatka", 
            "Pacific/Fiji" => "(GMT+12:00) Marshall Is.", 
            "Pacific/Auckland" => "(GMT+12:00) Wellington", 
            "Pacific/Tongatapu" => "(GMT+13:00) Nuku'alofa"
            
        );
        
        
        return $array[$nameKey];
    }
    
    
    
    public function getWebsiteInfoByAttribute($attribute = 'domaine'){
        
        if( !empty($this->configWeb) && array_key_exists($attribute,$this->configWeb) )
        {
            return $this->configWeb[$attribute];    
        }
        
        return null;
    }
    
    public function getRubriques($table = '_rubrique'){
        
        
        $rubOut = array();
        $isGroupeRubrique = $this->dbQ("SELECT * FROM $table WHERE showinmenu = '1' ORDER BY ordre");
        
        if( !empty($isGroupeRubrique) ){
            
            foreach($isGroupeRubrique as $v ){
                
                if( !empty($v['idModule']) ){
                    
                        
                    $isModule = $this->dbQS($v['idModule'],'_modules');
                    
                    if( !empty($isModule) AND $isModule['active'] === '1' ){
                        
                        $isModuleTrad = $this->dbQS($v['idModule'],'_modules_traduction','id_module'," AND langue = '".$this->myLanguage()."'");
                        if( !empty($isModuleTrad) ){
                            
                            $rubOut[$isModule['uri']]['label']      = $isModuleTrad['nom'];
                            $rubOut[$isModule['uri']]['type']       = $isModule['type'];
                            $rubOut[$isModule['uri']]['all']        = $isModule + $isModuleTrad;
                            if($isModule['type'] === 'multipage'){
                                $rubOut[$isModule['uri']]['categories'] = $this->getCategoriesMultipage($isModule['uri']);
                            }else{
                                $rubOut[$isModule['uri']]['categories'] = $this->getCategories($isModule['uri']); 
                            }
                            
                        }
                        
                    }
                }   
            }
            
        }
        
        return $rubOut;
        
    }
    
    public function getRubriquesUsers($table = '_rubrique',$modulesArray){
        
        
        $rubOut = array();
        $isGroupeRubrique = $this->dbQ("SELECT * FROM $table WHERE showinmenu = '1' ORDER BY ordre");
        
        if( !empty($isGroupeRubrique) ){
            
            foreach($isGroupeRubrique as $v ){
                
                if( !empty($v['idModule']) ){
                    
                    $isModule = $this->dbQS($v['idModule'],'_modules');
                    
                    if( !empty($isModule) AND $isModule['active'] === '1' AND  in_array($v['idModule'],$modulesArray) ){
                        
                        $isModuleTrad = $this->dbQS($v['idModule'],'_modules_traduction','id_module'," AND langue = '".$this->myLanguage()."'");
                        if( !empty($isModuleTrad) ){
                            
                            $rubOut[$isModule['uri']]['label']      = $isModuleTrad['nom'];
                            $rubOut[$isModule['uri']]['type']       = $isModule['type'];
                            $rubOut[$isModule['uri']]['all']        = $isModule + $isModuleTrad;
                            $rubOut[$isModule['uri']]['categories'] = $this->getCategories($isModule['uri']);
                            
                        }
                        
                    }
                }   
            }
            
        }
        
        return $rubOut;
        
    }
    
    public function getCategories($module=''){
        
        $out = array();
        
        $isAllRC = $this->dbQ("
        SELECT _categories.id as id,
        _categories.uri_module as module,
        _categories_traduction.nom as nom,
        _categories_traduction.uri as uri
        FROM _categories,_categories_traduction
        WHERE  _categories.id = _categories_traduction.id_cat
        AND _categories.uri_module = '$module'
        AND _categories_traduction.langue = '".$this->getLangueTradution()."'
        ORDER BY _categories.ordre ASC ");
        
        $cRC = count($isAllRC);
        if($cRC > 0){
            for($i=0;$i<$cRC;$i++){
                
                $out[$isAllRC[$i]['uri']]['id'] = $isAllRC[$i]['id'];
                $out[$isAllRC[$i]['uri']]['name'] = $isAllRC[$i]['nom'];
            }
        }
        
        return $out;
        
    }

    public function getCategoriesMultipage($module=''){
        
        $nameTable = '_m_'.$module;
        $nameTableTraduction = $nameTable.'_traduction';
        $tablesSql = $nameTable.', '.$nameTableTraduction;
        
        $out = array();
        
        $isContent = $this->dbQA($tablesSql," WHERE $nameTable.active = 2 AND $nameTable.id = $nameTableTraduction.id_content AND  $nameTableTraduction.langue = '".$this->myLanguage."' ORDER BY ordre LIMIT 100");
        $cContent = count($isContent);
        if($cContent > 0){
            for($i=0;$i<$cContent;$i++){
                $out[$isContent[$i]['uri']]['id'] = $isContent[$i]['id'];
                $out[$isContent[$i]['uri']]['name'] = $isContent[$i]['titre'];
            }
        }
        
        return $out;
        
    }
    
    public function getUrl($type = ''){
        
        $out = BASE_URL;
        
        if(empty($type)){ return $out; }
        
        switch($type){
            
            case 'facebook':
                if(!empty($this->configWeb['facebook'])){
                    $out = 'http://www.facebook.com/'.$this->configWeb['facebook'];   
                }
                break;
            
            case 'twitter':
                if(!empty($this->configWeb['twitter'])){
                    $out = 'http://www.twitter.com/'.$this->configWeb['twitter'];   
                }
                break;
            
            case 'pinterest':
                if(!empty($this->configWeb['pinterest'])){
                    $out = 'https://www.pinterest.com/'.$this->configWeb['pinterest'];   
                }
                break;
            
            case 'linkedin':
                if(!empty($this->configWeb['linkedin'])){
                    $out = 'http://www.linkedin.com/in/'.$this->configWeb['linkedin'];   
                }
                break;
            
            case 'youtube':
                if(!empty($this->configWeb['youtube'])){
                    $out = 'http://www.youtube.com/user/'.$this->configWeb['youtube'];   
                }
                break;
            
            case 'google':
                if(!empty($this->configWeb['google'])){
                    $out = 'https://plus.google.com/u/0/'.$this->configWeb['google'];   
                }
                break;
            
            case 'myspace':
                if(!empty($this->configWeb['myspace'])){
                    $out = 'http://www.myspace.com/'.$this->configWeb['myspace'];   
                }
                break;
            
        }
        
        return $out;
    }
    
    public function getImageSkin($type = ''){
        
        $out = BASE_IMG.'logo.png';
        
        if(empty($type)){ return $out; }
        
        switch($type){
            
            case 'facebook':
                if(!empty($this->configWeb['facebook'])){
                    $out = BASE_IMG.'icone_facebook.png';   
                }
                break;
            
            case 'twitter':
                if(!empty($this->configWeb['twitter'])){
                    $out = BASE_IMG.'icone_twitter.png';   
                }
                break;
            
            case 'pinterest':
                if(!empty($this->configWeb['pinterest'])){
                    $out = BASE_IMG.'icone_pinterest.png';   
                }
                break;
            
            case 'linkedin':
                if(!empty($this->configWeb['linkedin'])){
                    $out = BASE_IMG.'icone_linkedin.png';   
                }
                break;
            
            case 'youtube':
                if(!empty($this->configWeb['youtube'])){
                    $out = BASE_IMG.'icone_youtube.png';   
                }
                break;
            
            case 'google':
                if(!empty($this->configWeb['google'])){
                    $out = BASE_IMG.'icone_google.png';   
                }
                break;
            
            case 'myspace':
                if(!empty($this->configWeb['myspace'])){
                    $out = BASE_IMG.'icone_myspace.png';   
                }
                break;
            
        }
        
        return $out;
    }
    
    
    
    public function _toArray($list){
        
        $out = array();
        $ListeArray = array();
        
        if(!empty($list)){
            
            $ListeArray = explode(',',$list); 
        }
        foreach ($ListeArray as $key => $value) {
            if(!empty($value)){
                $out[$key] = trim($value);
            }
        }
        
        return $out;
    
    }
    public function _toArrayKeys($list){
        
        $out = array();
        $ListeArray = array();
        
        if(!empty($list)){
            
            $ListeArray = explode(',',$list); 
        }
        foreach ($ListeArray as $key => $value) {
            $value = trim($value);
            $vKey = strstr($value,'|',true);
            $vValue = str_replace('|','',strstr($value,'|'));
            if(!empty($value)){
                $out[$vKey] = $vValue;
            }
        }
        
        return $out;
    
    }
    
    public function _genKey($t) {
        
        $kc = md5(KEY_SECRET);  $ct=0;  $v = ""; 
        for ($ctr=0;$ctr<strlen($t);$ctr++) 
        { 
            if ($ct==strlen($kc)){ $ct=0; }
            $v.= substr($t,$ctr,1) ^ substr($kc,$ct,1); $ct++; 
            
        }
        
        return $v;
    
    }
    
    public function _genRandomKey($amount = 18){
        
        $keyset = "abcdefghijklmABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        $randkey = "";
        for ($i=0; $i<$amount; $i++)
        $randkey .= substr($keyset, rand(0, strlen($keyset)-1), 1);
        
        return $randkey;
    
    }
    
    public function _trackMe($idUser){
        
        $dataTrack['id_user']       = $idUser;
        $dataTrack['id_session']    = session_id();
        $dataTrack['ip_session']    = $_SERVER['REMOTE_ADDR'];
        $dataTrack['url_page']      = $_SERVER['REQUEST_URI'];
        
        if(!array_key_exists('HTTP_REFERER',$_SERVER)){ $_SERVER['HTTP_REFERER'] = ''; }
        
        $dataTrack['url_referer']   = $_SERVER['HTTP_REFERER'];
        $dataTrack['date']          = time();
        
        $this->dbQI($dataTrack,'_users_notification');
        
    }
    
    public function _crypt($t){
        
        srand((double)microtime()*1000000);  $kc = md5(rand(0,32000) );  $ct=0;  $v = ""; 
        for ($ctr=0;$ctr<strlen($t);$ctr++) 
        { 
            if ($ct==strlen($kc))  { $ct=0; } 
            $v.= substr($kc,$ct,1).(substr($t,$ctr,1) ^ substr($kc,$ct,1) ); $ct++;
        }
        
        return base64_encode($this->_genKey($v) );
    
    }
    public function _decrypt($t){ 
        
        $t = $this->_genKey(base64_decode($t)); $v = ""; 
        for ($ctr=0;$ctr<strlen($t);$ctr++) 
        { 
            $md5 = substr($t,$ctr,1);  $ctr++; 
            $v.= (substr($t,$ctr,1) ^ $md5); 
        }
        
        return $v;
    
    }
    
    public function time(){
        
        $date = new DateTime(null, new DateTimeZone(date_default_timezone_get()));
        
        return $date->getTimestamp() + $date->getOffset();
        
    }
    
    public function isIpUserStatut(){
        
        $listeIP = $this->_toArray($this->configWeb['statut_ip']);
        
        if( !empty($listeIP) && in_array($_SERVER['REMOTE_ADDR'],$listeIP) )
        {
            return true;
        }
        return false;
    }
    
    public function getAllThemesName(){
        
        $dir = BASE.'themes/';
        $f = array();
        foreach (scandir($dir) as $file) { 
            
            if ($file == '.' || $file == '..' || $file == 'index.php') continue;
            if(is_dir($dir.$file)){ $f[] = $file; }
            
        }
        
        return $f;
        
    }
    
    public function duplicateTheme($dirFrom,$dirTo){
        
        $dir = BASE.'themes/';
        @mkdir($dir.$dirTo, 0777, true);
        if($this->rcopy($dir.$dirFrom, $dir.$dirTo)){
            return true;
        }
        return false;
    }
    
    public function deleteTheme($dirName){
        
        $dir = BASE.'themes/';
        $this->rrmdir($dir.$dirName);
        
    }
    
    private function rrmdir($dir) {
      if (is_dir($dir)) {
        $files = scandir($dir);
        foreach ($files as $file)
        if ($file != "." && $file != "..") $this->rrmdir("$dir/$file");
        rmdir($dir);
        
      }
      else if (file_exists($dir)) unlink($dir);
    }
    
    public function listThemeFiles($dirName) {
        
        
        $dir = BASE.'themes/'.$dirName;
        
        if (is_dir($dir)) {
            $files = scandir($dir);
            foreach ($files as $file){
                if ($file != "." && $file != ".."){
                    
                    $dirFile = str_replace('../themes/','',"$dir/$file");
                    
                    $restJs = substr($file, -3);
                    $restCss = substr($file, -4);
                    $restTpl = substr($file, -8);
                    if($restJs === '.js'){
                        $this->_tempdata['js']["$dirFile"] = $file;   
                    }
                    if($restCss === '.css'){
                        $this->_tempdata['css']["$dirFile"] = $file;   
                    }
                    if($restTpl === '.tpl.php'){
                        $this->_tempdata['tpl']["$dirFile"] = $file;   
                    }
                    
                    $this->listThemeFiles("$dirFile");
                }
            }
            
        
        }
        
        return $this->_tempdata;
    }
    
    
    public function rcopy($src, $dst) {
      if (file_exists($dst)) $this->rrmdir($dst);
      if (is_dir($src)) {
        mkdir($dst);
        $files = scandir($src);
        foreach ($files as $file)
        if ($file != "." && $file != "..") $this->rcopy("$src/$file", "$dst/$file"); 
      }
      else if (file_exists($src)) copy($src, $dst);
    }
    
    public function files($dir = ''){
        
        if(!is_dir($dir)) return array();
        $f = array();
        foreach (scandir($dir) as $file) { 
            if ($file == '.' || $file == '..' || $file == 'index.php' || $file == '.htaccess' ) continue;
            if(is_file($dir.$file)){ $f[] = $file; }
            
        }
        
        return $f;
        
    }
    
    public function _truncate($string,$lenMax = 100){
        $len = strlen($string);
        if( $len > $lenMax - 1 ){
            $string = substr(strip_tags($string),0,$lenMax).'...';
        }
        return $string;
    }
    
    public function _formToHtml($data,$form){
        
        
        $out = '';
        if(empty($data)){ return $out; }
        $iData = count($data);
        
        for($i=1;$i<$iData+1;$i++){
            
            $valObli = '';
            if($data[$i]['obligatoire'] === 'yes'){$valObli = ' <span class="color-red">*</span>';}
            switch ($data[$i]['type']){
                
                case 'tag-title':
                    
                    if($data[$i]['active'] === 'yes'){
                        $out .= '<div class="row"><div class="col-xs-12">';
                        $out .= '<'.$data[$i]['filtre'].' class="'.$data[$i]['css'].'">'.$data[$i]['label'].'</'.$data[$i]['filtre'].'>';
                        $out .= '</div></div>';                        
                    }

                    break;
                
                case 'tag-quotte':
                    
                    if($data[$i]['active'] === 'yes'){
                        $out .= '<div class="row"><div class="col-xs-12">';
                        $out .= '<blockquote class="'.$data[$i]['css'].'">'.$data[$i]['label'].'</blockquote>';
                        $out .= '</div></div>';                        
                    }

                    break;
                
                case 'tag-separateur':
                    
                    if($data[$i]['active'] === 'yes'){
                        $out .= '<div class="row"><div class="col-xs-12">';
                        $out .= '<hr class="'.$data[$i]['css'].'" />';
                        $out .= '</div></div>';                        
                    }

                    break;
                
                case 'text':
                    
                    if($data[$i]['active'] === 'yes'){
                        $out .= '<div class="row"><div class="col-xs-12">';
                        $out .= '<div class="input-group '.$data[$i]['css'].'">';
                        $out .= $form->input($data[$i]['label'].$valObli.' <div class="in-label"></div> ',$data[$i]['value'],'text','','form-control '.$data[$i]['css']);
                        $out .= '<small>'.$data[$i]['info'].'</small></div></div></div>';                        
                    }

                    break;
                
                case 'textarea':
                    
                    if($data[$i]['active'] === 'yes'){
                        $out .= '<div class="row"><div class="col-xs-12">';
                        $out .= '<div class="input-group '.$data[$i]['css'].'">';
                        $out .= $form->textarea($data[$i]['label'].$valObli.' <div class="in-label"></div> ',$data[$i]['value'],'','form-control '.$data[$i]['css']);
                        $out .= '<small>'.$data[$i]['info'].'</small></div></div></div>';
                    }
                    break;
                
                case 'select':
                    
                    if($data[$i]['active'] === 'yes'){
                        $r = array();
                        $e = explode(',',$data[$i]['liste']);
                        foreach($e as $v){
                            if(!empty($v)){
                                $r[$v] = trim($v);
                            }
                        }
                        $out .= '<div class="row"><div class="col-xs-12"><div class="input-group '.$data[$i]['css'].'">';
                        $out .= '';
                        $out .= $form->select($data[$i]['label'].$valObli.'<div class="in-label"></div> ',$data[$i]['value'],$r,'form-control '.$data[$i]['css']);
                        $out .= '<small>'.$data[$i]['info'].'</small></div></div></div>';
                    }
                    break;
                
                case 'checkbox':
                    
                    if($data[$i]['active'] === 'yes'){
                        $e = explode(',',$data[$i]['liste']);
                        $out .= '<div class="row"><div class="col-xs-12"><div class="input-group '.$data[$i]['css'].'">';
                        $out .= $form->checkbox($data[$i]['label'].$valObli,$data[$i]['value'],1,'','checkbox-inline');
                        $out .= '<small>'.$data[$i]['info'].'</small></div></div></div>';
                    }
                    break;
                
                case 'radio':
                    
                    if($data[$i]['active'] === 'yes'){
                        $out .= '<div class="row"><div class="col-xs-12"><div class="input-group '.$data[$i]['css'].'">';
                        $e = explode(',',$data[$i]['liste']);
                        $out .= '<label>'.$data[$i]['label'].$valObli.'</label>';
                        foreach($e as $v){
                            $v = trim($v);
                            if(!empty($v)){
                                $out .= $form->radio($v,$data[$i]['value'],$v,'','radio-inline');
                            }
                        }
                        $out .= '<small>'.$data[$i]['info'].'</small></div></div></div>';
                    }
                    break;
                
                case 'file':
                    
                    if($data[$i]['active'] === 'yes'){
                        $out .= '<div class="row"><div class="col-xs-12"><div class="input-group '.$data[$i]['css'].'">';
                        $out .= $form->file($data[$i]['label'].$valObli,$data[$i]['value']);
                        $out .= '<small>'.$data[$i]['info'].'</small></div></div></div>';
                    }
                    break;
            }
        }
        
        return $out;
    }
    
    public function _getGenFormFields($data){
        
        $out = array();
        if(empty($data)){ return $out; }
        $iData = count($data);
        
        $aFields = array("text","textarea","select","checkbox","radio","file");
        for($i=1;$i<$iData+1;$i++){
            
            if( in_array($data[$i]['type'],$aFields) && $data[$i]['active'] === 'yes' ){
                
                $out[$data[$i]['value']] = $data[$i];
                
            }
        }
        return $out;
    }
    
    public function getIdContentPosition($id,$pos = 'next'){
        
        
        $isContent = $this->dbQS($id,$this->table);
        if(!empty($isContent)){
            
            $position = (int)$isContent['ordre'] ;
            
            if($pos==='next'){
                $isPosContent = $this->dbQA($this->table," WHERE ordre > ".$position." LIMIT 1"); 
            }else{
                $isPosContent = $this->dbQA($this->table," WHERE ordre < ".$position." LIMIT 1"); 
            }
            
            if(!empty($isPosContent)){
                return (int)$isPosContent[0]['id'];
            }
            
        }
        
        return 0;
    
    }
    
    public function getIdContentPositionDate($id,$pos = 'next'){
        
        $isContent = $this->dbQS($id,$this->table);
        if(!empty($isContent)){
            
            if($pos==='next'){
                $isPosContent = $this->dbQA($this->table," WHERE id > ".$id." LIMIT 1"); 
            }else{
                $isPosContent = $this->dbQA($this->table," WHERE id < '".$id."' ORDER BY id DESC LIMIT 1"); 
            }
            if(!empty($isPosContent)){
                return (int)$isPosContent[0]['id'];
            }
            
        }
        
        return 0;
    
    }
}