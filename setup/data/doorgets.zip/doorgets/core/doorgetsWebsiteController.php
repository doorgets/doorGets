<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 5.1 - 04 December, 2013
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class doorgetsWebsiteController {
    
    public $Website;
    
    public function __construct($WebsiteObject){
        
        if(!is_object($WebsiteObject)){ return null; }
        $this->Website = $WebsiteObject;
        $this->setContent();
        $this->getModel();
        $this->getView();
        
    }
    
    public function setContent(){
        
    }
    
    public function getModel(){
        
        $type = $this->Website->getType();
        if(empty($type)){ return null; }

        $nameModel = 'module'.ucfirst($type).'Model';
        $fileNameModel = MODELS.'website/'.$nameModel.'.php';
        
        if(!is_file($fileNameModel))
        { echo 'Model not found : ' . $fileNameModel; exit();  }
        require_once $fileNameModel;
        
        if(!class_exists ($nameModel))
        { echo 'Class  not found : ' . $nameModel.' : '; exit(); }
        
        return new $nameModel($this->Website);
        
    }
    
    public function getView(){
        
        $type = $this->Website->getType();
        if(empty($type)){ return null; }
        
        $nameView = 'module'.ucfirst($type).'View';
        $fileNameView = VIEW.'website/'.$nameView.'.php';
        
        if(!is_file($fileNameView))
        { echo 'View not found : ' . $fileNameView; exit();  }
        require_once $fileNameView;
        
        if(!class_exists ($nameView))
        { echo 'Class  not found : ' . $nameView.' : '; exit(); }
        $view = new $nameView($this->Website);
        $this->Website->setContentView($view->getContent());
    
    }
    
}