<?php

header("Location:../");
exit;