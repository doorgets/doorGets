<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?><div style="padding:0 0 15px;">
    {{!$this->genLangueMenu()!}}
</div>

{{!$formWebsite->open()!}}

<table  width="100%" align="center" style="border:solid 1px #999;padding: 5px;border-radius:0 0 4px 4px;text-align:left;background-color:#f1f1f1;">
<tr>
    <td width="100%" valign="top" >
    <table  width="100%" align="center">
        <tr>
            <td  valign="top" >
                {{!$formWebsite->input($lTitre.'<br />','title','text',$this->info['title'])!}}
            </td>
        </tr>
        <tr>
            <td valign="top" >
                {{!$formWebsite->input($lSlogan.'<br />','slogan','text',$this->info['slogan'])!}}
            </td>
        </tr>
        <tr>
            <td width="430px" valign="top" >
                {{!$formWebsite->input($lDescription.'<br />','description','text',$this->info['description'])!}}
            </td>
        </tr>
    </table>
    <table  width="430px" align="left">
        <tr>
            <td  valign="top" >
                {{!$formWebsite->input($lCopyright.'<br />','copyright','text',$this->info['copyright'])!}}
            </td>
        </tr>
    </table>
    <table  width="200px" align="left" >
        <tr>
            <td width="200px" valign="top" >
                {{!$formWebsite->input($lCreation.'<br />','year','text',$this->info['year'])!}}
            </td>
        </tr>
    </table>
    <table   width="100%"  align="center" >
        <tr>
            <td valign="top" >
                {{!$formWebsite->input($lKeywords.'<br />','keywords','text',$this->info['keywords'])!}}
            </td>
        </tr>
    </table>
    <div class="green topbottom padding " style="padding-left:0;">{{!$this->getWords('Commentaire')!}}</div>
    <table   width="100%"  align="left" >
        <tr>
            <td valign="top" >
                
                {{!$formWebsite->input('ID Facebook <br />','id_facebook','text',$this->info['id_facebook'])!}}
                
            </td>
        </tr>
        <tr>
            <td valign="top" >
                
                {{!$formWebsite->input('Disqus <br />','id_disqus','text',$this->info['id_disqus'])!}}
                
            </td>
        </tr>
    </table>
    <div class="green topbottom padding " style="padding-left:0;">{{!$this->getWords('Choisir un theme pour votre site')!}}</div>
    <table   width="100%"  align="left" >
        <tr>
            <td valign="top" >
                
                {{/($isAllTheme as $theme):}}
                    {{!$formWebsite->radio($theme,'theme',$theme,$this->info['theme']).'<br />'!}}
                {/}
                
            </td>
        </tr>
    </table>
    
    </td>
</tr>
</table>
<table  width="100%" align="center" cellpadding="10px" style="padding: 5px;">
    <tr>
        <td  style="text-align:center;">
            {{!$formWebsite->submit($this->getWords('Sauvegarder'))!}}
        </td>
    </tr>
</table>

{{!$formWebsite->close()!}}