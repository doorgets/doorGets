<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>{{?(!empty($cAll)):}}
    
    
    
    <div style="padding:5px 0;">
    {{!$this->genLangueMenu()!}}
    </div>
    
    <div class=" topbottom paddingtb  ">
    {{!($ini+1)!}} {{!$this->getWords('à')!}} {{!$finalPer!}} {{!$this->getWords('sur')!}} <b>{{!$cResultsInt!}} 
    {{?( $cResultsInt > 1 ):}} {{!$this->getWords('Questions')!}} {??} {{!$this->getWords('Question')!}} {?}
    </b>
    <a class="right green" href="./?m={{!$this->uri!}}&add_faq">
        <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
        {{!$this->getWords('Ajouter une question / réponse')!}}
    </a>
    </div>
    <div class=" topbottom"  >
    {{-($i=0;$i<$cAll;$i++):}}
    
        {{
            $all[$i]['reponse_tinymce'] = htmlspecialchars_decode(html_entity_decode($all[$i]['reponse_tinymce']));
            $zz = $i + 1;
            $idQuestion = $all[$i]['id'];        
        }}

        <table class="texte" style="width:100%;padding:0px;margin:0px;"><tr><td  valign="top" >
        
            <span style="float:left;margin:0 5px 5px -10px" class="annuler" >{{!$zz!}}</span>
            <b>{{!$all[$i]['question']!}}</b>
            <div id="faq-reponse-bt-afficher-{{!$idQuestion!}}" class="bt-slide" >+ {{!$this->getWords('Réponse')!}}</div>
            <div id="faq-reponse-bt-masquer-{{!$idQuestion!}}" class="bt-slide" style="display:none;">- {{!$this->getWords('Réponse')!}}</div>
            <div id="faq-reponse-content-{{!$idQuestion!}}" style="display:none;"><small style="font-weight:100;">{{!$all[$i]['reponse_tinymce']!}}</small></div>
            <script type="text/javascript">
                $("#faq-reponse-bt-afficher-{{!$idQuestion!}}").click(
                    function() {
                        $("#faq-reponse-bt-masquer-{{!$idQuestion!}}").show();
                        $(this).hide();
                        $("#faq-reponse-content-{{!$idQuestion!}}").slideDown();
                    });
                $("#faq-reponse-bt-masquer-{{!$idQuestion!}}").click(
                    function() {
                        $("#faq-reponse-bt-afficher-{{!$idQuestion!}}").show();
                        $(this).hide();
                        $("#faq-reponse-content-{{!$idQuestion!}}").slideUp();
                    });
            </script>
            
        </td><td valign="middle"  style="width:30px;text-align:center;border-left:dashed 1px #ccc;">
        
            {{?( $all[$i]['ordre'] != 1 ):}}
                {{!$this->moveUp($all[$i]['id_content'],$all[$i]['ordre'],$cResultsInt)!}}
            {??}
                <span>&nbsp;</span>
            {?}
            
        </td><td  valign="middle"  style="width:30px;text-align:center;border-left:dashed 1px #ccc;">
        
            {{?( $all[$i]['ordre'] != $cResultsInt ):}}
                {{!$this->moveDown($all[$i]['id_content'],$all[$i]['ordre'],$cResultsInt)!}}
            {??}
                <span>&nbsp;</span>
            {?}
            
        </td><td valign="middle"  style="width:30px;text-align:center;border-left:dashed 1px #ccc;">
        
            <a href="./?m={{!$this->uri!}}&action=modifier&lg={{!$lgActuel!}}&id={{!$all[$i]['id_content']!}}">
                <img src="{{!THM.'ad_/img/modifier.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" ></a>
            
        </td><td valign="middle"  style="width:30px;text-align:center;border-left:dashed 1px #ccc;">
        
            <a href="./?m={{!$this->uri!}}&action=supprimer&lg={{!$lgActuel!}}&id={{!$all[$i]['id_content']!}}"><img src="{{!THM.'ad_/img/supprimer.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" ></a>
        
        </td></tr></table>
        
    {-}
    
    </div>
    
{??}
    
    <div class=" topbottom padding">
        <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
        <a class="green" href="./?m={{!$this->uri!}}&add_faq">{{!$this->getWords('Ajouter une question / réponse')!}}</a>
    </div>
    
{?}