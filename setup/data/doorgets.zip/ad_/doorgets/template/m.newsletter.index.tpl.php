<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>{{?(!empty($cAll)):}}
    
    <div class=" topbottom padding backccc">
        {{!($ini+1)!}} {{!$this->getWords("à")!}} {{!$finalPer!}} {{!$this->getWords("sur")!}}
        <b>{{!$cResultsInt.' '!}}
        {{?( $cResultsInt > 1 ):}}{{!$this->getWords('Contacts')!}} {??} {{!$this->getWords('Contact')!}} {?}
        </b>
    </div>
    <div class=" topbottom" style="padding-top:10px;">
    {{-($i=0;$i<$cAll;$i++):}}
        <div class="listing_page topbottom texte padding hover">
            <b>{{!ucfirst($all[$i]['nom'])!}}</b> {{!$all[$i]['email']!}}
            <span class="right ">
                {{!date('d/m/Y H:i',$all[$i]['date_creation'])!}}
                <a href="./?r=newsletter&action=supprimer&id={{!$all[$i]['id']!}}"><img src="{{!THM.'ad_/img/supprimer.png'!}}" style="height: 15px;width:15px;vertical-align: middle;" ></a>
            </span>
        </div>
    {-}
    </div>
    <br /><div class=" center width-100">
    {{!$valPage!}}
    </div>
    
{??}

    <div class=" red topbottom backccc padding">
        {{!$this->getWords("Il n'y a actuellement aucun contact")!}}
    </div>
    
{?}

    