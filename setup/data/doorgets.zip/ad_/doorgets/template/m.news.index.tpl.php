<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
{{?(!empty($q)):}}
    <div class=" topbottom paddingtb " style="border-top:0;" >
        {{!$this->getWords('chercher')!}} : <b style="color:#007D9A;">{{!$q!}}</b>
         <a href="./?m={{!$this->uri!}}&lg={{!$lgActuel!}}" class="padding annuler" style="margin-left:5px;">{{!$this->getWords('retour à la liste compléte')!}}</a>
        
    </div>
{?}
<div style="padding:5px 0;">
    {{!$this->genLangueMenu()!}}
</div>
{{?(!empty($cAll)):}}
    
    <div class=" topbottom padding" style="background-color:#f1f1f1;">
        
        {{!($ini+1)!}} {{!$this->getWords('à')!}} {{!$finalPer!}} {{!$this->getWords('sur')!}} <b>{{!$cResultsInt!}}
        {{?( $cResultsInt > 1 ):}} {{!$this->getWords('actualités')!}} {??} {{!$this->getWords('actualité')!}} {?}</b>
    
    </div>
    <div class=" topbottom"  style="padding-top:10px;text-algin:left;">
    {{-($i=0;$i<$cAll;$i++):}}
        
        {{
            $lgGroupe = unserialize($all[$i]['groupe_traduction']); $idTraduction = $lgGroupe[$lgActuel];
            $idContenuTrad = $this->dbQS($idTraduction,$this->table.'_traduction');        
        }}

        
        {{?(!empty($idContenuTrad)):}}
            <div class="listing_page padding  texte green "  >
                
                {{!date('d/m/Y',$all[$i]['date_creation'])!}}
                <a href="./?m={{!$this->uri!}}&categorie={{!$all[$i]['categorie']!}}" style="font-size:12pt;float: right;">{{!$this->categorieSimple[$all[$i]['categorie']]!}}</a>
                <img src="{{!$fileTag!}}" style="width:18px;height:18px;margin:0px 0;vertical-align:bottom;margin-right:8px;float: right;" >
                
            </div>
            <div class="listing_page padding  texte hover"  >
                <div class="listing_page padding green topbottom" style="border-top:0px;" >
                    <a href="./?m={{!$this->uri!}}&action=voir&id={{!$all[$i]['id']!}}" style="font-size:15pt;"  >
                        {{!ucfirst($idContenuTrad['titre'])!}}
                    </a>
                    <br />
                    <a href="./?m={{!$this->uri!}}&action=modifier&id={{!$all[$i]['id']!}}">
                        <img src="{{!THM.'ad_/img/modifier.png'!}}" style="height: 15px;width:15px;vertical-align: middle;" >
                        {{!$this->getWords('Modifier')!}}
                    </a>
                    <a href="./?m={{!$this->uri!}}&action=supprimer&id={{!$all[$i]['id']!}}">
                        <img src="{{!THM.'ad_/img/supprimer.png'!}}" style="height: 15px;width:15px;vertical-align: middle;" >
                        {{!$this->getWords('Supprimer')!}}
                    </a>
                </div>
                <div class="listing_page padding "  >
                    {{!ucfirst($idContenuTrad['description'])!}}
                </div>
                
            </div>   
        {?}
    {-}
    </div>
    <div class=" center width-100">
    {{!$valPage;}}
    </div>
    
{??}
    
    {{?(isset($_GET['categorie'])):}}
        
        <div class=" red topbottom backccc padding">
            {{!$this->getWords("Il n'y a actuellement aucune actualité pour cette catégorie.")!}}
            <a class="green" href="./?m={{!$this->uri!}}&add_contenu">
                <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
                {{!$this->getWords('Ajouter une actualité')!}}
            </a>
        </div>
        
    {{???(!empty($q)):}}
        
        <div class=" red topbottom backccc  padding">
            {{!$this->getWords("Aucune actualité trouvé pour votre recherche.");}}
        </div>
        
    {??}
        
        <div class=" topbottom  padding">
            <a class="green" href="./?m={{!$this->uri!}}&add_contenu">
                <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
                {{!$this->getWords('Ajouter une actualité')!}}
            </a>
        </div>
    {?}

{?}