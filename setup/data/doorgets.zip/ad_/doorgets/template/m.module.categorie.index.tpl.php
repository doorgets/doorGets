<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
{{?(!empty($cAll)):}}

    {{ $lgActuel = $this->getLangueTradution(); }}
    
    <div style="padding:5px 0;">
    {{!$this->genLangueMenu();}}
    </div>
    
    <div class=" topbottom paddingtb  ">
        {{!($ini+1)!}} {{!$this->getWords('à')!}} {{!$finalPer!}} {{!$this->getWords('sur')!}} <b>{{!$cResultsInt!}} 
        {{?( $cResultsInt > 1 ):}}{{!$this->getWords('Catégories')!}}{??}{{!$this->getWords('Catégorie')!}}{?}
        </b>
        <a class="right green" href="./?m={{!$this->module!}}cat&add_categorie">
            <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
            {{!$this->getWords('Ajouter une catégorie')!}}
        </a>
    </div>
    <div class=" "  >
    <dd id="sortable">
    {{-($i=0;$i<$cAll;$i++):}}
        
        {{
            $lgGroupe = unserialize($all[$i]['groupe_traduction']);
            $idTraduction = $lgGroupe[$lgActuel]; $idCatTrad = $this->dbQS($idTraduction,$this->table.'_traduction');
        }}
        
        {{?(!empty($idCatTrad)):}}
           
            
            <dl  id="{{!$idCatTrad['uri']!}}_{{!$i!}}" name="{{!$idCatTrad['uri']!}}_{{!$i!}}" class="ui-state-default padding  texte hover  green" style="font-size:12pt;margin:0px;padding:0;" >
            <table style="width: 100%;padding:0px;margin:0px;">
                <tr>
                    <td  valign="top"  style="width: 90%;">
                        <a href="./?m={{!$this->module!}}cat&action=voir&lg={{!$lgActuel!}}&id={{!$all[$i]['id']!}}" style="padding:5px;text-align:left;"  >
                        {{!ucfirst($idCatTrad['nom'])!}}
                        <small style="font-weight:100;">
                            - {{!ucfirst($idCatTrad['titre'])!}}
                        </small>
                        </a>
                    </td>
                    <td valign="top" style="text-align: right;width: 30px;" >
                        {{?( $all[$i]['ordre'] != 1 ):}}
                            {{!$this->moveUp($all[$i]['id'],$all[$i]['ordre'],$cResultsInt); }}
                        {??}
                            &nbsp;
                        {?}
                    </td>
                    <td  valign="top" style="text-align: right;width: 30px;" >
                        {{?( $all[$i]['ordre'] != $cResultsInt ):}}
                            {{!$this->moveDown($all[$i]['id'],$all[$i]['ordre'],$cResultsInt); }}
                        {??}
                            &nbsp;
                        {?}
                    </td>
                    <td valign="top" style="text-align: right;width: 32px;" >
                        <a href="./?m={{!$this->module!}}cat&action=modifier&lg={{!$lgActuel!}}&id={{!$all[$i]['id']!}}"><img src="{{!THM.'ad_/img/modifier.png'!}}" style="height: 25px;width:25px;" ></a> 
                    </td>
                    <td  valign="top" style="text-align: right;width: 32px;"  >
                        <a href="./?m={{!$this->module!}}cat&action=supprimer&lg={{!$lgActuel!}}&id={{!$all[$i]['id']!}}""><img src="{{!THM.'ad_/img/supprimer.png'!}}" style="height: 25px;width:25px;" ></a>
                    </td>
                </tr>
            </table>
            </dl>
            
        {?}

        
        
    {-}
    </dd>
    </div>
        <br /><div class=" center width-100">
        {{!$valPage!}}
    </div>
    
{??}
    
    <div class=" topbottom paddingtb">
        <a class="green" href="./?m={{!$this->module!}}cat&add_categorie">
            <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
            {{!$this->getWords('Ajouter une catégorie')!}}
        </a>
    </div>
    
{?}
