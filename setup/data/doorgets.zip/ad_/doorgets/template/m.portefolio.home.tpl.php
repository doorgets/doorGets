<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
<div id="m-portefolio-home">
{{?(!empty($q)):}}
    
    <div class=" topbottom padding " style="border-top:0;padding-left:0px;" >
        {{!$this->getWords('chercher')!}} : <b style="color:#007D9A;">{{!$q!}}</b>
        <a href="./?m={{!$this->uri!}}" class="padding annuler" style="margin-left:5px;">{{!$this->getWords('retour à la liste compléte')!}}</a>
        
    </div>
    
{?}

<div style="padding:5px 0;">
    {{!$this->genLangueMenu()!}}
</div>

{{?(!empty($cAll)):}}
    
    <dl class="line-none"  >
    {{-($i=0;$i<$cAll;$i++):}}
    {{
        $iCat = $this->dbQ('SELECT COUNT(*) as counter FROM '.$this->table.' WHERE active = 1 AND categorie = '.$all[$i]['categorie']);
        $cCat = (int)$iCat[0]['counter'];
        $portefolioComment = new ContentCommentaire($all[$i]['id_content'],'portefolio_comments',$this->GetLangue())
    }}
        {{?(strlen($all[$i]['titre']) > 30):}}{{ $all[$i]['titre'] = substr($all[$i]['titre'],0,30); }}{?}
        {{ $all[$i]['image'] = URL.'data/'.$this->uri.'/middle/'.$all[$i]['image']; }}
        <dd class="contour-hombre"  >
            
            <div class="porte-titre" >
                <span class="color-in" >
                    {{!utf8_encode(ucfirst($this->categorieSimple[$all[$i]['categorie']]))!}}
                </span>
            </div>
            <div  >
                <a href="./?m={{!$this->uri!}}&categorie={{!$all[$i]['categorie']!}}"  >
                    <img alt="" src="{{!$all[$i]['image']!}}" style="width:265px;height:250px;margin-right:2px;border:solid 1px #ccc;padding:2px;background-color:#000;" >
                </a>
                
                <div  >
                    
                    <span >
                       <a href="./?m={{!$this->uri!}}&categorie={{!$all[$i]['categorie']!}}"  >
                       <img alt="" src="{{!$filePortefolio!}}" class="img-icone-plus"  >
                       {{!$cCat!}}
                       </a>
                    </span>
                
                </div>
            </div> 
            
        </dd>
    {-}
    </dl>
    <br /><div class=" center width-100">
    {{!$valPage!}}
    </div>
    
{??}
    
    {{?(isset($_GET['categorie'])):}}
        
        <div class=" red topbottom backccc padding">
            {{!$this->getWords("Il n'y a actuellement aucune image pour cette catégorie.")!}}
            <a class="green" href="./?m={{!$this->uri!}}&add_contenu">
                <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
                {{!$this->getWords('Ajouter une image')!}}
            </a>
        </div>
        
    {{???(!empty($q)):}}
        
        <div class=" red topbottom backccc  padding">
            {{!$this->getWords("Aucune image trouvé pour votre recherche.");}}
        </div>
        
    {??}
        
        <div class="  topbottom  paddingtb">
            <a class="green" href="./?m={{!$this->uri!}}&add_contenu">
                <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
                {{!$this->getWords('Ajouter une image')!}}
            </a>
        </div>
    {?}
    
{?}
</div>