<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
<div id="titre_top_admin" >

    {{?( array_key_exists($rub,$rubss) ):}}
        
        {{?( $rub === 'blogcat' || $rub === 'blogcomment' ):}}
            
            <a href="./?r=blog" style="font-weight:bold;color:#f1f1f1;">{{!$this->getWords('Blog')!}}</a> &#187;
            
        {?}
        {{?( $rub === 'tutocat' || $rub === 'tutocomment' ):}}
            
            <a href="./?r=tuto" style="font-weight:bold;color:#f1f1f1;">{{!$this->getWords('Tutoriels')!}}</a> &#187;
            
        {?}
        {{?( $rub === 'portefoliocat' || $rub === 'portefoliocomment' ):}}
            
            <a href="./?r=portefolio" style="font-weight:bold;color:#f1f1f1;">{{!$this->getWords('PorteFolio')!}}</a> &#187;
            
        {?}
        <b>{{!$rubss[$rub]!}}</b>
        
    {{???( array_key_exists($rub,$rubs) ):}}
        {{?($rub === 'gestion'):}}<img src="{{!THM.'ad_/img/ico_module.png'!}}" style="width: 25px;height: 25px;vertical-align: middle;margin-right: 5px;">{?}
        {{?($rub === 'rubrique'):}}<img src="{{!THM.'ad_/img/list-rubrique-b.png'!}}" style="width: 25px;height: 25px;vertical-align: middle;margin-right: 5px;">{?}
        {{?($rub === 'comment'):}}<img src="{{!THM.'ad_/img/comment_blog-b.png'!}}" style="width: 25px;height: 25px;vertical-align: middle;margin-right: 5px;">{?}
        {{?($rub === 'contactezmoi'):}}<img src="{{!THM.'ad_/img/contact-b.png'!}}" style="width: 25px;height: 25px;vertical-align: middle;margin-right: 5px;">{?}
        {{?($rub === 'config'):}}<img src="{{!THM.'ad_/img/icone-configuration-b.png'!}}" style="width: 25px;height: 25px;vertical-align: middle;margin-right: 5px;">{?}
        
        <b>{{!$rubs[$rub]!}}</b>
        
    {?}
    
</div>