<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>{{?(!empty($cAll)):}}
    
    
    
    <div style="padding:5px 0;">
    {{!$this->genLangueMenu()!}}
    </div>
    
    <div class=" topbottom paddingtb  ">
        {{!($ini+1)!}} {{!$this->getWords('à')!}} {{!$finalPer!}} {{!$this->getWords('sur')!}} <b>{{!$cResultsInt!}} 
        {{?( $cResultsInt > 1 ):}} {{!$this->getWords('Liens')!}} {??} {{!$this->getWords('Lien')!}} {?}
        </b>
        <a class="right green" href="./?m={{!$this->uri!}}&add_liens">
            <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
            {{!$this->getWords('Ajouter un lien')!}}
        </a>
    </div>
    <div class=" topbottom"  >
    {{-($i=0;$i<$cAll;$i++):}}
        
        {{ $zz = $i + 1; }}
        <table class="texte" style="width:100%;padding:0px;margin:0px;"><tr>
        <td  valign="top" style="width:80px;text-align:center;border-right:dashed 1px #ccc;" >
            
            <img src="{{!THM!}}data/{{!$this->uri!}}/{{!$all[$i]['image']!}}" style="width:100px;height:100px;" >
            
        </td><td valign="top" style="width:700px;"  >
        
            <b>{{!$all[$i]['titre']!}}</b>
            <br /><small style="font-weight:100;">{{!$all[$i]['url']!}}</small>
            <div id="liens-bt-afficher-{{!$i!}}" class="bt-slide" >+ {{!$this->getWords('afficher')!}}</div>
            <div id="liens-bt-masquer-{{!$i!}}" class="bt-slide" style="display:none;">- {{!$this->getWords('masquer')!}}</div>
            <div id="liens-content-{{!$i!}}" style="display:none;"><small style="font-weight:100;">{{!$all[$i]['description']!}}</small></div>
            
            <script type="text/javascript">
                $("#liens-bt-afficher-{{!$i!}}").click(
                    function() {
                        $("#liens-bt-masquer-{{!$i!}}").show();
                        $(this).hide();
                        $("#liens-content-{{!$i!}}").slideDown();
                    });
                $("#liens-bt-masquer-{{!$i!}}").click(
                    function() {
                        $("#liens-bt-afficher-{{!$i!}}").show();
                        $(this).hide();
                        $("#liens-content-{{!$i!}}").slideUp();
                    });
            </script>
            
            
        </td><td valign="middle"  style="width:25px;text-align:center;border-left:dashed 1px #ccc;">
        
            {{?( $all[$i]['ordre'] != 1 ):}}
                {{!$this->moveUp($all[$i]['id_content'],$all[$i]['ordre'],$cResultsInt)!}}
            {??}  <div>&nbsp;</div> {?}
            
        </td><td  valign="middle"  style="width:30px;text-align:center;border-left:dashed 1px #ccc;">
        
            {{?( $all[$i]['ordre'] != $cResultsInt ):}}
                {{!$this->moveDown($all[$i]['id_content'],$all[$i]['ordre'],$cResultsInt)!}}
            {??} <div>&nbsp;</div> {?}
            
        </td><td valign="middle"  style="width:30px;text-align:center;border-left:dashed 1px #ccc;">
        
            <a href="./?m={{!$this->uri!}}&action=modifier&lg={{!$lgActuel!}}&id={{!$all[$i]['id_content']!}}"><img src="{{!THM.'ad_/img/modifier.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" ></a>
            
        </td><td valign="middle"  style="width:25px;text-align:center;border-left:dashed 1px #ccc;">
        
            <a href="./?m={{!$this->uri!}}&action=supprimer&lg={{!$lgActuel!}}&id={{!$all[$i]['id_content']!}}"><img src="{{!THM.'ad_/img/supprimer.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" ></a>
        
        </td></tr></table>
        
    {-}
    
    </div>
    
{??}
    
    <div class="  topbottom  padding">
        
        <a class="green" href="./?m={{!$this->uri!}}&add_liens">
            <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
            {{!$this->getWords('Ajouter un lien')!}}
        </a>
    </div>
    
{?}