<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?><div class="  ">
    <div class=" paddingtb backccc  " >
        <img src="{{!THM.'ad_/img/modifier.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
        {{!$this->getWords('Modifier un lien')!}}  : <b>{{!$idLiensTrad['titre']!}}</b>
    </div>
    <div class=" paddingtb-10 topbottom " >
        {{!$form->open('post','')!}}
        <div class=" paddingtb topbottom marginb">
            {{!$this->genLangueMenu()!}}
        </div>
        {{!$form->input($this->getWords('Titre').'<br />','titre','text',$idLiensTrad['titre'])!}}
        <br />
        {{!$form->input($this->getWords('URL').'<br />','url','text',$idLiensTrad['url'])!}}
        <br />
        {{!$form->textarea($this->getWords('Description').'<br />','description',$idLiensTrad['description'])!}}        
    </div>
    <div class=" padding center" >
        {{!$form->submit($this->getWords('Sauvegarder'))!}}
        <a class="annuler" href="./?m={{!$this->uri!}}&lg={{!$lgActuel!}}">{{!$this->getWords('annuler')!}}</a>
    </div>
        {{!$form->close();}} 
</div>