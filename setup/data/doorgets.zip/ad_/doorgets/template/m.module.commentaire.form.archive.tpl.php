<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
<div class="content">
    
    <div class=" topbottom " style="">
    
        <div  style="border:0px;text-align:left;padding:4px;font-size:12pt;">
            <a  href="./?r=comment">{{!$this->getWords('retour à la liste compléte')!}}</a>
            {{!$isDeleted;}}
        </div>
    </div>
    <div class=" topbottom padding texte " style="margin-left:0px;font-size:13pt;color:#603CA8;margin-top:10px;{{!$colorBack!}}">
        
        <b>{{!ucwords($isCommentaire['nom'])!}}</b>, {{!$isCommentaire['email']!}},  {{!$this->getWords('le')!}} {{!date('d/m/Y',$isCommentaire['date_creation'])!}}
    </div>
    <div style="width:98%;margin:0 auto;border:solid 1px #ccc;padding:5px;margin-top:-10px;border-radius:0 0 5px 5px;" >
        
        <div class=" padding ">
            {{!$isCommentaire['comment'];}}
        </div>
    </div>
</div>

{{?(empty($isCommentaire['archive'])):}}
    
    <div class=" topbottom  ">
        {{!$form->open('post','','')!}}
        {{!$form->input('','archive','hidden','1')!}}
        <table id="box_login_bottom"  class="topbottom width-100 center"><tr><td >
        {{!$form->submit($this->getWords("Archiver ce commentaire"))!}}
         <a class="annuler" href="./?r=comment&action=voir&id={{!$isCommentaire['id']!}}">{{!$this->getWords('annuler')!}}</a>
        </td></tr></table>
        {{!$form->close()!}}
    </div>
    
{??}
    
    <div class=" topbottom  ">
        {{!$form->open('post','','')!}}
        {{!$form->input('','archive','hidden','0')!}}
        <table id="box_login_bottom"  class="topbottom width-100 center"><tr><td >
        {{!$form->submit($this->getWords("Désarchiver ce commentaire"))!}}
         <a class="annuler" href="./?r=comment&action=voir&id={{!$isCommentaire['id']!}}">{{!$this->getWords('annuler')!}}</a>
        </td></tr></table>
        {{!$form->close()!}}
    </div>
    
{?}
