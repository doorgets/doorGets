<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
<div style="padding:5px 0;">
    {{!$this->genLangueMenu()!}}
</div>
{{?(!empty($cAll)):}}
    
    <div class=" topbottom padding" >
    {{!($ini+1)!}} {{!$this->getWords('à')!}} {{!$finalPer!}} {{!$this->getWords('sur')!}} <b>{{!$cResultsInt!}}</b>
    <a class="right green" href="./?r=modules&add_module">{{!$this->getWords('Ajouter un module')!}}</a>
    </div>
    <div class=" topbottom"  style="padding-top:10px;text-algin:left;">
    {{-($i=0;$i<$cAll;$i++):}}
        
        {{
            $lgGroupe = unserialize($all[$i]['groupe_traduction']); $idTraduction = $lgGroupe[$lgActuel];
            $idContenuTrad = $this->dbQS($idTraduction,$this->table_trad);
            $isFirstr = '';
            if($all[$i]['is_first']){
                $isFirstr = 'backccc';
            }
        }}

        
        {{?(!empty($idContenuTrad)):}}
            
        <div class="listing_page padding  texte hover {{!$isFirstr!}}"  >
                <a href="./?r=modules&action=voir&id={{!$all[$i]['id']!}}" style="font-size:9pt;"  >
                    <b>{{!ucfirst($all[$i]['uri'])!}}</b> - [<em>{{!$all[$i]['type']!}}</em>]
                    <br />
                    <small style="color: #999;">
                        {{!ucfirst($idContenuTrad['titre'])!}}
                    </small>
                </a>
        </div>   
        {?}
    {-}
    </div>
    <br /><div class=" center width-100">
    {{!$valPage;}}
    </div>
    
{??}

    <div class=" red topbottom backccc padding">
        {{!$this->getWords("Il n'y a actuellement aucun module dans la base")!}} :
        <a class="annuler" href="./?r=modules&add_module">
            {{!$this->getWords('Ajouter un module')!}}
        </a>
    </div>
    
{?}