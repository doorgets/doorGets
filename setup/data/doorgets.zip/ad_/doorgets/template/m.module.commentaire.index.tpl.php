<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
{{?(!empty($q)):}}
    <div class=" topbottom padding " style="border-top:0;" >
        {{!$this->getWords('recherche')!}}
        : <b style="color:#007D9A;">{{!$q!}}</b>
    </div>
{?}


{{?(!empty($cAll)):}}
    
    
    <div class=" " style="padding-top:5px;padding-bottom:10px;">
    
    <table border="0" style="width:100%;">
        <tr style="text-align:center;">
            <td style="width:50%;border-bottom:dashed #ccc 1px;text-align:left;">
            {{!($ini+1)!}} {{!$this->getWords('à')!}} {{!$finalPer!}} {{!$this->getWords('sur')!}} <b>{{!$cResultsInt!}}
            {{?( $cResultsInt > 1 ):}}
                {{!$this->getWords('Commentaires')!}}
            {??}
                {{!$this->getWords('Commentaire')!}}
            {?}
            </b>
            </td>
            <td style="width:10%;border-bottom:dashed #ccc 1px;">{{!$this->getWords('Date')!}}</td>
            <td style="width:15%;border-bottom:dashed #ccc 1px;">{{!$this->getWords('Module')!}}</td>
            <td style="width:15%;border-bottom:dashed #ccc 1px;">{{!$this->getWords('Contenu')!}}</td>
            
            <td style="width:15%;border-bottom:dashed #ccc 1px;">{{!$this->getWords('Validation')!}}</td>
            
        </tr>

        {{-($i=0;$i<$cAll;$i++):}}
            
            {{
                $lCut = 60;$isLu = '';
                $lMessage = strlen($all[$i]['comment']);
                if($lMessage > $lCut){ $all[$i]['comment'] = substr($all[$i]['comment'],0,$lCut).'...'; }
                if(empty($all[$i]['lu'])){ $isLu = 'background-color:#f1f1f1;'; }
                if(!empty($all[$i]['date_validation'])){ $all[$i]['date_validation'] =  date('d/m/Y',$all[$i]['date_validation']); }else{$all[$i]['date_validation'] = '-';}
                $ImageStatut = THM.'ad_/img/puce-orange.png';
                if($all[$i]['validation'] == 1){
                    $ImageStatut = THM.'ad_/img/puce-verte.png';
                }elseif($all[$i]['validation'] == 2){
                    $ImageStatut = THM.'ad_/img/puce-rouge.png';
                }
            
            }}
            
            
            <tr style="text-align:center;" class="listing_page topbottom texte padding hover  " style="">
                
                <td style="width:87%;text-align:left;padding:10px 0;{{!$isLu!}}">
                    <a href="./?r=comment&filter={{!$all[$i]['uri_module']!}}&action=voir&id={{!$all[$i]['id']!}}" style="margin-left:5px;font-size:12pt;"><img src="{{!$ImageStatut!}}" style="vertical-align: middle;" ><small style="margin-left:5px;color:#aaa;"><b>{{!ucfirst($all[$i]['nom'])!}}</b>, {{!$all[$i]['comment']!}}</small></a>
                </td>
                
                <td style="text-align:center;color:#777;font-size:9pt;">
                    {{!date('d/m/Y H:i',$all[$i]['date_creation']);}}
                </td>
                <td style="text-align:center;color:#777;font-size:9pt;">
                    {{!$all[$i]['uri_module']!}}
                </td>
                <td style="text-align:center;color:#777;font-size:9pt;">
                    <a href="./?m={{!$all[$i]['uri_module']!}}&action=voir&id={{!$all[$i]['uri_content']!}}" target="blank">{{!$this->getWords('voir')!}}</a>
                </td>
                <td style="text-align:center;color:#777;font-size:9pt;">
                    {{!$all[$i]['date_validation'];}}
                </td>
                <td style="width:13%;text-align:center;color:#777;font-size:9pt;">
                    <a href="./?r=comment&filter={{!$all[$i]['uri_module']!}}&action=supprimer&id={{!$all[$i]['id']!}}"><img src="{{!THM.'ad_/img/supprimer.png'!}}" style="height: 20px;width:20px;vertical-align: middle;" ></a>
                </td>
            </tr>
                
        {-}
        </table>
        </div>
        <br /><div class=" center paddingtb">
        {{!$valPage;}}
        </div>
        {{?(!empty($q)):}}
            <div class=" topbottom padding" style="margin-top:10px;border-bottom:0;" >
                <a href="./?r=comment">
                    <img src="{{!THM.'ad_/img/retour.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
                    {{!$this->getWords('retour')!}}
                </a>
            </div>
        {?}
        
        <div class=" topbottom padding">
            <img src="{{!THM.'ad_/img/puce-verte.png'!}}" style="vertical-align: middle;" > {{!$this->getWords("Commentaire active")!}},
            <img src="{{!THM.'ad_/img/puce-rouge.png'!}}" style="vertical-align: middle;" > {{!$this->getWords("Commentaire bloqué")!}},
            <img src="{{!THM.'ad_/img/puce-orange.png'!}}" style="vertical-align: middle;" > {{!$this->getWords("Commentaire en attente")!}}
        </div>
    
{??}
    
    <div class=" red topbottom backccc padding">
        {{!$this->getWords("Aucun commentaire trouvé.");}}
    </div>
    {{?(!empty($q)):}}
        <div class=" topbottom padding"  >
            <a href="./?r=comment">
                <img src="{{!THM.'ad_/img/retour.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
                {{!$this->getWords('retour')!}}
            </a>
        </div>
    {?}
    
{?}