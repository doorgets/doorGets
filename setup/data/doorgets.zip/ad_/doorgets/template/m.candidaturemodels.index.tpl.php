<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>{{?(!empty($cAll)):}}
    
    <div class=" topbottom padding backccc">
        {{!($ini+1)!}} {{!$this->getWords('à')!}} {{!$finalPer!}} {{!$this->getWords('sur')!}}
         <b>{{!$cResultsInt!}}
         {{?( $cResultsInt > 1 ):}} {{!$this->getWords('candidats')!}} {??} {{!$this->getWords('candidat')!}} {?}</b>
        
    </div>
    <div class=" topbottom" style="padding-top:10px;">
    
    <table border="0" style="width:100%;">
        <tr style="text-align:center;">
            <td style="width:5%;border-bottom:dashed #ccc 1px;">&nbsp;</td>
            <td style="width:75%;border-bottom:dashed #ccc 1px;">&nbsp;</td>
            <td style="width:20%;border-bottom:dashed #ccc 1px;">{{!$this->getWords('date')!}}</td>
        </tr>

        {{-($i=0;$i<$cAll;$i++):}}
            
            {{
                $file = THM.'ad_/img/user.png';
                if($all[$i]['sexe'] === 'men')
                { $file = THM.'ad_/img/user-h.png'; }elseif($all[$i]['sexe'] === 'women'){ $file = THM.'ad_/img/user-f.png';}            
            }}

            
            <tr style="text-align:center;" class="listing_page topbottom texte padding hover">
                <td style="width:5%;">
                    <a href="./?m={{!$this->table!}}&action=voir&id={{!$all[$i]['id']!}} " >
                        <img src="{{!$file!}}" style="width:36px;height:36px;margin:3px 0;" >
                    </a>
                </td>
                <td style="width:75%;text-align:left;">
                    <a href="./?m={{!$this->table!}}&action=voir&id={{!$all[$i]['id']!}} " style="margin-left:5px;">
                        <b>{{!ucfirst($all[$i]['nom'])!}}</b><br /><small style="margin-left:5px;">{{!$all[$i]['email']!}}</small>
                    </a>
                </td>
                <td style="width:20%;text-align:center;">
                    <a href="./?m={{!$this->table!}}&action=voir&id={{!$all[$i]['id']!}} " style="margin-left:5px;">
                        {{!date('d/m/Y H:i',$all[$i]['date_creation'])!}}
                    </a>
                </td>
                
            </tr>
            
        {-}
        </table>
        </div>
        <br />
        <div class=" center width-100">
        {{!$valPage;}}
        </div>
    </table>
    
{??}
    
    <div class=" red topbottom paddingtb">
        {{!$this->getWords("Il n'y a actuellement aucune candidature")!}} 
    </div>
    
{?}

   