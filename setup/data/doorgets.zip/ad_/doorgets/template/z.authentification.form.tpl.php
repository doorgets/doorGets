<div id="page">

    <div class="texte" style="margin:35px auto 0;width:450px;background-color:#fff;border-radius:8px;padding:5px 13px 5px 10px">
    
        <div class="topbottom green" style="padding:10px 3px;color:#603CA8;border-top:0px;font-size:14pt;">
        {{!$this->getWords('Identifiez-vous')!}}
        </div>
        <br />
    
        {{!$form->open('post','','')!}}
        {{!$form->input($this->getWords('Identifiant').'<br />','login')!}}
        <br />
        {{!$form->input($this->getWords('Mot de passe').'<br />','pwd','password')!}}
        <br /><br />
        <div class="topbottom green center" style="padding:10px 3px;color:#603CA8;font-size:14pt;">
        {{!$form->submit($this->getWords('Connexion'))!}}
        </div>
        {{!$form->close()!}}
    </div>
</div>
<div style="margin:10px auto 0; width:470px;height:45px;text-align:right;" >
    <a target="self" title="doorGets CMS PHP & MySQL V4.1" href="http://www.doorgets.com/">doorGets CMS PHP & MySQL V4.1</a>
     {{!$this->getWords('par')!}}
    <a target="self" title="Professeur PHP" href="http://www.professeur-php.com/">Mounir R'Quiba © 2013</a>
</div>
