<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
{{?(!empty($cAll)):}}
    
    <div class=" topbottom padding" >
    {{!($ini+1)!}} {{!$this->getWords('à')!}} {{!$finalPer!}} {{!$this->getWords('sur')!}} <b>{{!$cResultsInt!}}
    {{?( $cResultsInt > 1 ):}}{{!$this->getWords('rubriques')!}}{??}{{!$this->getWords('rubrique')!}}{?}</b>
    <a class="right green" href="./?r=rubrique&add_rubrique">
        <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 26px;width:26px;vertical-align: middle;" > {{!$this->getWords('Ajouter une rubrique')!}}
    </a>
    </div>
    <div class=" topbottom"  style="padding-top:10px;text-algin:left;">
    {{-($i=0;$i<$cAll;$i++):}}
        {{
            
            $bCss = 'backddd';$nModule = '';$tModule = '';$tiModule = '';
            $isModule = $this->dbQS($all[$i]['idModule'],'_modules');
            $isModuleTrad = $this->dbQS($all[$i]['idModule'],'_modules_traduction','id_module'," AND langue = '".$this->GetLangue()."' LIMIT 1 ");
            if( !empty($isModule) && !empty($isModuleTrad) ){
                $nModule=$isModule['uri'];
                $tModule='['.$isModule['type'].']';
                $tiModule = $isModuleTrad['nom'].' - '.$isModuleTrad['titre'];
                $bCss = ' hover';
            }
            
        }}
        <div class="listing_page padding  texte {{!$bCss!}}"  >
            {{?( $all[$i]['ordre'] != $cResultsInt ):}}
                {{!$this->moveDown($all[$i]['id'],$all[$i]['ordre'],$cResultsInt); }}
            {?}
            {{?( $all[$i]['ordre'] != 1 ):}}
                {{!$this->moveUp($all[$i]['id'],$all[$i]['ordre'],$cResultsInt); }}
            {?}
            <a href="./?r=rubrique&action=voir&id={{!$all[$i]['id']!}}" style="font-size:10pt;"  >
                <img src="{{!THM.'ad_/img/list-rubrique.png'!}}" style="height: 26px;width:26px;vertical-align: middle;" >
                <b>{{!ucfirst($all[$i]['name'])!}}</b> {{!$tModule!}}
            </a>
            <a href="./?r=rubrique&action=modifier&id={{!$all[$i]['id']!}}" class=" " >
                <img src="{{!THM.'ad_/img/modifier.png'!}}" style="height: 20px;width:20px;vertical-align: middle;" >
            </a>
            <a href="./?r=rubrique&action=supprimer&id={{!$all[$i]['id']!}}" class=" " >
               <img src="{{!THM.'ad_/img/supprimer.png'!}}" style="height: 20px;width:20px;vertical-align: middle;" >
            </a>
            <br />
            {{!$tiModule!}}  
        </div>
        
    {-}
    </div>
    
{??}

    <div class=" red topbottom  padding">
        {{!$this->getWords("Il n'y a actuellement aucune rubrique")!}} :
        <a class="green" href="./?r=rubrique&add_rubrique">
            <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 26px;width:26px;vertical-align: middle;" > {{!$this->getWords('Ajouter une rubrique')!}}
        </a>
    </div>
    
{?}