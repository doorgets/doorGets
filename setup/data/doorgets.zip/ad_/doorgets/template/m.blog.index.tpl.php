<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>{{?(!empty($q)):}}
    <div class=" topbottom padding " style="border-top:0;padding-left:0px;" >
        {{!$this->getWords('chercher')!}} : <b style="color:#007D9A;">{{!$q!}}</b>
         <a href="./?m={{!$this->uri!}}" class="padding annuler" style="margin-left:5px;">{{!$this->getWords('retour à la liste compléte')!}}</a>
        
    </div>
{?}
<div style="padding:5px 0;">
    {{!$this->genLangueMenu()!}}
</div>
{{?(!empty($cAll)):}}
    
    <div class=" topbottom padding" style="background-color:#f1f1f1;">
    {{!($ini+1)!}} {{!$this->getWords('à')!}} {{!$finalPer!}} {{!$this->getWords('sur')!}} <b>{{!$cResultsInt!}}
    {{?( $cResultsInt > 1 ):}}{{!$this->getWords('articles')!}}{??}{{!$this->getWords('article')!}}{?}
    </b>
    </div>
    <div class=" topbottom"  style="padding-top:10px;text-algin:left;">
    <ul style="list-style-type: none;clear:both;display: inline-block;width:98%;">
    {{-($i=0;$i<$cAll;$i++):}}
        {{
            $lgGroupe = unserialize($all[$i]['groupe_traduction']);
            $idTraduction = $lgGroupe[$lgActuel];
            $idContenuTrad = $this->dbQS($idTraduction,$this->table.'_traduction');
        }}

        
        {{?(!empty($idContenuTrad)):}}
        
            {{ $blogComment = new ContentCommentaire($all[$i]['id'],'_comments',$this->uri,$lgActuel); }}
            {{ $sComm = $this->getWords('Commentaire'); }}
            {{?($blogComment->countCommentaire > 1):}}{{ $sComm = $this->getWords('Commentaires'); }}{?}
        
            {{ $fileLogo = THM.'data/'.$this->uri.'/'.$idContenuTrad['image']; }}
            {{?( !is_file($fileLogo) ):}}{{ $fileLogo = THM.'data/contenu/no-file.png'; }}{?}
            
            {{ $fileActive = THM.'ad_/img/voir.png'; }}
            {{?(!$all[$i]['active']):}}
                $fileActive = THM.'ad_/img/pasvoir.png';
            {?}
            
            <li style="float:left;width:100%;margin-left:-40px;border-right:0px;" >
                
                    <div class="listing_page padding  texte hover" style="width:100%;" >
                        <div class="listing_page padding  topbottom" style="width:98%;border-top:0px;" >
                            <a href="./?m={{!$this->uri!}}&action=voir&lg={{!$lgActuel!}}&id={{!$idContenuTrad['id_content']!}}" class="green"  >{{!ucfirst($idContenuTrad['titre'])!}}</a>
                            <br />
                            <a href="./?m={{!$this->uri!}}&action=modifier&lg={{!$lgActuel!}}&id={{!$idContenuTrad['id_content']!}}"><img src="{{!THM.'ad_/img/modifier.png'!}}" style="height: 15px;width:15px;vertical-align: middle;" > {{!$this->getWords('Modifier')!}}</a> 
                            <a href="./?m={{!$this->uri!}}&action=supprimer&lg={{!$lgActuel!}}&id={{!$idContenuTrad['id_content']!}}"><img src="{{!THM.'ad_/img/supprimer.png'!}}" style="height: 15px;width:15px;vertical-align: middle;" > {{!$this->getWords('Supprimer')!}}</a>
                            
                        </div>
                        <div class="listing_page padding topbottom" style="width:98%;border-top:0px;font-size:10pt;color:#999;" >
                                <img src="{{!$fileActive!}}" style="width:25px;height:25px;vertical-align:middle;margin-right:3px;" >
                                {{!ucfirst(strftime("%A %d %B %Y",$idContenuTrad['date_creation']))!}}
                                    
                                 <span class="right "> {{!$blogComment->countCommentaire!}} {{!$sComm!}} </span>
                                 <span class="right " style="border-right:dashed 1px #ccc;border-left:dashed 1px #ccc;margin-right:10px;padding:5px 10px;margin-top:-5px">
                                 <a href="./?m={{!$this->uri!}}&lg={{!$lgActuel!}}&categorie={{!$idContenuTrad['categorie']!}}">{{!$this->categorieSimple[$idContenuTrad['categorie']]!}}</a> </span>
                        </div>
                        <div class="listing_page padding" style="width:95%;" >
                            <table style="width:104%;"><tr><td  valign="top" width="305x">
                            
                                    <a href="./?m={{!$this->uri!}}&action=voir&lg={{!$lgActuel!}}&id={{!$all[$i]['id']!}}" style="width:95%;"  >
                                        <img src="{{!$fileLogo!}}" style="border:1px #cccccc solid;padding:3px;margin:3px;width:300px;height:200px;font-size:9pt;" >
                                    </a>
                                    
                                </td><td valign="top" >
                                    <div class="listing_page padding" style="width:100%;color:#999;font-size:11pt;" >
                                        {{!$idContenuTrad['description']!}}
                                        <br /><br /><a href="./?m={{!$this->uri!}}&action=voir&lg={{!$lgActuel!}}&id={{!$all[$i]['id']!}}" class="annuler right" style="font-size:12pt;margin-right:10px;padding:5px 15px;">{{!$this->getWords("Lire l'article")!}}</a>
                                    </div>
                            </td></tr></table>
                        </div>
                    </div>   
                
            </li>
        {?}
    {-}
    </ul>
    </div>
    <br />
    <div class=" center width-100">
    {{!$valPage!}}
    </div>
    
{??}
    
    {{?(isset($_GET['categorie'])):}}
        
        <div class=" red topbottom backccc padding">
            {{!$this->getWords("Il n'y a actuellement aucun article pour cette catégorie.")."  "!}}
            <a class="green" href="./?m={{!$this->uri!}}&add_contenu">
                <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 26px;width:26px;vertical-align: middle;" > {{!$this->getWords('Ajouter un article')!}}
            </a>
        </div>
        
    {{???(!empty($q)):}}
        
        <div class=" red topbottom backccc  padding">
            {{!$this->getWords("Aucun article trouvé pour votre recherche.")!}}
        </div>
        
    {??}
        
        <div class=" topbottom paddingtb">
            
            <a class="green" href="./?m={{!$this->uri!}}&add_contenu">
                <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 26px;width:26px;vertical-align: middle;" > {{!$this->getWords('Ajouter un article')!}}
            </a>
        </div>
    {?}

{?}
