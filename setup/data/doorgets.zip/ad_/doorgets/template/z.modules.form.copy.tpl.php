<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
<div class="  ">
    <div class=" paddingtb backccc  " >
        <img src="{{!THM.'ad_/img/icone-copy.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
        {{!$this->getWords('Dupliquer un module')!}} : {{!$isContenu['uri']!}} [{{!$isContenu['type']!}}]
    </div>
    <div class=" paddingtb-10 topbottom green " >
        {{!$form->open('post','')!}}
        {{!$form->input($this->getWords('Nom').'<br />','nom')!}}
        <br />
        {{!$form->input($this->getWords('Titre').'<br />','titre','text',$idContenuTrad['titre'])!}}
        <br />
        {{!$form->textarea($this->getWords('Description').'<br />','description',$idContenuTrad['description'])!}}
        <br />
        {{!$form->textarea($this->getWords('Article').'<br />','article_tinymce',htmlspecialchars_decode(html_entity_decode($idContenuTrad['article_tinymce'])),'tinymce')!}}
        <br />
        {{!$form->select($this->getWords('Groupe').' ','bynum',$numGroupe,$isContenu['bynum']);}}
        <br />
        {{!$form->select($this->getWords('A voir aussi').' ','avoiraussi',$numGroupe,$isContenu['avoiraussi']);}}
        <br />
        
        <div>
            <img src="{{!$imageIcone!}}" style="height: 36px;width:36px;float: left;margin: 5px 5px 0 0;" >
            {{!$form->file($this->getWords('Icône').'<small style="font-size:11pt;font-weight:100;">(Hauteur : 30px, Largeur : 30px, PNG ou JPG)</small><br />','image')!}}
       
        </div>
        
        <div class="paddingtb green topbottom backccc" >
            &#187; SEO
        </div>
        <br />
        {{!$form->input($this->getWords('URI').' <small style="font-weight:100;">('.$this->getWords("Caractères alpha numérique seulement").')</small><br />','uri');}}
        <br />
        {{!$form->input($this->getWords('Meta Titre').'<br />','meta_titre','text',$idContenuTrad['meta_titre']);}}
        <br />
        {{!$form->input($this->getWords('Meta Description').'<br />','meta_description','text',$idContenuTrad['meta_description']);}}
        <br />
        {{!$form->input($this->getWords('Meta mots clés').'<br />','meta_keys','text',$idContenuTrad['meta_keys']);}}
        <br />
        <div class="paddingtb-10 green topbottom" >
            {{!$form->checkbox($this->getWords('Activer ce module').'','active','1',$isActiveModule);}}
        </div>
        <div class="paddingtb-10 green topbottom" >
            {{!$form->checkbox($this->getWords("Page d'accueil du site").'','is_first',1,$isHomePage);}}
        </div>
        <div class="paddingtb-10 green topbottom" >
            {{!$form->checkbox($this->getWords('Adresse email').'','notification_mail','1',$isActiveNotification);}}
        </div>
        
    </div>
    <div class=" padding center" >
        {{!$form->submit($this->getWords('Sauvegarder'))!}}
        <a class="annuler" href="./?r=gestion">{{!$this->getWords('annuler')!}}</a>
    </div>
        {{!$form->close();}} 
</div>
<script >
$("#dupliquer_module_nom").keyup(function(){

    var str = $(this).val();
    str = str.replace(/^\s+|\s+$/g, ''); // trim
    str = str.toLowerCase();
    
    // remove accents, swap ñ for n, etc
    var from = "ãàáäâẽèéëêìíïîõòóöôùúüûñç·/_,:;";
    var to   = "aaaaaeeeeeiiiiooooouuuunc      ";
    for (var i=0, l=from.length ; i<l ; i++) {
      str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
    }
    
    str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
      .replace(/\s+/g, '') // collapse whitespace and replace by -
      .replace(/-+/g, ''); // collapse dashes
      
    $("#dupliquer_module_uri").val(str);        
});
$("#dupliquer_module_titre").keyup(function(){

    var str = $(this).val();
    $("#dupliquer_module_meta_titre").val(str);
    
});
$("#dupliquer_module_description").keyup(function(){

    var str = $(this).val();
    $("#dupliquer_module_meta_description").val(str);
    
});
</script>