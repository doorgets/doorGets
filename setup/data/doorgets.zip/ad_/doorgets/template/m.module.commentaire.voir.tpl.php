<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?><div class="content">
    
    <div class=" topbottom " style="">
    
        <div  style="border:0px;text-align:right;padding:4px;font-size:12pt;">
            <a style="float:left;" href="./?r=comment&filter={{!$isCommentaire['uri_module']!}}">
                <img src="{{!THM.'ad_/img/retour.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
                {{!$this->getWords('retour')!}}
            </a>
            <a href="./?r=comment&filter={{!$isCommentaire['uri_module']!}}&action=supprimer&id={{!$isCommentaire['id']!}}">
                <img src="{{!THM.'ad_/img/supprimer.png'!}}" style="height: 20px;width:20px;vertical-align: middle;" >
                {{!$this->getWords('Supprimer')!}}
            </a>
            {{!$isDeleted;}}
        </div>
    </div>
    <div class=" topbottom padding texte " style="margin-left:0px;font-size:13pt;color:#603CA8;margin-top:10px;{{!$colorBack!}}">
        <img src="{{!$ImageStatut!}}" style="height: 25px;width:25px;vertical-align: middle;" >
        <b>{{!ucwords($isCommentaire['nom'])!}}</b>, {{!$isCommentaire['email']!}},  {{!$this->getWords('le')!}} {{!date('d/m/Y H:i',$isCommentaire['date_creation'])!}}
    </div>
    <div style="width:98%;margin:0 auto;border:solid 1px #ccc;padding:5px;margin-top:-10px;border-radius:0 0 5px 5px;" >
        
        <div class=" padding ">
            {{!$isCommentaire['comment'];}}
        </div>
    </div>
</div>
