<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
<div id="menu_top_admin" >
    
    {{/($this->rubrique as $k=>$v ):}}
    
        <a href="?r={{!$k!}}" {{?( $this->rub === $k  ):}}{{! ' class="top-bt-ok" ' !}}{?} {{?( ( $this->rub === 'newsletter' || $this->rub === 'fichier' ) && $k === 'gestion'  ):}}{{! ' class="top-bt-ok" ' !}}{?} >
            {{?($k === 'gestion'):}}<img src="{{!THM.'ad_/img/ico_module.png'!}}" style="width: 20px;height: 20px;vertical-align: middle;margin-right: 5px;">{?}
            {{?($k === 'rubrique'):}}<img src="{{!THM.'ad_/img/list-rubrique.png'!}}" style="width: 20px;height: 20px;vertical-align: middle;margin-right: 5px;">{?}
            {{?($k === 'comment'):}}<img src="{{!THM.'ad_/img/comment_blog.png'!}}" style="width: 20px;height: 20px;vertical-align: middle;margin-right: 5px;">{?}
            {{?($k === 'contactezmoi'):}}<img src="{{!THM.'ad_/img/contact.png'!}}" style="width: 20px;height: 20px;vertical-align: middle;margin-right: 5px;">{?}
            {{?($k === 'config'):}}<img src="{{!THM.'ad_/img/icone-configuration.png'!}}" style="width: 20px;height: 20px;vertical-align: middle;margin-right: 5px;">{?}
            {{!$v!}}
        </a>
        
    {/}
    
    <span style="float:right;">
       <a style="background: none;border: none;margin: 0;padding: 0 5px;"  href="?d" title="{{!$this->getWords('Se deconnecter')!}}" ><img src="{{!THM.'ad_/img/logout.png'!}}" style="width: 30px;height: 30px;vertical-align: middle;">{{!$this->getWords('Se deconnecter')!}}</a>
    </span>
    <span style="float:right;">
       <a style="background: none;border: none;margin: 0;padding: 0 5px;"  target="self"  href="{{!BASE!}}" title="{{!$this->getWords('Site Web')!}}" ><img src="{{!THM.'ad_/img/go-siteweb.png'!}}" style="width: 30px;height: 30px;vertical-align: middle;">{{!$this->getWords('Site Web')!}}</a>
    </span>

</div>