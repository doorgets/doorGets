<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
<div class=" topbottom" style="padding-top:10px;border-top:0;">

    <a href="./?r=fichier&groupe=all" class="upload-m-all {{?($outGroupe === 'all'):}}{{! ' upload-active ' !}}{?} ">
        {{!$this->getWords('Tous les fichiers')!}}
    </a>
    
    {{/($this->typeImage as $k=>$v):}}
    
        <a href="./?r=fichier&groupe={{!$k!}}" class="upload-m {{?($outGroupe === $k):}}{{! ' upload-active ' !}}{?} ">
            {{!$v!}} {{!$this->typeExtension[$k]!}}
        </a>
        
    {/}

</div>

<div class="content">
    <div class=" topbottom " style="padding:3px 0;">
        <span style="float:left;"><a href="./?r=fichier">{{!$this->getWords('Fichier')!}}</a> &#187; {{!ucwords($isFile['nom'])!}}</span>
        <div  style="border:0px;text-align:right;padding-top:2px;font-size:11pt;">
            <a href="./?r=fichier&action=modifier&id={{!$isFile['id']!}}"><img src="{{!THM.'ad_/img/modifier.png'!}}" style="height: 15px;width:15px;vertical-align: middle;" > {{!$this->getWords('Modifier')!}}</a> 
            <a href="./?r=fichier&action=supprimer&id={{!$isFile['id']!}}"><img src="{{!THM.'ad_/img/supprimer.png'!}}" style="height: 15px;width:15px;vertical-align: middle;" > {{!$this->getWords('Supprimer')!}}</a>
        </div>
    </div>
    <div class=" topbottom backccc padding">
    {{!$this->typeImage[$isFile['type']]!}}
    <input type="text" value="{{!$urlFile!}}" style="width:90%;font-size:10pt;margin:0;" >
    </div>


{{?( $isFile['type'] === 'image/png' || $isFile['type'] === 'image/jpeg' || $isFile['type'] === 'image/gif' ):}}
    <div class=" texte center  padding">
        <img src="{{!$urlFile!}}" >
    </div>
{?}
</div>