<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?><div id="configuration_menu">
    
    <a  class="{{?($this->name === 'siteweb'):}}{{! ' active ' !}}{?}" href="./?r=config&siteweb">
        <img src="{{!THM.'ad_/img/home.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
        {{!$this->getWords("Site web")!}}
    </a>
    <br /><br />
    <a  class="{{?($this->name === 'langue'):}}{{! ' active ' !}}{?}" href="./?r=config&langue">
        <img src="{{!THM.'ad_/img/icone-langue.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
        {{!$this->getWords("Langue")!}}
    </a><br /><br />
    <a  class="{{?($this->name === 'media'):}}{{! ' active ' !}}{?}" href="./?r=config&media">
        <img src="{{!THM.'ad_/img/icone-website.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
        {{!$this->getWords("Logo")!}} & {{!$this->getWords("Icône")!}}
    </a>
    <br /><br />
    <a  class="{{?($this->name === 'modules'):}}{{! ' active ' !}}{?}" href="./?r=config&modules">
        <img src="{{!THM.'ad_/img/icone-module.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
        {{!$this->getWords("Modules interne")!}}
    </a>
    
    <br /><br />
    <a  class="{{?($this->name === 'adresse'):}}{{! ' active ' !}}{?}" href="./?r=config&adresse">
        <img src="{{!THM.'ad_/img/icone-contact.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
        {{!$this->getWords("Adresse")!}} & {{!$this->getWords("Contact")!}}
    </a>
    <br /><br />
    <a  class="{{?($this->name === 'network'):}}{{! ' active ' !}}{?}" href="./?r=config&network">
        <img src="{{!THM.'ad_/img/icone-network.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
        {{!$this->getWords("Réseaux Sociaux")!}}
    </a>
    <br /><br />
    <a  class="{{?($this->name === 'analytics'):}}{{! ' active ' !}}{?}" href="./?r=config&analytics">
        <img src="{{!THM.'ad_/img/icone-stats.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
        {{!$this->getWords("Google Analytics")!}}
    </a>
    <br /><br />
    <a  class="{{?($this->name === 'sitemap'):}}{{! ' active ' !}}{?}" href="./?r=config&sitemap">
        <img src="{{!THM.'ad_/img/icone-sitemap.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
        {{!$this->getWords("Plan du site")!}}
    </a>
    <br /><br />
    <a  class="{{?($this->name === 'mentions'):}}{{! ' active ' !}}{?}" href="./?r=config&mentions">
        <img src="{{!THM.'ad_/img/icone-mentions.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
        {{!$this->getWords("Mentions légales")!}}
    </a>
    <br /><br />
    <a  class="{{?($this->name === 'cgu'):}}{{! ' active ' !}}{?}" href="./?r=config&cgu">
        <img src="{{!THM.'ad_/img/icone-terms.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
        {{!$this->getWords("Conditions d'utilisations")!}}
    </a>
    <br /><br />
    <a  class="{{?($this->name === 'error'):}}{{! ' active ' !}}{?}" href="./?r=config&error">
        <img src="{{!THM.'ad_/img/icone-404.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
        {{!$this->getWords("Page introuvable")!}}
    </a>
    <br /><br />
    <a  class="{{?($this->name === 'pwd'):}}{{! ' active ' !}}{?}" href="./?r=config&pwd">
        <img src="{{!THM.'ad_/img/icone-pwd.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
        {{!$this->getWords("Mot de passe")!}}
    </a>
    <br /><br />                
</div>