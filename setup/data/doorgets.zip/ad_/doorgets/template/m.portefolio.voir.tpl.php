<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
<div class="content">
    <div class=" topbottom " style="padding:10px 0px;font-size:13pt;border-top:0px;" >
        <span style="float:left;"><a href="./?m={{!$this->uri!}}">{{!$this->getWords('Catégorie')!}}</a> &#187;
         <a href="./?m={{!$this->uri!}}&categorie={{!$isContenu['categorie']!}}">{{!$this->categorieSimple[$isContenu['categorie']]!}}</a>
         &#187;
        {{!ucwords($idContenuTrad['titre'])!}}</span>
        <div  style="border:0px;text-align:right;padding-top:4px;font-size:11pt;">
            <a href="./?m={{!$this->uri!}}&action=modifier&id={{!$isContenu['id']!}}"><img src="{{!THM.'ad_/img/modifier.png'!}}" style="height: 15px;width:15px;vertical-align: middle;" > {{!$this->getWords('Modifier')!}}</a>
            | <a href="./?m={{!$this->uri!}}&action=supprimer&id={{!$isContenu['id']!}}"><img src="{{!THM.'ad_/img/supprimer.png'!}}" style="height: 15px;width:15px;vertical-align: middle;" > {{!$this->getWords('Supprimer')!}}</a>
        </div>
    </div>
    <div style="padding:5px 0;">
        {{!$this->genLangueMenu();}}
    </div>
    <div class=" topbottom padding " style="margin-left:-8px;font-size:14pt;color:#603CA8;">
        <b>{{!$idContenuTrad['titre']!}}</b>
    </div>
    <div class="listing_page padding topbottom" style="width:98%;border-top:0px;font-size:10pt;color:#999;" >
            <img src="{{!$fileActive!}}" style="width:20px;height:20px;vertical-align:middle;margin-right:10px;"  >
            <span style="margin-left:-6px;">{{!ucfirst(strftime("%A %d %B %Y",$idContenuTrad['date_creation']))!}}</span>
             
             <span class="right " style="border-right:dashed 1px #ccc;border-left:dashed 1px #ccc;margin-right:10px;padding:5px 10px;margin-top:-5px">
             <a href="./?m={{!$this->uri!}}&categorie={{!$isContenu['categorie']!}}">{{!$this->categorieSimple[$isContenu['categorie']]!}}</a> </span>
    </div>
</div>

<div class="m-portefolio-pagination">
    {{?(!empty($urlPrev)):}} <a class="left-p" href="{{!$urlPrev!}}">Precedente</a> {?}{{?(!empty($urlNext)):}}<a class="right-p" href="{{!$urlNext!}}">Suivante</a> {?}
</div>
<div class=" topbottom  texte padding " style="background-color:#000;text-align:center;"><img src="{{!$idContenuTrad['image']!}}" style="margin:25px 0;" ></div>

<div>{{!$contentComment->countCommentaire!}} {{!$sComm!}}</div>
