<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
<div class=" topbottom" style="padding-top:10px;border-top:0;">

    <a href="./?r=fichier&groupe=all" class="upload-m-all {{?($outGroupe === 'all'):}}{{! ' upload-active ' !}}{?} ">
        {{!$this->getWords('Tous les fichiers')!}}
    </a>
    
    {{/($this->typeImage as $k=>$v):}}
    
        <a href="./?r=fichier&groupe={{!$k!}}" class="upload-m {{?($outGroupe === $k):}}{{! ' upload-active ' !}}{?} ">
            {{!$v!}} {{!$this->typeExtension[$k]!}}
        </a>
        
    {/}

</div>

{{?(!empty($cAll)):}}

    <div class=" topbottom" style="padding:5px 0;">
        
        {{!($ini+1)!}} {{!$this->getWords("à")!}} {{!$finalPer!}} {{!$this->getWords("sur")!}}
        <b>{{!$cResultsInt.' '!}}
        {{?( $cResultsInt > 1 ):}}{{!$this->getWords("Fichiers")!}}{??}{{! $this->getWords("Fichier")!}}{?}
        </b>
        <a class="right green" href="./?r=fichier&add_file">
            <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
            {{!$this->getWords("Ajouter un fichier")!}}
        </a>
    </div>
    <div class=" topbottom" style="padding-top:10px;">
    {{-($i=0;$i<$cAll;$i++):}}
        
        
        <div class="listing_page topbottom texte padding hover">
            <a class="right padding" href="./?r=fichier&action=supprimer&id={{!$all[$i]['id']!}}"><img src="{{!THM.'ad_/img/supprimer.png'!}}" style="height: 20px;width:20px;vertical-align: middle;" ></a>
            <a class="right padding" href="./?r=fichier&action=modifier&id={{!$all[$i]['id']!}}"><img src="{{!THM.'ad_/img/modifier.png'!}}" style="height: 20px;width:20px;vertical-align: middle;" ></a> 
                
            <a href="./?r=fichier&action=voir&id={{!$all[$i]["id"]!}}">
                {{!$this->typeImage[$all[$i]["type"]]!}}
                <b>{{!ucfirst($all[$i]["nom"])!}}</b>
            </a>
            
        </div>
        
        
    {-}
    </div>
    {{?(!empty($valPage)):}}
        <br /><div class=" center width-100">
        {{!$valPage!}}
        </div>
    {?}
    
{??}
    
    <div class="  topbottom  padding">
        
        <a class="green" href="./?r=fichier&add_file">
            <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
            {{!$this->getWords("Ajouter un fichier")!}}
        </a>
    </div>
    
{?}