<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
{{?(!empty($q)):}}

    <div class=" topbottom padding " style="border-top:0;padding-left:0px;" >
        
        {{!$this->getWords('chercher')!}} : <b style="color:#007D9A;">{{!$q!}}</b>
        <a href="./?m={{!$this->uri!}}" class="padding annuler" style="margin-left:5px;">{{!$this->getWords('retour à la liste compléte')!}}</a>
        
    </div>
    
{?}
<div style="padding:5px 0;">
    {{!$this->genLangueMenu()!}}
</div>
{{?($cAll !== 0):}}
    
    <div class=" topbottom padding" style="background-color:#f1f1f1;">
    {{!($ini+1)!}} {{!$this->getWords('à')!}} {{!$finalPer!}} {{!$this->getWords('sur')!}} <b>{{!$cResultsInt!}}
    {{?( $cResultsInt > 1 ):}} {{!$this->getWords('images')!}} {??} {{!$this->getWords('image')!}} {?}</b>
    {{!$this->getWords('dans')!}} <b>{{!$this->categorieSimple[$getGroupe];}}</b>
    </div>
    <div class=" topbottom"  style="padding-top:10px;text-algin:left;">
    <ul style="list-style-type: none;clear:both;display: inline-block;width:98%;">
    {{-($i=0;$i<$cAll;$i++):}}
        
        {{
            $lgGroupe = unserialize($all[$i]['groupe_traduction']); $idTraduction = $lgGroupe[$lgActuel];
            $idContenuTrad = $this->dbQS($idTraduction,$this->table.'_traduction');
        }}
        
        {{?(!empty($idContenuTrad)):}}
            
            {{
            
                $fileLogo = THM.'data/'.$this->uri.'/middle/'.$idContenuTrad['image'];
            }}
            
        
            <li style="float:left;width:260px;height:260px;border:0px;margin:5px;padding:7px;overflow:none;" >
                
                    <div class="listing_page padding  texte hover" style="width:95%;" >
                        <div class="listing_page padding green topbottom" style="width:95%;border-top:0px;" >
                            <span style="padding:0px 5px 0 0;border-right:solid 1px #999;color:#555;border-radius:3px;margin-right: 5px;">
                                {{!$all[$i]['ordre']!}}
                            </span>
                            <a href="./?m={{!$this->uri!}}&action=voir&id={{!$all[$i]['id']!}}" style="width:100%;font-size:9pt;"  >
                                {{!ucfirst($idContenuTrad['titre'])!}}
                            </a>
                        </div>
                        <div class="listing_page padding" style="width:95%;" >
                            <table style="width:98%;text-align:center;"><tr><td  valign="top" width="295px">
                            
                                    <a href="./?m={{!$this->uri!}}&action=voir&id={{!$all[$i]['id']!}}" style="width:95%;"  >
                                        <img src="{{!$fileLogo!}}" style="width:220px;height:130px;margin-right:2px;border:solid 1px #603CA8;padding:2px;background-color:#000;" >
                                    </a>
                                    
                                    
                            </td></tr></table>
                            <div class="listing_page " style="width:100%;color:#999;font-size:11pt;" >
                                <table style="width: 100%;">
                                    <tr>
                                        <td style="width: 20%;">
                                            {{?(isset($_GET['categorie'])):}}
                                    
                                                    {{?( $all[$i]['ordre'] != 1 ):}}
                                                        {{!$this->moveUp($all[$i]['id'],$all[$i]['categorie'],$all[$i]['ordre'],$cResultsInt); }}
                                                    {?}
                                                
                                            {?}
                                        </td>
                                        <td style="width: 20%;">
                                            {{?(isset($_GET['categorie'])):}}
                                    
                                                    {{?( $all[$i]['ordre'] != $cResultsInt ):}}
                                                        {{!$this->moveDown($all[$i]['id'],$all[$i]['categorie'],$all[$i]['ordre'],$cResultsInt); }}
                                                    {?}
                                                
                                            {?}
                                        </td>
                                        <td style="width: 60%;text-align: right;" >
                                            <a  href="./?m={{!$this->uri!}}&action=modifier&id={{!$all[$i]['id']!}}">
                                                <img src="{{!THM.'ad_/img/modifier.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
                                            </a>
                                            <a href="./?m={{!$this->uri!}}&action=supprimer&id={{!$all[$i]['id']!}}">
                                                <img src="{{!THM.'ad_/img/supprimer.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
                                            </a>
                                        </td>
                                    </tr>
                                </table>
                                
                                
                                    
        
                            </div>
                        </div>
                        
                    </div>   
                
            </li>
        {?}
    {-}
    </ul>
    </div>
    <br /><div class=" center width-100">
    {{!$valPage!}}
    </div>
    
{??}
    
    {{?(isset($_GET['categorie'])):}}
        
        <div class=" red topbottom backccc padding">
            {{!$this->getWords("Il n'y a actuellement aucune image pour cette catégorie.")!}}
            : <a class="annuler" href="./?m={{!$this->uri!}}&add_contenu">{{!$this->getWords('Ajouter une image')!}}</a>
        </div>
        
    {{???(!empty($q)):}}
        
        <div class=" red topbottom backccc  padding">
            {{!$this->getWords("Aucune image trouvé pour votre recherche.")!}}
        </div>
        
    {??}
        
        <div class=" red topbottom backccc padding">
            {{!$this->getWords("Il n'y a actuellement aucune image dans la base")!}}
            : <a class="annuler" href="./?m={{!$this->uri!}}&add_contenu">{{!$this->getWords('Ajouter une image')!}}</a>
        </div>
    {?}
{?}

