<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
{{?( !empty($this->categorie) ):}}
    
    <div class="  ">
        <div class=" paddingtb backccc  " >
            <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
            {{!$this->getWords('Ajouter une image');}}
        </div>
        <div class=" paddingtb-10 topbottom green " >
            {{!$form->open('post','');}}
            {{!$form->select($this->getWords('Catégorie').' : ','categorie',$this->categorie);}}
            <br />
            {{!$form->file($this->getWords('Image').'<small style="font-size:11pt;font-weight:100;">(png, jpg, jpeg)</small><br />','image');}}
            <br /><br />
            {{!$form->input($this->getWords('Titre').'<br />','titre');}}
            <br />
            {{!$form->textarea($this->getWords('Description').'<br />','description');}}
            <br /><br />
            <div class="paddingtb green topbottom backccc" >
                &#187; SEO
            </div>
            <br />
            {{!$form->input($this->getWords('URI').' <small style="font-weight:100;">('.$this->getWords("Caractères alpha numérique seulement").')</small><br />','uri');}}
            <br /><br />
            {{!$form->input($this->getWords('Meta Titre').'<br />','meta_titre');}}
            <br />
            {{!$form->input($this->getWords('Meta Description').'<br />','meta_description');}}
            <br />
            {{!$form->input($this->getWords('Meta mots clés').'<br />','meta_keys');}}
            <br /><br />
            <div class="paddingtb green topbottom backccc" >
                &#187; {{!$this->getWords('Commentaires')!}}
            </div>
            <table class="paddingtb-10 " >
                <tr >
                    <td valign="top" >
                        {{!$form->checkbox($this->getWords('Autoriser les commentaires'),'comments','1','checked')!}}
                    </td>
                    <td>
                        {{!$form->checkbox($this->getWords('Addresse email').' ','mailsender','1','')!}}
                        {{!$form->input('','sendto','text',$this->configInfo['email'])!}}
                    </td>
                </tr>
                <tr >
                    <td valign="top" >{{!$form->checkbox($this->getWords('Autoriser les commentaires').' Disqus ','disqus','1','')!}}</td>
                    <td>{{!$form->input('ID Disqus','id_disqus','text',$this->configInfo['id_disqus'])!}}</td>
                </tr>
                <tr >
                    <td valign="middle" >{{!$form->checkbox($this->getWords('Autoriser les commentaires').' Facebook ','facebook','1','')!}}</td>
                    <td></td>
                </tr>
            </table>
            <div class="paddingtb-10 green topbottom" >
                {{!$form->checkbox($this->getWords('Autoriser le partage').' ShareThis','partage','1','checked')!}}
            </div>
            <div class="paddingtb-10 green topbottom" >
                {{!$form->checkbox($this->getWords('Activer'),'active','1','checked')!}}
            </div>
        </div>
        <div class=" padding center" >
            {{!$form->submit($this->getWords('Sauvegarder'));}}
            <a class="annuler" href="./?m={{!$this->uri!}}">{{!$this->getWords('annuler')!}}</a>
        </div>
            {{!$form->close();}} 
    </div>
    
    <script type="text/javascript">

    $("#ajouter_contenu_titre").keyup(function(){
    
        var str = $(this).val();
        str = str.replace(/^\s+|\s+$/g, ''); // trim
        str = str.toLowerCase();
      
        // remove accents, swap ñ for n, etc
        var from = "ãàáäâẽèéëêìíïîõòóöôùúüûñç·/_,:;";
        var to   = "aaaaaeeeeeiiiiooooouuuunc------";
        for (var i=0, l=from.length ; i<l ; i++) {
          str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
        }
      
        str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
          .replace(/\s+/g, '-') // collapse whitespace and replace by -
          .replace(/-+/g, '-'); // collapse dashes
          
        $("#ajouter_contenu_uri").val(str);        
    });
    $("#ajouter_contenu_titre").keyup(function(){
    
        var str = $(this).val();
        $("#ajouter_contenu_meta_titre").val(str);
        
    });
    $("#ajouter_contenu_description").keyup(function(){
    
        var str = $(this).val();
        var lendesc =  str.length;
        if(lendesc >= 250){
            str = str.substr(0,250);
        }
        $("#ajouter_contenu_meta_description").val(str);
        
    });
    </script>
    
{??}
    
    <div class="  ">
        <div class=" paddingtb backccc  " >
            <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
            {{!$this->getWords('Ajouter une image');}}
        </div>
        <div class=" paddingtb-10 topbottom green " >
            {{!$this->getWords('Vous devez commencez par ajouter une catégorie')!}}
        </div>
        <div class=" padding center" >
            <a class="green" href="./?m={{!$this->uri!}}cat&add_categorie">
                <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
                {{!$this->getWords('Ajouter une catégorie')!}}
            </a>
        </div>
    </div>
    
{?}
