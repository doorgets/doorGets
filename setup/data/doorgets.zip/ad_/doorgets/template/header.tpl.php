<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?><!DOCTYPE html>
<html>
    <head>
        <title>{{!$this->title!}} - doorGets.com</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta http-equiv="Content-Style-Type" content="text/css" />
        <meta http-equiv="Content-Language" content="fr" />
		<META NAME="robots" CONTENT="noindex,nofollow,noarchive">
        <script  src="{{!$uri!}}/js/jquery-1.8.0.min.js" type="text/javascript"></script>
        <script src="{{!$uri!}}/js/jquery-ui-1.8.23.custom.min.js" type="text/javascript"></script>
        <link href="{{!$uri!}}/css/doorgets_admin.css" rel="stylesheet" type="text/css" />
        <!-- Load TinyMCE -->
	<script type="text/javascript" src="{{!$uri!}}/js/tiny_mce/jquery.tinymce.js"></script>
	<script type="text/javascript">
		$().ready(function() {
			$('textarea.tinymce').tinymce({
				// Location of TinyMCE script
				script_url : '{{!$uri!}}/js/tiny_mce/tiny_mce.js',
				convert_urls: false,
				relative_urls: false,
				// General options
				theme : "advanced",
				plugins : "autolink,lists,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,advlist",
				valid_elements : '*[*]',
				
				// Theme options
				theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect",
				theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
				theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
				theme_advanced_buttons4 : "",
				theme_advanced_toolbar_location : "top",
				theme_advanced_toolbar_align : "left",
				theme_advanced_statusbar_location : "bottom",
				theme_advanced_resizing : true,
	
				// Example content CSS (should be your site CSS)
				content_css : "{{!$uri!}}/css/mm.css"
	
			});
			$('#flash').slideDown('slow');
			setTimeout(function() {
			    $('#flash').slideUp('slow');
			}, 5000);
			
			$('#closeFlash').click(function(){
			
			    $('#flash').slideUp('slow');
			});
			
			
		});
		
            
		window.onload=Init;
		function Init()
		{
		    
		    var myFile = document.getElementById("uploader_fichier");
		    if(myFile != null){
			//binds to onchange event of the input field
			myFile.addEventListener('change', function() {
			    
			    if( (this.files[0].size) > {{!$sMax!}} ){
				myFile.value = "";
				alert("2M  max");
			    }
			    
			});			
		    }

		}
        </script>
    </head>
    <body>