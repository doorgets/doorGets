<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
{{?( !isset($_GET['add_contenu']) ):}} 
    {{?( !isset($_GET['action']) || ( isset($_GET['action']) && $_GET['action']  === 'voir' ) ):}}
    <div  style="text-align: right;padding-top: 5px;" class="topbottom " >
        <form id="search" name="search" method="get" action="">
            <a class=" green" style="float: left;" href="./?m={{!$this->uri!}}&add_contenu">
                <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 26px;width:26px;vertical-align: middle;" > {{!$this->getWords('Ajouter une vidéo')!}}
            </a>
            <input type="hidden" id="m" name="m" value="{{!$this->uri!}}" >
            <input type="hidden" id="lg" name="lg" value="{{!$lgActuel!}}" >
            <input type="text" id="q" name="q" value="{{!$q!}}" class="" style="width:200px;border-radius:4px 0 0 4px ;padding:2px 3px;border-color:#007D9A;"  >
            <input type="submit"  value="{{!$this->getWords('chercher')!}}" style="border-radius:0 4px 4px 0;padding:1px 5px;" >
        </form>
    </div>
    {?}
{?}