<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?><div class="content">
    <div class="helper_view_content topbottom ">
    
        <span style="float:left;"><a href="./?m={{!$this->table!}}">{{!$this->getWords('retour à la liste des candidatures')!}}</a></span>
        <div  style="border:0px;text-align:right;padding-top:4px;font-size:11pt;">
            <a href="./?m={{!$this->table!}}&action=supprimer&id={{!$isUser['id']!}}"><img src="{{!THM.'ad_/img/supprimer.png'!}}" style="height: 15px;width:15px;vertical-align: middle;" > {{!$this->getWords('Supprimer')!}}</a>
        </div>
        
    </div>
    <div class="helper_view_content topbottom backccc ">
        <img src="{{!$file!}}" style="width:36px;height:36px;margin:3px 0;vertical-align:middle; " >
        <b>{{!ucwords($isUser['nom'])!}}</b>,
        {{!$isUser['email']!}}
        , <small>
            {{!$isUser['ethnie']!}}
            , {{!$this->getWords('née le')!}} {{!$isUser['date_naissance']!}}
        </small>
    </div>
    <div class="helper_view_content  ">
        
        <label>{{!$this->getWords("Qui c'est")!}} ?</label>
        <div class="texte padding" style="text-align:justify;color:#555;">{{!$isUser['description']!}}</div>
        
        <label>{{!$this->getWords('Photos')!}}</label>
        <div class="texte padding" style="text-align:justify;color:#555;">
            {{?(!empty($isUser['photo_visage'])):}}<img src="{{!THM!}}data/{{!$this->table!}}/{{!$isUser['photo_visage']!}}" style="width:100%;" ><br />{?}
            {{?(!empty($isUser['photo_face'])):}}<img src="{{!THM!}}data/{{!$this->table!}}/{{!$isUser['photo_face']!}}" style="width:100%;" ><br />{?}
            {{?(!empty($isUser['photo_profil'])):}}<img src="{{!THM!}}data/{{!$this->table!}}/{{!$isUser['photo_profil']!}}" style="width:100%;" ><br />{?}
            {{?(!empty($isUser['photo_autre'])):}}<img src="{{!THM!}}data/{{!$this->table!}}/{{!$isUser['photo_autre']!}}" style="width:100%;" ><br />{?}
        </div>
        
    </div>
</div>
