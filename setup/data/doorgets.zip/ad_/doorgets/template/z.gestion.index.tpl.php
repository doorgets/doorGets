<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
<div style="padding:5px 0;">
    {{!$this->genLangueMenu()!}}
</div>
{{?(!empty($cAll)):}}
{{ $isHomePageIn = ''; }}
    <div class=" topbottom" style="padding-top:10px;padding-bottom:10px;">
    
    <table border="0" style="width:100%;">
        <tr style="text-align:center;">
            <td style="width: 50px; border-bottom:dashed #ccc 1px;">
                <a class="green" href="./?r=modules&add_module">
                    <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" > 
                </a>
            </td>
            <td style="width:55%;border-bottom:dashed #ccc 1px;text-align:left;">
                <a class="green" href="./?r=modules&add_module">
                    {{!$this->getWords('Générer un nouveau module')!}}
                </a>
            </td>
            <td style="width:15%;border-bottom:dashed #ccc 1px;">{{!$this->getWords('Statut')!}}</td>
            <td style="width:15%;border-bottom:dashed #ccc 1px;">{{!$this->getWords('Rubrique')!}}</td>
            <td style="width:15%;border-bottom:dashed #ccc 1px;">{{!$this->getWords('Catégorie')!}}</td>
            <td style="width:15%;border-bottom:dashed #ccc 1px;">{{!$this->getWords('Commentaire')!}}</td>
            <td style="width:15%;border-bottom:dashed #ccc 1px;">{{!$this->getWords('Contenu')!}}</td>
            <td style="width:15%;border-bottom:dashed #ccc 1px;">&nbsp;</td>
            <td style="width:15%;border-bottom:dashed #ccc 1px;">&nbsp;</td>
            <td style="width:15%;border-bottom:dashed #ccc 1px;">&nbsp;</td>
        </tr>
    {{-($i=0;$i<$cAll;$i++):}}
        
        {{
            $lgGroupe = unserialize($all[$i]['groupe_traduction']); $idTraduction = $lgGroupe[$lgActuel];
            $idContenuTrad = $this->dbQS($idTraduction,'_modules_traduction');
            
            $imageIcone = THM.'data/_gestion/'.$all[$i]['image'];
            
            if(!is_file($imageIcone)){
                $imageIcone = THM.'ad_/img/ico_module.png';
            }
            
            $cResultsComInt = '';
            $cResultsContentsInt = '';
            $cResultsCatInt = '';
            $cResultsRub = '-';
            $idRub = 0;
            if( $all[$i]['type'] !== 'page'  && $all[$i]['type'] !== 'contact'  && $all[$i]['type'] !== 'link' && $all[$i]['type'] !== 'candidaturemodels' ){
                
                $iComments = $this->dbQ("SELECT COUNT(*) as counter FROM _comments WHERE uri_module = '".$all[$i]['uri']."' ");
                $cResultsComInt = (int)$iComments[0]['counter'];
                
                $iContents = $this->dbQ("SELECT COUNT(*) as counters FROM _m_".$all[$i]['uri']."  ");
                $cResultsContentsInt = (int)$iContents[0]['counters'];
                
                $iCat = $this->dbQ("SELECT COUNT(*) as counters FROM _categories WHERE uri_module = '".$all[$i]['uri']."' ");
                $cResultsCatInt = (int)$iCat[0]['counters'];
                
                $aRubrique = $this->dbQS($all[$i]['id'],'_rubrique','idModule');
                if(!empty($aRubrique)){
                    $cResultsRub = $aRubrique['name'];
                    $idRub = $aRubrique['id'];
                }
                
            }
            if( $all[$i]['type'] === 'page' || $all[$i]['type'] === 'link' ){
                
                $aRubrique = $this->dbQS($all[$i]['id'],'_rubrique','idModule');
                if(!empty($aRubrique)){
                    $cResultsRub = $aRubrique['name'];
                    $idRub = $aRubrique['id'];
                }
                
            }
            if( $all[$i]['type'] === 'candidaturemodels' ){
                
                $iContents = $this->dbQ("SELECT COUNT(*) as counters FROM candidature WHERE uri_module = '".$all[$i]['uri']."'  ");
                $cResultsContentsInt = (int)$iContents[0]['counters'];
                
                $aRubrique = $this->dbQS($all[$i]['id'],'_rubrique','idModule');
                if(!empty($aRubrique)){
                    $cResultsRub = $aRubrique['name'];
                    $idRub = $aRubrique['id'];
                }
                
            }
            if( $all[$i]['type'] === 'contact' ){
                
                $iContents = $this->dbQ("SELECT COUNT(*) as counters FROM contactezmoi WHERE uri_module = '".$all[$i]['uri']."'  ");
                $cResultsContentsInt = (int)$iContents[0]['counters'];
                
                $aRubrique = $this->dbQS($all[$i]['id'],'_rubrique','idModule');
                if(!empty($aRubrique)){
                    $cResultsRub = $aRubrique['name'];
                    $idRub = $aRubrique['id'];
                }
                
            }
            $isFirstr = '';
            $imgFirst = '';
            if($all[$i]['is_first']){
                $imgFirst = '<img src="'.THM.'ad_/img/home.png" style="vertical-align: middle;width: 20px;height: 20px;" >';
                $isHomePageIn = 1;
            }
            
            $ImageStatut = THM.'ad_/img/puce-orange.png';
            if($all[$i]['active'] == '1' AND $cResultsRub !== '-'){
                $ImageStatut = THM.'ad_/img/puce-verte.png';
            }elseif($all[$i]['active'] == '0'){
                $ImageStatut = THM.'ad_/img/puce-rouge.png';
            }
        }}

        
        {{?(!empty($idContenuTrad)):}}
            
            <tr class=" padding hover " >
                <td style="width: 50px; text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                    <a href="./?m={{!$all[$i]['uri']!}}" ><img src="{{!$imageIcone!}}" style="height: 36px;width:36px;" ></a>
                </td>
                <td style="width:87%;border-bottom:dashed #ccc 1px;text-align:left;padding:10px 5px;" >
                    
                    <a href="./?m={{!$all[$i]['uri']!}}" style="font-size:9pt;"  >
                    <b>{{!ucfirst($all[$i]['uri'])!}}</b> - [<em>{{!$all[$i]['type']!}}</em>]
                    <br />
                    <small style="color: #999;">
                        {{!ucfirst($idContenuTrad['titre'])!}}
                    </small>
                </a>
                </td>
                <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                    {{!$imgFirst!}}
                    <img src="{{!$ImageStatut!}}" style="vertical-align: middle;" >
                </td>
                <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                    <a href="./?r=rubrique&action=voir&id={{!$idRub!}}">{{!$cResultsRub!}}</a>
                </td>
                <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                    <a href="./?m={{!$all[$i]['uri']!}}cat">{{!$cResultsCatInt!}}</a>
                </td>
                <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                    {{!$cResultsComInt!}}
                </td>
                <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                    <a href="./?m={{!$all[$i]['uri']!}}">{{!$cResultsContentsInt!}}</a>
                </td>
                <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                    <a href="./?r=modules&action=modifier&lg={{!$lgActuel!}}&id={{!$all[$i]['id']!}}">
                        <img src="{{!THM.'ad_/img/icone-config.png'!}}" style="height: 36px;width:36px;" >
                    </a>
                </td>
                <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                    <a href="./?r=modules&action=dupliquer&id={{!$all[$i]['id']!}}">
                        <img src="{{!THM.'ad_/img/icone-copy.png'!}}" style="height: 36px;width:36px;" >
                    </a>
                </td>
                <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                    <a href="./?r=modules&action=supprimer&lg={{!$lgActuel!}}&id={{!$all[$i]['id']!}}">
                        <img src="{{!THM.'ad_/img/icone-delete.png'!}}" style="height: 36px;width:36px;" >
                    </a>
                </td>
            </tr>
        {?}
    {-}
    
        <tr class=" padding hover " >
            <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                <a href="./?r=newsletter" ><img src="{{!THM.'ad_/img/ico_module.png'!}}" style="height: 36px;width:36px;" ></a>
            </td>
            <td style="width:87%;border-bottom:dashed #ccc 1px;text-align:left;padding:10px 5px;">
                <a href="./?r=newsletter" style="font-size:9pt;"  >
                <b>{{!$this->getWords("Newsletter")!}}</b>
                <br />
                <small style="color: #999;">
                    {{!$this->getWords("Inscription à la newsletter")!}}
                </small>
            </a>
            </td>
            <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                <img src="{{!THM.'ad_/img/puce-verte.png'!}}" style="vertical-align: middle;" >
            </td>
            <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                -
            </td>
            <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                -
            </td>
            <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                -
            </td>
            <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                <a href="./?r=newsletter">{{!$iNewsletter!}}</a>
            </td>
            <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                -
            </td>
            <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                -
            </td>
            <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                -
            </td>
        </tr>
        <tr class=" padding hover " >
            <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                <a href="./?r=fichier" ><img src="{{!THM.'ad_/img/ico_module.png'!}}" style="height: 36px;width:36px;" ></a>
            </td>
            <td style="width:87%;border-bottom:dashed #ccc 1px;text-align:left;padding:10px 5px;">
                <a href="./?r=fichier" style="font-size:9pt;"  >
                <b>{{!$this->getWords("Fichier")!}}</b>
                <br />
                <small style="color: #999;">
                    {{!$this->getWords("Importer des fichiers")!}}
                </small>
            </a>
            </td>
            <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                <img src="{{!THM.'ad_/img/puce-verte.png'!}}" style="vertical-align: middle;" >
            </td>
            <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                -
            </td>
            <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                -
            </td>
            <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                -
            </td>
            <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                <a href="./?r=fichier">{{!$iFile!}}</a>
            </td>
            <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                -
            </td>
            <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                -
            </td>
            <td style="text-align:center;border-bottom:dashed #ccc 1px;color:#777;font-size:9pt;">
                -
            </td>
        </tr>
    </table>
    </div>
    {{?(empty($isHomePageIn)):}}
    <div  class="red topbottom padding">
        <img src="{{!THM.'ad_/img/stop.png'!}}" style="height: 36px;width:36px;vertical-align: middle;" >
        {{!$this->getWords("Attention vous n'avez déclaré aucun module comme page d'acceuil")!}}
    </div>
    {?}
    <div class=" topbottom backccc paddingtb">
        <a class="green right" href="./?r=modules&add_module">
            <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" > {{!$this->getWords('Générer un nouveau module')!}}
        </a>
        
        <img src="{{!THM.'ad_/img/puce-verte.png'!}}" style="vertical-align: middle;" > {{!$this->getWords("Module active")!}},
        <img src="{{!THM.'ad_/img/puce-rouge.png'!}}" style="vertical-align: middle;" > {{!$this->getWords("Module inactive")!}},
        <img src="{{!THM.'ad_/img/puce-orange.png'!}}" style="vertical-align: middle;" > {{!$this->getWords("Module active non utilisé")!}},
        <img src="{{!THM.'ad_/img/home.png'!}}" style="vertical-align: middle;width: 20px;height: 20px;" > {{!$this->getWords("Page d'acceuil")!}}
    </div>
{??}

    <div class=" red topbottom paddingtb">
        {{!$this->getWords("Il n'y a actuellement aucun module")!}} :
        <a class="" href="./?r=modules&add_module">
            <img src="{{!THM.'ad_/img/icone-add.png'!}}" style="height: 36px;width:36px;vertical-align: middle;" > {{!$this->getWords('Générer un nouveau module')!}}
        </a>
    </div>
    
{?}