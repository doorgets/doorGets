<?php if( !defined(__DOORGETS__) ){ header('Location:../'); exit; }

/**
 *
 *   doorGets CMS V4.1 -  28 feb 2013
 *   doorGets it's free PHP Open Source CMS PHP & MySQL
 *   
 *   Copyright (C) 2012 - 2013  Mounir R'Quiba from Paris, Marrakesh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
 *   
 *   Contact Mounir R'Quiba : professeurphp@gmail.com
 *   
 *   OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)
 *
 **/

?>
{{

    $isArchive = '';
    $isDeleted = '';
    $isLu = '';
    
    
}}


<div class="content">
    <div class=" topbottom paddingtb" style="border-top:0;">
        <span >
            
            {{!$this->getWords('Par')!}} <b>{{!ucwords($isMessage['nom'])!}}</b>,
            {{!$this->getWords('le')!}} {{!date('d/m/Y  H:i',$isMessage['date_creation'])!}}
            <small><em>[{{!$isMessage['uri_module']!}}]</em></small>
        </span>
        <div  class=" right">
            
            <a href="./?r=contactezmoi&filter={{!$isMessage['uri_module']!}}&action=supprimer&id={{!$isMessage['id']!}}"><img src="{{!THM.'ad_/img/supprimer.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" > {{!$this->getWords('Supprimer')!}}</a>
            {{!$isDeleted!}}
        </div>
    </div>
    <div class="texte padding" ><label>{{!ucfirst($isMessage['sujet'])!}}</label></div>
    <div style="width:98%;margin:0 auto;border:solid 1px #ccc;padding:5px;margin-top:-10px;background-color:#f1f1f1;border-radius:0 0 5px 5px;" >
        
        <div class="  ">
            <label>{{!$this->getWords("Qui c'est ?")!}}</label>
            <div class="texte padding" style="background: #fff;">
            {{!ucwords($isMessage['nom'])!}} - Tel : {{!ucwords($isMessage['telephone'])!}} - Mail : {{!$isMessage['email']!}}
            <div style="border-top:solid 1px #ccc;padding-top:5px;color:#555;">{{!$isMessage['description']!}}</div>
            </div>
            <label>{{!$this->getWords('Message')!}}</label>
            <div class="texte padding" style="text-align:justify;color:#555;background: #fff;">{{!$isMessage['message']!}}</div>
        </div>
    </div>
</div>
<div class="padding">
    
    <a href="./?r=contactezmoi&filter={{!$isMessage['uri_module']!}}">
        <img src="{{!THM.'ad_/img/retour.png'!}}" style="height: 25px;width:25px;vertical-align: middle;" >
        {{!$this->getWords('retour')!}}
    </a>
</div>

