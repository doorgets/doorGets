<?php

/**
 *
    doorGets Tutorial V2.0
    doorGets it's free PHP Open Source CMS Final for tutorial and blog
    
    Copyright (C) 2012  Mounir R'Quiba from Paris

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class SetupFinish  extends Langue{
    
    public function form(){
        
        $lg = $_SESSION['doorgetsLangue'];
        $this->setLangue($lg);
        
        $out = '';
        
        $out .= '<div class="titre">';
        
            $out .= $this->getWords("Générer votre FCMS doorGets Tutoriel");
            
        $out .= '</div>';
        $out .= '<div class="info center">';
        
            $formGen = new Formulaire('generate');
            if(
                !empty($formGen->i) && empty($formGen->e)
            ){
                
                
                
                $fileTemp = THM.'setup/temp/host.php';
                if(is_file($fileTemp)){
                    
                    $cFile = file_get_contents($fileTemp);
                    $DBinfo = unserialize($cFile);
                    
                    $queryUpdate = '';
                    $fileTempWebsite = THM.'setup/temp/website.php';
                    if(is_file($fileTemp)){
                        
                        $cFileWS = file_get_contents($fileTempWebsite);
                        $WSinfo = unserialize($cFileWS);
                        
                        $fileTempAdm = THM.'setup/temp/admin.php';
                        if(is_file($fileTempAdm)){
                            
                            $cFileAdm = file_get_contents($fileTempAdm);
                            $cOutFileAdm = unserialize($cFileAdm);
                            
                            $WSinfo['email'] = $cOutFileAdm['email'];
                            $WSinfo['langue'] = $_SESSION['doorgetsLangue'];
                            $WSinfo['langue_front'] = $_SESSION['doorgetsLangue'];
                            
                        }
                        
                        $queryUpdate = $this->createSqlQuery($DBinfo['prefix'].'_website',$WSinfo);
                        
                    }
                    
                    // Installation de la base de données
                    $newDatabase = new installDatabase();
                    $newDatabase->install($DBinfo['hote'],$DBinfo['name'],$DBinfo['login'],$DBinfo['pwd'],$DBinfo['prefix'],$queryUpdate);
                    
                    // Décompresssion du zip
                    new UnzipFile();
                    
                    // Suppression de la session
                    $_SESSION = array();
                    
                    $this->destroy_dir('./setup');
                    
                }
                
                header("Location:".$_SERVER['REQUEST_URI'].'admin/');
                exit();
                
            }
            $out .= $formGen->open('post','','');
            
                $out .= $formGen->input('','step','hidden',6);
                $out .= $formGen->submit($this->getWords('Générer mon site maintenant'),'width:auto;padding:5px 15px;cursor:pointer;border-radius:5px;');
                
            $out .= $formGen->close();
            
            
        $out .= '</div>';
        
        $out .= '<div class="footer finish" >';
        
            $formPrev = new Formulaire('previous');
            if(
                !empty($formPrev->i) && empty($formPrev->e)
            ){
                
                $_SESSION['doorgetsStep'] = $formPrev->i['step'];
                
                header("Location:".$_SERVER['REQUEST_URI']);
                exit();
                
            }
            $out .= $formPrev->open('post','','');
                $out .= $formPrev->input('','step','hidden',6);
                $out .= $formPrev->submit($this->getWords('Précédent'));
            $out .= $formPrev->close();
            
        $out .= '</div>';
        
        
        return $out;
        
    }
    
    private function createSqlQuery($table,$data){
        
        $d = "UPDATE ".$table." SET ";
        foreach($data as $k=>$v){
            $d .= $k." = '".$v."',";
        }
        $d = substr($d,0,-1);
        $d .= " WHERE id = 1 ;";
        
        return $d;
        
    }
    
    private function destroy_dir($dir) { 
        if (!is_dir($dir) || is_link($dir)) return unlink($dir); 
        foreach (scandir($dir) as $file) { 
            if ($file == '.' || $file == '..') continue; 
            if (!$this->destroy_dir($dir . DIRECTORY_SEPARATOR . $file)) { 
                chmod($dir . DIRECTORY_SEPARATOR . $file, 0777); 
                if (!$this->destroy_dir($dir . DIRECTORY_SEPARATOR . $file)) return false; 
            }; 
        } 
        return rmdir($dir); 
    } 
    
}