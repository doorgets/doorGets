<?php

/**
 *
    doorGets Tutorial V2.0
    doorGets it's free PHP Open Source CMS Final for tutorial and blog
    
    Copyright (C) 2012  Mounir R'Quiba from Paris

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class installDatabase{
    
    
    private $prefix;
    
    public function __construct(){
        
        
        
    }
    
    public function install($host,$db,$login,$password,$prefix = 'doorgets',$other=''){
        
        $this->prefix = $prefix;
        
        $fileTemp = THM.'setup/temp/host.php';
        if(is_file($fileTemp)){
            
            $cFile = file_get_contents($fileTemp);
            $cOutFile = unserialize($cFile);
            
            $sql_host = $cOutFile['hote'];
            $sql_db = $cOutFile['name'];
            $sql_login = $cOutFile['login'];
            $sql_pwd = $cOutFile['pwd'];
            $sql_prefix = $cOutFile['prefix'];
            
        }
        
        $sql_query = <<<Q
        
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
        
DROP TABLE IF EXISTS `blog`;

CREATE TABLE IF NOT EXISTS `blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categorie` varchar(255) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  `comments` int(11) NOT NULL DEFAULT '0',
  `partage` int(11) NOT NULL DEFAULT '1',
  `groupe_traduction` text,
  `date_creation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;



DROP TABLE IF EXISTS `blog_cat`;

CREATE TABLE IF NOT EXISTS `blog_cat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupe_traduction` text,
  `ordre` int(11) DEFAULT NULL,
  `date_creation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;



DROP TABLE IF EXISTS `blog_cat_traduction`;

CREATE TABLE IF NOT EXISTS `blog_cat_traduction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cat` int(11) NOT NULL DEFAULT '0',
  `langue` varchar(10) NOT NULL DEFAULT 'fr',
  `nom` varchar(255) DEFAULT NULL,
  `titre` varchar(255) DEFAULT NULL,
  `description` text,
  `uri` varchar(255) DEFAULT NULL,
  `meta_titre` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keys` varchar(255) DEFAULT NULL,
  `date_creation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;



DROP TABLE IF EXISTS `blog_comments`;

CREATE TABLE IF NOT EXISTS `blog_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `langue` varchar(10) NOT NULL DEFAULT 'fr',
  `uri_content` varchar(255) DEFAULT NULL,
  `nom` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `comment` text,
  `lu` int(11) NOT NULL DEFAULT '0',
  `archive` int(11) NOT NULL DEFAULT '0',
  `date_creation` int(11) DEFAULT NULL,
  `validation` int(11) DEFAULT '0',
  `date_validation` int(11) DEFAULT '0',
  `date_archive` int(11) NOT NULL DEFAULT '0',
  `adress_ip` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;



DROP TABLE IF EXISTS `blog_traduction`;

CREATE TABLE IF NOT EXISTS `blog_traduction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_content` int(11) NOT NULL DEFAULT '0',
  `langue` varchar(10) NOT NULL DEFAULT 'fr',
  `categorie` varchar(255) DEFAULT NULL,
  `titre` varchar(255) DEFAULT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `article_tinymce` text,
  `uri` varchar(255) DEFAULT NULL,
  `meta_titre` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keys` varchar(255) DEFAULT NULL,
  `date_creation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;



DROP TABLE IF EXISTS `contactezmoi`;

CREATE TABLE IF NOT EXISTS `contactezmoi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sujet` varchar(255) NOT NULL DEFAULT 'aucun sujet',
  `nom` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `description` text,
  `message` text,
  `telephone` varchar(255) DEFAULT NULL,
  `lu` int(11) NOT NULL DEFAULT '0',
  `archive` int(11) NOT NULL DEFAULT '0',
  `date_creation` int(11) NOT NULL DEFAULT '0',
  `date_archive` int(11) NOT NULL DEFAULT '0',
  `date_lu` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;



DROP TABLE IF EXISTS `faq`;

CREATE TABLE IF NOT EXISTS `faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ordre` int(11) DEFAULT NULL,
  `groupe_traduction` text,
  `date_creation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;



DROP TABLE IF EXISTS `faq_traduction`;

CREATE TABLE IF NOT EXISTS `faq_traduction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_content` int(11) DEFAULT NULL,
  `langue` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `question` text,
  `reponse_tinymce` text,
  `date_creation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;



DROP TABLE IF EXISTS `liens`;

CREATE TABLE IF NOT EXISTS `liens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ordre` int(11) DEFAULT NULL,
  `groupe_traduction` text,
  `date_creation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;



DROP TABLE IF EXISTS `liens_traduction`;

CREATE TABLE IF NOT EXISTS `liens_traduction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_content` int(11) DEFAULT NULL,
  `langue` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `titre` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `description` text,
  `date_creation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;




DROP TABLE IF EXISTS `newsletter`;

CREATE TABLE IF NOT EXISTS `newsletter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL DEFAULT '1',
  `nom` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `description` text,
  `date_creation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;



DROP TABLE IF EXISTS `page`;

CREATE TABLE IF NOT EXISTS `page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `langue` varchar(255) DEFAULT NULL,
  `page` varchar(255) DEFAULT NULL,
  `content` text,
  `date_modification` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;



DROP TABLE IF EXISTS `tuto`;

CREATE TABLE IF NOT EXISTS `tuto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categorie` varchar(255) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  `comments` int(11) NOT NULL DEFAULT '0',
  `partage` int(11) NOT NULL DEFAULT '1',
  `groupe_traduction` text,
  `date_creation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;



DROP TABLE IF EXISTS `tuto_cat`;

CREATE TABLE IF NOT EXISTS `tuto_cat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupe_traduction` text,
  `ordre` int(11) DEFAULT NULL,
  `date_creation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;



DROP TABLE IF EXISTS `tuto_cat_traduction`;

CREATE TABLE IF NOT EXISTS `tuto_cat_traduction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cat` int(11) NOT NULL DEFAULT '0',
  `langue` varchar(10) NOT NULL DEFAULT 'fr',
  `nom` varchar(255) DEFAULT NULL,
  `titre` varchar(255) DEFAULT NULL,
  `description` text,
  `uri` varchar(255) DEFAULT NULL,
  `meta_titre` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keys` varchar(255) DEFAULT NULL,
  `date_creation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;



DROP TABLE IF EXISTS `tuto_comments`;

CREATE TABLE IF NOT EXISTS `tuto_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uri_content` varchar(255) DEFAULT NULL,
  `nom` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `comment` text,
  `lu` int(11) NOT NULL DEFAULT '0',
  `archive` int(11) NOT NULL DEFAULT '0',
  `date_creation` int(11) DEFAULT NULL,
  `validation` int(11) DEFAULT '0',
  `date_validation` int(11) DEFAULT '0',
  `date_archive` int(11) NOT NULL DEFAULT '0',
  `adress_ip` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;



DROP TABLE IF EXISTS `tuto_traduction`;

CREATE TABLE IF NOT EXISTS `tuto_traduction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_content` int(11) NOT NULL DEFAULT '0',
  `langue` varchar(255) DEFAULT NULL,
  `categorie` varchar(255) DEFAULT NULL,
  `youtube` varchar(255) DEFAULT NULL,
  `titre` varchar(255) DEFAULT NULL,
  `description` text,
  `uri` varchar(255) DEFAULT NULL,
  `meta_titre` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keys` varchar(255) DEFAULT NULL,
  `date_creation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;



DROP TABLE IF EXISTS `uploader`;

CREATE TABLE IF NOT EXISTS `uploader` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `nom` varchar(255) DEFAULT NULL,
  `description` text,
  `fichier` varchar(255) DEFAULT NULL,
  `poid` varchar(255) DEFAULT NULL,
  `date_creation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;



DROP TABLE IF EXISTS `_website`;

CREATE TABLE IF NOT EXISTS `_website` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domaine` varchar(220) NOT NULL,
  `title` varchar(220) NOT NULL,
  `slogan` varchar(180) DEFAULT NULL,
  `copyright` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `description` varchar(220) NOT NULL,
  `keywords` varchar(220) NOT NULL,
  `email` varchar(80) DEFAULT NULL,
  `pays` varchar(180) DEFAULT NULL,
  `ville` varchar(180) DEFAULT NULL,
  `adresse` varchar(220) DEFAULT NULL,
  `codepostal` varchar(25) DEFAULT NULL,
  `tel_fix` varchar(30) DEFAULT NULL,
  `tel_mobil` varchar(30) DEFAULT NULL,
  `tel_fax` varchar(30) DEFAULT NULL,
  `facebook` varchar(120) DEFAULT NULL,
  `twitter` varchar(120) DEFAULT NULL,
  `youtube` varchar(120) DEFAULT NULL,
  `google` varchar(250) DEFAULT NULL,
  `analytics` varchar(50) DEFAULT NULL,
  `langue` varchar(255) DEFAULT 'fr',
  `langue_front` varchar(255) DEFAULT 'fr',
  `langue_groupe` TEXT ,
  `horaire` varchar(255) DEFAULT '315',
  `mentions` int(11) DEFAULT '1',
  `cgu` int(11) DEFAULT '1',
  `m_blog` int(1) NOT NULL DEFAULT '1',
  `m_tuto` int(1) NOT NULL DEFAULT '1',
  `m_faq` int(1) NOT NULL DEFAULT '1',
  `m_liens` int(1) NOT NULL DEFAULT '1',
  `theme` varchar(255) NOT NULL DEFAULT 'doorgets-light',
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;




DROP TABLE IF EXISTS `_website_traduction`;

CREATE TABLE IF NOT EXISTS `_website_traduction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `langue` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slogan` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `copyright` varchar(255) DEFAULT NULL,
  `year` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `date_modification` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

INSERT INTO `_website` ( `title`,`langue_groupe` ) VALUES (  'Professeur-php.com','a:0:{}' );

$other

Q;
    
    
        
        $dsn_connexion = "mysql:host=$host;dbname=$db";
        
        $pdo = new PDO($dsn_connexion,$login,$password);
        $pdo-> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        $pdo->beginTransaction();
        $pdo->query($sql_query);
        $pdo->commit();
        
        return $sql_query;
    
    }
    
    
}