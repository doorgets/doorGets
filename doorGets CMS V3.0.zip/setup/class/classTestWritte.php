<?php

/**
 *
    doorGets Tutorial V2.0
    doorGets it's free PHP Open Source CMS Final for tutorial and blog
    
    Copyright (C) 2012  Mounir R'Quiba from Paris

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
     any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Website exemple : http://www.professeur-php.com
    Website info : http://www.doorgets.com
    
    Contact Mounir R'Quiba : professeurphp@gmail.com
    
    OPEN MIND IS GOOD, OPEN SOURCE IS BETTER ;)

**/

class TestWritte extends Langue{
    
    public $val =  0;
    
    
    public function __construct(){
        
        $lg = $_SESSION['doorgetsLangue'];
        $this->setLangue($lg);
        
    }
    
    public function test(){
        
        try{
            
            $file = dirname('index.php');
            if(@is_writable($file)){
                $this->val = 1;
            }
            
        }catch(Exception $e){  }
        
    }
    
    public function form(){
        
        $this->test();
        
        $out = '';
        
        $form = new Formulaire('written');
        
        if(
           !empty($form->i) && empty($form->e)
        ){
            
            $_SESSION['doorgetsStep'] = $form->i['step'];
            
            header("Location:".$_SERVER['REQUEST_URI']);
            exit();
            
        }
        
        $out .= $form->open('post','','');
        
        $out .= '<div class="titre">';
        
            $out .= $this->getWords("Test de vos droits d'écriture");
            
        $out .= '</div>';
        $out .= '<div class="info">';
        
            if( !empty($this->val) ){
                
                $out .= '<img src="setup/img/valide.png" style="vertical-align:middle;margin-right:10px;" > ';
                $out .= $this->getWords("Votre dossier est bien en mode écriture.");
                
            }else{
                
                $out .= $this->getWords("Votre dossier n'a pas les droits d'écriture...");
                
            }
            
            
        $out .= '</div>';
        
        if( !empty($this->val) ){
            
            $out .= '<div class="footer right" >';
                $out .= $form->input('','step','hidden',4);
                $out .= $form->submit($this->getWords('Suivant'));
            $out .= '</div>';
            
        }
            
        
        $out .= $form->close();
        
        $out .= '<div class="previous_bt" >';
        
            $formPrev = new Formulaire('previous');
            if(
                !empty($formPrev->i) && empty($formPrev->e)
            ){
                
                $_SESSION['doorgetsStep'] = $formPrev->i['step'];
                
                header("Location:".$_SERVER['REQUEST_URI']);
                exit();
                
            }
            $out .= $formPrev->open('post','','');
                $out .= $formPrev->input('','step','hidden',2);
                $out .= $formPrev->submit($this->getWords('Précédent'));
            $out .= $formPrev->close();
            
        $out .= '</div>';
        
        return $out;
        
    }
    
}